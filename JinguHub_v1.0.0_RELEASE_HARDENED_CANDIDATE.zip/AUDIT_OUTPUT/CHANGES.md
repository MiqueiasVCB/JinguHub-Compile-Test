# Alterações sobre Repair19

Mudanças somente na única cópia de `Hub/`; produto continua v1.0.0. O nome do ZIP identifica o candidato hardened, sem criar Repairs intermediárias. Nenhum endpoint ou integração real foi removido.

| Arquivo | Mudança |
|---|---|
| `src-tauri/src/godot_versions.rs` | Componentes seguros, seletor inequívoco de SO/arquitetura, destinos estáveis e preservação de árvores existentes, limites de download/ZIP, verificações antes de probe/execução, transação de registro e quatro regressões. |
| `src-tauri/src/terminal.rs` | Execução Windows sem `cmd /C start`; teste de argumentos literais. |
| `src-tauri/src/github.rs` | Commit OAuth vinculado à geração, refresh serializado e invalidação 401 vinculada ao token; três testes sem keyring real. |
| `src-tauri/src/continuity.rs` | Invalidação 401 usa o token da requisição. |
| `src/jingu/views/PlansView.tsx` | Exclusão mútua síncrona do checkout e liberação em todos os caminhos de saída. |
| `tests/checkout_concurrency.test.mjs` | Novo teste do handler efetivo, com mocks de configuração/checkout, concorrência, erro e retry. |
| `scripts/run-frontend-domain-tests.mjs` | Inclui o novo teste no gate existente; mantém limites de cobertura. |
| `src-tauri/Cargo.lock` | rustls 0.23.41→0.23.45; h2 0.4.15→0.4.16; event-listener 5.4.1→5.4.2; aws-lc-rs 1.17.1→1.18.0; aws-lc-sys 0.42.0→0.44.0; rustls-webpki 0.103.13→0.103.14. `Cargo.toml` preservado. |
| `tests/unified_access_contract.test.mjs` | Atualiza três expectativas estáticas de auth para a assinatura com geração e a invalidação por token; mantém os testes externos pendentes. |
| `SOURCE_MANIFEST.sha256` | Regenerado após as alterações; 211 entradas. |

O inventário [final/identity.json](logs/final/identity.json) contém os hashes antes/depois de cada arquivo alterado e todos os hashes finais. Não há remoções. A ausência posterior do arquivo original impediu gerar um diff textual completo verificável; o inventário inicial foi preservado, sem reconstruir uma baseline fictícia.

As atualizações do Cargo foram resolvidas pelo próprio Cargo offline. O acesso HTTPS do Cargo falhou com `SEC_E_NO_CREDENTIALS`; o runner de auditoria consultou o índice oficial por HTTPS, atualizou os seis registros necessários no cache e conferiu o SHA-256 dos arquivos `.crate` contra o lockfile antes de usá-los. Não houve desativação de TLS ou edição manual das resoluções do lockfile. Evidência em `logs/hardening/official-*.json`, `offline-dependencies.json` e logs de update.

Os cabeçalhos de licença de dois arquivos JS apresentaram um erro de encoding durante a edição; o gate detectou, os cabeçalhos foram corrigidos e o gate passou novamente. O resultado anterior foi mantido em `logs/final-source/headers.log`; a aprovação final está em `logs/final-verified/headers.log`.

Limite deliberado: não foi feita migração ampla de GTK/Tauri para substituir `glib 0.18`, nem reescrita cosmética de módulos. Os alertas restantes e a análise de alcance estão documentados; o candidato não é aprovado para publicação.

Três testes de contrato ainda esperavam a assinatura antiga de `set_session` e logout incondicional no tratamento de 401. Foram ajustados para a nova fronteira de segurança, sem retirar verificações externas. Reexecução: 54 PASS e os mesmos 9 ENOENT da baseline; log final em `logs/final-verified/contracts.log`. A regressão comportamental Rust valida preservação de credencial nova.
