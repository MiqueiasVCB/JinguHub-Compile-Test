# Auditoria final — Jingu Hub v1.0.0 Repair19

**Veredito: NOT_READY_FOR_V1_RELEASE.** As correções locais justificam um candidato de source hardened; não justificam liberar a versão pública nos quatro alvos.

Auditoria executada em 24–25/09/2026, Windows x64, exclusivamente no `Hub/` fornecido. Os documentos de contexto e o prompt mestre foram lidos como contexto do pacote; as instruções diretas do usuário prevaleceram. Nenhum endpoint operacional foi removido, nenhuma feature foi adicionada e nenhum serviço foi publicado. GitHub OAuth, pagamentos, Cloudflare, D1 e contas reais não foram utilizados para testes. As consultas externas feitas foram de dependências/advisories e ferramentas de build. Os testes financeiros usaram mocks locais e `JINGU_PAYMENTS_BR_ENABLED=0`.

## Identidade e preservação

- SHA-256 inicial do ZIP recebido: `275ce0e0cfb7db2619863b6a80a8661576ae61f2c9ddb3a9042023eaf63a611d`.
- Preflight inicial: 238 entradas, 4.535.094 bytes descompactados, CRC/caminhos/colisões/links verificados; 218 hashes do pacote conferidos. Somente os 212 arquivos de `Hub/` foram extraídos, uma única vez.
- O manifesto original de source tinha 210 entradas; seu próprio arquivo e `src-tauri/continuity_endpoint.txt` não pertenciam a esse manifesto. Ambos foram cobertos pelo inventário independente de 212 arquivos da auditoria.
- Há uma única cópia de trabalho. Os originais não foram editados, movidos ou apagados por esta auditoria. Ao retomar a sessão, o ZIP e o prompt já não estavam no caminho informado em Downloads; a busca pelo nome do ZIP dentro de Downloads não o encontrou. A revalidação final do original e o diff textual completo contra o ZIP são **PENDING_NOT_RUN**. O usuário foi solicitado a informar o novo caminho.
- A comparação de hashes contra o inventário inicial continua disponível: 9 arquivos existentes alterados, 1 teste novo, nenhum arquivo original removido. Candidato: 213 arquivos Hub; manifesto regenerado com 211 entradas. Inventários completos em [baseline/identity.json](logs/baseline/identity.json) e [final/identity.json](logs/final/identity.json).
- O candidato contém `Hub/` e os cinco relatórios essenciais com logs. Não contém `node_modules`, `target`, caches, credenciais, binários de repro ou outra árvore de source. O build nativo fica apenas na cópia de trabalho; este ZIP é um candidato de source, não um instalador assinado.

## Achados corrigidos

Severidade abaixo é a avaliação desta auditoria sobre o impacto local, não um CVSS oficial. Correção validada por teste unitário não implica E2E de produção aprovado.

| ID | Severidade | Evidência / causa | Correção e validação |
|---|---|---|---|
| ENG-01 | Alta | Seletor original aceitou `Jingu-windows-x64-linux-arm64.zip` e `../escape-windows-x64.zip`; chave derivada de tag `../outside` escapava lexicalmente da raiz. Reprodução isolada com funções originais: 2 asserções negativas falharam. | Nome/tag/chave devem ser componentes seguros antes de I/O; seleção rejeita SO/arquitetura conflitantes, universal, fonte e símbolos. Teste `hardened_engine_names_reject_paths_devices_and_conflicting_targets` passou. |
| ENG-02 | Alta | `enclosed_name` sozinho não estabelece o contrato de nomes Windows nem rejeita todos os aliases normalizados. Caminhos com ADS, nomes de dispositivos, separadores/segmentos ambíguos exigiam restrição adicional. | Validação de cada componente ZIP/entrypoint, sem normalizar silenciosamente entradas perigosas; mantém guardas de symlink, colisão, contagem e expansão. Teste `hardened_zip_rejects_aliases_ads_and_reserved_names` passou. Não se afirma exploração E2E da baseline. |
| ENG-03 | Alta | Destino reutilizado poderia conter árvore anterior/links; o destino de job podia mudar com a configuração enquanto pausado. Registro usava transações read/modify/write separadas, permitindo perder uma instalação concorrente. | Destino é capturado no job; diretório regular e conteúdo permitido são verificados antes de baixar/extrair, preservando árvore preexistente; chaves concorrentes também comparam case. Transação do registro serializada. Testes de preservação e 8 registros concorrentes passaram. |
| PROC-01 | Alta | `cmd /C start` interpretava argumentos como linguagem de shell. Repro inofensiva demonstrou expansão de `%JINGU_AUDIT_SENTINEL%` em vez de preservação literal. Não foi executado payload malicioso. | Windows passa programa e argumentos diretamente a `Command` com nova console. Teste com `%`, `!`, aspas, `&` e Unicode passou. Visibilidade da console e acompanhamento real do processo continuam pendentes de GUI. |
| AUTH-01 | Alta | Resposta OAuth iniciada antes do logout podia persistir/restaurar sessão; refreshes simultâneos podiam competir por token rotativo. | Geração de sessão valida o commit antes de persistir; mutex serializa refresh e snapshot é obtido após o gate. Dois testes de estado/persistência simulada passaram. |
| AUTH-02 | Média | 401 de requisição antiga apagava sessão atual incondicionalmente, inclusive pelo formatador de erros e pelo Continuity. | Invalidação compara a credencial usada; formatar erro não altera sessão. Teste confirma que token antigo não apaga credencial nova, enquanto token correspondente invalida. Sem keyring real no teste. |
| PAY-01 | Média | Dois cliques enquanto a configuração aguardava dispararam duas solicitações de checkout no handler real extraído, com mocks: esperado 1, obtido 2. | Guard síncrono `useRef` adquirido antes do primeiro await e liberado em `finally`. Regressão cobre concorrência, erro e nova tentativa. Não comprova idempotência do backend. |
| DEP-01 | Média | OSV encontrou versões afetadas de rustls, h2 e event-listener no lockfile. | Atualização restrita de seis entradas do lockfile, incluindo três dependências obrigatórias de rustls. Nova consulta OSV não lista esses três pacotes; testes Rust e Clippy refeitos. Ver [SECURITY_REVIEW](SECURITY_REVIEW.md). |

Também foram reforçados: limite de bytes durante download (não apenas depois), timeout de leitura, cancelamento antes de extrair/registrar, criação exclusiva do destino de importação, validação de arquitetura antes do probe `--version` e da execução do wrapper console. Esses ajustes integram ENG-01/03; não foram contabilizados como dezenas de bugs independentes nem como provas E2E separadas.

## Matriz da Engine e do Hub

| Alvo | Política Engine observada no source | Evidência desta auditoria | Gate de release |
|---|---|---|---|
| Windows x64 | ZIP Windows x64 inequívoco, manifesto/tamanho/SHA-256/entrypoint, PE x64 antes de probe/execução | Seleção e fixtures PE/ZIP; 95 testes Rust host; frontend; build release nativo PASS | GUI, instalador, Engine real e assinatura: PENDING_NOT_RUN |
| Windows ARM64 | Sem suporte de Engine Windows ARM64 neste source; seleção e validação falham fechadas, sem fallback x64/emulação | Matriz de strings executada no host; ramo nativo ARM64 não compilado/executado | Build e runtime do Hub ARM64: PENDING_NOT_RUN; não anunciar Engine ARM64 |
| Linux x64 | ZIP Linux x64; verificador ELF64 de arquitetura x86_64 | Seleção por strings revisada/testada; ramo ELF e desktop Linux não executados | Build, runtime, keyring, terminal e pacote Linux: PENDING_NOT_RUN |
| Linux ARM64 | Sem suporte de Engine Linux ARM64 neste source; nenhum fallback x64 | Política estática e testes do seletor no host | Hub ARM64 nativo: PENDING_NOT_RUN; não anunciar Engine ARM64 |

Não é possível afirmar “nunca recebe asset incompatível” como prova universal de runtime nos quatro alvos. Há rejeição explícita no source e regressões de seleção; a validação real por alvo precisa dos ambientes correspondentes. macOS permanece no source existente, mas está fora da matriz solicitada e não foi qualificado aqui.

## Cobertura e limites materiais

Foram revisados caminhos operacionais de React/TS → IPC → Rust para downloads/importação/execução, projetos e persistência, Git/processos, OAuth/keyring, Community, Freelancers, Plans/InfinitePay, Continuity, updater, CSP/capabilities e scripts/locks de release. Regras e limites detalhados estão em [SECURITY_REVIEW](SECURITY_REVIEW.md). Inventário de arquivos não deve ser interpretado como cobertura dinâmica de todas as linhas.

**Pendências que impedem o READY:** qualificação nativa/GUI dos alvos; backend de pagamentos e quotas ausente; alertas transitivos restantes, sobretudo `glib` Linux; testes integrados dependentes de `Infrastructure/` e `Manager/` ausentes; empacotamento/assinaturas e canal público não qualificados; ZIP original indisponível para rehash final. WSL retornou `E_ACCESSDENIED`. Não foram criados stubs externos para transformar essas lacunas em PASS.

O total de 95 testes Rust, 8 testes frontend e build Windows não elimina esses gates. As alegações históricas de CI ou uso físico nos documentos do pacote não foram promovidas a evidência nova. Consulte [TEST_RESULTS](TEST_RESULTS.md) e [RELEASE_READINESS](RELEASE_READINESS.md) para os estados executados e pendentes.
