# Gate de release v1.0.0

**NOT_READY_FOR_V1_RELEASE**

O source hardened tem correções locais validadas e pode ser submetido à qualificação de release. Não é um release público aprovado nem um instalador assinado. O Repair19 original foi tratado como somente leitura.

| Gate obrigatório | Estado | Critério objetivo para fechar |
|---|---|---|
| Identidade inicial do material | PASS | Inventário e hashes iniciais preservados. |
| Integridade final do original | PENDING_NOT_RUN | Localizar o mesmo ZIP e reconferir SHA-256 `275ce0e0…a611d`; gerar diff textual se necessário. |
| Correções e regressões locais | PASS no Windows x64 | 95 testes Rust, 8 frontend; typecheck, Clippy, manifestos e validadores documentados. |
| Build Windows release | PASS; `logs/final-source/release-build.json` | Exit 0 e PE x64 identificado; separado de smoke GUI. |
| Builds/GUI Linux e ARM64 | PENDING_NOT_RUN | Executar matriz nativa em máquinas/runners apropriados, sem herdar PASS histórico. |
| Engine por alvo | PENDING_NOT_RUN para E2E | Testar release real compatível; corrupção, SHA incorreto, path traversal, ZIP Slip, arquivo grande, queda de rede, pausa/resume/cancel, mudança de destino, registro concorrente e execução. ARM64 Win/Linux deve apresentar indisponibilidade de Engine, sem fallback incompatível. |
| Supply chain Linux | OPEN | Qualificar/corrigir o caminho afetado por `glib 0.18.5`; avaliar manutenção de `proc-macro-error` e UNIC com dependências Tauri. Não suprimir alertas sem justificativa de alcance. |
| QA integrado do monorepo | PENDING_NOT_RUN | Disponibilizar Infrastructure/Manager corretos fora da baseline e executar os nove testes dependentes, sem stubs que apenas satisfaçam strings. |
| GitHub/auth/keyring | PENDING_NOT_RUN | Conta de teste isolada, logout/refresh/401/retomada e falha do armazenamento seguro; nenhuma credencial pessoal usada. |
| Pagamentos/entitlements/quotas | SERVER_SIDE_NOT_IN_SCOPE / PENDING_NOT_RUN | Auditoria do Worker/DB/webhooks/idempotência, valores raw safe-integer, autoria, replay e quotas atômicas; E2E em sandbox autorizado. |
| Empacotamento/distribuição | PENDING_NOT_RUN | Instaladores de cada alvo, assinatura/hash, canal público, instalação limpa, atualização/desinstalação preservando dados. |

O ZIP `JinguHub_v1.0.0_RELEASE_HARDENED_CANDIDATE.zip` contém source e evidências. Sua criação não altera este veredito. O recibo `logs/candidate-package.json`, externo ao próprio ZIP, registra o hash e a verificação final do arquivo.
