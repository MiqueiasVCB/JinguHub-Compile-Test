# Revisão de segurança

## Fronteiras de confiança

O renderer principal pode chamar os comandos autorizados do Hub; dados vindos de releases, Issues, perfil/cache e entradas do usuário continuam não confiáveis. Conteúdo remoto não deve receber os privilégios do webview principal. O sistema local, keyring e cadeia oficial de distribuição também são partes da confiança: um teste de strings não prova isolamento contra comprometimento do usuário/SO.

### Engine, filesystem e processos

Download público restringe a URL inicial ao repositório oficial; download TEST exige acesso ao repositório privado autorizado. O catálogo consulta manifesto com metadados de SO/CPU, tamanho, SHA-256 e entrypoint. A admissão IPC valida formato/target/URL e a extração verifica tamanho e hash. **Limite:** o comando recebe o hash/entrypoint do renderer; não refaz independentemente a consulta do manifesto nessa chamada. O hash não é uma assinatura independente e o redirect final não tem pinning separado de host. A confiança permanece no catálogo, no webview principal, em HTTPS e no canal oficial. Nenhuma verificação de release real foi feita nesta auditoria.

ENG-01/02/03 eliminam caminhos aceitos indevidamente, reforçam componente Windows e estabilizam destino. ZIP rejeita links, travessia/aliases/ADS/dispositivos, colisões case, mais de 20.000 entradas, mais de 8 GiB declarados descompactados e razões suspeitas nas entradas grandes. ZIP local não tem manifesto assinado obrigatório: é uma importação deliberada pelo usuário, validada estruturalmente e pelo cabeçalho nativo, sem afirmar autenticidade do fornecedor. A validação de arquitetura foi colocada também antes do probe `--version` e do wrapper console.

Operações ainda usam caminhos e metadados convencionais; não foram demonstradas garantias contra outro processo do mesmo usuário trocando diretórios/links entre validação e uso. Esse cenário TOCTOU, extração sob interferência externa e cancelamento exatamente no commit precisam de teste adicional. Não afirmar proteção absoluta contra filesystem hostil concorrente.

Criação de projeto usa exclusividade; exclusão exige validação e utiliza lixeira antes de remover o registro; builds externos são referências e não devem apagar o source do usuário. Escrita JSON atômica já possuía regressões. A alteração serializa as transações do registro Engine e preserva a ordem de locks ao reatar projetos. Não houve exclusão de projeto/Engine real.

PROC-01 remove interpretação de shell no caminho console Windows. Git usa argumentos estruturados e `--` nos pontos relevantes; autenticação usa mecanismo temporário askpass/env, sem gravar o token no script. Repositórios/clones continuam conteúdo ativo controlado pelo usuário: hooks, ferramentas instaladas e protocolos admitidos por Git não equivalem a um sandbox de código malicioso. O shell quoting Unix foi revisado estaticamente, mas seu runtime ficou PENDING_NOT_RUN.

### OAuth, sessão e privacidade

GitHub Device Flow e refresh são tratados no Rust. O Client ID público não é segredo e foi preservado. Keyring 4.1.5 utiliza o armazenamento nativo apropriado via suas features; disponibilidade/comportamento real em Linux depende do serviço de secrets. AUTH-01 impede persistência tardia de resposta anterior ao logout e coalesce refresh rotativo; AUTH-02 impede 401 de token antigo apagar credencial nova. Os testes injetam persistência/remoção simuladas, não acessam o cofre pessoal.

Ainda precisam de E2E: falha do keyring ao apagar/persistir, mudança de “lembrar login”, revogação real, device-flow cancelado/repetido, sessões entre processos e cache sob troca de conta. A proteção por geração não transforma um novo poll iniciado após logout em um cancelamento global de todos os device codes externos.

Scan de padrões em 121 arquivos textuais UTF-8, independentemente da extensão, no inventário de 213 arquivos não encontrou tokens GitHub, chaves privadas ou credenciais compatíveis com as regras. O log final separa `inventory_files` de `text_files_scanned`; arquivos binários/não UTF-8 foram excluídos do scan textual. O contador da primeira execução descrevia o inventário, não o total de textos efetivamente examinados. Não é um scanner semântico completo, não inclui histórico Git inexistente e não prova ausência absoluta de segredos. O scan ficou restrito ao pacote Hub; arquivos pessoais externos não foram inspecionados em busca de segredos.

Diagnósticos aplicam redação e rotação; paths de diretório/ambiente podem identificar usuário. Os logs desta auditoria incluem paths locais e são material privado de continuidade, não um pacote sanitizado para publicação aberta. Imagens remotas HTTPS podem expor IP ao host da imagem; CSP não elimina esse efeito de privacidade.

### Tauri, React e IPC

Revisados `tauri.conf.json`, capabilities e validações de URL/entrada. Capability principal restrita ao webview `main`, sem conceder capacidade remota a páginas externas. CSP restringe scripts a self e conexão do renderer ao IPC; `style-src` admite inline, imagens admitem HTTPS remoto. Não foi encontrado uso operacional de HTML remoto bruto no React nos caminhos revisados. Não houve teste de exploração de XSS/IPC em WebView2/WebKitGTK real.

Checkout é aberto em webview separado, com controles de URL, sem autoridade para conceder plano no callback. Navegação posterior HTTPS admite provedores de autenticação/3DS; esse fato requer teste do fluxo real e não autoriza tratar qualquer conteúdo HTTPS como confiável. Download no webview de pagamento é bloqueado. Não houve redução da CSP, relaxamento de capabilities ou remoção de integração para fazer teste passar.

### Community e Freelancers

Entradas remotas passam por parsing/limites e são renderizadas como texto; URLs são validadas, caches são limitados. Ownership é consultado antes das ações relevantes em Issues e escritas dependem da autorização GitHub. Isso não prova que a infraestrutura remota aplica todas as regras comerciais.

**SERVER_SIDE_NOT_IN_SCOPE:** quotas calculadas pelo cliente e contagem de Issues não impõem exclusão mútua entre clientes; projeção de membership, etiquetas, reconciliação, autoria e fechamento/arquivamento dependem de Infrastructure/Worker/repositórios ausentes. Regras de acesso ao GitHub não substituem quotas comerciais server-side. Não se removeu o endpoint de Freelancers, não se fabricou backend e não se atribuiu PASS às nove verificações sem arquivos externos.

**Risco residual de disponibilidade (médio, alcance não reproduzido por rede):** algumas respostas de Community/Continuity são materializadas com `bytes()`/`text()` antes da checagem de tamanho. O limite pós-leitura não limita o pico de memória contra um upstream hostil. O download de Engine agora limita cada chunk, mas isso não equivale a streaming bounded em todas as APIs. Próxima correção exige padronizar os readers e testes de respostas fragmentadas/oversized sem enfraquecer mensagens/contratos; permaneceu aberto, não classificado como resolvido pelo timeout.

### Planos / InfinitePay / updater

PAY-01 fecha a duplicação local de checkout. Valores e URLs do checkout possuem validações no Hub; o retorno apenas dispara atualização, não concede entitlement sozinho. Nenhuma cobrança real foi criada e nenhum dado de cartão foi coletado pela auditoria.

**SERVER_SIDE_NOT_IN_SCOPE:** o pacote não permite auditar `payment_check`, webhook, raw amount/paid_amount, replay, associação de usuário/intent, transação de créditos e idempotência de banco. O contrato esperado exige `amount` raw safe-integer igual ao intent e `paid_amount` raw safe-integer maior ou igual; callbacks são sinais, não prova de pagamento. Esse contrato veio do contexto anterior e precisa ser conferido contra o servidor atual; não foi afirmado como implementação verificada neste Hub.

Updater do Hub compara versões e abre a página oficial de release. Não é um mecanismo de instalação automática autenticada de binários; não há prova de assinatura de updater a extrair desse comportamento. Assinar/verificar instaladores e conferir a distribuição pública permanece gate de release.

## Supply chain

Locks npm/Cargo foram preservados ou alterados de modo rastreável; ações de workflow revisadas usam referências pinadas. O workflow declara matriz, mas declaração não prova execução. `npm audit` reportou zero advisories nesta consulta. OSV foi consultado para 569 pacotes registry do Cargo.lock; o relatório final ainda acusa sete pacotes.

| Grupo | Decisão / evidência |
|---|---|
| rustls 0.23.41 | Atualizado para 0.23.45 por [RUSTSEC-2026-0285](https://rustsec.org/advisories/RUSTSEC-2026-0285.html), falha de validação do nível de criptografia de mensagens TLS 1.3. Não confundir com prova de MITM ou quebra de autenticação; a avaliação oficial é média. |
| h2 0.4.15 | Atualizado para 0.4.16 por [RUSTSEC-2026-0258](https://rustsec.org/advisories/RUSTSEC-2026-0258.html), tratamento de DATA vazio com risco de consumo de recursos/panic. |
| event-listener 5.4.1 | Atualizado para 5.4.2 por [RUSTSEC-2026-0221](https://rustsec.org/advisories/RUSTSEC-2026-0221.html), soundness de StackSlot. Dependência relevante no caminho Unix de secrets. |
| glib 0.18.5 | **OPEN — médio para triagem da auditoria; advisory oficial INFO Unsound.** [RUSTSEC-2024-0429](https://rustsec.org/advisories/RUSTSEC-2024-0429.html) afeta `VariantStrIter` e está corrigido a partir de 0.20. O caminho transitivo GTK/Tauri Linux usa a família 0.18; trocar apenas o lock para outra major/minor incompatível não é correção validada. Não foi encontrado uso direto de VariantStrIter no Hub, mas alcance transitivo e runtime Linux não foram excluídos. GHSA do mesmo item é alias, não segundo bug. |
| proc-macro-error 1.0.4 | [Alerta de manutenção](https://rustsec.org/advisories/RUSTSEC-2024-0370.html), sem versão corrigida indicada. Não é exploit demonstrado. |
| Cinco pacotes UNIC 0.9 | Alertas de manutenção de unic-char-property, unic-char-range, unic-common, unic-ucd-ident e unic-ucd-version; [referência UNIC](https://rustsec.org/advisories/RUSTSEC-2025-0081.html). Substituição exige compatibilidade com os consumidores Tauri; não foi feita migração ampla. |

As três atualizações vulneráveis desapareceram da consulta final; os alertas restantes não foram escondidos por allowlist. Consultar OSV é evidência de versões/advisories conhecidos na data, não análise completa de explorabilidade nem garantia contra supply-chain malicioso ainda desconhecido. `cargo audit` não estava instalado; o relatório informa OSV, não finge uma execução dessa ferramenta.

## Decisão

Nenhum segredo real foi publicado, nenhum serviço externo foi alterado e nenhum PASS histórico foi reciclado. Persistem gates e riscos descritos acima. **NOT_READY_FOR_V1_RELEASE** até a qualificação técnica e operacional documentada em `RELEASE_READINESS.md`.
