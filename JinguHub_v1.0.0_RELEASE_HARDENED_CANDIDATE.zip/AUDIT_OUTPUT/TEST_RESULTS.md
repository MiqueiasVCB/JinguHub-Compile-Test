# Resultados dos testes

Os JSON dos runners mantêm comando, exit code, duração e log. `FAIL` significa execução com retorno de erro; `PENDING_NOT_RUN` identifica a verificação que não pôde ocorrer. Um FAIL de infraestrutura não é renomeado PASS. Não somar os totais de reexecuções como testes distintos.

| Gate | Resultado efetivo | Evidência |
|---|---|---|
| Preflight e identidade inicial | PASS; 218 hashes externos, 212 arquivos Hub; manifesto original 210 | `logs/baseline/identity.json`, `manifest.log` |
| Regressão negativa do seletor original | FAIL esperado: 1 demonstração passou e 2 asserções negativas falharam | `logs/baseline/engine-repro.log`; funções capturadas em `logs/repro/engine_baseline_repro.rs` |
| Checkout baseline | FAIL esperado: duas chamadas em concorrência onde deveria haver uma | `logs/baseline/checkout-concurrency.log` |
| Shell Windows baseline | Expansão indevida reproduzida com variável inofensiva | `logs/baseline/console-expansion.log` |
| Rust Repair19 | PASS: 87 testes | `logs/baseline/rust-tests.log` |
| Rust candidato final | PASS: 95, 0 falhas, 0 ignorados | `logs/final-source/rust-tests.log`, `rust-tests.json` |
| Clippy final, todos os targets do host, warnings negados | PASS | `logs/final-source/clippy.log`, `clippy.json` |
| Rustfmt | PASS | `logs/final-source/rustfmt.log` |
| Frontend TypeScript | PASS | `logs/final/typecheck.log` |
| Frontend domínio + checkout | PASS: 8 testes; planDomain 95,35% linhas / 80% branches / 100% funções | `logs/final-verified/frontend-domain.log` |
| Vite produção com configLoader native | PASS | `logs/final/frontend-build-native-loader.log` |
| Limite de bundle | PASS | `logs/final/bundle.log` |
| Windows x64 release nativo | PASS; exit 0, PE x64 (0x8664), 14.183.936 bytes; `logs/final-source/release-build.json` e `logs/final/identity.json` | O sucesso deste gate requer exit 0; não equivale a installer/GUI |
| Manifesto final | PASS; `logs/final-verified/manifest.log` | 211 entradas; endpoint coberto também por identity.json |
| Layout, i18n, Tauri config, Cargo.lock | PASS | `logs/final-source/{layout,i18n,tauri-config,cargo-lock}.log` |
| Licença/cabeçalhos final | PASS após corrigir encoding detectado pelo gate | `logs/final-verified/headers.log` |
| QA static agregado | FAIL bruto: arquivo Infrastructure ausente; gate integral PENDING_NOT_RUN | `logs/final-source/static.log` |
| Contratos integrados | FAIL bruto: 63 testes, 54 PASS, 9 FAIL por ENOENT de Infrastructure/Manager; os nove cenários integrados PENDING_NOT_RUN | `logs/final-verified/contracts.log` |
| npm audit | PASS na consulta: 0 advisories reportados; lock npm não alterado | `logs/baseline/npm-audit.log` |
| OSV Cargo.lock final | FAIL: 7 pacotes com alertas restantes, não sete exploits comprovados | `logs/supply-chain.json`; baseline tinha 10 pacotes |
| Segredos, scan por padrões | Nenhum match nos formatos textuais inspecionados; não é prova universal de ausência | `logs/secret-scan.json` |
| Rehash original no encerramento | PENDING_NOT_RUN; arquivo original não está no caminho fornecido | `logs/final/identity.json` |

## Reprodução

Na raiz `Hub/`, com Python 3, Node 24, Rust 1.97.1 e SDK/MSVC configurados, os comandos centrais são:

```text
python scripts/validate-source-manifest.py
python scripts/validate-project-layout.py
python scripts/validate-source-headers.py
node scripts/validate-i18n.mjs
node scripts/validate-tauri-config.mjs
node scripts/validate-cargo-lock.mjs
npm run typecheck
node scripts/run-frontend-domain-tests.mjs
node node_modules/vite/bin/vite.js build --configLoader native
node scripts/validate-bundle-size.mjs
cargo fmt --all --manifest-path src-tauri/Cargo.toml -- --check
cargo test --locked --offline --manifest-path src-tauri/Cargo.toml --lib
cargo clippy --locked --offline --manifest-path src-tauri/Cargo.toml --all-targets -- -D warnings
cargo build --locked --offline --release --manifest-path src-tauri/Cargo.toml
```

`--all-targets` no Clippy significa targets Cargo do host, não os quatro triples de SO/CPU. Os testes PE e a suite Rust rodaram em Windows x86_64. O teste de lifecycle com fixtures não invoca todo o download IPC assíncrono, nem instala uma Engine real; os testes OAuth são de estado com persistência simulada; o checkout executa o handler efetivo extraído/transpilado, sem montar uma janela React.

Os runners originais e repros mínimos estão em `logs/repro/`; apontam para o layout da cópia de trabalho e podem exigir ajuste de caminho em outro computador. Os testes novos do produto já estão nos arquivos `Hub/` do candidato.

## Limitações de execução

O install npm foi `npm ci --ignore-scripts --no-audit`; o teste offline inicial falhou por cache incompleto. O comando normal `npm run build` não passou neste sandbox: o carregador esbuild do config encontrou erro de acesso ao diretório ancestral do perfil. TypeScript e Vite com carregador nativo foram executados separadamente e passaram; o script oficial não foi alterado para ocultar a falha. Os logs de tentativas ficam em `logs/baseline/`.

O helper de ambiente MSVC não disponibilizou todas as ferramentas; os runners usaram explicitamente MSVC 14.44.35207 e SDK 10.0.26100.0 instalados. Somente `x86_64-pc-windows-msvc` está instalado como target Rust. WSL retornou `Wsl/EnumerateDistros/Service/E_ACCESSDENIED`, registrado em `logs/environment/`.

**PENDING_NOT_RUN:** testes/builds nativos Windows ARM64, Linux x64 e Linux ARM64; smoke GUI em conta isolada; Engine real download/resume/cancel/install/run/uninstall; keyring real e troca/revogação de conta; checkout InfinitePay/sandbox e fulfillment; quotas e Worker; integração Community/Freelancers autenticada; installer, assinatura e atualização pública. O startup acessa o keyring do usuário, inclusive limpeza de credencial legada: executar o EXE somente com filesystem portátil não isolaria esse estado. Por isso não foi usado como smoke “seguro” neste perfil real.

A execução intermediária de contratos (`logs/final-source/contracts.log`) teve 51 PASS / 12 FAIL: nove arquivos externos ausentes e três expectativas estáticas antigas de autenticação. Após atualizá-las, o resultado final voltou a 54 PASS / 9 FAIL externos. Não foram descartadas falhas comportamentais para obter esse resultado.
