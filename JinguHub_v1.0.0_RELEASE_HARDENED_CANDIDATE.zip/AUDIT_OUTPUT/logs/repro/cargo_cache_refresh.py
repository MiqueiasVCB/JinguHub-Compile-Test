"""Refresh selected official sparse metadata over verified HTTPS; no TLS bypass.
Cargo still resolves versions and validates downloaded crate checksums.
"""
import hashlib,json,pathlib,sys,tomllib,urllib.request
from run_checks import HUB,OUT
registry=pathlib.Path(r'C:\Users\Miquéias\.cargo\registry')
cache=registry/'index/index.crates.io-1949cf8c6b5b557f/.cache'
records=[]
for name in ['rustls','h2','event-listener','rustls-webpki','aws-lc-rs','aws-lc-sys']:
    rel=f'{name[:2]}/{name[2:4]}/{name}' if len(name)>3 else f'{len(name)}/{name}'
    url='https://index.crates.io/'+rel
    with urllib.request.urlopen(url,timeout=30) as response:
        data=response.read();etag=response.headers.get('ETag','')
    rows=[json.loads(line) for line in data.splitlines()]
    assert all(row['name']==name and len(row['cksum'])==64 for row in rows)
    existing=cache/rel
    assert existing.read_bytes()[:5]==bytes([3,2,0,0,0])
    payload=bytes([3,2,0,0,0])+('etag: '+etag).encode()+b'\0'
    for line,row in zip(data.splitlines(),rows):payload+=row['vers'].encode()+b'\0'+line+b'\0'
    existing.write_bytes(payload)
    records.append({'url':url,'body_sha256':hashlib.sha256(data).hexdigest(),'rows':len(rows)})
(OUT/'hardening/official-index-refresh.json').write_text(json.dumps(records,indent=2))
print('Refreshed verified official metadata:',len(records))
if '--download-locked' in sys.argv:
    downloaded=[]
    for package in tomllib.loads((HUB/'src-tauri/Cargo.lock').read_text())['package']:
        if package['name'] not in ['rustls','h2','event-listener','rustls-webpki','aws-lc-rs','aws-lc-sys']:continue
        file=f"{package['name']}-{package['version']}.crate"
        dest=registry/'cache/index.crates.io-1949cf8c6b5b557f'/file
        if dest.exists(): continue
        url=f"https://static.crates.io/crates/{package['name']}/{file}"
        data=urllib.request.urlopen(url,timeout=60).read()
        checksum=hashlib.sha256(data).hexdigest()
        assert checksum==package['checksum'],file
        dest.write_bytes(data)
        downloaded.append({'url':url,'sha256':checksum,'bytes':len(data)})
    (OUT/'hardening/official-crate-downloads.json').write_text(json.dumps(downloaded,indent=2))
    print('Downloaded and checksum verified:',len(downloaded))
