import fs from 'node:fs'
import vm from 'node:vm'
import ts from './Hub/node_modules/typescript/lib/typescript.js'
const source=fs.readFileSync(new URL('./Hub/src/jingu/views/PlansView.tsx',import.meta.url),'utf8')
const code=source.slice(source.indexOf('const startCheckout=async()=>{'),source.indexOf('  const previewText='))
let releaseConfig
const deferred=new Promise(resolve=>releaseConfig=resolve)
let requests=0
const ctx={ checkoutChoice:{kind:'units'}, checkoutInFlight:{current:false},
 api:{paymentConfig:()=>deferred,paymentCheckoutStart:async()=>{requests++;return {checkout_url:'https://checkout.infinitepay.io/fixture',intent_id:'fixture'}}},
 setPaymentConfig(){},publicBrlCurrencies:x=>x,paymentCurrency:'BRL',unitAmount:500,selectedAllocation:{},unitCount:1,
 effectiveTier:'bronze',setWorkingTier(){},setCheckoutBrowser(){},window:{dispatchEvent(){}},CustomEvent:class {},
 notify(){},c:{},setCheckoutChoice(){},setCreditsWorking(){},onRequireGitHubLogin(){},selectedCurrency:{provider:'infinitepay'},
}
vm.createContext(ctx)
vm.runInContext(ts.transpile(code+';globalThis.startCheckout=startCheckout;', {target:ts.ScriptTarget.ES2020}),ctx)
const first=ctx.startCheckout(),second=ctx.startCheckout()
releaseConfig({currencies:[{code:'BRL',available:true,checkout_enabled:true}]})
await Promise.all([first,second])
console.log(JSON.stringify({scenario:'two clicks while config awaits',checkout_requests:requests,expected:1}))
if(requests!==1)process.exitCode=1
