fn engine_asset_matches_target(name: &str, os: &str, arch: &str) -> bool {
    let n = name.to_ascii_lowercase();
    if !n.ends_with(".zip")
        || n.contains("symbols")
        || n.contains("source")
        || n.contains("universal")
    {
        return false;
    }
    match (os, arch) {
        ("windows", "x86_64") => {
            n.contains("windows-x86_64") || n.contains("windows-x64") || n.contains("win64")
        }
        ("linux", "x86_64") => {
            n.contains("linux-x86_64") || n.contains("linux-x64") || n.contains("linux64")
        }
        ("macos", "aarch64" | "arm64") => {
            (n.contains("macos") || n.contains("darwin"))
                && (n.contains("arm64") || n.contains("aarch64"))
                && !n.contains("x86_64")
                && !n.contains("intel")
        }
        ("macos", "x86_64") => {
            (n.contains("macos") || n.contains("darwin"))
                && (n.contains("x86_64") || n.contains("x64") || n.contains("intel"))
                && !n.contains("arm64")
                && !n.contains("aarch64")
        }
        _ => false,
    }
}
fn download_key(tag: &str, asset_name: &str) -> String {
    if asset_name.to_lowercase().contains("mono") {
        format!("{}-mono", tag)
    } else {
        tag.to_string()
    }
}
#[test]
fn rejects_conflicting_os_and_arch_markers() {
 for (name,os) in [("Jingu-windows-x64-linux-arm64.zip","windows"),
                   ("Jingu-linux-x64-windows-arm64.zip","linux"),
                   ("Jingu-darwin64.zip","windows")] {
   assert!(!engine_asset_matches_target(name,os,"x86_64"),"accepted {name}");
 }
}
#[test]
fn rejects_asset_paths() {
 assert!(!engine_asset_matches_target("../escape-windows-x64.zip","windows","x86_64"));
}
#[test]
fn demonstrates_tag_path_escape() {
 let root=std::env::current_dir().unwrap().join("Engine");
 let key=download_key("../outside","engine-windows-x64.zip");
 let candidate=root.join(key);
 assert!(candidate.components().any(|c| c==std::path::Component::ParentDir));
 println!("Unvalidated tag reaches joined path: {}",candidate.display());
}
