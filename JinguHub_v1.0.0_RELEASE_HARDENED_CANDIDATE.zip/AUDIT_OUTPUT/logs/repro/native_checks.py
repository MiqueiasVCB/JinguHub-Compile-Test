import json, os, pathlib, sys
from run_checks import run, OUT, env
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207')
sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10')
env['PATH']=str(vc/'bin/Hostx64/x64')+';'+str(sdk/'bin/10.0.26100.0/x64')+';'+env.get('PATH',env.get('Path',''))
env['LIB']=';'.join(str(x) for x in [vc/'lib/x64',sdk/'Lib/10.0.26100.0/ucrt/x64',sdk/'Lib/10.0.26100.0/um/x64'])
env['INCLUDE']=';'.join(str(x) for x in [vc/'include',sdk/'Include/10.0.26100.0/ucrt',sdk/'Include/10.0.26100.0/um',sdk/'Include/10.0.26100.0/shared'])
env.update(CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0')
phase=sys.argv[1] if len(sys.argv)>1 else 'baseline'
items=[('rust-tests',['cargo','test','--locked','--offline','--manifest-path','src-tauri/Cargo.toml','--lib'],1200)]
if len(sys.argv)>2 and sys.argv[2]=='clippy':
    items=[('clippy',['cargo','clippy','--locked','--offline','--manifest-path','src-tauri/Cargo.toml','--all-targets','--','-D','warnings'],1200)]
if len(sys.argv)>2 and sys.argv[2]=='release':
    items=[('release-build',['cargo','build','--locked','--offline','--release','--manifest-path','src-tauri/Cargo.toml'],1800)]
results=[run(x,phase) for x in items]
(OUT/phase/(items[0][0]+'.json')).write_text(json.dumps(results,indent=2))
