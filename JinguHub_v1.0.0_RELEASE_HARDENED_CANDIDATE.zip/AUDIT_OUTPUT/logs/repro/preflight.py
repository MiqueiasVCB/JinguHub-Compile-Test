import hashlib, json, pathlib, re, stat, zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ARCHIVE = pathlib.Path(r'C:\Users\Miquéias\Downloads\JINGU_HUB_V1_CODEX_GPT6_ASTRA_ALTO_FINAL_AUDIT_PACKAGE.zip')
OUT = ROOT / 'outputs/AUDIT_OUTPUT'
OUT.joinpath('logs/baseline').mkdir(parents=True, exist_ok=True)
PREFIX = 'JINGU_HUB_V1_CODEX_AUDIT_REPAIR19/'
with zipfile.ZipFile(ARCHIVE) as z:
    seen = set()
    for i in z.infolist():
        p = pathlib.PurePosixPath(i.filename)
        assert not p.is_absolute() and '\\' not in i.filename
        assert all(x not in ('..', '.') and ':' not in x and x.rstrip(' .') == x for x in p.parts)
        assert i.filename.casefold() not in seen
        seen.add(i.filename.casefold())
        assert not stat.S_ISLNK(i.external_attr >> 16) and not (i.flag_bits & 1)
        assert i.file_size < 100_000_000
    assert z.testzip() is None
    verified = 0
    for line in z.read(PREFIX+'PACKAGE_SHA256SUMS.txt').decode('utf-8-sig').splitlines():
        h, n = line.split(maxsplit=1)
        n = str(pathlib.PurePosixPath(n.lstrip('*')))
        assert hashlib.sha256(z.read(PREFIX+n)).hexdigest() == h, n
        verified += 1
    manifest = {}
    for n in z.namelist():
        if n.startswith(PREFIX+'Hub/') and not n.endswith('/'):
            data = z.read(n)
            relative = n[len(PREFIX):]
            dest = ROOT/'work'/relative
            assert not dest.exists(), dest
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            manifest[relative] = hashlib.sha256(data).hexdigest()
    report = dict(archive_sha256=hashlib.file_digest(ARCHIVE.open('rb'),'sha256').hexdigest(),
                  entries=len(z.infolist()), expanded_bytes=sum(i.file_size for i in z.infolist()),
                  package_hashes_verified=verified, source_files=len(manifest), safety='PASS', files=manifest)
    (OUT/'logs/baseline/identity.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k != 'files'}, indent=2))
