import pathlib, subprocess, json, sys
from run_checks import ROOT, HUB, OUT, run, env
vc=pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207')
sdk=pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10')
env['PATH']=str(vc/'bin/Hostx64/x64')+';'+env.get('PATH','')
env['LIB']=';'.join(str(x) for x in [vc/'lib/x64',sdk/'Lib/10.0.26100.0/ucrt/x64',sdk/'Lib/10.0.26100.0/um/x64'])
s=(HUB/'src-tauri/src/godot_versions.rs').read_text(encoding='utf-8')
def function(name):
    start=s.index('fn '+name+'(')
    # Top-level functions terminate at a non-indented closing brace.
    end=s.index('\n}',start)+2
    return s[start:end]
body='\n'.join(function(n) for n in ['engine_asset_matches_target','download_key'])
body+='''
#[test]
fn rejects_conflicting_os_and_arch_markers() {
 for (name,os) in [("Jingu-windows-x64-linux-arm64.zip","windows"),
                   ("Jingu-linux-x64-windows-arm64.zip","linux"),
                   ("Jingu-darwin64.zip","windows")] {
   assert!(!engine_asset_matches_target(name,os,"x86_64"),"accepted {name}");
 }
}
#[test]
fn rejects_asset_paths() {
 assert!(!engine_asset_matches_target("../escape-windows-x64.zip","windows","x86_64"));
}
#[test]
fn demonstrates_tag_path_escape() {
 let root=std::env::current_dir().unwrap().join("Engine");
 let key=download_key("../outside","engine-windows-x64.zip");
 let candidate=root.join(key);
 assert!(candidate.components().any(|c| c==std::path::Component::ParentDir));
 println!("Unvalidated tag reaches joined path: {}",candidate.display());
}
'''
dest=ROOT/'work/engine_baseline_repro.rs'; dest.write_text(body,encoding='utf-8')
binary=ROOT/'work/engine_baseline_repro.exe'
results=[run(('engine-repro-compile',['rustc','--edition','2021','--test',str(dest),'-o',str(binary)],120),'baseline')]
if results[0]['exit_code']==0: results.append(run(('engine-repro',[str(binary),'--nocapture'],60),'baseline'))
(OUT/'baseline/engine-repro.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
