import concurrent.futures, json, os, pathlib, subprocess, sys, time
ROOT=pathlib.Path(__file__).resolve().parents[1]
HUB=ROOT/'work/Hub'
OUT=ROOT/'outputs/AUDIT_OUTPUT/logs'
PY=sys.executable
env=os.environ.copy()
for k in list(env):
    if any(s in k.upper() for s in ('TOKEN','SECRET','PASSWORD','CREDENTIAL','API_KEY')): env.pop(k)
env.update(PYTHONIOENCODING='utf-8',JINGU_PAYMENTS_BR_ENABLED='0',CARGO_NET_OFFLINE='true',RUSTUP_OFFLINE='1')
def run(item,phase):
    name,cmd,timeout=item
    log=OUT/phase/(name+'.log'); log.parent.mkdir(parents=True,exist_ok=True)
    start=time.time()
    with log.open('w',encoding='utf-8') as f:
        f.write('COMMAND '+subprocess.list2cmdline(cmd)+'\n'); f.flush()
        try:
            p=subprocess.run(cmd,cwd=HUB,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
            rc=p.returncode
        except (OSError,subprocess.TimeoutExpired) as e:
            f.write('\nRUNNER: '+str(e)); rc=None
    result=dict(name=name,command=cmd,exit_code=rc,status='PASS' if rc==0 else 'FAIL' if rc is not None else 'PENDING_NOT_RUN',seconds=round(time.time()-start,2),log=str(log.relative_to(ROOT/'outputs/AUDIT_OUTPUT')))
    print(json.dumps(result),flush=True)
    return result
checks=[
 ('manifest',[PY,'scripts/validate-source-manifest.py'],60),
 ('layout',[PY,'scripts/validate-project-layout.py'],60),
 ('headers',[PY,'scripts/validate-source-headers.py'],60),
 ('static',[PY,'scripts/qa.py','--static'],90),
 ('contracts',['node','--test','tests/unified_access_contract.test.mjs'],120),
 ('i18n',['node','scripts/validate-i18n.mjs'],60),
 ('tauri-config',['node','scripts/validate-tauri-config.mjs'],60),
 ('cargo-lock',['node','scripts/validate-cargo-lock.mjs'],60),
 ('rustfmt',['cargo','fmt','--all','--manifest-path','src-tauri/Cargo.toml','--','--check'],120),
]
if __name__=='__main__':
    phase=sys.argv[1] if len(sys.argv)>1 else 'baseline'
    results=[]
    for item in checks: results.append(run(item,phase))
    (OUT/phase/'results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
