import hashlib,json,pathlib,re,tomllib,urllib.request
from run_checks import HUB,OUT
packages=tomllib.loads((HUB/'src-tauri/Cargo.lock').read_text(encoding='utf-8'))['package']
registry=[p for p in packages if p.get('source','').startswith('registry+')]
queries=[{'package':{'name':p['name'],'ecosystem':'crates.io'},'version':p['version']} for p in registry]
findings=[]
try:
    for offset in range(0,len(queries),200):
        request=urllib.request.Request('https://api.osv.dev/v1/querybatch',data=json.dumps({'queries':queries[offset:offset+200]}).encode(),headers={'Content-Type':'application/json'})
        payload=json.load(urllib.request.urlopen(request,timeout=45))
        for pkg,result in zip(registry[offset:offset+200],payload['results']):
            if result.get('vulns'): findings.append({'name':pkg['name'],'version':pkg['version'],'advisories':result['vulns']})
    result={'status':'PASS' if not findings else 'FAIL','database':'https://api.osv.dev/v1/querybatch','packages_checked':len(registry),'findings':findings}
except Exception as error:
    result={'status':'PENDING_NOT_RUN','reason':str(error),'partial_findings':findings}
(OUT/'supply-chain.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
# Never print matched credential text; retain locations and categories only.
patterns={'github_token':r'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,})',
          'private_key':r'-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----',
          'aws_access_key':r'\bAKIA[0-9A-Z]{16}\b',
          'assigned_secret':r'(?i)(?:client_secret|api_key|password|signing_secret)\s*[:=]\s*[\"\'][^\"\']{16,}[\"\']'}
identity=json.loads((OUT/'final/identity.json').read_text())
hits=[]
scanned=0
for relative in identity['files']:
    path=HUB.parent/relative
    try:
        text=path.read_text(encoding='utf-8-sig',errors='strict')
    except UnicodeDecodeError:
        continue
    if '\0' in text: continue
    scanned+=1
    for category,pattern in patterns.items():
        for m in re.finditer(pattern,text):
            hits.append({'path':relative,'line':text.count('\n',0,m.start())+1,'category':category})
report={'inventory_files':len(identity['files']),'text_files_scanned':scanned,'pattern_hits':hits,'note':'Pattern scan of UTF-8 text files regardless of extension; binary/non-UTF-8 skipped; findings require manual classification; values never copied.'}
(OUT/'secret-scan.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
