<!--
/**************************************************************************/
/*  THIRD_PARTY_NOTICES.md                                                */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                           */
/**************************************************************************/
-->
# Third-party notices — Jingu Hub

## GodotHub

Jingu Hub uses and modifies source code from **GodotHub**, Copyright (c) 2026 Rayyan Aziz, licensed under the MIT License.

The unmodified upstream MIT license is distributed at `legal/GODOTHUB_LICENSE.txt`.
Upstream project: `RykoTheDev/GodotHub`.

## Source-file attribution policy

Human-authored Jingu Hub source files created by the Jingu project carry a compact Jingu MIT header. Files derived from and modified relative to GodotHub additionally name GodotHub and Rayyan Aziz in that header and point back to this notice. Untouched upstream/generated files and structured formats that do not safely support comments are not modified merely to add a banner; their license/provenance remains preserved here and in `legal/GODOTHUB_LICENSE.txt`.

## Tauri and dependencies

Jingu Hub also uses Tauri, React and other open-source dependencies. Their package-level license metadata remains available through `package-lock.json` and `src-tauri/Cargo.lock`; release engineering must retain all notices required by those dependencies.

## keyring-rs

Cross-platform secure credential persistence uses the `keyring` Rust crate and its platform credential-store providers. The crate is distributed under MIT OR Apache-2.0 terms. Jingu Hub uses it only to access the operating system's secure credential store; OAuth tokens are not written to Hub JSON files.

## ISO country and subdivision catalog

The Freelancer country/state selector includes a generated ISO 3166-1/3166-2 catalog produced from `pycountry 24.6.1` / Debian `iso-codes` data. `iso-codes` data copyright includes © 2001-2008 Alastair McKinstry, © 2004-2016 Christian Perrier, and © 2005-2025 Dr. Tobias Quathamer. The Debian `iso-codes` package is distributed under LGPL-2.1-or-later; the LGPL-2.1 text is shipped at `legal/ISO_CODES_LGPL_2_1.txt`. Jingu ships only the generated country/subdivision identifiers and names required for validation and offline selection, not the `pycountry` Python package itself.

## Noto Emoji — bundled currency flag icons

The currency selector ships small PNG flag icons rasterized from **Noto Color Emoji**, Copyright © 2013 Google, Inc., licensed under the Apache License 2.0. Only the generated PNG assets required by the Jingu payment currency selector are distributed; the font file itself is not included.

The Apache License 2.0 text is shipped at `legal/NOTO_EMOJI_APACHE_2_0.txt`.

