REM ************************************************************************
REM  VALIDAR_JINGU_HUB.cmd
REM ************************************************************************
REM                         This file is part of:
REM                              JINGU HUB
REM                        https://github.com/JinguEngine
REM ************************************************************************
REM Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
REM Licensed under the MIT License. See LICENSE.
REM ************************************************************************
@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0validate-hub-windows.ps1"
set "RC=%ERRORLEVEL%"
exit /b %RC%
