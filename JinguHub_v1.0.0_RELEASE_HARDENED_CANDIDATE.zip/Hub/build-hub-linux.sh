#!/usr/bin/env bash
# ************************************************************************
#  build-hub-linux.sh
# ************************************************************************
#                         This file is part of:
#                              JINGU HUB
#                        https://github.com/JinguEngine
# ************************************************************************
# Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
# Licensed under the MIT License. See LICENSE.
# ************************************************************************
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
CLEAN=0
while (($#)); do case "$1" in --clean) CLEAN=1; shift;; *) echo "ERRO: argumento desconhecido: $1" >&2; exit 2;; esac; done
export CARGO_TERM_COLOR=never NO_COLOR=1 FORCE_COLOR=0 CARGO_BUILD_JOBS="${CARGO_BUILD_JOBS:-1}" CARGO_INCREMENTAL=0
if ((CLEAN)); then rm -rf dist src-tauri/target Exports/Unified/Linux; fi
python3 scripts/validate-source-manifest.py
npm ci --no-audit --no-fund
npm run validate:i18n
node --test tests/unified_access_contract.test.mjs
python3 scripts/validate-source-manifest.py
python3 scripts/qa.py --static
cargo fmt --all --manifest-path src-tauri/Cargo.toml -- --check
cargo check --locked --all-targets --manifest-path src-tauri/Cargo.toml
cargo clippy --locked --all-targets --manifest-path src-tauri/Cargo.toml -- -D warnings
cargo test --locked --all-targets --manifest-path src-tauri/Cargo.toml
npm run tauri:build
npm run validate:bundle
VERSION="$(node -p "require('./package.json').version")"
CHANNEL="$(node -p "require('./release-profile.json').channel")"
[[ "$CHANNEL" =~ ^(stable|beta|experimental|dev)$ ]] || { echo "ERRO: canal de release invalido: $CHANNEL" >&2; exit 1; }
case "$(uname -m)" in
  x86_64|amd64) PLATFORM_TOKEN=linux64 ;;
  aarch64|arm64) PLATFORM_TOKEN=linuxarm64 ;;
  *) echo "ERRO: arquitetura Linux nao suportada: $(uname -m). Use x64 ou ARM64." >&2; exit 2 ;;
esac
OUT="Exports/Unified/Linux"; mkdir -p "$OUT"
BIN="src-tauri/target/release/jingu-hub"; [[ -x "$BIN" ]] || BIN="src-tauri/target/release/jingu_hub"
[[ -x "$BIN" ]] || { echo 'ERRO: executavel Linux nao encontrado.' >&2; exit 1; }
TMP=".jingu-build/portable-linux"; rm -rf "$TMP"; mkdir -p "$TMP"; cp "$BIN" "$TMP/JinguHub"; printf 'Jingu Hub portable mode\n' > "$TMP/portable.flag"
tar -C "$TMP" -czf "$OUT/JinguHub_v${VERSION}-${CHANNEL}_${PLATFORM_TOKEN}.tar.gz" .
DEB="$(find src-tauri/target/release/bundle/deb -maxdepth 1 -type f -name '*.deb' 2>/dev/null | head -1 || true)"; [[ -z "$DEB" ]] || cp "$DEB" "$OUT/JinguHub_v${VERSION}-${CHANNEL}_${PLATFORM_TOKEN}.deb"
RPM="$(find src-tauri/target/release/bundle/rpm -maxdepth 1 -type f -name '*.rpm' 2>/dev/null | head -1 || true)"; [[ -z "$RPM" ]] || cp "$RPM" "$OUT/JinguHub_v${VERSION}-${CHANNEL}_${PLATFORM_TOKEN}.rpm"
echo "[OK] Jingu Hub unified Linux: $OUT"
