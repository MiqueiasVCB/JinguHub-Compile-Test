#!/usr/bin/env bash
# ************************************************************************
#  build-hub-macos.sh
# ************************************************************************
#                         This file is part of:
#                              JINGU HUB
#                        https://github.com/JinguEngine
# ************************************************************************
# Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
# Licensed under the MIT License. See LICENSE.
# ************************************************************************
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"; cd "$ROOT"
CLEAN=0; TARGET="universal-apple-darwin"
while (($#)); do case "$1" in --clean) CLEAN=1; shift;; --target) TARGET="${2:?--target exige valor}"; shift 2;; *) echo "ERRO: argumento desconhecido: $1" >&2; exit 2;; esac; done
export CARGO_TERM_COLOR=never NO_COLOR=1 FORCE_COLOR=0 CARGO_BUILD_JOBS="${CARGO_BUILD_JOBS:-1}" CARGO_INCREMENTAL=0
if ((CLEAN)); then rm -rf dist src-tauri/target Exports/Unified/macOS; fi
python3 scripts/validate-source-manifest.py
npm ci --no-audit --no-fund
npm run validate:i18n
node --test tests/unified_access_contract.test.mjs
python3 scripts/validate-source-manifest.py
python3 scripts/qa.py --static
cargo fmt --all --manifest-path src-tauri/Cargo.toml -- --check
cargo check --locked --all-targets --manifest-path src-tauri/Cargo.toml
cargo clippy --locked --all-targets --manifest-path src-tauri/Cargo.toml -- -D warnings
cargo test --locked --all-targets --manifest-path src-tauri/Cargo.toml
if [[ "$TARGET" == universal-apple-darwin ]]; then npm run tauri:build -- --target universal-apple-darwin; else npm run tauri:build -- --target "$TARGET"; fi
npm run validate:bundle
VERSION="$(node -p "require('./package.json').version")"; CHANNEL="$(node -p "require('./release-profile.json').channel")"; [[ "$CHANNEL" =~ ^(stable|beta|experimental|dev)$ ]] || { echo "ERRO: canal de release invalido: $CHANNEL" >&2; exit 1; }; OUT="Exports/Unified/macOS/universal"; mkdir -p "$OUT"
SEARCH="src-tauri/target/${TARGET}/release/bundle"; [[ -d "$SEARCH" ]] || SEARCH="src-tauri/target/release/bundle"
APP="$(find "$SEARCH" -type d -name 'Jingu Hub.app' 2>/dev/null | head -1 || true)"; [[ -n "$APP" ]] || { echo 'ERRO: Jingu Hub.app nao encontrado.' >&2; exit 1; }
TMP=".jingu-build/macos-package"; rm -rf "$TMP"; mkdir -p "$TMP"; cp -R "$APP" "$TMP/"
(cd "$TMP" && zip -qry "$ROOT/$OUT/JinguHub_v${VERSION}-${CHANNEL}_macos.zip" 'Jingu Hub.app')
DMG="$(find "$SEARCH" -type f -name '*.dmg' 2>/dev/null | head -1 || true)"; [[ -z "$DMG" ]] || cp "$DMG" "$OUT/JinguHub_v${VERSION}-${CHANNEL}_macos.dmg"
echo "[OK] Jingu Hub unified macOS: $OUT"
