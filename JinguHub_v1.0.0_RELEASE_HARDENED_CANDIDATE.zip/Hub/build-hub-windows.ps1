<#
************************************************************************
build-hub-windows.ps1
************************************************************************
This file is part of:
JINGU HUB
https://github.com/JinguEngine
************************************************************************
Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
Licensed under the MIT License. See LICENSE.
************************************************************************
#>
param(
    [switch]$Clean,
    [ValidateRange(0,64)][int]$CargoJobs = 0,
    [string]$LogPath = ""
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($LogPath)) { $LogPath = Join-Path $Root 'build-hub.log' }
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$env:CARGO_TERM_COLOR='never'; $env:NO_COLOR='1'; $env:FORCE_COLOR='0'
$oldCargoJobs=$env:CARGO_BUILD_JOBS
if($CargoJobs -gt 0){$env:CARGO_BUILD_JOBS=[string]$CargoJobs}else{Remove-Item Env:CARGO_BUILD_JOBS -ErrorAction SilentlyContinue}

function Invoke-Native {
    param([string]$Title,[string]$Exe,[string[]]$CommandArgs)
    Write-Host "`n===== $Title =====" -ForegroundColor Cyan
    Add-Content -LiteralPath $LogPath -Encoding UTF8 -Value "`n===== $Title =====`n> $Exe $($CommandArgs -join ' ')"
    $old=$ErrorActionPreference; $ErrorActionPreference='Continue'
    try {
        & $Exe @CommandArgs 2>&1 | ForEach-Object { $line=[string]$_; Add-Content -LiteralPath $LogPath -Encoding UTF8 -Value $line; Write-Host $line }
        $rc=$LASTEXITCODE
    } finally { $ErrorActionPreference=$old }
    if($rc -ne 0){ throw "$Title falhou (exit $rc)." }
}
function Require([string]$Name){ $c=Get-Command $Name -ErrorAction SilentlyContinue | Select-Object -First 1; if($null -eq $c){throw "Comando ausente: $Name"}; return $c.Source }

$profile = Get-Content -LiteralPath (Join-Path $Root 'release-profile.json') -Raw | ConvertFrom-Json
$channel=[string]$profile.channel
if($channel -notin @('stable','beta','experimental','dev')){throw "release-profile.json: canal invalido: $channel"}
Set-Content -LiteralPath $LogPath -Encoding UTF8 -Value "Jingu Hub build`nRoot=$Root`nChannel=$channel`n"
$npm=Require 'npm.cmd'; if([string]::IsNullOrWhiteSpace($npm)){$npm=Require 'npm'}
if($Clean){
    @('dist','Exports\Unified\Windows','src-tauri\target\release\bundle') | ForEach-Object { $p=Join-Path $Root $_; if(Test-Path -LiteralPath $p){Remove-Item -LiteralPath $p -Recurse -Force} }
}
Push-Location $Root
try {
    Invoke-Native 'Frontend production build' $npm @('run','build')
    Invoke-Native 'Frontend bundle budget' $npm @('run','validate:bundle')
    Invoke-Native 'Tauri unified release build' $npm @('run','tauri:build')

    $package = Get-Content -LiteralPath (Join-Path $Root 'package.json') -Raw | ConvertFrom-Json
    $version=[string]$package.version
    $release=Join-Path $Root 'src-tauri\target\release'
    $exeCandidates=@(
        (Join-Path $release 'jingu-hub.exe'),
        (Join-Path $release 'jingu_hub.exe'),
        (Join-Path $release 'JinguHub.exe')
    )
    $exe=$exeCandidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
    if([string]::IsNullOrWhiteSpace($exe)){ throw 'Executavel release do Jingu Hub nao encontrado.' }
    $nativeArch=([string]$env:PROCESSOR_ARCHITECTURE).ToUpperInvariant()
    $platformToken=switch($nativeArch){'AMD64'{'win64'}'ARM64'{'winarm64'}default{throw "Arquitetura Windows nao suportada: $nativeArch. Use x64 ou ARM64."}}
    $out=Join-Path $Root 'Exports\Unified\Windows'; New-Item -ItemType Directory -Force -Path $out | Out-Null
    $portable=Join-Path $Root ('.jingu-build\portable-v'+$version+'-'+$platformToken); if(Test-Path $portable){Remove-Item $portable -Recurse -Force}; New-Item -ItemType Directory -Force -Path $portable | Out-Null
    Copy-Item -LiteralPath $exe -Destination (Join-Path $portable 'JinguHub.exe') -Force
    Set-Content -LiteralPath (Join-Path $portable 'portable.flag') -Encoding ASCII -Value 'Jingu Hub portable mode'
    $zip=Join-Path $out ("JinguHub_v{0}-{1}_{2}.zip" -f $version,$channel,$platformToken)
    if(Test-Path $zip){Remove-Item $zip -Force}
    Compress-Archive -Path (Join-Path $portable '*') -DestinationPath $zip -CompressionLevel Optimal
    $nsis=Get-ChildItem -LiteralPath (Join-Path $release 'bundle\nsis') -Filter '*.exe' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
    if($null -ne $nsis){ Copy-Item -LiteralPath $nsis.FullName -Destination (Join-Path $out ("JinguHub_v{0}-{1}_{2}-setup.exe" -f $version,$channel,$platformToken)) -Force }
    Write-Host "`n[OK] Build unificado concluido: $out" -ForegroundColor Green
} finally {
    Pop-Location
    if([string]::IsNullOrEmpty($oldCargoJobs)){Remove-Item Env:CARGO_BUILD_JOBS -ErrorAction SilentlyContinue}else{$env:CARGO_BUILD_JOBS=$oldCargoJobs}
}
