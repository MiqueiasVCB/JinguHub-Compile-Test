<#
************************************************************************
run-hub-diagnostic.ps1
************************************************************************
This file is part of:
JINGU HUB
https://github.com/JinguEngine
************************************************************************
Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
Licensed under the MIT License. See LICENSE.
************************************************************************
#>
param(
    [switch]$KillExisting,
    [switch]$CloseAfterTest,
    [string]$ExePath = "",
    [int]$TimeoutSeconds = 12
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$HubRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = $HubRoot
$ReleaseProfile = Get-Content -LiteralPath (Join-Path $Root 'release-profile.json') -Raw | ConvertFrom-Json
$ReleaseVersion = [string]$ReleaseProfile.version
$ReleaseChannel = [string]$ReleaseProfile.channel
if($ReleaseVersion -notmatch '^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$'){throw "release-profile.json: versao invalida: $ReleaseVersion"}
if($ReleaseChannel -notin @('stable','beta','experimental','dev')){throw "release-profile.json: canal invalido: $ReleaseChannel"}
$DefaultExe = Join-Path $HubRoot "src-tauri\target\release\jingu-hub.exe"
$Exe = if ([string]::IsNullOrWhiteSpace($ExePath)) { $DefaultExe } else { [System.IO.Path]::GetFullPath($ExePath) }
$ExeDir = Split-Path -Parent $Exe
$PortableMarker = Join-Path $ExeDir "portable.flag"
$StartupLog = if (Test-Path -LiteralPath $PortableMarker -PathType Leaf) {
    Join-Path $ExeDir "data\logs\startup.log"
} else {
    Join-Path $env:LOCALAPPDATA "JinguHub\logs\startup.log"
}
$DiagnosticsRoot = Join-Path $HubRoot "Diagnostics"
if (-not (Test-Path -LiteralPath $DiagnosticsRoot)) { New-Item -ItemType Directory -Force -Path $DiagnosticsRoot | Out-Null }
$Report = Join-Path $DiagnosticsRoot "runtime-diagnostic.log"
$startedAt = Get-Date

# Diagnostics are a support surface, never a credential transport. Apply a second
# redaction layer here even though the Rust startup logger already redacts before
# disk, because Windows Event Log messages originate outside that logger.
function Protect-DiagnosticText {
    param([AllowNull()][string]$Text)
    if ($null -eq $Text) { return "" }
    $safe = [string]$Text
    $safe = $safe -replace '(?i)\b(?:ghp_|github_pat_|gho_|ghu_|ghs_|ghr_)[A-Za-z0-9_-]+', '[REDACTED_GITHUB_TOKEN]'
    $safe = $safe -replace '(?i)(Bearer\s+)[^\s,;"''&]+', '$1[REDACTED]'
    $safe = $safe -replace '(?i)((?:authorization|access_token|refresh_token|client_secret|jingu_continuity_ingest_key|ingest_key|jingu_payment_signing_secret|signing_secret|api_key|x-api-key|x-jingu-ingest-key|password|device_code|code_verifier|token)["'']?\s*[:=]\s*["'']?)[^\s,;"''&}\]]+', '$1[REDACTED]'
    $safe = $safe -replace '(?i)(/v1/(?:webhooks|payments/return)/infinitepay/[0-9a-f-]{36}/)[^\s/?#]+', '$1[REDACTED]'
    if (-not [string]::IsNullOrWhiteSpace($env:USERPROFILE)) {
        $safe = $safe.Replace([string]$env:USERPROFILE, '%USERPROFILE%')
    }
    return $safe
}

Set-Content -LiteralPath $Report -Encoding UTF8 -Value @(
    ("Jingu Hub v{0} [{1}] - runtime diagnostic" -f $ReleaseVersion,$ReleaseChannel)
    "Inicio: $($startedAt.ToString('yyyy-MM-dd HH:mm:ss'))"
    (Protect-DiagnosticText "Executavel: $Exe")
    "Windows: $([Environment]::OSVersion.VersionString)"
    "PowerShell: $($PSVersionTable.PSVersion.ToString())"
    ""
)

function Write-Diag {
    param([string]$Text = "", [ConsoleColor]$Color = [ConsoleColor]::Gray)
    $safeText = Protect-DiagnosticText $Text
    Write-Host $safeText -ForegroundColor $Color
    Add-Content -LiteralPath $Report -Value $safeText -Encoding UTF8
}

function Get-StartupLines {
    if (-not (Test-Path -LiteralPath $StartupLog -PathType Leaf)) {
        return @()
    }
    return @(Get-Content -LiteralPath $StartupLog -Encoding UTF8 -ErrorAction SilentlyContinue)
}

$ProcessName = [System.IO.Path]::GetFileNameWithoutExtension($Exe)
$existing = @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue)
if ($existing.Count -gt 0) {
    Write-Diag ("Instancias existentes: {0}" -f (($existing | ForEach-Object { $_.Id }) -join ", ")) Yellow
    if ($KillExisting) {
        $existing | Stop-Process -Force
        Start-Sleep -Milliseconds 700
        Write-Diag "Instancias anteriores encerradas." Yellow
    }
    else {
        Write-Diag "Use -KillExisting para eliminar uma instancia invisivel/stale antes do teste." Yellow
    }
}

if (-not (Test-Path -LiteralPath $Exe -PathType Leaf)) {
    Write-Diag "Executavel release nao encontrado." Red
    Write-Diag $Exe Red
    Write-Diag "Compile primeiro com: .\build-hub-windows.ps1 -Clean" Yellow
    exit 2
}

$beforeLines = @(Get-StartupLines)
$beforeCount = $beforeLines.Count

Write-Diag "Iniciando Jingu Hub..." Cyan
$p = Start-Process -FilePath $Exe -PassThru
Write-Diag ("PID iniciado: {0}" -f $p.Id) Cyan

$deadline = (Get-Date).AddSeconds([Math]::Max(3, $TimeoutSeconds))
$mainWindowSeen = $false
$runtimeReady = $false
$fatalSeen = $false
$fatalLine = ""
$lastTitle = ""
$lastHandle = 0
$newStartupLines = @()

while ((Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 350
    try { $p.Refresh() } catch { break }

    $allLines = @(Get-StartupLines)
    if ($allLines.Count -ge $beforeCount) {
        $newStartupLines = @($allLines | Select-Object -Skip $beforeCount)
    }
    else {
        # The startup log rotated between snapshot and launch. In this case all
        # currently visible lines belong to the new/rotated log surface.
        $newStartupLines = $allLines
    }

    $fatal = @($newStartupLines | Where-Object { $_ -match '\bFATAL:' } | Select-Object -Last 1)
    if ($fatal.Count -gt 0) {
        $fatalSeen = $true
        $fatalLine = [string]$fatal[0]
        break
    }

    if ($p.HasExited) { break }

    $lastHandle = $p.MainWindowHandle
    $lastTitle = [string]$p.MainWindowTitle

    # A native fatal MessageBox also owns an HWND. Never classify that dialog
    # as the Jingu Hub main window.
    if ($lastHandle -ne 0 -and $lastTitle -eq "Jingu Hub") {
        $mainWindowSeen = $true
    }

    if (@($newStartupLines | Where-Object { $_ -match 'Tauri application built; entering event loop' }).Count -gt 0) {
        $runtimeReady = $true
    }

    if ($mainWindowSeen -and $runtimeReady) {
        # Give any immediately-following panic/fatal entry a short chance to be
        # flushed before declaring the launch healthy.
        Start-Sleep -Milliseconds 650
        $allLines = @(Get-StartupLines)
        if ($allLines.Count -ge $beforeCount) {
            $newStartupLines = @($allLines | Select-Object -Skip $beforeCount)
        }
        $fatal = @($newStartupLines | Where-Object { $_ -match '\bFATAL:' } | Select-Object -Last 1)
        if ($fatal.Count -gt 0) {
            $fatalSeen = $true
            $fatalLine = [string]$fatal[0]
        }
        break
    }
}

try { $p.Refresh() } catch {}
if ($fatalSeen) {
    Write-Diag "FALHA: o runtime registrou erro fatal durante a inicializacao." Red
    Write-Diag $fatalLine Red
}
elseif ($p.HasExited) {
    Write-Diag ("FALHA: processo encerrou durante o startup. ExitCode={0}" -f $p.ExitCode) Red
}
elseif ($mainWindowSeen -and $runtimeReady) {
    Write-Diag ("OK: Jingu Hub entrou no event loop e a janela principal foi detectada. PID={0}, HWND={1}, Title={2}" -f $p.Id, $lastHandle, $lastTitle) Green
}
elseif ($lastHandle -ne 0 -and $lastTitle -match '(?i)erro de inicializa') {
    Write-Diag ("FALHA: foi detectada apenas a caixa de erro de inicializacao. PID={0}, HWND={1}, Title={2}" -f $p.Id, $lastHandle, $lastTitle) Red
}
elseif ($mainWindowSeen) {
    Write-Diag ("ALERTA: a janela principal apareceu, mas o log nao confirmou entrada no event loop dentro de {0}s." -f $TimeoutSeconds) Yellow
}
else {
    Write-Diag ("ALERTA: processo continua ativo, mas a janela principal 'Jingu Hub' nao foi confirmada. PID={0}, HWND={1}, Title={2}" -f $p.Id, $lastHandle, $lastTitle) Yellow
}

Write-Diag ""
Write-Diag "===== startup.log desta execucao =====" Yellow
if ($newStartupLines.Count -gt 0) {
    foreach ($line in $newStartupLines) {
        Write-Diag ([string]$line)
    }
    Write-Diag ("Startup log: {0}" -f $StartupLog) Yellow
}
elseif (Test-Path -LiteralPath $StartupLog -PathType Leaf) {
    Write-Diag "Nenhuma nova linha foi detectada no startup.log; exibindo as ultimas 40 linhas para contexto." Yellow
    foreach ($line in (Get-Content -LiteralPath $StartupLog -Encoding UTF8 -Tail 40)) {
        Write-Diag ([string]$line)
    }
    Write-Diag ("Startup log: {0}" -f $StartupLog) Yellow
}
else {
    Write-Diag "Nenhum startup.log foi criado. O executavel pode ter sido bloqueado antes de entrar no codigo Rust." Yellow
}

Write-Diag ""
Write-Diag "===== Windows Application events =====" Yellow
try {
    $events = @(Get-WinEvent -FilterHashtable @{ LogName = 'Application'; StartTime = $startedAt.AddMinutes(-1) } -ErrorAction Stop |
        Where-Object { $_.Message -match '(?i)jingu-hub\.exe|Jingu Hub' } |
        Select-Object -First 8)
    if ($events.Count -eq 0) {
        Write-Diag "Nenhum evento de aplicacao relacionado ao Jingu Hub encontrado." DarkGray
    }
    else {
        foreach ($event in $events) {
            Write-Diag ("[{0}] Provider={1} Id={2}" -f $event.TimeCreated, $event.ProviderName, $event.Id) Yellow
            Write-Diag (($event.Message -replace "`r?`n", " ").Trim())
        }
    }
}
catch {
    Write-Diag ("Nao foi possivel consultar o Event Log: {0}" -f $_.Exception.Message) DarkGray
}

Write-Diag ""
Write-Diag ("Relatorio salvo em: {0}" -f $Report) Green

$healthy = -not $fatalSeen -and -not $p.HasExited -and ($mainWindowSeen -and $runtimeReady)
if ($CloseAfterTest -and -not $p.HasExited) {
    try { Stop-Process -Id $p.Id -Force -ErrorAction Stop; Write-Diag "Processo de smoke test encerrado." DarkGray } catch {}
}
if (-not $healthy) { exit 1 }
exit 0
