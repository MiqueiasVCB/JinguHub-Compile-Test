#!/usr/bin/env python3
# ************************************************************************
#  generate-godot-i18n.py
# ************************************************************************
#                         This file is part of:
#                              JINGU HUB
#                        https://github.com/JinguEngine
# ************************************************************************
# Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
# Licensed under the MIT License. See LICENSE.
# ************************************************************************
from __future__ import annotations
import argparse, ast, json, os, re
from pathlib import Path

HUB = Path(__file__).resolve().parents[1]
ROOT = HUB.parent
OUT = HUB / 'src' / 'jingu' / 'godot_locale.generated.json'
COPY = HUB / 'src' / 'jingu' / 'copy.ts'

MSGIDS = {
    'projects':'Projects', 'settings':'Settings', 'refresh':'Refresh', 'import':'Import',
    'newProject':'New Project', 'openProject':'Open', 'favorite':'Add to Favorites',
    'unfavorite':'Remove from Favorites', 'openFolder':'Open in File Manager',
    'options':'Options', 'removeList':'Remove', 'copyContinue':'Continue', 'cancel':'Cancel',
    'install':'Install', 'delete':'Delete', 'open':'Open', 'checkUpdates':'Check for Updates',
    'downloading':'Downloading...', 'gitProject':'Project', 'remote':'Remote', 'pull':'Pull',
    'push':'Push', 'fetch':'Fetch', 'branch':'Branches', 'stageAll':'Stage all changes',
    'unstageAll':'Unstage all changes', 'noChanges':'No files or changes to export.',
    'commit':'Commit', 'description':'Description', 'create':'Create', 'newBranch':'Create New Branch',
    'animations':'Animation', 'language':'Language', 'defaultProjectFolder':'Project Path',
    'loading':'Loading...', 'error':'Error', 'retry':'Retry', 'close':'Close', 'save':'Save',
    'projectName':'Name', 'location':'Path', 'sortName':'Name', 'unavailable':'Unavailable',
    'versionLabel':'Version', 'projectIdentity':'Project', 'gitNotInstalled':'Git',
    'browserBack':'Back', 'browserHome':'Home', 'choose':'Select', 'installUpdate':'Update',
    'searchProjects':'Search', 'clean':'Remove', 'engineVersion':'Version',
    'noEngine':'Unavailable', 'selectEngine':'Select', 'searchVersions':'Search',
    'releaseSource':'Source', 'importVersionTitle':'Import', 'importVersionZip':'Import',
    'importVersionFolder':'Import', 'importVersionExecutable':'Import',
    'copyCode':'Copy', 'branchTitle':'Branches', 'createBranch':'Create New Branch',
    'engineVersionFolder':'Path', 'newProjectTitle':'New Project', 'createProject':'Create',
    'importProjectTitle':'Import', 'installApp':'Install', 'sortRecent':'Sort by Last Modified',
    'viewGodotHub':'Open', 'viewGitHubApp':'Open', 'viewGodot':'Open', 'viewLicenses':'Open',
    'updated':'Modified', 'waiting':'Loading...',
    'switchBranch':'Select', 'repoName':'Name', 'createRepo':'Create', 'openGitHub':'Open',
    'allRepositories':'All', 'selectedRepositories':'Selection', 'selected':'Selection',
}

def q(s:str)->str:
    try: return ast.literal_eval(s)
    except Exception: return ''

def parse_po(path:Path)->dict[str,str]:
    lines=path.read_text(encoding='utf-8',errors='replace').splitlines()
    out={}; i=0
    while i < len(lines):
        if not lines[i].startswith('msgid '):
            i+=1; continue
        msgid=q(lines[i][6:].strip()); i+=1
        while i<len(lines) and lines[i].startswith('"'):
            msgid += q(lines[i]); i+=1
        while i<len(lines) and not lines[i].startswith('msgstr ') and not lines[i].startswith('msgid '): i+=1
        if i>=len(lines) or not lines[i].startswith('msgstr '): continue
        msgstr=q(lines[i][7:].strip()); i+=1
        while i<len(lines) and lines[i].startswith('"'):
            msgstr += q(lines[i]); i+=1
        if msgid and msgstr: out[msgid]=msgstr
    return out

def resolve_editor(explicit: str | None) -> Path:
    candidates=[]
    if explicit:
        candidates.append(Path(explicit))
    env=os.environ.get('JINGU_ENGINE_TRANSLATIONS')
    if env:
        candidates.append(Path(env))
    candidates.extend([
        ROOT / 'Engine' / 'editor' / 'translations' / 'editor',
        ROOT.parent / 'Engine' / 'editor' / 'translations' / 'editor',
    ])
    for candidate in candidates:
        if candidate.is_dir() and any(candidate.glob('*.po')):
            return candidate.resolve()
    checked='\n'.join(f'  - {candidate}' for candidate in candidates)
    raise SystemExit(
        'Nao foi localizado um checkout completo da Engine com os arquivos .po.\n'
        'Isso NAO impede o build do Hub: o catalogo gerado ja esta versionado.\n'
        'Este script serve apenas para atualizar o snapshot de traducoes.\n'
        f'Caminhos verificados:\n{checked}\n'
        'Use --engine-translations <pasta> ou JINGU_ENGINE_TRANSLATIONS para informar outro local.'
    )


def curated_locales() -> list[str]:
    """Return only locales explicitly exposed by the Hub language selector.

    The Engine may gain additional upstream translations before the Hub has
    curated Jingu-specific copy for them. Feature-freeze builds must not
    silently publish a new language just because a local Engine checkout has a
    new .po file. English is authored directly in copy.ts, so it is excluded
    from the generated Godot snapshot.
    """
    copy = COPY.read_text(encoding='utf-8')
    locales = re.findall(r"\{\s*value:\s*'[^']+',\s*locale:\s*'([^']+)'", copy)
    if not locales:
        raise SystemExit(f'Nao foi possivel extrair LANGUAGE_OPTIONS de {COPY}.')
    ordered=[]
    for locale in locales:
        if locale == 'en' or locale in ordered:
            continue
        ordered.append(locale)
    return ordered

def main() -> None:
    parser=argparse.ArgumentParser(description='Regenera o snapshot i18n do Hub a partir dos .po da Jingu/Godot Engine.')
    parser.add_argument('--engine-translations', help='Pasta editor/translations/editor de um checkout completo da Engine.')
    args=parser.parse_args()
    editor=resolve_editor(args.engine_translations)
    supported=curated_locales()
    available={po.stem:po for po in editor.glob('*.po')}
    missing=[locale for locale in supported if locale not in available]
    if missing:
        raise SystemExit('Engine sem locale(s) curado(s) pelo Hub: ' + ', '.join(missing))
    result={}
    for locale in supported:
        table=parse_po(available[locale])
        pack={key:table[msgid] for key,msgid in MSGIDS.items() if table.get(msgid)}
        result[locale]=pack
    upstream_only=sorted(set(available)-set(supported)-{'en'})
    OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'wrote {OUT}: {len(result)} locales, {sum(map(len,result.values()))} translated key-values')
    print(f'source: {editor}')
    if upstream_only:
        print('info: locales da Engine ainda nao curados/expostos pelo Hub: ' + ', '.join(upstream_only))

if __name__ == '__main__':
    main()
