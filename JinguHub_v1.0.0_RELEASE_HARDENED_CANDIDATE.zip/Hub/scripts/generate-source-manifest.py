#!/usr/bin/env python3
# ************************************************************************
#  generate-source-manifest.py
# ************************************************************************
#                         This file is part of:
#                              JINGU HUB
#                        https://github.com/JinguEngine
# ************************************************************************
# Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
# Licensed under the MIT License. See LICENSE.
# ************************************************************************
"""Regenerate SOURCE_MANIFEST.sha256 after a deliberate source/release change.

Run only from a clean, reviewed Hub tree. Generated/build/runtime directories are
excluded using the same narrow rules as validate-source-manifest.py.
"""
from __future__ import annotations
import hashlib
import re
from pathlib import Path

HUB = Path(__file__).resolve().parents[1]
OUT = HUB / "SOURCE_MANIFEST.sha256"
EXCLUDED_DIRS = {
    ".git", ".jingu-build", "node_modules", "dist", "dist-ssr", "target",
    "Exports", "Release", "Diagnostics", "__pycache__",
}
IGNORED_ROOT_PATTERNS = (
    re.compile(r"^build-hub-.*\.log$", re.IGNORECASE),
    re.compile(r"^runtime-diagnostic-.*\.log$", re.IGNORECASE),
)
GENERATED_PREFIXES = {("src-tauri", "gen", "schemas")}
GENERATED_FILES: set[str] = {"src-tauri/continuity_endpoint.txt"}
SELF_EXCLUDED = {"SOURCE_MANIFEST.sha256"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ignored(path: Path) -> bool:
    rel = path.relative_to(HUB)
    rel_posix = rel.as_posix()
    if rel_posix in SELF_EXCLUDED or rel_posix in GENERATED_FILES:
        return True
    if any(rel.parts[: len(prefix)] == prefix for prefix in GENERATED_PREFIXES):
        return True
    if any(part in EXCLUDED_DIRS for part in rel.parts):
        return True
    return len(rel.parts) == 1 and any(pattern.fullmatch(rel.name) for pattern in IGNORED_ROOT_PATTERNS)


def main() -> int:
    files = [path for path in HUB.rglob("*") if path.is_file() and not ignored(path)]
    lines = [f"{sha256(path)}  {path.relative_to(HUB).as_posix()}" for path in sorted(files)]
    OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"SOURCE_MANIFEST.sha256 atualizado: {len(lines)} arquivos.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
