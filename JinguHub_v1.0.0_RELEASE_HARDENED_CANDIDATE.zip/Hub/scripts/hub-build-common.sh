#!/usr/bin/env bash
# ************************************************************************
#  hub-build-common.sh
# ************************************************************************
#                         This file is part of:
#                              JINGU HUB
#                        https://github.com/JinguEngine
# ************************************************************************
# Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
# Licensed under the MIT License. See LICENSE.
# ************************************************************************
# Shared invariants for the single unified Hub build. Kept intentionally small:
# OS-specific scripts own packaging, while architecture/security is validated by
# scripts/qa.py and tests/unified_access_contract.test.mjs.
set -euo pipefail
jingu_hub_root(){ cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd; }
