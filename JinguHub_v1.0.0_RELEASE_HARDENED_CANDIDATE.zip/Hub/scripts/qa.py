#!/usr/bin/env python3
# ************************************************************************
#  qa.py
# ************************************************************************
#                         This file is part of:
#                              JINGU HUB
#                        https://github.com/JinguEngine
# ************************************************************************
# Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
# Licensed under the MIT License. See LICENSE.
# ************************************************************************
from __future__ import annotations
import argparse, json, pathlib, re
ROOT=pathlib.Path(__file__).resolve().parents[1]
PASS=0; FAIL=0
SKIP_PARTS={'node_modules','dist','target','Exports','Diagnostics','.jingu-build'}
SOURCE_SUFFIXES={'.rs','.ts','.tsx','.js','.mjs','.json','.toml','.ps1','.sh','.cmd','.md','.yml','.yaml'}

def check(label, cond, detail=''):
    global PASS,FAIL
    if cond:
        PASS+=1; print(f'[PASS] {label}')
    else:
        FAIL+=1; print(f'[FAIL] {label}' + (f' :: {detail}' if detail else ''))

def text(rel): return (ROOT/rel).read_text(encoding='utf-8-sig')

def corpus():
    chunks=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in SOURCE_SUFFIXES or any(part in SKIP_PARTS for part in p.parts):
            continue
        chunks.append(p.read_text(encoding='utf-8-sig',errors='ignore'))
    return '\n'.join(chunks)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--static',action='store_true'); ap.add_argument('--full',action='store_true'); ap.parse_args()
    required=['package.json','package-lock.json','src-tauri/Cargo.toml','src-tauri/Cargo.lock','src-tauri/tauri.conf.json','src-tauri/src/github.rs','src-tauri/src/godot_versions.rs','src-tauri/src/freelancers.rs','tests/unified_access_contract.test.mjs','VALIDAR_JINGU_HUB.cmd']
    for rel in required: check(f'required {rel}',(ROOT/rel).is_file())
    pkg=json.loads(text('package.json')); lock=json.loads(text('package-lock.json'))
    check('Browserslist CVE-2026-73088/73089 fix is exact and lock-pinned', pkg.get('overrides',{}).get('browserslist')=='4.28.7' and lock.get('packages',{}).get('node_modules/browserslist',{}).get('version')=='4.28.7')
    check('baseline-browser-mapping GHSA-w5vr-8v7q-w6rv fix is exact and lock-pinned', pkg.get('overrides',{}).get('baseline-browser-mapping')=='2.11.0' and lock.get('packages',{}).get('node_modules/baseline-browser-mapping',{}).get('version')=='2.11.0')
    cargo=text('src-tauri/Cargo.toml'); github=text('src-tauri/src/github.rs'); jingu=text('src-tauri/src/jingu.rs'); engine=text('src-tauri/src/godot_versions.rs'); lib=text('src-tauri/src/lib.rs'); startup=text('src-tauri/src/startup.rs')
    check('single Cargo build', not re.search(r'(?:public|developer)-hub',cargo))
    tauri=text('src-tauri/tauri.conf.json')
    check('single Tauri identity', 'Jingu Hub' in tauri and 'dev.jingu.hub' in tauri)
    header_validator=text('scripts/validate-source-headers.py')
    check('Jingu source attribution header policy is enforced', 'UPSTREAM_DERIVED' in header_validator and 'Rayyan Aziz' in header_validator and 'THIRD_PARTY_NOTICES.md' in header_validator)
    i18n_validator=text('scripts/validate-i18n.mjs'); i18n_generator=text('scripts/generate-godot-i18n.py')
    check('Hub i18n drift distinguishes curated locales from new Engine-only locales', all(token in i18n_validator for token in ['missingCurated','upstreamOnly','locales adicionais da Engine ainda nao curados/expostos pelo Hub']))
    check('Godot i18n generator is feature-freeze safe and emits only LANGUAGE_OPTIONS locales', all(token in i18n_generator for token in ['curated_locales()','supported=curated_locales()','upstream_only=sorted(set(available)-set(supported)']))
    all_source=corpus()
    forbidden=[
        r'Jingu(?:Engine|Hub)-[A-Za-z0-9_-]*Releases[A-Za-z0-9_-]*Test',
        r'JinguHub-[A-Za-z0-9_-]*Freelancers[A-Za-z0-9_-]*Test',
        r'JINGU_[A-Z0-9_]*TEST[A-Z0-9_]*TOKEN',
        r'JinguHubD' + r'ev(?:eloper)?',
        r'Jingu Hub D' + r'ev\w+',
        r'release[-_]test[-_]token\.dpapi',
    ]
    for pattern in forbidden: check(f'no private/legacy pattern {pattern}', re.search(pattern,all_source,re.I) is None)
    check('dynamic user installations discovery','/user/installations?per_page=100' in github)
    check('dynamic authorized repo enumeration','/user/installations/{installation_id}/repositories' in github)
    check('requires GitHub private=true','row.get("private")' in github and 'Some(true)' in github)
    check('ambiguity fails closed','assign_unique' in github and 'PrivateRepositories::default()' in github)
    check('public Engine repo only in config','PUBLIC_ENGINE_RELEASES_REPOSITORY' in jingu)
    check('public Hub repo only in config','PUBLIC_HUB_RELEASES_REPOSITORY' in jingu)
    check('private rows excluded from cache','!release.restricted && release.channel == "stable"' in engine)
    check('download reauthorization','job.restricted' in engine and 'authorized_private_repository' in engine)
    check('release-profile adaptive runtime','channel: crate::release_profile::CHANNEL' in lib and 'flavor: "unified"' in lib and 'version: crate::release_profile::VERSION' in lib and 'adaptive_private_access: true' in lib)
    validators=sorted(path.name for path in ROOT.glob('VALIDAR_JINGU_HUB*.cmd'))
    check('single Windows validator',validators == ['VALIDAR_JINGU_HUB.cmd'],str(validators))
    check('no legacy Developer area at Hub root',not any(path.is_dir() and path.name.lower().startswith('developer') for path in ROOT.iterdir()))
    validator=text('validate-hub-windows.ps1')
    check('Windows runner avoids PowerShell automatic $args collision', '[string[]]$CommandArgs' in validator and '@CommandArgs' in validator and '[string[]]$Args' not in validator and '@Args' not in validator)
    check('Windows certification validates immutable source before and after toolchain work', "Run '0/13 source manifest integrity'" in validator and "scripts/validate-source-manifest.py" in validator and "scripts/generate-source-manifest.py" not in validator and "@('fmt','--all','--manifest-path','src-tauri/Cargo.toml','--','--check')" in validator and "13/13 source manifest final integrity" in validator and validator.index("0/13 source manifest integrity") < validator.index("1/13 npm ci"))
    check('Windows Rust QA is memory-resilient', all(token in validator for token in ['CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_PROFILE_DEV_CODEGEN_UNITS','CARGO_PROFILE_TEST_CODEGEN_UNITS','STATUS_STACK_BUFFER_OVERRUN','rustc-LLVM ERROR','Run-CargoSafe','Wait-Memory']))
    msvc_helper=text('scripts/windows-msvc-toolchain.ps1')
    check('Windows native QA auto-initializes the shipped MSVC helper before Cargo', 'Initialize-JinguWindowsMsvcToolchain' in validator and all(token in msvc_helper for token in ['vswhere.exe','VsDevCmd.bat','link.exe','rc.exe']))
    check('Shared MSVC helper carries canonical Jingu source header', all(token in msvc_helper[:2400] for token in ['This file is part of:','JINGU HUB','JINGU MANAGER','Miquéias Veloso','MIT License']))
    win_build=text('build-hub-windows.ps1')
    check('Windows build runner avoids PowerShell automatic $args collision', '[string[]]$CommandArgs' in win_build and '@CommandArgs' in win_build and '[string[]]$Args' not in win_build and '@Args' not in win_build)
    for shell_script in ['build-hub-linux.sh','build-hub-macos.sh']:
        shell=text(shell_script)
        check(f'{shell_script} validates immutable manifest without rewriting source', 'python3 scripts/validate-source-manifest.py' in shell and 'python3 scripts/generate-source-manifest.py' not in shell and 'cargo fmt --all --manifest-path src-tauri/Cargo.toml -- --check' in shell and not re.search(r'cargo\s+fmt(?![^\n]*--check)', shell))
    terminal=text('src-tauri/src/terminal.rs'); tray=text('src-tauri/src/tray.rs'); versions_api=text('src/api/versions.ts')
    check('child env sanitizer is warning-free on non-Linux targets', 'pub fn sanitize_child_env(_cmd: &mut Command)' in terminal and '_cmd.env_remove("LD_LIBRARY_PATH")' in terminal)
    check('download command uses a structured IPC request', 'pub struct DownloadGodotVersionRequest' in engine and 'request: DownloadGodotVersionRequest' in engine and '#[serde(rename_all = "camelCase")]' in engine and "{request:{tag,assetName,downloadUrl,expectedSha256,expectedSize,entrypoint,restricted}}" in versions_api)
    check('tray awaits async project opening through Tauri runtime', 'let task = tauri::async_runtime::spawn(async move' in tray and 'projects::open_project(' in tray and '.await' in tray and 'std::mem::drop(task)' in tray and 'let _ = projects::open_project' not in tray)
    freelancers=text('src-tauri/src/freelancers.rs')
    public_fallback = freelancers
    check('freelancer WhatsApp validation is E.164-bounded and rejects zero prefix', '(8..=15).contains(&parts[0].len())' in freelancers and "parts[0].starts_with('0')" in freelancers and not re.search(r'digits\s*>=\s*8\s*&&\s*digits\s*<=\s*15', freelancers))
    notifications=text('src/jingu/notifications.ts'); freelancer_view=text('src/jingu/views/FreelancersView.tsx'); settings_view=text('src/jingu/views/SettingsView.tsx'); github_view=text('src/jingu/views/GitHubView.tsx'); api_ts=text('src/lib/api.ts'); copy_ts=text('src/jingu/copy.ts'); continuity=text('src-tauri/src/continuity.rs')
    check('installation status internal calls always provide explicit refresh semantics', 'github_installation_status().await' not in github and 'github_installation_status_inner(false).await.ok()' in github and 'github_installation_status_inner(true).await?' in github)
    check('Repair21 Engine target matcher is OS/architecture exact', 'fn engine_asset_matches_target' in engine and 'manifest_platform_matches_target' in engine and 'n.contains("universal")' in engine)
    check('Repair21 Engine manifest schema 2 is metadata-bound', 'Some(1) | Some(2)' in engine and 'engine_manifest_platform_metadata' in engine and 'item["packaging"].as_str() != Some("zip")' in engine)
    check('Repair21 Engine ZIP extraction is hardened before extract', 'validate_engine_zip_archive(&mut archive)?' in engine and 'enclosed_name().is_none()' in engine and 'symlink não permitido' in engine and 'case-collision' in engine)
    check('Repair21 Engine ZIP validator compiles on non-Windows hosts', 'use std::io::{Read, Seek, Write};' in engine and '#[cfg(target_os = "windows")]\nuse std::io::SeekFrom;' in engine)
    check('Repair21 Engine executable architecture is checked after install and before launch', engine.count('verify_executable_arch(&exe_path)?') >= 3 and 'verify_executable_arch(exe)?' in engine)
    check('Repair21 godotenv tests use UUID temp isolation', 'uuid::Uuid::new_v4()' in text('src-tauri/src/godotenv.rs'))
    check('Repair27 macOS Mach-O comparisons avoid Clippy op_ref', 'magic == [0xCF, 0xFA, 0xED, 0xFE]' in engine and 'magic == [0xFE, 0xED, 0xFA, 0xCF]' in engine and 'magic == &[' not in engine)
    payment_browser=text('src-tauri/src/payment_browser.rs')
    check('Embedded payment navigation avoids Clippy needless-borrow', 'emit_navigation(&app_for_nav, url);' in payment_browser and 'emit_navigation(&app_for_nav, &url);' not in payment_browser)
    check('repository creation refreshes GitHub App capability before mutation', 'pub async fn github_create_repository' in github and 'github_installation_status_inner(true).await?' in github[github.index('pub async fn github_create_repository'):])
    check('Repair19 Continuity retry status pattern is Clippy-safe', 'matches!(response.status().as_u16(), 502..=504)' in continuity and '502 | 503 | 504' not in continuity)
    check('Repair19 GitHub reset delay uses clamp idiom', 'reset.saturating_sub(now_epoch).clamp(1, 86_400)' in github and '.max(1).min(86_400)' not in github)
    check('Repair19 cooldown Option uses question-mark idiom', 'let blocked_until = guard.blocked_until?;' in github and 'let Some(blocked_until) = guard.blocked_until else' not in github)
    check('GitHub transient failures retry with backoff and preserve Hub session', 'matches!(status.as_u16(), 500 | 502..=504)' in github and 'const DELAYS_MS: [u64; 3] = [350, 900, 1_800]' in github and 'Sua sessão foi preservada' in github and 'temporariamente indisponível' in notifications)
    check('GitHub retry loop is Clippy-safe', 'DELAYS_MS.get(attempt)' in github and 'for attempt in 0..=DELAYS_MS.len()' not in github and 'DELAYS_MS[attempt]' not in github)
    refresh_section=github[github.find('async fn refresh('):github.find('pub async fn access_token()', github.find('async fn refresh('))]
    check('OAuth refresh is single-attempt to avoid ambiguous credential replay', 'OAuth refresh failed without automatic retry' in refresh_section and '.send()' in refresh_section and 'send_with_retry(' not in refresh_section)
    check('Freelancer continuity cache is structurally public-only', all(token in freelancers for token in ['PUBLIC_CACHE_FILE','public_only_posts','post.channel == "public"','continuity_cache_never_keeps_test_rows','let public_posts = public_only_posts(posts.iter().cloned())','entry.posts = public_only_posts(entry.posts)']) and 'save_public_cache(&app, page, sort, private_more' not in public_fallback)
    check('Hub hides internal Freelancer reconciliation states from end users', "feed.state==='error'" in freelancer_view and "feed?.state==='continuity'||feed?.state==='degraded'" not in freelancer_view and 'c.continuityMode' not in freelancer_view)
    community=text('src-tauri/src/community.rs'); versions_rs=text('src-tauri/src/godot_versions.rs'); hub_release_rs=text('src-tauri/src/hub_releases.rs'); shell_ts=text('src/jingu/JinguShell.tsx')
    check('Hub hot reads are cache-first and reuse pooled HTTP connections', 'OnceLock<reqwest::Client>' in continuity and 'refresh_catalog_edge' in community and 'compare_exchange(false, true' in community and 'fast_cached_feed' in freelancers and 'active_refreshes' in freelancers and 'fn release_http_client()' in versions_rs and 'spawn_releases_refresh' in versions_rs and 'jingu-engine-catalog-refreshed' in versions_rs and 'OnceLock<reqwest::Client>' in hub_release_rs and 'refreshVersions(false,true)' in shell_ts)
    membership=text('src-tauri/src/membership.rs')
    check('Hub display membership is short-cached while paid enforcement remains authoritative', 'DISPLAY_CACHE_TTL' in membership and '/v1/membership/public-id/' in membership and '/v1/membership/me' in membership and 'current_profile().await' in public_fallback)
    check('Freelancer like state is batched instead of N-plus-one REST reads', 'freelancers_reaction_states' in freelancers and 'viewerHasReacted reactors' in freelancers and 'freelancersReactionStates' in freelancer_view)
    check('Freelancer plan badges are always visible and current without N-plus-one membership reads', "normalized==='free'" not in freelancer_view and "'border-line bg-base/75 text-muted'" in freelancer_view and 'public_profiles_by_ids' in membership and '/v1/membership/public-batch?ids=' in membership and 'enrich_current_memberships' in freelancers and '/v1/freelancers/feed?page=' in public_fallback)
    check('Hub diagnostics are bounded/redacted/private and absent from Settings IPC', 'MAX_LOG_BYTES: u64 = 1024 * 1024' in startup and 'pub(crate) fn redact_text' in startup and '[REDACTED_GITHUB_TOKEN]' in startup and '\"client_secret\"' in startup and 'restrict_log_permissions' in startup and 'runtime_log_tail' not in lib and 'open_runtime_logs' not in lib and 'runtimeLogTail' not in api_ts and 'openRuntimeLogs' not in settings_view and 'openTechnicalLogs' not in settings_view and 'diagnosticsPreview' not in settings_view)
    check('Hub main WebView is the only privileged Tauri WebView', '"webviews"' in text('src-tauri/capabilities/default.json') and '"main"' in text('src-tauri/capabilities/default.json') and '"windows"' not in text('src-tauri/capabilities/default.json'))
    check('Hub frontend production-build regressions are guarded',
          all(copy_ts.count(f'{key}:') == 2 for key in ['myCommunityRequests','noMyCommunityRequests','requestPending','requestApproved','requestRejected'])
          and 'runtimeLogTail' not in api_ts
          and 'disabled={!feed?.has_more}' in freelancer_view)
    check('Plan, Alertas and Downloads share one icon-only utility row with accessible labels', 'grid grid-cols-3 gap-1' in shell_ts and shell_ts.count('<UtilityNavButton') == 3 and 'title={label} aria-label={label}' in shell_ts and "<UtilityNavButton active={tab==='plans'} icon=\"heart\"" in shell_ts and '<UtilityNavButton active={alertsOpen} icon="bell"' in shell_ts and '<UtilityNavButton active={downloadsOpen} icon="download"' in shell_ts)
    hub_release=text('src-tauri/src/hub_releases.rs'); about=text('src/jingu/views/AboutView.tsx')
    check('Public release reads reuse authenticated GitHub budget while Freelancer browsing stays cache/Continuity-first', all(token in hub_release for token in ['let token = if crate::github::cached_user().is_some()','crate::github::access_token().await.ok()','token.as_deref()']) and all(token in engine for token in ['let public_token = if crate::github::cached_user().is_some()','crate::github::access_token().await.ok()','public_token.as_deref()']) and 'let feed = live_feed(&app, page, &sort, creator.as_deref(), false).await;' in freelancers and 'github_public_feed_fallback(&app, page, sort, creator).await' in freelancers)
    check('Empty public release repositories are valid without README bootstrap', 'StatusCode::CONFLICT' in hub_release and 'StatusCode::CONFLICT' in engine)
    membership=text('src-tauri/src/membership.rs')
    check('Freelancer membership architecture is server-authoritative with safe Free fallback', all(token in freelancers for token in ['CURRENT_SCHEMA: u32 = 5','FREE_SUMMARY_MAX: usize = 180','FREE_DESCRIPTION_MAX: usize = 3_000','profile.active_post_limit','profile.summary_max_chars','profile.description_max_chars','DELETED_MARKER_PREFIX']) and 'const FREE_ACTIVE_POST_LIMIT: usize = 1' in membership and 'const FREE_ACTIVE_POST_LIMIT' not in public_fallback)
    check('Freelancer schema 5 stays strict while old/future contracts use the stable compatibility core', all(token in freelancers for token in ['metadata.schema != CURRENT_SCHEMA','decode_marker_compatible','legacy_display_id','compatible_geography','portfolio_url','contact_url','source_schema >= CURRENT_SCHEMA','compat_v5','u32::try_from','CURRENT_SCHEMA + 1']) and 'issue_reconciliation_ready' in public_fallback)
    cached_fixture = freelancers.split('fn cached_post', 1)[1] if 'fn cached_post' in freelancers else ''
    check('Freelancer schema 5 Rust cache fixture tracks canonical geography', all(token in cached_fixture for token in ['country_code: "BR".into()','country: "Brasil".into()','region_code: "BR-PI".into()','region: "Piauí".into()']) and 'debug_assert!(profile.summary_max_chars >= FREE_SUMMARY_MAX);' in freelancers and 'debug_assert!(profile.description_max_chars >= FREE_DESCRIPTION_MAX);' in public_fallback)
    models=text('src-tauri/src/models.rs'); settings_rs=text('src-tauri/src/settings.rs')
    check('GitHub remember-login and tray minimization default on', 'pub remember_github_login: bool' in models and 'remember_github_login: true' in models and 'fn default_minimize_to_tray() -> bool' in models and 'minimize_to_tray: default_minimize_to_tray()' in models and 'AtomicBool::new(true)' in github and 'configure_session_persistence' in github and 'if !session_persistence_enabled()' in github and 'configure_session_persistence(settings.remember_github_login)' in settings_rs and 'settings.remember_github_login' in settings_view)
    freelancer_seed=(ROOT/'../Infrastructure/GitHubSeeds/JinguHub-Freelancers/.github/workflows/sync-freelancer-labels.yml').resolve().read_text(encoding='utf-8-sig')
    check('Freelancer report labels are self-provisioned without manual bootstrap', 'JINGU_REPORT_V1 target=\\d+ reporter=\\d+' in freelancer_seed and 'reportDefinitions' in freelancer_seed and 'issues.createLabel' in freelancer_seed and not (ROOT/'../Infrastructure/GitHubSeeds/JinguHub-Freelancers/.github/workflows/bootstrap-labels.yml').resolve().exists())
    check('Repair36 Continuity degraded reconciliation state survives Hub fast/fallback feeds', 'invalid_managed_count: usize' in freelancers and 'feed.state != "degraded"' in freelancers and 'invalid_managed > 0' in public_fallback)
    check('Repair39 Freelancer reconciliation is periodic, auto-migrates old contracts and never auto-closes drift', 'Publicado pelo Jingu Hub.' in freelancers and 'managed_issue(issue)' in freelancers and "cron: '17 * * * *'" in freelancer_seed and 'upgradeIssueBody' in freelancer_seed and 'parsed.legacy' in freelancer_seed and 'jingu:reconcile-pending' in freelancer_seed and 'jingu:quota-excess' in freelancer_seed and 'markUnsupported' in freelancer_seed and 'closeInvalid' not in freelancer_seed and 'reconciler no longer closes Issues automatically' in freelancer_seed and "context.payload.action==='closed'" in freelancer_seed)
    check('Freelancer quota and display IDs fail closed on partial public inventory after TEST retirement', all(token in freelancers for token in ['MAX_CREATOR_PAGES: usize = 3','Hub recusou calcular o limite de anúncios a partir de uma lista truncada','MAX_ID_SCAN_PAGES: usize = 100','Hub recusou alocar um ID usando um inventário truncado','managed_display_id_from_body']) and 'let public = repository_target("public", true).await?' in freelancers and 'inventário Freelancer TEST autorizado' not in public_fallback)
    check('Repair36 Freelancer membership display stays coherent while paid enforcement remains authoritative', 'jingu-membership-changed' in freelancer_view and 'membership:JinguMembershipProfile|null' in freelancer_view and 'display_profile(force_refresh' in membership and 'current_profile()' in public_fallback)
    check('Freelancer UI removes LIVE subtitle and provides My Ads delete-only flow', 'myFreelancerPosts' in freelancer_view and 'deletePost' in freelancer_view and 'freelancersLive' not in freelancer_view and 'freelancersSubtitle' not in freelancer_view and 'editPost' not in freelancer_view)
    check('Freelancer irreversible delete contract removes update IPC and dead edit path', 'pub async fn freelancers_update' not in freelancers and 'freelancers::freelancers_update' not in lib and 'freelancersUpdate' not in api_ts and 'freelancerDeleteTypeId' in copy_ts and 'deleteConfirmation.trim()!==closingPost.display_id' in freelancer_view)
    plan_catalog=text('src/jingu/planCatalog.ts'); plans_view=text('src/jingu/views/PlansView.tsx'); plan_domain=text('src/jingu/planDomain.ts'); worker=(ROOT/'../Infrastructure/Cloudflare/JinguContinuity/worker.js').resolve().read_text(encoding='utf-8-sig'); schema=(ROOT/'../Infrastructure/Cloudflare/JinguContinuity/schema.sql').resolve().read_text(encoding='utf-8-sig'); icon_ts=text('src/jingu/components/Icon.tsx')
    check('Plans use exactly Free/Bronze/Silver/Gold with progressive limits and an outline-heart utility entry', all(token in plan_catalog for token in ["tier:'free'","activePosts:1","tier:'bronze'","activePosts:2","tier:'silver'","activePosts:3","tier:'gold'","activePosts:4","rgba(250,204,21"]) and 'diamond' not in plan_catalog.lower() and 'diamante' not in plan_catalog.lower() and 'style={{borderColor:plan.borderColor,background:plan.background}}' in plans_view and "<UtilityNavButton active={tab==='plans'} icon=\"heart\"" in shell_ts and 'xl:col-span-1' in plans_view and 'xl:col-span-3' in plans_view and 'heart:' in icon_ts)
    check('Plans are one-time multi-unit purchases without automatic renewal copy', 'Compra única · 31 dias por unidade · sem renovação automática' in copy_ts and 'addDays:' in copy_ts and 'chooseAmount:' in copy_ts and 'c.plansSubtitle' in plans_view and 'c.addDays' in plans_view and 'c.chooseAmount' in plans_view and 'Cancelamento' not in plans_view)
    check('Freelancer search and scope controls are in their intended locations', 'placeholder={c.freelancersSearch} value={query}' in freelancer_view and 'draftFilters.query' not in freelancer_view and "draftFilters.scope==='mine'" in freelancer_view and "scope:'mine'" in freelancer_view)
    check('Membership identity and lifetime are durable across GitHub username changes', '/v1/membership/public-id/' in membership and 'github_user_id INTEGER PRIMARY KEY' in worker and 'syncMembershipIdentity' in worker and 'releaseLoginCollision' in worker and 'lifetime INTEGER NOT NULL DEFAULT 0' in worker and 'cycle_ends_at IS NULL OR cycle_ends_at=?' in worker and '/v1/membership/public-id/${id}' in freelancer_seed and 'issue.user?.id' in freelancer_seed)
    check('Hub frontend stays compatible with ES2020 and avoids stale domain imports', '.at(' not in plans_view and '.at(' not in plan_domain and '.replaceAll(' not in all_source and 'allocations[allocations.length-1]' in plan_domain and 'resolveCheckoutDestination' in plans_view and 'allocationsFor' not in plans_view and 'export function allocationsFor' in plan_domain and "'5/13 frontend domain behavior'" in validator and "'6/13 frontend typecheck'" in validator)
    frontend_runner=text('scripts/run-frontend-domain-tests.mjs'); frontend_tests=text('tests/frontend_domain.test.mjs')
    check('Plans frontend behavior has measurable coverage gates', '--experimental-test-coverage' in frontend_runner and '--test-coverage-lines=80' in frontend_runner and '--test-coverage-branches=80' in frontend_runner and '--test-coverage-functions=85' in frontend_runner and 'transition preview mirrors server value-proration semantics' in frontend_tests)
    check('Public v1 checkout allowlist is InfinitePay-only', 'checkout.infinitepay.io' in membership and 'checkout.infinitepay.com.br' in membership and 'dodopayments' not in membership.lower() and 'dodopayments' not in text('src-tauri/src/payment_browser.rs').lower())
    check('Payment upstream failures are not mislabeled as GitHub outages', 'infinitepay checkout could not be created' in notifications.lower() and 'O provedor de pagamento não conseguiu iniciar o checkout' in notifications and 'dodo' not in notifications.lower())
    check('Public v1 TierFlow is BRL/InfinitePay-only and fail-closed', all(token in worker for token in ['/v1/payments/checkout','/v1/payments/preview','/v1/webhooks/infinitepay/','/v1/payments/return/infinitepay/','https://api.checkout.infinitepay.io/links','https://api.checkout.infinitepay.io/payment_check','JINGU_PAYMENT_SIGNING_SECRET','paymentCallbackToken','verifyPaymentCallbackToken','PAYMENT_DURATION_DAYS = 31','PAYMENT_PRICING_VERSION = 3',"PAYMENT_MARKET_BR = 'BR'","PAYMENT_PROVIDER_INFINITEPAY = 'infinitepay'","PAYMENT_CURRENCY_BR = 'BRL'",'payment_fulfillment_claims','membership_revision_claims','membership_transition_events','verified?.paid !== true','env.DB.batch([']) and 'DODO_' not in worker and 'dodopayments' not in worker.lower() and 'JINGU_PAYMENTS_INTL_ENABLED' not in worker and 'public_brl_only_payment_config' in membership and 'publicBrlCurrencies' in plans_view)
    check('Credits history is per user+tier, filterable and defensively capped', 'membership_manual_credit_events' in worker and 'GROUP BY github_user_id,tier' in worker and 'Math.min(1200' in worker and 'Math.min(1200' in about and "key={`${entry.github_login}:${entry.tier}`}" in about and 'subscriberFilter' in about and 'subscribersLoadError' in about and 'apoiador exibido nos créditos' not in about.lower())
    check('Continuity serves indexed paged Freelancer feeds with joined current membership projection', "path === '/v1/freelancers/feed'" in worker and 'FROM freelancer_projection p' in worker and 'LEFT JOIN membership_profiles m' in worker and 'LIMIT ? OFFSET ?' in worker and 'limit=31' in worker and 'rows.slice(0,30)' in worker and 'db.batch([' in worker)
    check('Public hot paths use safe cache/coalescing while GitHub private access stays conditional and fail-closed', 'edgeReadInflight' in worker and '__jingu_cache_variant' in worker and 'If-None-Match' in github and 'installations_refresh_gate' in github and 'private_repo_refresh_gate' in github and 'StatusCode::NOT_MODIFIED' in github)
    check('GitHub healthy account card hides redundant success copy and preserves a warning-only transient status path', '!installationHealthy' in github_view and 'c.permissionsOk' not in github_view and 'organizationSelection' in github_view and 'personalSelection' in github_view and 'accountStatusUnavailable' in github_view and 'c.githubStatusUnavailable' in github_view)
    check('Public payment configuration bypasses stale desktop/edge caches at checkout boundary', 'payment_config(force_refresh: Option<bool>)' in membership and '/v1/payments/config?fresh=1' in membership and 'paymentConfig:(forceRefresh=false)' in text('src/api/freelancers.ts') and 'api.paymentConfig(true)' in plans_view and "url.searchParams.get('fresh') === '1'" in worker)
    check('Public BRL arbitrary-value support remains server-authoritative', 'planAllocationAtPrice(unitPriceMinor, amountMinor)' in worker and 'supportAmountMinor' in worker and 'PAYMENT_DONATION_MIN_BR_MINOR = 100' in worker and "purpose === 'donation'" in worker)
    desktop_workflow=text('.github/workflows/desktop-build.yml')
    check('Repair5 Hub desktop CI is exactly Windows x64/ARM64 plus Linux x64/ARM64', all(job in desktop_workflow for job in ['windows-x64:','windows-arm64:','linux-x64:','linux-arm64:']) and 'macos-universal:' not in desktop_workflow and 'windows-11-vs2026-arm' in desktop_workflow and 'ubuntu-22.04-arm' in desktop_workflow)
    check('Repair4 startup rejects stale tiny window geometry and maximizes the Hub', 'StateFlags::MAXIMIZED' in text('src-tauri/src/lib.rs') and 'StateFlags::SIZE' not in text('src-tauri/src/lib.rs') and '.unminimize()' in text('src-tauri/src/lib.rs') and '.maximize()' in text('src-tauri/src/lib.rs'))
    check('Repair4 GitHub identity is remotely revalidated before titlebar reuse', 'SESSION_REMOTE_VALIDATION_TTL' in github and 'fetch_user(&token).await' in github and 'session_remote_validation_gate' in github and 'setGithubUser(null)' in shell_ts)
    check('Repair4 Freelancer refresh resolves current identity before mine-scope loading with no fixed post-write wait', 'const user=await refreshIdentity(true)' in freelancer_view and 'await load(page,sort,scope,user,true)' in freelancer_view and 'Promise.all([load(page,sort,scope,session' not in freelancer_view and 'waitForRemoteRefreshSettle' not in freelancer_view and 'live_feed(&app, page, &sort, creator.as_deref(), false).await' in freelancers)
    check('Payment currency routing is compile-time BRL/InfinitePay-only in public source', 'paymentCurrencyRoutes' in worker and "code:'BRL'" in worker and "provider:PAYMENT_PROVIDER_INFINITEPAY" in worker and 'DODO_' not in worker and 'JINGU_PAYMENTS_INTL_ENABLED' not in worker and 'public_brl_only_payment_config' in membership and 'publicBrlCurrencies' in plans_view and 'paymentRouteForCurrency' in worker and 'payment_config(Some(true)).await' in membership and "paymentCheckoutStart(effectiveTier,amountMinor,paymentCurrency,checkoutChoice.kind==='units'?unitCount:null)" in plans_view)
    check('Payments stay in the Jingu modal and Pix keeps checkout PII provider-direct', 'EmbeddedPaymentCheckout' in plans_view and 'pixCheckoutNotice' in plans_view and 'api.openHttpsUrl(currentUrl)' not in plans_view and 'body?.customer !== undefined' in worker and 'body?.address !== undefined' in worker and 'checkout.infinitepay.com.br' in worker and 'checkout.infinitepay.io' in worker)
    check('About is simplified with Jingu public contact', 'jinguengine@gmail.com' in about and 'hubTechnology' not in about and 'sourceTech' not in about)
    check('Community requests carry random display IDs and public timestamps', 'pub display_id: String' in community and 'pub created_at: String' in community and 'pub issue_number: u64' not in community and 'pub number: u64' not in community)
    # JSON syntax
    for p in ROOT.rglob('*.json'):
        if any(part in SKIP_PARTS for part in p.parts): continue
        try: json.loads(p.read_text(encoding='utf-8-sig')); ok=True; detail=''
        except Exception as e: ok=False; detail=str(e)
        check(f'json {p.relative_to(ROOT)}',ok,detail)
    profile=json.loads(text('release-profile.json')); print(f"\nHub v{profile.get('version','?')} [{profile.get('channel','?')}] static QA: {PASS} PASS / {FAIL} FAIL")
    return 1 if FAIL else 0
if __name__=='__main__': raise SystemExit(main())
