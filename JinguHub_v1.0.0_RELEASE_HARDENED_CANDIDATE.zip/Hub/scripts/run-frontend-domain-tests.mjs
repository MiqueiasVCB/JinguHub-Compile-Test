/**************************************************************************/
/*  run-frontend-domain-tests.mjs                                       */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { spawnSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const out=path.join(root,'.jingu-test-out','frontend-domain')
fs.rmSync(path.join(root,'.jingu-test-out'),{recursive:true,force:true})
fs.mkdirSync(out,{recursive:true})
const emptyTypeRoots=path.join(root,'.jingu-test-out','empty-types')
fs.mkdirSync(emptyTypeRoots,{recursive:true})
const tsc=path.join(root,'node_modules','typescript','bin','tsc')
const compile=spawnSync(process.execPath,[tsc,'src/jingu/planDomain.ts','src/jingu/currencyPresentation.ts','--target','ES2020','--module','ES2020','--moduleResolution','bundler','--lib','ES2020,DOM,DOM.Iterable','--strict','--skipLibCheck','--typeRoots',emptyTypeRoots,'--rootDir','src','--outDir',out],{cwd:root,stdio:'inherit'})
if(compile.status!==0){process.exit(compile.status??1)}
const run=spawnSync(process.execPath,['--experimental-test-coverage','--test',"--test-coverage-include=.jingu-test-out/frontend-domain/jingu/planDomain.js",'--test-coverage-lines=80','--test-coverage-branches=80','--test-coverage-functions=85','tests/frontend_domain.test.mjs','tests/checkout_concurrency.test.mjs'],{cwd:root,stdio:'inherit'})
fs.rmSync(path.join(root,'.jingu-test-out'),{recursive:true,force:true})
process.exit(run.status??1)
