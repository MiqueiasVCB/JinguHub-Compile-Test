/**************************************************************************/
/*  validate-bundle-size.mjs                                             */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import fs from 'node:fs'
import path from 'node:path'
import process from 'node:process'
import { gzipSync } from 'node:zlib'
import { fileURLToPath } from 'node:url'

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const dist=path.join(root,'dist')
const budget={minChunks:4,maxLargestRaw:780*1024,maxLargestGzip:240*1024,maxTotalGzip:320*1024,maxCssGzip:55*1024}
let pass=0,fail=0
function check(name,ok,detail=''){if(ok){pass++;console.log(`[PASS] ${name}${detail?` :: ${detail}`:''}`)}else{fail++;console.error(`[FAIL] ${name}${detail?` :: ${detail}`:''}`)}}
if(!fs.existsSync(dist)){console.error('[FAIL] Hub dist is missing. Run the production frontend build first.');process.exit(1)}
const files=[]
function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const full=path.join(dir,entry.name);entry.isDirectory()?walk(full):files.push(full)}}
walk(dist)
const rel=file=>path.relative(dist,file).split(path.sep).join('/')
const metrics=ext=>files.filter(file=>file.toLowerCase().endsWith(ext)).map(file=>{const data=fs.readFileSync(file);return{name:rel(file),raw:data.length,gzip:gzipSync(data,{level:9}).length}})
const js=metrics('.js'),css=metrics('.css'),maps=files.filter(file=>file.toLowerCase().endsWith('.map'))
const sum=(rows,key)=>rows.reduce((total,row)=>total+row[key],0),max=(rows,key)=>rows.reduce((value,row)=>Math.max(value,row[key]),0),kib=value=>(value/1024).toFixed(2)
check('Hub production bundle contains JavaScript',js.length>0,`${js.length} chunks`)
check('Hub keeps secondary views code-split',js.length>=budget.minChunks,`${js.length} >= ${budget.minChunks}`)
check('Hub largest JS raw chunk stays within budget',max(js,'raw')<=budget.maxLargestRaw,`${kib(max(js,'raw'))} KiB <= ${kib(budget.maxLargestRaw)} KiB`)
check('Hub largest JS gzip chunk stays within budget',max(js,'gzip')<=budget.maxLargestGzip,`${kib(max(js,'gzip'))} KiB <= ${kib(budget.maxLargestGzip)} KiB`)
check('Hub total JS gzip stays within budget',sum(js,'gzip')<=budget.maxTotalGzip,`${kib(sum(js,'gzip'))} KiB <= ${kib(budget.maxTotalGzip)} KiB`)
check('Hub total CSS gzip stays within budget',sum(css,'gzip')<=budget.maxCssGzip,`${kib(sum(css,'gzip'))} KiB <= ${kib(budget.maxCssGzip)} KiB`)
check('Hub production bundle contains no source maps',maps.length===0,maps.map(rel).join(', '))
check('Hub JS/CSS assets are non-empty',[...js,...css].every(row=>row.raw>0))
for(const row of [...js].sort((a,b)=>b.gzip-a.gzip).slice(0,8))console.log(`[INFO] ${row.name}: ${kib(row.raw)} KiB raw / ${kib(row.gzip)} KiB gzip`)
console.log(`HUB BUNDLE QA: ${pass} PASS / ${fail} FAIL / ${pass+fail} TOTAL`)
process.exit(fail?1:0)
