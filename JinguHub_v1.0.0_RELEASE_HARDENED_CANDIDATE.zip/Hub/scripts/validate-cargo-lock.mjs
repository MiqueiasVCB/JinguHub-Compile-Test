/**************************************************************************/
/*  validate-cargo-lock.mjs                                             */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const hub = path.resolve(here, '..')
const lockPath = path.join(hub, 'src-tauri', 'Cargo.lock')
const manifestPath = path.join(hub, 'src-tauri', 'Cargo.toml')
const [lock, manifest] = await Promise.all([
  readFile(lockPath, 'utf8'),
  readFile(manifestPath, 'utf8'),
])

function parsePackageBlocks(source) {
  const matches = [...source.matchAll(/^\[\[package\]\]\s*$/gm)]
  return matches.map((m, index) => {
    const start = m.index
    const end = index + 1 < matches.length ? matches[index + 1].index : source.length
    const block = source.slice(start, end)
    const name = block.match(/^name = "([^"]+)"$/m)?.[1]
    const version = block.match(/^version = "([^"]+)"$/m)?.[1]
    const depsSection = block.match(/^dependencies = \[\s*\n([\s\S]*?)^\]\s*$/m)?.[1] ?? ''
    const dependencies = [...depsSection.matchAll(/^\s*"([^"]+)"\s*,?\s*$/gm)].map((x) => x[1])
    return { name, version, dependencies, block }
  })
}

function parseManifestDependencies(source) {
  const result = new Set()
  let section = ''
  for (const raw of source.split(/\r?\n/)) {
    const line = raw.replace(/\s+#.*$/, '').trim()
    const header = line.match(/^\[([^\]]+)\]$/)
    if (header) {
      section = header[1]
      continue
    }
    const dependencySection = section === 'dependencies'
      || section === 'build-dependencies'
      || /^target\..+\.dependencies$/.test(section)
    if (!dependencySection || !line || line.startsWith('#')) continue
    const key = line.match(/^([A-Za-z0-9_-]+)\s*=/)?.[1]
    if (key) result.add(key)
  }
  return result
}

function dependencyName(dep) {
  return dep.match(/^(\S+)/)?.[1] ?? dep
}

function inlineFeatures(crate) {
  const escaped = crate.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const line = manifest.match(new RegExp(`^${escaped}\\s*=\\s*\\{([^}]*)\\}`, 'm'))?.[1] ?? ''
  return [...line.matchAll(/features\s*=\s*\[([^\]]*)\]/g)]
    .flatMap((m) => [...m[1].matchAll(/"([^"]+)"/g)].map((x) => x[1]))
}

const packages = parsePackageBlocks(lock)
const failures = []

if (!/^version = 4$/m.test(lock)) failures.push('Cargo.lock deve permanecer no formato version = 4')
if (packages.length === 0) failures.push('nenhum bloco [[package]] encontrado em Cargo.lock')
if (packages.some((p) => !p.name || !p.version)) failures.push('ha bloco [[package]] sem name/version')

const byName = new Map()
const byNameVersion = new Map()
for (let i = 0; i < packages.length; i += 1) {
  const pkg = packages[i]
  if (!byName.has(pkg.name)) byName.set(pkg.name, [])
  byName.get(pkg.name).push(i)
  const key = `${pkg.name}\u0000${pkg.version}`
  if (byNameVersion.has(key)) failures.push(`pacote duplicado no lock: ${pkg.name}@${pkg.version}`)
  byNameVersion.set(key, i)
}

const roots = packages
  .map((pkg, index) => ({ pkg, index }))
  .filter(({ pkg }) => pkg.name === 'jingu-hub')
if (roots.length !== 1) failures.push(`esperado exatamente 1 pacote raiz jingu-hub; encontrados ${roots.length}`)

function resolveDependency(dep, owner) {
  const match = dep.match(/^(\S+)(?:\s+(\d[^\s]*))?(?:\s+\(.+\))?$/)
  if (!match) {
    failures.push(`dependencia com formato inesperado em ${owner}: ${dep}`)
    return null
  }
  const [, name, version] = match
  if (version) {
    const exact = byNameVersion.get(`${name}\u0000${version}`)
    if (exact === undefined) failures.push(`dependencia ausente no lock: ${owner} -> ${name}@${version}`)
    return exact ?? null
  }
  const candidates = byName.get(name) ?? []
  if (candidates.length !== 1) {
    failures.push(`dependencia ambigua/ausente no lock: ${owner} -> ${name} (candidatos=${candidates.length})`)
    return null
  }
  return candidates[0]
}

const reachable = new Set()
if (roots.length === 1) {
  const queue = [roots[0].index]
  reachable.add(roots[0].index)
  while (queue.length > 0) {
    const index = queue.shift()
    const pkg = packages[index]
    for (const dep of pkg.dependencies) {
      const next = resolveDependency(dep, `${pkg.name}@${pkg.version}`)
      if (next !== null && !reachable.has(next)) {
        reachable.add(next)
        queue.push(next)
      }
    }
  }
}

const stale = packages
  .map((pkg, index) => ({ pkg, index }))
  .filter(({ index }) => roots.length === 1 && !reachable.has(index))
  .map(({ pkg }) => `${pkg.name}@${pkg.version}`)
  .sort()
if (stale.length > 0) {
  failures.push(`Cargo.lock contem ${stale.length} pacote(s) orfao(s)/obsoleto(s): ${stale.join(', ')}`)
}

// Validate the direct manifest/lock contract. The historical graph-only validator
// could report 561/561 reachable while Cargo still needed to rewrite the lock.
if (roots.length === 1) {
  const manifestDeps = parseManifestDependencies(manifest)
  const rootDeps = new Set(roots[0].pkg.dependencies.map(dependencyName))
  const missing = [...manifestDeps].filter((name) => !rootDeps.has(name)).sort()
  const extra = [...rootDeps].filter((name) => !manifestDeps.has(name)).sort()
  if (missing.length) failures.push(`dependencias do Cargo.toml ausentes no pacote raiz do lock: ${missing.join(', ')}`)
  if (extra.length) failures.push(`dependencias raiz do lock ausentes no Cargo.toml: ${extra.join(', ')}`)
}

// Manifest feature contracts are source-policy checks only. Do not infer the
// exact Cargo.lock package fingerprint from them: the official Cargo resolver
// is the authority for optional/transitive dependency resolution.
const tokioFeatures = inlineFeatures('tokio')
if (!tokioFeatures.includes('full')) {
  failures.push(`tokio deve manter features=["full"] nesta baseline; atual=${JSON.stringify(tokioFeatures)}`)
}

const reqwestFeatures = inlineFeatures('reqwest')
for (const expected of ['json', 'stream']) {
  if (!reqwestFeatures.includes(expected)) failures.push(`reqwest deve manter feature ${expected}`)
}
if (reqwestFeatures.includes('form')) {
  failures.push('reqwest/form nao deve ser reintroduzido: OAuth Device Flow usa encoder local auditavel')
}

if (failures.length > 0) {
  console.error('Cargo.lock/Cargo.toml invalido:')
  for (const failure of failures) console.error(` - ${failure}`)
  process.exit(42)
}

console.log('Cargo.lock + Cargo.toml: preflight estrutural OK (Cargo e a autoridade final)')
console.log(` - pacotes: ${packages.length}`)
console.log(` - alcancaveis a partir de jingu-hub: ${reachable.size}`)
console.log(' - pacotes orfaos/obsoletos: 0')
console.log(` - dependencias diretas sincronizadas: ${parseManifestDependencies(manifest).size}`)
console.log(` - tokio features: ${tokioFeatures.join(', ')}`)
console.log(` - reqwest features: ${reqwestFeatures.join(', ')}`)
