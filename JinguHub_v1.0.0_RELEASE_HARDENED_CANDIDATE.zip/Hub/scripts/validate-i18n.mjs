/**************************************************************************/
/*  validate-i18n.mjs                                                   */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here=path.dirname(fileURLToPath(import.meta.url))
const hub=path.resolve(here,'..')
const copyPath=path.join(hub,'src','jingu','copy.ts')
const generatedPath=path.join(hub,'src','jingu','godot_locale.generated.json')
const overridesPath=path.join(hub,'src','jingu','jingu_locale_overrides.json')

function fail(messages){
  console.error('i18n Jingu invalido:')
  for(const message of messages)console.error(` - ${message}`)
  process.exit(43)
}

const errors=[]
for(const file of [copyPath,generatedPath,overridesPath])if(!fs.existsSync(file))errors.push(`arquivo ausente: ${file}`)
if(errors.length)fail(errors)

const copy=fs.readFileSync(copyPath,'utf8')
if(copy.includes('const localeToCopy'))errors.push('fallback legado localeToCopy ainda existe')
if(!copy.includes('godotLocalePacks')||!copy.includes('jinguLocaleOverrides'))errors.push('camadas Godot/Jingu nao estao conectadas')
if(!copy.includes("if(locale==='pt')return {...pt,...godot,...jingu}"))errors.push('Português (Portugal) deve preservar fallback em português')
if(!copy.includes('return {...en,...godot,...jingu}'))errors.push('locales não portugueses devem usar inglês, nunca PT-BR, como fallback de chaves Jingu')
if(!copy.includes("new Set(['ar','he','fa'])"))errors.push('locales RTL ar/he/fa nao estao declarados')

const notificationsPath=path.join(hub,'src','jingu','notifications.ts')
if(!fs.existsSync(notificationsPath))errors.push(`arquivo ausente: ${notificationsPath}`)
else{
  const notifications=fs.readFileSync(notificationsPath,'utf8')
  if(!notifications.includes('looksPortuguese(raw)'))errors.push('notificações backend não possuem proteção contra vazamento PT-BR em outros idiomas')
  if(!notifications.includes("locale === 'pt_BR' || locale === 'pt'"))errors.push('notificações não preservam explicitamente a família portuguesa')
}

const generated=JSON.parse(fs.readFileSync(generatedPath,'utf8'))
const overrides=JSON.parse(fs.readFileSync(overridesPath,'utf8'))
const generatedLocales=Object.keys(generated).sort()
if(generatedLocales.length<30)errors.push(`catalogo empacotado insuficiente: ${generatedLocales.length} locales`)
if(!generatedLocales.includes('pt_BR'))errors.push('catalogo empacotado nao contem pt_BR')

const nonBase=generatedLocales.filter(locale=>locale!=='pt_BR')
for(const locale of nonBase){
  if(!overrides[locale])errors.push(`override Jingu ausente para ${locale}`)
  else if(Object.keys(overrides[locale]).length<30)errors.push(`override Jingu insuficiente para ${locale}: ${Object.keys(overrides[locale]).length} chaves`)
}

const optionLocales=[...copy.matchAll(/\{ value: '[^']+', locale: '([^']+)'/g)].map(match=>match[1])
const expectedOptions=new Set(['en',...generatedLocales])
if(optionLocales.length!==expectedOptions.size)errors.push(`seletor deve ter ${expectedOptions.size} idiomas; encontrado ${optionLocales.length}`)
for(const locale of expectedOptions)if(!optionLocales.includes(locale))errors.push(`idioma nao exposto no seletor: ${locale}`)
if(optionLocales[0]!=='pt_BR')errors.push('Português (Brasil) deve ser o primeiro/padrao')

// The Hub must be independently buildable. Engine PO files are a development
// source used only to regenerate the checked-in catalog, never a build input.
// If a full Engine checkout happens to be present we perform a non-fatal drift
// diagnostic so developers know when the snapshot can be refreshed.
const root=path.resolve(hub,'..')
const candidates=[
  process.env.JINGU_ENGINE_TRANSLATIONS,
  path.join(root,'Engine','editor','translations','editor'),
].filter(Boolean)
const engineLocales=candidates.find(candidate=>fs.existsSync(candidate))
if(engineLocales){
  // English is authored directly in copy.ts and intentionally is not part of
  // godot_locale.generated.json. Exclude en.po from the optional Engine drift
  // diagnostic so the built-in English catalog is not misreported as missing.
  const sourceLocales=fs.readdirSync(engineLocales).filter(name=>name.endsWith('.po')).map(name=>path.basename(name,'.po')).filter(locale=>locale!=='en').sort()
  const missingCurated=generatedLocales.filter(locale=>!sourceLocales.includes(locale))
  if(missingCurated.length){
    console.warn(`AVISO i18n: Engine local nao contem locale(s) curado(s) pelo Hub: ${missingCurated.join(', ')}.`)
  }
  const upstreamOnly=sourceLocales.filter(locale=>!generatedLocales.includes(locale))
  if(upstreamOnly.length){
    console.log(` - locales adicionais da Engine ainda nao curados/expostos pelo Hub: ${upstreamOnly.join(', ')}`)
  }
}

if(errors.length)fail(errors)
console.log('i18n Jingu OK')
console.log(` - idiomas no seletor: ${optionLocales.length}`)
console.log(` - catalogos empacotados no Hub: ${generatedLocales.length}`)
console.log(` - overrides Jingu curados: ${Object.keys(overrides).length}`)
console.log(` - valores Godot reutilizados: ${Object.values(generated).reduce((sum,pack)=>sum+Object.keys(pack).length,0)}`)
console.log(' - dependencia da pasta Engine durante build: nenhuma')
