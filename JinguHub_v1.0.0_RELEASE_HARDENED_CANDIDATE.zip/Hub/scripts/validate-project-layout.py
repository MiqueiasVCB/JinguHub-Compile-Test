#!/usr/bin/env python3
# ************************************************************************
#  validate-project-layout.py
# ************************************************************************
#                         This file is part of:
#                              JINGU HUB
#                        https://github.com/JinguEngine
# ************************************************************************
# Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
# Licensed under the MIT License. See LICENSE.
# ************************************************************************
"""Validate a supported Jingu workspace layout without coupling Hub to siblings."""
from __future__ import annotations
import argparse
from pathlib import Path

HUB = Path(__file__).resolve().parents[1]
DEFAULT_ROOT = HUB.parent
KNOWN_DIRS = {"Hub", "Engine", "Manager", "Infrastructure", "scripts"}
KNOWN_ROOT_FILES = {
    "VALIDAR_JINGU_COMPLETO.cmd",
    "README_WORKSPACE_V1_0_0.md",
    "SECURITY_REVIEW_V1_0_0.md",
}

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=DEFAULT_ROOT)
    parser.add_argument('--require-engine', action='store_true')
    args = parser.parse_args()
    root = args.root.resolve()
    hub = root / 'Hub'
    engine = root / 'Engine'
    if hub.resolve() != HUB.resolve():
        raise SystemExit(f'Hub esperado em {hub}; script atual pertence a {HUB}')
    if not hub.is_dir():
        raise SystemExit(f'Hub/ ausente em {root}')
    if args.require_engine and not engine.is_dir():
        raise SystemExit(f'Engine/ ausente em {root}')
    unexpected = sorted(
        p.name for p in root.iterdir()
        if not (p.is_dir() and p.name in KNOWN_DIRS)
        and not (p.is_file() and p.name in KNOWN_ROOT_FILES)
    )
    if unexpected:
        print('Aviso: itens adicionais na raiz não são dependências do Hub: ' + ', '.join(unexpected))
    print(f'Layout Jingu compatível: {root}')
    print(' - Hub/ (obrigatório)')
    if (root/'Manager').is_dir(): print(' - Manager/ (workspace administrativo separado)')
    if engine.is_dir(): print(' - Engine/ (opcional ao build do Hub)')
    print(' - Hub continua compilável sem Engine/ ou Manager/.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
