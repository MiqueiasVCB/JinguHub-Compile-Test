#!/usr/bin/env python3
# ************************************************************************
#  validate-source-headers.py
# ************************************************************************
#                         This file is part of:
#                              JINGU HUB
#                        https://github.com/JinguEngine
# ************************************************************************
# Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
# Licensed under the MIT License. See LICENSE.
# ************************************************************************
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
EXEMPT={"src/vite-env.d.ts","src-tauri/build.rs"}
UPSTREAM_DERIVED={
    'index.html',
    'src-tauri/Cargo.toml',
    'src-tauri/src/error.rs',
    'src-tauri/src/git.rs',
    'src-tauri/src/git_helpers.rs',
    'src-tauri/src/godot_versions.rs',
    'src-tauri/src/godotenv.rs',
    'src-tauri/src/lib.rs',
    'src-tauri/src/main.rs',
    'src-tauri/src/models.rs',
    'src-tauri/src/persist.rs',
    'src-tauri/src/projects.rs',
    'src-tauri/src/settings.rs',
    'src-tauri/src/terminal.rs',
    'src-tauri/src/tray.rs',
    'src/App.tsx',
    'src/ErrorBoundary.tsx',
    'src/api/git.ts',
    'src/api/projects.ts',
    'src/api/settings.ts',
    'src/api/versions.ts',
    'src/index.css',
    'src/lib/api.ts',
    'src/main.tsx',
    'src/types.ts',
    'vite.config.ts',
 }
EXPLICIT={'.github/workflows/desktop-build.yml','index.html','src-tauri/Cargo.toml','THIRD_PARTY_NOTICES.md'}
SUFFIXES={'.ts','.tsx','.rs','.mjs','.py','.sh','.ps1','.cmd','.css'}
SKIP={'node_modules','target','dist','.jingu-test-out'}
def targets():
    rows=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or any(part in SKIP for part in p.parts): continue
        rel=p.relative_to(ROOT).as_posix()
        if rel in EXEMPT: continue
        if p.suffix.lower() in SUFFIXES or rel in EXPLICIT: rows.append((rel,p))
    return sorted(rows)
fail=[];count=0;upstream=0
for rel,p in targets():
    text=p.read_text(encoding='utf-8-sig',errors='replace')
    head=text[:2400]
    count+=1
    if 'This file is part of:' not in head or 'JINGU HUB' not in head or 'Miquéias Veloso' not in head or 'MIT License' not in head:
        fail.append(f'{rel}: cabeçalho Jingu ausente/incompleto');continue
    if rel in UPSTREAM_DERIVED:
        upstream+=1
        if 'GodotHub' not in head or 'Rayyan Aziz' not in head or 'THIRD_PARTY_NOTICES.md' not in head:
            fail.append(f'{rel}: atribuição upstream GodotHub ausente')

# Central license/provenance files are part of the same gate so a future cleanup
# cannot accidentally preserve source banners while deleting the actual upstream
# license text they reference.
notice=(ROOT/'THIRD_PARTY_NOTICES.md').read_text(encoding='utf-8-sig',errors='ignore') if (ROOT/'THIRD_PARTY_NOTICES.md').exists() else ''
upstream_license=(ROOT/'legal/GODOTHUB_LICENSE.txt').read_text(encoding='utf-8-sig',errors='ignore') if (ROOT/'legal/GODOTHUB_LICENSE.txt').exists() else ''
jingu_license=(ROOT/'LICENSE').read_text(encoding='utf-8-sig',errors='ignore') if (ROOT/'LICENSE').exists() else ''
if not all(token in notice for token in ['GodotHub','Rayyan Aziz','legal/GODOTHUB_LICENSE.txt','MIT License']):
    fail.append('THIRD_PARTY_NOTICES.md: atribuição/licença GodotHub incompleta')
if not all(token in upstream_license for token in ['MIT License','Copyright (c) 2026 Rayyan Aziz','Permission is hereby granted']):
    fail.append('legal/GODOTHUB_LICENSE.txt: licença upstream MIT ausente/incompleta')
if 'This file is part of:' in upstream_license:
    fail.append('legal/GODOTHUB_LICENSE.txt: licença upstream foi modificada com cabeçalho Jingu')
if not all(token in jingu_license for token in ['MIT License','Miquéias Veloso','Permission is hereby granted']):
    fail.append('LICENSE: licença Jingu MIT ausente/incompleta')
# Structured formats must remain machine-readable; never inject banners into JSON
# or lock files merely to satisfy the source-header policy.
for p in ROOT.rglob('*'):
    if not p.is_file() or any(part in SKIP for part in p.parts): continue
    if p.suffix.lower() in {'.json','.lock','.png','.ico','.icns'} or p.name in {'Cargo.lock','package-lock.json'}:
        if p.suffix.lower() in {'.json','.lock'} or p.name in {'Cargo.lock','package-lock.json'}:
            head=p.read_text(encoding='utf-8-sig',errors='ignore')[:400]
            if 'This file is part of:' in head: fail.append(f'{p.relative_to(ROOT).as_posix()}: formato estruturado recebeu cabeçalho indevido')

# Generated/structured upstream files must not be modified merely to carry a comment.
for rel in EXEMPT:
    p=ROOT/rel
    if p.exists() and 'This file is part of:' in p.read_text(encoding='utf-8-sig',errors='ignore')[:1200]:
        fail.append(f'{rel}: arquivo upstream/generated isento recebeu cabeçalho indevido')
if fail:
    for item in fail: print('[FAIL]',item)
    print(f'SOURCE HEADER QA: {count-len(fail)} PASS / {len(fail)} FAIL')
    sys.exit(1)
print(f'SOURCE HEADER QA: {count} arquivos Jingu validados; {upstream} com atribuição GodotHub preservada')
