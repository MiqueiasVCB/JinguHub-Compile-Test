#!/usr/bin/env python3
# ************************************************************************
#  validate-source-manifest.py
# ************************************************************************
#                         This file is part of:
#                              JINGU HUB
#                        https://github.com/JinguEngine
# ************************************************************************
# Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
# Licensed under the MIT License. See LICENSE.
# ************************************************************************
"""Verify that the extracted Jingu Hub source matches the shipped baseline.

Generated/build directories, Tauri schema output and runtime logs are intentionally
ignored. Everything else in the source package is hashed, so mixing files from
different internal revisions is detected before Cargo/npm spend time compiling.
"""
from __future__ import annotations

import hashlib
import re
import sys
from pathlib import Path

HUB = Path(__file__).resolve().parents[1]
MANIFEST = HUB / "SOURCE_MANIFEST.sha256"

EXCLUDED_DIRS = {
    ".git",
    ".jingu-build",
    "node_modules",
    "dist",
    "dist-ssr",
    "target",
    "Exports",
    "Release",
    "Diagnostics",
    "__pycache__",
}
IGNORED_ROOT_PATTERNS = (
    re.compile(r"^build-hub-.*\.log$", re.IGNORECASE),
    re.compile(r"^runtime-diagnostic-.*\.log$", re.IGNORECASE),
)
SELF_EXCLUDED = {"SOURCE_MANIFEST.sha256"}
# Tauri schema output is reproducible build output. Keep the exclusion narrow:
# arbitrary files under src-tauri/gen are NOT ignored.
GENERATED_PREFIXES = {("src-tauri", "gen", "schemas")}
GENERATED_FILES: set[str] = {"src-tauri/continuity_endpoint.txt"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_ignored(path: Path) -> bool:
    rel = path.relative_to(HUB)
    rel_posix = rel.as_posix()
    if rel_posix in SELF_EXCLUDED or rel_posix in GENERATED_FILES:
        return True
    if any(rel.parts[: len(prefix)] == prefix for prefix in GENERATED_PREFIXES):
        return True
    if any(part in EXCLUDED_DIRS for part in rel.parts):
        return True
    if len(rel.parts) == 1 and any(p.fullmatch(rel.name) for p in IGNORED_ROOT_PATTERNS):
        return True
    return False


def load_manifest() -> dict[str, str]:
    if not MANIFEST.is_file():
        raise RuntimeError("SOURCE_MANIFEST.sha256 não foi encontrado.")
    expected: dict[str, str] = {}
    for number, raw in enumerate(MANIFEST.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = re.fullmatch(r"([0-9a-fA-F]{64})  (.+)", line)
        if not match:
            raise RuntimeError(f"Linha inválida no manifesto: {number}")
        digest, rel = match.groups()
        normalized = Path(rel).as_posix()
        if normalized.startswith("../") or normalized.startswith("/"):
            raise RuntimeError(f"Caminho inseguro no manifesto: {rel}")
        if normalized in expected:
            raise RuntimeError(f"Entrada duplicada no manifesto: {normalized}")
        expected[normalized] = digest.lower()
    if not expected:
        raise RuntimeError("SOURCE_MANIFEST.sha256 está vazio.")
    return expected


def main() -> int:
    try:
        expected = load_manifest()
    except Exception as exc:
        print(f"ERRO: {exc}", file=sys.stderr)
        return 2

    missing: list[str] = []
    changed: list[str] = []
    for rel, expected_hash in sorted(expected.items()):
        path = HUB / Path(rel)
        if not path.is_file():
            missing.append(rel)
            continue
        if sha256(path) != expected_hash:
            changed.append(rel)

    actual = {
        path.relative_to(HUB).as_posix()
        for path in HUB.rglob("*")
        if path.is_file() and not is_ignored(path)
    }
    unexpected = sorted(actual - set(expected))

    if missing or changed or unexpected:
        print("ERRO: a árvore do Hub não corresponde à baseline distribuída.", file=sys.stderr)
        if missing:
            print("Arquivos ausentes:", file=sys.stderr)
            for rel in missing:
                print(f"  - {rel}", file=sys.stderr)
        if changed:
            print("Arquivos alterados:", file=sys.stderr)
            for rel in changed:
                print(f"  - {rel}", file=sys.stderr)
        if unexpected:
            print("Arquivos inesperados:", file=sys.stderr)
            for rel in unexpected:
                print(f"  - {rel}", file=sys.stderr)
        return 1

    print(f"Baseline de fonte OK: {len(expected)} arquivos verificados por SHA-256.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
