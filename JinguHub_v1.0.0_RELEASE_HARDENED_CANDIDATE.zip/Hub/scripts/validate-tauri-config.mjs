/**************************************************************************/
/*  validate-tauri-config.mjs                                           */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const hub = path.resolve(here, '..')
const args = process.argv.slice(2)
let requested = null
let targetPlatform = process.platform
for (let i = 0; i < args.length; i += 1) {
  const arg = args[i]
  if (arg === '--platform') {
    const value = args[++i]
    if (!value) failEarly('--platform exige win32, linux ou darwin')
    targetPlatform = value
  } else if (arg.startsWith('--platform=')) {
    targetPlatform = arg.slice('--platform='.length)
  } else if (!requested) {
    requested = arg.trim()
  } else {
    failEarly(`argumento desconhecido: ${arg}`)
  }
}
if (!['win32', 'linux', 'darwin'].includes(targetPlatform)) failEarly(`plataforma invalida: ${targetPlatform}`)

function failEarly(message) {
  console.error(`Tauri config invalida: ${message}`)
  process.exit(1)
}
const basePath = path.join(hub, 'src-tauri', 'tauri.conf.json')
const sourcePath = path.join(hub, 'src-tauri', 'src', 'lib.rs')
const capabilityPath = path.join(hub, 'src-tauri', 'capabilities', 'default.json')

const platformFile = targetPlatform === 'win32'
  ? 'tauri.windows.conf.json'
  : targetPlatform === 'darwin'
    ? 'tauri.macos.conf.json'
    : targetPlatform === 'linux'
      ? 'tauri.linux.conf.json'
      : null

function fail(message) {
  console.error(`Tauri config invalida: ${message}`)
  process.exit(1)
}

function isObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value)
}

function merge(base, overlay) {
  if (!isObject(base) || !isObject(overlay)) return structuredClone(overlay)
  const out = structuredClone(base)
  for (const [key, value] of Object.entries(overlay)) {
    out[key] = key in out && isObject(out[key]) && isObject(value)
      ? merge(out[key], value)
      : structuredClone(value)
  }
  return out
}

async function parseJson(configPath) {
  try {
    return JSON.parse(await readFile(configPath, 'utf8'))
  } catch (error) {
    fail(`${path.basename(configPath)} nao pode ser lido/parseado: ${error}`)
  }
}

let config
let displayPath
if (requested) {
  const configPath = path.resolve(hub, requested)
  config = await parseJson(configPath)
  displayPath = configPath
} else {
  config = await parseJson(basePath)
  if (platformFile) {
    const platformPath = path.join(hub, 'src-tauri', platformFile)
    const platformConfig = await parseJson(platformPath)
    config = merge(config, platformConfig)
    displayPath = `${basePath} + ${platformPath}`
  } else {
    displayPath = basePath
  }
}

const lib = await readFile(sourcePath, 'utf8')
const capability = await parseJson(capabilityPath)
const capabilityText = JSON.stringify(capability)
if (config.productName !== 'Jingu Hub') fail('productName deve ser "Jingu Hub"')
if (config.identifier !== 'dev.jingu.hub') fail('identifier deve ser "dev.jingu.hub"')
if (!Array.isArray(config.app?.windows) || config.app.windows.length < 1) fail('app.windows deve conter a janela principal')
if (config.app.windows[0]?.visible !== true) fail('a janela principal deve iniciar visivel')
if (config.bundle?.active !== true) fail('bundle.active deve permanecer true')

const targets = config.bundle?.targets
if (!Array.isArray(targets) || targets.length === 0) {
  fail('a configuracao final da plataforma deve declarar pelo menos um bundle target')
}
if (targetPlatform === 'win32' && !targets.includes('nsis')) fail('Windows deve gerar bundle NSIS')
if (targetPlatform === 'linux') {
  for (const expected of ['appimage', 'deb', 'rpm']) if (!targets.includes(expected)) fail(`Linux deve gerar ${expected}`)
}
if (targetPlatform === 'darwin') {
  for (const expected of ['app', 'dmg']) if (!targets.includes(expected)) fail(`macOS deve gerar ${expected}`)
}

if (targetPlatform === 'win32') {
  const nsis = config.bundle?.windows?.nsis
  if (!isObject(nsis)) fail('bundle.windows.nsis deve existir no Windows')
  if (nsis.installMode !== 'currentUser') fail('NSIS deve usar installMode=currentUser para instalacao sem elevacao')
}

// R22 deliberately uses manual Hub updates through GitHub Releases.
// Self-updater configuration must not silently return to the runtime.
if (lib.includes('tauri_plugin_updater::')) fail('tauri-plugin-updater foi removido da arquitetura R22')
if (config.plugins?.updater != null) fail('plugins.updater nao deve existir na arquitetura R22')
if (config.bundle?.createUpdaterArtifacts === true) fail('createUpdaterArtifacts nao deve ser habilitado na arquitetura R22')
if (capabilityText.includes('updater:')) fail('capabilities nao podem conter permissoes do Tauri updater na arquitetura R22')

console.log('Configuracao Tauri/runtime OK')
console.log(` - arquivo(s): ${displayPath.split(hub).join('.')}`)
console.log(` - product: ${config.productName}`)
console.log(` - identifier: ${config.identifier}`)
console.log(` - platform: ${targetPlatform}`)
console.log(` - targets: ${targets.join(', ')}`)
console.log(' - Hub update mode: GitHub Release manual (sem Tauri updater)')
