# ************************************************************************
#  windows-msvc-toolchain.ps1
# ************************************************************************
#                         This file is part of:
#                              JINGU HUB
#                         and JINGU MANAGER
#                        https://github.com/JinguEngine
# ************************************************************************
# Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
# Licensed under the MIT License. See LICENSE.
# ************************************************************************
# Shared Windows MSVC discovery/bootstrap helper. This helper never installs
# software; it imports an existing Visual Studio Developer environment into the
# current PowerShell process when necessary.

function Get-JinguCommandPath {
    param([Parameter(Mandatory=$true)][string]$Name)
    $command = Get-Command $Name -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $command) { return $null }
    if (-not [string]::IsNullOrWhiteSpace($command.Path)) { return $command.Path }
    if (-not [string]::IsNullOrWhiteSpace($command.Source)) { return $command.Source }
    return [string]$command.Name
}

function Get-JinguRequiredMsvcTools {
    return @('cl.exe','link.exe','lib.exe','rc.exe','mt.exe')
}

function Get-JinguMissingMsvcTools {
    $missing = @()
    foreach ($name in @(Get-JinguRequiredMsvcTools)) {
        if ([string]::IsNullOrWhiteSpace((Get-JinguCommandPath $name))) { $missing += $name }
    }
    return @($missing)
}

function Get-JinguVsWherePath {
    $visible = Get-JinguCommandPath 'vswhere.exe'
    if (-not [string]::IsNullOrWhiteSpace($visible)) { return $visible }

    $candidates = @()
    $pf86 = [Environment]::GetFolderPath('ProgramFilesX86')
    $pf = [Environment]::GetFolderPath('ProgramFiles')
    if (-not [string]::IsNullOrWhiteSpace($pf86)) { $candidates += (Join-Path $pf86 'Microsoft Visual Studio\Installer\vswhere.exe') }
    if (-not [string]::IsNullOrWhiteSpace($pf)) { $candidates += (Join-Path $pf 'Microsoft Visual Studio\Installer\vswhere.exe') }
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    return $null
}

function Get-JinguVsDevArchitecture {
    $arch = [string]$env:PROCESSOR_ARCHITECTURE
    switch ($arch.ToUpperInvariant()) {
        'ARM64' { return 'arm64' }
        'X86' { return 'x86' }
        default { return 'x64' }
    }
}

function Import-JinguVsDeveloperEnvironment {
    param([Parameter(Mandatory=$true)][string]$VsDevCmd)
    $comSpec = [string]$env:ComSpec
    if ([string]::IsNullOrWhiteSpace($comSpec)) { $comSpec = 'cmd.exe' }
    $arch = Get-JinguVsDevArchitecture
    $commandLine = 'call "' + $VsDevCmd.Replace('"','""') + '" -no_logo -arch=' + $arch + ' -host_arch=' + $arch + ' >nul && set'
    $oldPreference = $ErrorActionPreference
    $lines = @()
    try {
        $ErrorActionPreference = 'Continue'
        $lines = @(& $comSpec /d /s /c $commandLine 2>&1)
        $code = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $oldPreference }
    if ($code -ne 0) {
        $tail = (@($lines | Select-Object -Last 8) -join ' | ')
        throw "VsDevCmd.bat falhou (exit $code). $tail"
    }
    foreach ($raw in $lines) {
        $line = [string]$raw
        $index = $line.IndexOf('=')
        if ($index -le 0) { continue }
        $name = $line.Substring(0,$index)
        $value = $line.Substring($index + 1)
        [Environment]::SetEnvironmentVariable($name,$value,'Process')
    }
}

function Initialize-JinguWindowsMsvcToolchain {
    if ($env:OS -ne 'Windows_NT') { throw 'Este helper MSVC deve ser executado no Windows.' }

    $missingBefore = @(Get-JinguMissingMsvcTools)
    if ($missingBefore.Count -eq 0) {
        return [pscustomobject]@{ Source='environment'; InstallationPath=$null; MissingBefore=@(); Tools=@(Get-JinguRequiredMsvcTools) }
    }

    $vswhere = Get-JinguVsWherePath
    if ([string]::IsNullOrWhiteSpace($vswhere)) {
        throw ('Visual Studio Build Tools nao encontrado (vswhere.exe ausente). Ferramentas MSVC ausentes: ' + ($missingBefore -join ', ') + '. Instale Visual Studio Build Tools com Desktop development with C++ / Microsoft.VisualStudio.Workload.VCTools, ferramentas MSVC da arquitetura nativa e Windows SDK.')
    }

    $targetArch = Get-JinguVsDevArchitecture
    $component = if ($targetArch -eq 'arm64') { 'Microsoft.VisualStudio.Component.VC.Tools.ARM64' } else { 'Microsoft.VisualStudio.Component.VC.Tools.x86.x64' }
    $oldPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $installLines = @(& $vswhere -latest -products * -requires $component -property installationPath 2>&1)
        $vswhereCode = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $oldPreference }
    $installationPath = @($installLines | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -First 1)
    if ($vswhereCode -ne 0 -or $installationPath.Count -eq 0) {
        throw ("Visual Studio foi detectado, mas o componente C++ MSVC exigido para {0} nao foi encontrado ({1}). Instale/repare Microsoft.VisualStudio.Workload.VCTools com os componentes recomendados e o Windows SDK." -f $targetArch,$component)
    }
    $installation = [string]$installationPath[0]
    $vsDevCmd = Join-Path $installation 'Common7\Tools\VsDevCmd.bat'
    if (-not (Test-Path -LiteralPath $vsDevCmd -PathType Leaf)) {
        throw ('VsDevCmd.bat ausente na instalacao detectada: ' + $installation)
    }

    Import-JinguVsDeveloperEnvironment -VsDevCmd $vsDevCmd
    $missingAfter = @(Get-JinguMissingMsvcTools)
    if ($missingAfter.Count -gt 0) {
        throw ('Ambiente MSVC incompleto apos VsDevCmd: ' + ($missingAfter -join ', ') + '. Repare/instale Visual Studio Build Tools com VCTools e Windows SDK.')
    }
    return [pscustomobject]@{ Source='VsDevCmd'; InstallationPath=$installation; MissingBefore=$missingBefore; Tools=@(Get-JinguRequiredMsvcTools) }
}
