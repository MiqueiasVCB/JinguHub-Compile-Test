/**************************************************************************/
/*  community.rs                                                        */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use crate::{paths, persist};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::HashSet;
use std::sync::{
    atomic::{AtomicBool, Ordering},
    OnceLock,
};
use std::time::Duration;
use tauri::{AppHandle, Emitter};

const BUNDLED_CATALOG: &str = include_str!("../community_catalog.default.json");
const CACHE_FILE: &str = "community-catalog-cache.json";
const CURRENT_CATALOG_SCHEMA: u32 = 1;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommunityRequestInput {
    pub name: String,
    #[serde(default)]
    pub country: String,
    pub region: String,
    pub description: String,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default)]
    pub links: Vec<CommunityLink>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommunityRequestResult {
    #[serde(default)]
    pub display_id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommunityRequestRow {
    #[serde(default)]
    pub display_id: String,
    pub author: String,
    pub avatar_url: String,
    pub created_at: String,
    pub html_url: String,
    pub proposed_id: String,
    pub name: String,
    pub region: String,
    pub country: String,
    pub description: String,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default)]
    pub links: Vec<CommunityLink>,
    pub status: String,
}

fn validate_request(input: &CommunityRequestInput) -> Result<(), String> {
    if input.name.trim().chars().count() < 2 || input.name.trim().chars().count() > 120 {
        return Err("O nome da comunidade deve ter entre 2 e 120 caracteres.".into());
    }
    if input.country.trim().chars().count() < 2
        || input.country.trim().chars().count() > 80
        || input.region.trim().chars().count() > 100
        || input.description.trim().chars().count() < 20
        || input.description.trim().chars().count() > 1500
    {
        return Err("País, região ou descrição da comunidade é inválida.".into());
    }
    if input.tags.len() > 16
        || input
            .tags
            .iter()
            .any(|tag| tag.trim().is_empty() || tag.chars().count() > 40)
        || input.links.is_empty()
        || input.links.len() > 16
    {
        return Err("Use ao menos um link e no máximo 16 links/tags válidos.".into());
    }
    for link in &input.links {
        if link.label.trim().is_empty()
            || link.label.len() > 40
            || link.kind.trim().is_empty()
            || link.kind.len() > 30
            || link.url.len() > 2048
            || reqwest::Url::parse(&link.url).ok().is_none_or(|url| {
                url.scheme() != "https"
                    || url.username() != ""
                    || url.password().is_some()
                    || url.host_str().is_none()
            })
        {
            return Err("A solicitação contém um link inválido. Use somente HTTPS.".into());
        }
    }
    Ok(())
}

#[tauri::command]
pub async fn community_submit_request(
    mut input: CommunityRequestInput,
) -> Result<CommunityRequestResult, String> {
    input.name = input.name.trim().to_string();
    input.country = input.country.trim().to_string();
    input.region = input.region.trim().to_string();
    input.description = input.description.trim().to_string();
    input.tags = input
        .tags
        .into_iter()
        .map(|v| v.trim().to_string())
        .filter(|v| !v.is_empty())
        .collect();
    input.tags.sort();
    input.tags.dedup();
    validate_request(&input)?;

    // Privacy invariant: new community requests are never opened as public GitHub
    // Issues. The user's GitHub token is sent only to Jingu Continuity over HTTPS
    // so the Worker can verify the identity; the Worker never persists the token.
    let token = crate::github::access_token().await?;
    let body = serde_json::to_value(&input).map_err(|error| error.to_string())?;
    let value = crate::continuity::request_json(
        reqwest::Method::POST,
        "/v1/community-requests",
        Some(&token),
        Some(body),
    )
    .await?;
    serde_json::from_value(value)
        .map_err(|error| format!("Resposta inválida ao criar solicitação privada: {error}"))
}

#[tauri::command]
pub async fn community_my_requests() -> Result<Vec<CommunityRequestRow>, String> {
    let token = crate::github::access_token().await?;
    let value = crate::continuity::request_json(
        reqwest::Method::GET,
        "/v1/community-requests/mine",
        Some(&token),
        None,
    )
    .await?;
    serde_json::from_value(value)
        .map_err(|error| format!("Resposta inválida ao consultar solicitações privadas: {error}"))
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommunityLink {
    pub label: String,
    pub kind: String,
    pub url: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommunityEntry {
    pub id: String,
    #[serde(default)]
    pub created_at: String,
    pub name: String,
    #[serde(default)]
    pub country: String,
    pub region: String,
    pub description: String,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default)]
    pub links: Vec<CommunityLink>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommunityCatalog {
    pub schema: u32,
    pub updated_at: String,
    #[serde(default)]
    pub communities: Vec<CommunityEntry>,
}

impl Default for CommunityCatalog {
    fn default() -> Self {
        serde_json::from_str(BUNDLED_CATALOG).unwrap_or_else(|_| Self {
            schema: CURRENT_CATALOG_SCHEMA,
            updated_at: "bundled".into(),
            communities: Vec::new(),
        })
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct CommunityCatalogResult {
    pub source: String,
    pub stale: bool,
    pub updated_at: String,
    pub communities: Vec<CommunityEntry>,
}

fn cache_path(app: &AppHandle) -> std::path::PathBuf {
    paths::app_data_dir(app).join(CACHE_FILE)
}

fn validate_catalog(catalog: &CommunityCatalog) -> Result<(), String> {
    if catalog.schema != CURRENT_CATALOG_SCHEMA {
        return Err("Versão interna do catálogo de comunidades inválida.".into());
    }
    if catalog.communities.len() > 250 {
        return Err("Catálogo de comunidades excedeu o limite de segurança.".into());
    }
    let mut ids = HashSet::new();
    for community in &catalog.communities {
        if community.id.trim().is_empty()
            || community.id.len() > 80
            || !community
                .id
                .chars()
                .all(|ch| ch.is_ascii_lowercase() || ch.is_ascii_digit() || ch == '-')
            || community.name.trim().is_empty()
            || community.name.len() > 120
            || community.description.trim().is_empty()
            || community.description.len() > 1_500
            || community.country.len() > 80
            || community.region.len() > 100
            || community.tags.len() > 16
            || community
                .tags
                .iter()
                .any(|tag| tag.trim().is_empty() || tag.chars().count() > 40)
            || community.links.len() > 16
        {
            return Err("O catálogo remoto contém uma comunidade inválida.".into());
        }
        if !ids.insert(community.id.to_ascii_lowercase()) {
            return Err("O catálogo remoto contém IDs de comunidades duplicados.".into());
        }
        for link in &community.links {
            if link.label.trim().is_empty()
                || link.label.len() > 40
                || link.kind.trim().is_empty()
                || link.kind.len() > 30
                || link.url.len() > 2_048
                || reqwest::Url::parse(&link.url).ok().is_none_or(|url| {
                    url.scheme() != "https"
                        || url.username() != ""
                        || url.password().is_some()
                        || url.host_str().is_none()
                })
            {
                return Err("O catálogo remoto contém um link inválido.".into());
            }
        }
    }
    Ok(())
}

fn normalize_catalog_value(value: Value) -> Result<CommunityCatalog, String> {
    let source_schema = match value.get("schema") {
        None => CURRENT_CATALOG_SCHEMA as u64,
        Some(schema) => schema
            .as_u64()
            .ok_or_else(|| "Schema do catálogo de comunidades inválido.".to_string())?,
    };
    if source_schema == 0 || source_schema > u32::MAX as u64 {
        return Err("Schema do catálogo de comunidades inválido.".into());
    }

    // Compatibility boundary: older/missing schemas are normalized to
    // the stable v1 read model. Future major schemas stay readable when they are
    // additive or carry an explicit compat_v1 projection. Unknown extra fields
    // are ignored; changed core semantics fail closed without affecting users.
    let mut compatible = if source_schema > CURRENT_CATALOG_SCHEMA as u64 {
        value.get("compat_v1").cloned().unwrap_or(value)
    } else {
        value
    };
    let object = compatible
        .as_object_mut()
        .ok_or_else(|| "Catálogo de comunidades não é um objeto JSON.".to_string())?;
    object.insert("schema".into(), Value::from(CURRENT_CATALOG_SCHEMA));
    let catalog: CommunityCatalog = serde_json::from_value(compatible)
        .map_err(|error| format!("Catálogo de comunidades incompatível: {error}"))?;
    validate_catalog(&catalog)?;
    Ok(catalog)
}

fn client() -> Result<reqwest::Client, String> {
    static CLIENT: OnceLock<reqwest::Client> = OnceLock::new();
    if let Some(client) = CLIENT.get() {
        return Ok(client.clone());
    }
    let built = reqwest::Client::builder()
        .user_agent(format!("JinguHub/{}", crate::jingu::PRODUCT_VERSION))
        .connect_timeout(Duration::from_secs(3))
        .timeout(Duration::from_secs(8))
        .pool_idle_timeout(Duration::from_secs(300))
        .pool_max_idle_per_host(8)
        .tcp_keepalive(Duration::from_secs(30))
        .build()
        .map_err(|error| error.to_string())?;
    let _ = CLIENT.set(built.clone());
    Ok(CLIENT.get().cloned().unwrap_or(built))
}

async fn fetch_github_catalog() -> Result<CommunityCatalog, String> {
    // Manual refresh uses the GitHub Contents API rather than raw.githubusercontent.com,
    // avoiding CDN staleness when a tag was just removed from communities.json.
    let url = format!(
        "https://api.github.com/repos/{}/JinguHub-Community/contents/communities.json?ref=main",
        crate::jingu::GITHUB_OWNER
    );
    let response = crate::github::send_with_retry(
        client()?
            .get(url)
            .header("Accept", "application/vnd.github.raw+json")
            .header("X-GitHub-Api-Version", "2026-03-10")
            .header("Cache-Control", "no-cache"),
        "o carregamento autoritativo do catálogo de Comunidades",
    )
    .await?;
    if !response.status().is_success() {
        return Err(format!("HTTP {}", response.status()));
    }
    let bytes = response.bytes().await.map_err(|error| error.to_string())?;
    if bytes.len() > 512 * 1024 {
        return Err("catálogo remoto grande demais".into());
    }
    let value: Value = serde_json::from_slice(&bytes).map_err(|error| error.to_string())?;
    normalize_catalog_value(value)
}

async fn fetch_continuity_catalog(fresh: bool) -> Result<CommunityCatalog, String> {
    let value = crate::continuity::request_json(
        reqwest::Method::GET,
        if fresh {
            "/v1/snapshots/communities?fresh=1"
        } else {
            "/v1/snapshots/communities"
        },
        None,
        None,
    )
    .await?;
    let payload = value
        .get("payload")
        .cloned()
        .ok_or_else(|| "Snapshot público de Comunidades ausente.".to_string())?;
    normalize_catalog_value(payload)
        .map_err(|error| format!("Snapshot público de Comunidades inválido: {error}"))
}

fn persist_catalog(app: &AppHandle, catalog: &CommunityCatalog) {
    if let Err(error) = persist::write_json(&cache_path(app), catalog) {
        crate::startup::log(format!(
            "WARNING: could not persist community catalog cache: {error}"
        ));
    }
}

fn catalog_result(catalog: CommunityCatalog, source: &str, stale: bool) -> CommunityCatalogResult {
    CommunityCatalogResult {
        source: source.into(),
        stale,
        updated_at: catalog.updated_at,
        communities: catalog.communities,
    }
}

async fn refresh_catalog_network(app: &AppHandle) -> CommunityCatalogResult {
    // An explicit “Atualizar” must mean source-of-truth freshness. GitHub is the
    // canonical Community catalog, while Continuity is the low-latency public
    // projection. Reading GitHub first prevents a successful but not-yet-mirrored
    // D1 snapshot from making the refresh button appear ineffective.
    match fetch_github_catalog().await {
        Ok(catalog) => {
            persist_catalog(app, &catalog);
            catalog_result(catalog, "github", false)
        }
        Err(github_error) => {
            crate::startup::log(format!(
                "Community catalog GitHub refresh failed: {github_error}"
            ));
            match fetch_continuity_catalog(true).await {
                Ok(catalog) => {
                    persist_catalog(app, &catalog);
                    catalog_result(catalog, "continuity-fresh", false)
                }
                Err(edge_error) => {
                    crate::startup::log(format!(
                        "Community fresh Continuity fallback failed: {edge_error}"
                    ));
                    if let Some(catalog) = load_cache(app) {
                        return catalog_result(catalog, "cache", true);
                    }
                    catalog_result(bundled_catalog(), "bundled", true)
                }
            }
        }
    }
}

async fn refresh_catalog_edge(app: &AppHandle) -> CommunityCatalogResult {
    // Public reads are optimized for the Cloudflare mirror. GitHub remains the
    // authoritative source and is still used by explicit/manual refresh and by
    // the mirror workflow itself.
    match fetch_continuity_catalog(false).await {
        Ok(catalog) => {
            persist_catalog(app, &catalog);
            catalog_result(catalog, "continuity", false)
        }
        Err(error) => {
            crate::startup::log(format!("Community edge refresh failed: {error}"));
            refresh_catalog_network(app).await
        }
    }
}

fn catalog_refreshing() -> &'static AtomicBool {
    static REFRESHING: AtomicBool = AtomicBool::new(false);
    &REFRESHING
}

fn spawn_catalog_refresh(app: AppHandle) {
    if catalog_refreshing()
        .compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)
        .is_err()
    {
        return;
    }
    tauri::async_runtime::spawn(async move {
        let result = refresh_catalog_edge(&app).await;
        let _ = app.emit("jingu-community-refreshed", result);
        catalog_refreshing().store(false, Ordering::Release);
    });
}

pub(crate) fn prewarm(app: AppHandle) {
    spawn_catalog_refresh(app);
}

fn load_cache(app: &AppHandle) -> Option<CommunityCatalog> {
    let path = cache_path(app);
    if !path.is_file() {
        return None;
    }
    let catalog: CommunityCatalog = persist::read_json(&path);
    validate_catalog(&catalog).ok()?;
    Some(catalog)
}

fn bundled_catalog() -> CommunityCatalog {
    let catalog = CommunityCatalog::default();
    if let Err(error) = validate_catalog(&catalog) {
        crate::startup::log(format!(
            "WARNING: bundled community catalog failed validation: {error}"
        ));
        return CommunityCatalog {
            schema: CURRENT_CATALOG_SCHEMA,
            updated_at: "bundled-invalid".into(),
            communities: Vec::new(),
        };
    }
    catalog
}

#[tauri::command]
pub async fn community_catalog(app: AppHandle, force_refresh: bool) -> CommunityCatalogResult {
    // Navigation path: render the last validated catalog immediately, then
    // refresh silently in the background. Manual Refresh remains network-first.
    if !force_refresh {
        if let Some(catalog) = load_cache(&app) {
            spawn_catalog_refresh(app.clone());
            return catalog_result(catalog, "cache", false);
        }

        // First run: the Cloudflare edge mirror is substantially faster than a
        // full GitHub round-trip. GitHub remains the source of truth and is
        // refreshed in the background immediately after this quick response.
        if crate::continuity::base_url().is_some() {
            if let Ok(catalog) = fetch_continuity_catalog(false).await {
                persist_catalog(&app, &catalog);
                spawn_catalog_refresh(app.clone());
                return catalog_result(catalog, "continuity", false);
            }
        }
    }

    refresh_catalog_network(&app).await
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_catalog_value() -> Value {
        serde_json::json!({
            "schema": 1,
            "updated_at": "2026-08-25T00:00:00Z",
            "communities": [{
                "id": "comunidade-segura",
                "created_at": "2026-08-25T00:00:00Z",
                "name": "Comunidade Segura",
                "country": "Brasil",
                "region": "Piauí",
                "description": "Uma descrição pública válida e suficientemente longa.",
                "tags": ["GameDev"],
                "links": [{"label":"Site","kind":"site","url":"https://example.test/community"}]
            }]
        })
    }

    #[test]
    fn bundled_catalog_is_valid() {
        validate_catalog(&bundled_catalog()).unwrap();
    }

    #[test]
    fn rejects_non_https_links() {
        let mut catalog = bundled_catalog();
        catalog.communities[0].links[0].url = "http://example.com".into();
        assert!(validate_catalog(&catalog).is_err());
    }

    #[test]
    fn legacy_and_additive_future_catalogs_normalize_to_v1() {
        let mut legacy = sample_catalog_value();
        legacy.as_object_mut().unwrap().remove("schema");
        legacy["unknown_legacy_field"] = Value::Bool(true);
        let normalized = normalize_catalog_value(legacy).unwrap();
        assert_eq!(normalized.schema, CURRENT_CATALOG_SCHEMA);

        let mut future = sample_catalog_value();
        future["schema"] = Value::from(99);
        future["future_addition"] = serde_json::json!({"ignored": true});
        assert_eq!(
            normalize_catalog_value(future).unwrap().communities.len(),
            1
        );

        let projected = serde_json::json!({
            "schema": 200,
            "breaking": "shape",
            "compat_v1": sample_catalog_value()
        });
        assert_eq!(normalize_catalog_value(projected).unwrap().schema, 1);
    }

    #[test]
    fn incompatible_future_duplicate_and_oversized_catalogs_fail_closed() {
        assert!(normalize_catalog_value(serde_json::json!({
            "schema": 2,
            "updated_at": "future",
            "communities": "not-an-array"
        }))
        .is_err());

        let mut duplicate = sample_catalog_value();
        let row = duplicate["communities"][0].clone();
        duplicate["communities"].as_array_mut().unwrap().push(row);
        assert!(normalize_catalog_value(duplicate).is_err());

        let mut oversized = sample_catalog_value();
        let row = oversized["communities"][0].clone();
        oversized["communities"] = Value::Array(vec![row; 251]);
        assert!(normalize_catalog_value(oversized).is_err());
    }

    #[test]
    fn catalog_link_and_request_boundaries_reject_hostile_payloads() {
        for url in [
            "http://example.test",
            "javascript:alert(1)",
            "https://user:secret@example.test/path",
            "https://",
        ] {
            let mut value = sample_catalog_value();
            value["communities"][0]["links"][0]["url"] = Value::from(url);
            assert!(normalize_catalog_value(value).is_err(), "accepted {url}");
        }

        let mut request = CommunityRequestInput {
            name: "Comunidade Segura".into(),
            country: "Brasil".into(),
            region: "Piauí".into(),
            description: "Uma descrição privada válida e suficientemente longa.".into(),
            tags: vec!["GameDev".into()],
            links: vec![CommunityLink {
                label: "Site".into(),
                kind: "site".into(),
                url: "https://example.test/community".into(),
            }],
        };
        validate_request(&request).unwrap();
        request.links[0].url = "https://token@example.test/private".into();
        assert!(validate_request(&request).is_err());
        request.links[0].url = "https://example.test/community".into();
        request.description = "x".repeat(1_501);
        assert!(validate_request(&request).is_err());
    }

    #[test]
    fn malformed_catalog_fuzz_corpus_never_becomes_trusted() {
        let corpus = [
            Value::Null,
            Value::Array(vec![]),
            serde_json::json!({"schema": 0, "updated_at":"x", "communities":[]}),
            serde_json::json!({"schema": -1, "updated_at":"x", "communities":[]}),
            serde_json::json!({"schema": 1, "updated_at":[], "communities":[]}),
            serde_json::json!({"schema": 1, "updated_at":"x", "communities":[null]}),
            serde_json::json!({"schema": 1, "updated_at":"x", "communities":[{"id":"../escape"}]}),
        ];
        for value in corpus {
            assert!(normalize_catalog_value(value).is_err());
        }
    }
}
