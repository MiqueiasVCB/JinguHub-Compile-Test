/**************************************************************************/
/*  continuity.rs                                                       */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use reqwest::Method;
use serde_json::Value;
use std::sync::OnceLock;
use std::time::Duration;

const COMPILED_ENDPOINT: &str = include_str!("../continuity_endpoint.txt");

pub fn base_url() -> Option<String> {
    // Production builds are pinned to the endpoint compiled into the trusted
    // application. An arbitrary process environment variable must never be able
    // to redirect a GitHub bearer token to another HTTPS host. Developers may
    // override the endpoint only in debug builds.
    #[cfg(debug_assertions)]
    let raw = std::env::var("JINGU_CONTINUITY_URL")
        .ok()
        .filter(|value| !value.trim().is_empty())
        .unwrap_or_else(|| COMPILED_ENDPOINT.trim().to_string());
    #[cfg(not(debug_assertions))]
    let raw = COMPILED_ENDPOINT.trim().to_string();
    let value = raw.trim().trim_end_matches('/').to_string();
    let parsed = reqwest::Url::parse(&value).ok()?;
    if parsed.scheme() != "https" || parsed.host_str().is_none() {
        return None;
    }
    Some(value)
}

fn client() -> Result<reqwest::Client, String> {
    static CLIENT: OnceLock<reqwest::Client> = OnceLock::new();
    if let Some(client) = CLIENT.get() {
        return Ok(client.clone());
    }
    let built = reqwest::Client::builder()
        .user_agent(format!("JinguHub/{}", crate::jingu::PRODUCT_VERSION))
        .connect_timeout(Duration::from_secs(3))
        .timeout(Duration::from_secs(8))
        .pool_idle_timeout(Duration::from_secs(300))
        .pool_max_idle_per_host(8)
        .tcp_keepalive(Duration::from_secs(30))
        .build()
        .map_err(|error| error.to_string())?;
    let _ = CLIENT.set(built.clone());
    Ok(CLIENT.get().cloned().unwrap_or(built))
}

fn response_reference(response: &reqwest::Response) -> String {
    let request_id = response
        .headers()
        .get("x-jingu-request-id")
        .and_then(|value| value.to_str().ok())
        .unwrap_or("");
    let cf_ray = response
        .headers()
        .get("cf-ray")
        .and_then(|value| value.to_str().ok())
        .unwrap_or("");
    match (request_id.is_empty(), cf_ray.is_empty()) {
        (false, false) => format!("request_id={request_id}, cf_ray={cf_ray}"),
        (false, true) => format!("request_id={request_id}"),
        (true, false) => format!("cf_ray={cf_ray}"),
        (true, true) => "no-request-reference".to_string(),
    }
}

pub async fn request_json(
    method: Method,
    path: &str,
    token: Option<&str>,
    body: Option<Value>,
) -> Result<Value, String> {
    const DELAYS_MS: [u64; 2] = [200, 600];
    let base = base_url().ok_or_else(|| {
        "Jingu Continuity não está configurado neste build. Defina o endpoint HTTPS antes de compilar.".to_string()
    })?;
    let path = if path.starts_with('/') {
        path.to_string()
    } else {
        format!("/{path}")
    };
    let url = format!("{base}{path}");
    let retry_safe = method == Method::GET || method == Method::HEAD;
    let mut attempt = 0usize;
    let response = loop {
        let mut request = client()?.request(method.clone(), &url);
        if let Some(token) = token {
            request = request.bearer_auth(token);
        }
        if let Some(body) = body.as_ref() {
            request = request.json(body);
        }
        match request.send().await {
            Ok(response) if retry_safe && matches!(response.status().as_u16(), 502..=504) => {
                if let Some(&delay) = DELAYS_MS.get(attempt) {
                    crate::startup::log(format!(
                        "Jingu Continuity transient HTTP {} on {} {}; retry {}/{}",
                        response.status(),
                        method,
                        path,
                        attempt + 1,
                        DELAYS_MS.len()
                    ));
                    attempt += 1;
                    tokio::time::sleep(Duration::from_millis(delay)).await;
                    continue;
                }
                break response;
            }
            Ok(response) => break response,
            Err(error) if retry_safe && (error.is_timeout() || error.is_connect()) => {
                if let Some(&delay) = DELAYS_MS.get(attempt) {
                    crate::startup::log(format!(
                        "Jingu Continuity transient network error on {} {}; retry {}/{}: {error}",
                        method,
                        path,
                        attempt + 1,
                        DELAYS_MS.len()
                    ));
                    attempt += 1;
                    tokio::time::sleep(Duration::from_millis(delay)).await;
                    continue;
                }
                crate::startup::log(format!(
                    "Jingu Continuity network failure on {} {} after retries: {error}",
                    method, path
                ));
                return Err(format!("Jingu Continuity indisponível: {error}"));
            }
            Err(error) => {
                crate::startup::log(format!(
                    "Jingu Continuity request failed on {} {} without automatic retry: {error}",
                    method, path
                ));
                return Err(format!("Jingu Continuity indisponível: {error}"));
            }
        }
    };

    let status = response.status();
    let reference = response_reference(&response);
    let bytes = response.bytes().await.map_err(|error| {
        crate::startup::log(format!(
            "Jingu Continuity response read failure on {} {} ({reference}): {error}",
            method, path
        ));
        format!("Falha ao ler resposta do Jingu Continuity: {error}")
    })?;
    if bytes.len() > 2 * 1024 * 1024 {
        return Err("Resposta do Jingu Continuity excedeu o limite de segurança.".into());
    }
    if !status.is_success() {
        if status == reqwest::StatusCode::UNAUTHORIZED {
            // Continuity validates this same GitHub credential server-side. A 401
            // therefore proves the cached session is stale/revoked.
            if let Some(token) = token {
                crate::github::invalidate_session(token);
            }
        }
        let detail = crate::startup::redact_text(String::from_utf8_lossy(&bytes).trim())
            .chars()
            .take(300)
            .collect::<String>();
        crate::startup::log(format!(
            "Jingu Continuity HTTP {status} on {} {} ({reference}){}",
            method,
            path,
            if detail.is_empty() {
                String::new()
            } else {
                format!(": {detail}")
            }
        ));
        return Err(format!(
            "Jingu Continuity recusou a operação (HTTP {status}){}",
            if detail.is_empty() {
                String::new()
            } else {
                format!(": {detail}")
            }
        ));
    }
    serde_json::from_slice(&bytes).map_err(|error| {
        crate::startup::log(format!(
            "Jingu Continuity invalid JSON on {} {} ({reference}): {error}",
            method, path
        ));
        format!("Resposta inválida do Jingu Continuity: {error}")
    })
}
