/**************************************************************************/
/*  credentials.rs                                                      */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
//! Cross-platform secure credential-store abstraction.
//!
//! GitHub OAuth tokens are never persisted in JSON or plaintext files. The
//! keyring crate selects the native secure store for the host platform:
//! Windows Credential Manager, macOS Keychain Services, or Secret Service on
//! Linux/*nix. Windows also contains a one-time reader for the pre-HF5
//! Credential Manager key format so existing user sessions migrate forward.

use keyring::v1::{Entry, Error};
use serde::Serialize;

const SERVICE: &str = "dev.jingu.hub";
const ACCOUNT_PREFIX: &str = "JinguHub";

fn entry(key: &str) -> Result<Entry, String> {
    if key.trim().is_empty() {
        return Err("invalid credential key".into());
    }
    Entry::new(SERVICE, &format!("{ACCOUNT_PREFIX}/{key}"))
        .map_err(|error| format!("secure credential store is unavailable: {error}"))
}

pub fn store(key: &str, value: &str) -> Result<(), String> {
    if value.is_empty() {
        return Err("invalid credential value".into());
    }
    entry(key)?
        .set_password(value)
        .map_err(|error| format!("secure credential store rejected the credential: {error}"))?;
    #[cfg(target_os = "windows")]
    {
        // One-time migration from the legacy Windows credential target.
        let _ = legacy_windows::erase(key);
    }
    Ok(())
}

pub fn load(key: &str) -> Option<String> {
    let entry = match entry(key) {
        Ok(entry) => entry,
        Err(error) => {
            crate::startup::log(format!("WARNING: {error}"));
            return None;
        }
    };
    match entry.get_password() {
        Ok(value) => Some(value),
        Err(Error::NoEntry) => {
            #[cfg(target_os = "windows")]
            {
                if let Some(value) = legacy_windows::load(key) {
                    // Best-effort forward migration. If the write fails, retain
                    // the legacy item so the session remains recoverable.
                    if entry.set_password(&value).is_ok() {
                        let _ = legacy_windows::erase(key);
                        crate::startup::log(
                            "Migrated legacy Windows credential into HF5 secure store",
                        );
                    }
                    return Some(value);
                }
            }
            None
        }
        Err(error) => {
            crate::startup::log(format!(
                "WARNING: secure credential store could not read {key}: {error}"
            ));
            None
        }
    }
}

pub fn erase(key: &str) -> Result<(), String> {
    let native_result = match entry(key)?.delete_credential() {
        Ok(()) | Err(Error::NoEntry) => Ok(()),
        Err(error) => Err(format!(
            "secure credential store could not delete the credential: {error}"
        )),
    };

    #[cfg(target_os = "windows")]
    {
        let legacy_result = legacy_windows::erase(key);
        native_result.and(legacy_result)
    }

    #[cfg(not(target_os = "windows"))]
    {
        native_result
    }
}

fn backend_name() -> &'static str {
    #[cfg(target_os = "windows")]
    {
        return "Windows Credential Manager";
    }
    #[cfg(target_os = "macos")]
    {
        return "macOS Keychain";
    }
    #[cfg(all(unix, not(target_os = "macos")))]
    {
        return "Secret Service";
    }
    #[allow(unreachable_code)]
    "Native keyring"
}

#[derive(Debug, Clone, Serialize)]
pub struct CredentialStoreStatus {
    pub backend: &'static str,
    pub available: bool,
    pub detail: Option<String>,
}

#[tauri::command]
pub fn credential_store_status() -> CredentialStoreStatus {
    // Probe with a reserved, never-written entry. A missing credential is the
    // expected success case; transport/access errors mean the native store is
    // not currently usable (for example, no Secret Service session on Linux).
    let status = match entry("__store_healthcheck__") {
        Ok(probe) => match probe.get_password() {
            Ok(_) | Err(Error::NoEntry) => Ok(()),
            Err(error) => Err(error.to_string()),
        },
        Err(error) => Err(error),
    };

    match status {
        Ok(()) => CredentialStoreStatus {
            backend: backend_name(),
            available: true,
            detail: None,
        },
        Err(error) => CredentialStoreStatus {
            backend: backend_name(),
            available: false,
            detail: Some(error),
        },
    }
}

/// Reader/remover for the credential target format used by R12 through HF4.
/// It is intentionally Windows-only and can be deleted after the migration
/// window is considered closed in a future major Hub release.
#[cfg(target_os = "windows")]
mod legacy_windows {
    use std::ffi::c_void;
    use std::ptr;

    const CRED_TYPE_GENERIC: u32 = 1;

    #[repr(C)]
    struct FileTime {
        low: u32,
        high: u32,
    }

    #[repr(C)]
    struct CredentialAttributeW {
        keyword: *mut u16,
        flags: u32,
        value_size: u32,
        value: *mut u8,
    }

    #[repr(C)]
    struct CredentialW {
        flags: u32,
        kind: u32,
        target_name: *mut u16,
        comment: *mut u16,
        last_written: FileTime,
        credential_blob_size: u32,
        credential_blob: *mut u8,
        persist: u32,
        attribute_count: u32,
        attributes: *mut CredentialAttributeW,
        target_alias: *mut u16,
        user_name: *mut u16,
    }

    #[link(name = "Advapi32")]
    extern "system" {
        fn CredReadW(
            target_name: *const u16,
            kind: u32,
            flags: u32,
            credential: *mut *mut CredentialW,
        ) -> i32;
        fn CredDeleteW(target_name: *const u16, kind: u32, flags: u32) -> i32;
        fn CredFree(buffer: *mut c_void);
    }

    fn wide(value: &str) -> Vec<u16> {
        value.encode_utf16().chain(std::iter::once(0)).collect()
    }

    pub fn load(key: &str) -> Option<String> {
        let target = wide(&format!("JinguHub/{key}"));
        let mut raw: *mut CredentialW = ptr::null_mut();
        let ok = unsafe { CredReadW(target.as_ptr(), CRED_TYPE_GENERIC, 0, &mut raw) };
        if ok == 0 || raw.is_null() {
            return None;
        }
        let result = unsafe {
            let cred = &*raw;
            if cred.credential_blob.is_null() || cred.credential_blob_size == 0 {
                None
            } else {
                let bytes = std::slice::from_raw_parts(
                    cred.credential_blob,
                    cred.credential_blob_size as usize,
                );
                String::from_utf8(bytes.to_vec()).ok()
            }
        };
        unsafe { CredFree(raw.cast::<c_void>()) };
        result
    }

    pub fn erase(key: &str) -> Result<(), String> {
        let target = wide(&format!("JinguHub/{key}"));
        let ok = unsafe { CredDeleteW(target.as_ptr(), CRED_TYPE_GENERIC, 0) };
        if ok != 0 {
            return Ok(());
        }
        let err = std::io::Error::last_os_error();
        // ERROR_NOT_FOUND means the desired signed-out state is already true.
        if err.raw_os_error() == Some(1168) {
            Ok(())
        } else {
            Err(format!(
                "legacy Windows Credential Manager cleanup failed: {err}"
            ))
        }
    }
}
