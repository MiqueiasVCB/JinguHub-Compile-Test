/**************************************************************************/
/*  freelancers.rs                                                      */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine as _};
use reqwest::{Method, StatusCode};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::{HashMap, HashSet};
use std::sync::{Mutex, OnceLock};
use std::time::Duration;
use tauri::{AppHandle, Emitter};

const MARKER_PREFIX: &str = "<!-- JINGU_FREELANCER_V1:";
const CURRENT_SCHEMA: u32 = 5;
const FREE_SUMMARY_MAX: usize = 180;
const FREE_DESCRIPTION_MAX: usize = 3_000;
const ABSOLUTE_SUMMARY_MAX: usize = 500;
const ABSOLUTE_DESCRIPTION_MAX: usize = 10_000;
const DELETED_MARKER_PREFIX: &str = "<!-- JINGU_FREELANCER_DELETED_V1:";
const DISPLAY_ID_CHARS: usize = 7;
const MARKER_SUFFIX: &str = " -->";
const DETAILS_MARKER: &str = "<!-- JINGU_FREELANCER_DETAILS -->";
const LEGACY_MANAGED_FOOTER: &str = "Publicado pelo Jingu Hub.";
const PER_PAGE: u32 = 30;
const PUBLIC_CACHE_FILE: &str = "freelancers-public-cache.json";
const PUBLIC_CACHE_SCHEMA: u32 = 3;
const PUBLIC_CACHE_ENTRIES: usize = 12;

const ALLOWED_KINDS: &[&str] = &["recruiting", "seeking"];
const ALLOWED_COMPENSATION: &[&str] = &["paid", "volunteer", "negotiable"];
const ALLOWED_AREAS: &[&str] = &[
    "programming",
    "art-2d",
    "art-3d",
    "game-design",
    "ui-ux",
    "animation",
    "music",
    "sound",
    "qa",
    "writing",
    "production",
    "marketing",
    "community",
    "other",
];

#[derive(Debug, Deserialize)]
struct GeographyPayload {
    countries: Vec<GeographyCountry>,
}
#[derive(Debug, Deserialize)]
struct GeographyCountry {
    code: String,
    name: String,
    #[serde(default)]
    subdivisions: Vec<GeographySubdivision>,
}
#[derive(Debug, Deserialize)]
struct GeographySubdivision {
    code: String,
    name: String,
}

fn geography() -> &'static GeographyPayload {
    static GEO: OnceLock<GeographyPayload> = OnceLock::new();
    GEO.get_or_init(|| {
        serde_json::from_str(include_str!(
            "../../src/jingu/freelancer-geography.generated.json"
        ))
        .expect("bundled freelancer geography must be valid JSON")
    })
}

fn resolve_geography(
    country_code: &str,
    region_code: &str,
) -> Result<(String, String, String, String), String> {
    let country_code = country_code.trim().to_ascii_uppercase();
    let region_code = region_code.trim().to_ascii_uppercase();
    let country = geography()
        .countries
        .iter()
        .find(|item| item.code == country_code)
        .ok_or_else(|| "Selecione um país válido da lista.".to_string())?;
    if country.subdivisions.is_empty() {
        if !region_code.is_empty() {
            return Err(
                "Este país não possui Estado/região selecionável no catálogo atual.".into(),
            );
        }
        return Ok((
            country.code.clone(),
            country.name.clone(),
            String::new(),
            String::new(),
        ));
    }
    let region = country
        .subdivisions
        .iter()
        .find(|item| item.code == region_code)
        .ok_or_else(|| "Selecione um Estado/região válido para o país escolhido.".to_string())?;
    Ok((
        country.code.clone(),
        country.name.clone(),
        region.code.clone(),
        region.name.clone(),
    ))
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FreelancerLink {
    pub kind: String,
    pub label: String,
    pub value: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FreelancerPostInput {
    pub title: String,
    pub summary: String,
    pub description: String,
    pub kind: String,
    pub compensation: String,
    #[serde(default)]
    pub areas: Vec<String>,
    #[serde(default)]
    pub country_code: String,
    #[serde(default)]
    pub region_code: String,
    #[serde(default)]
    pub portfolio_links: Vec<FreelancerLink>,
    #[serde(default)]
    pub contact_links: Vec<FreelancerLink>,
    pub image_url: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct FreelancerMetadata {
    schema: u32,
    display_id: String,
    summary: String,
    kind: String,
    compensation: String,
    #[serde(default)]
    areas: Vec<String>,
    country_code: String,
    country: String,
    region_code: String,
    region: String,
    #[serde(default)]
    portfolio_links: Vec<FreelancerLink>,
    #[serde(default)]
    contact_links: Vec<FreelancerLink>,
    image_url: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FreelancerAuthor {
    pub id: u64,
    pub login: String,
    pub avatar_url: String,
    pub html_url: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FreelancerPost {
    /// Internal GitHub issue number. Never use as the user-facing listing ID.
    pub number: u64,
    pub display_id: String,
    pub channel: String,
    pub title: String,
    pub summary: String,
    pub description: String,
    pub kind: String,
    pub compensation: String,
    pub areas: Vec<String>,
    #[serde(default)]
    pub country_code: String,
    #[serde(default)]
    pub country: String,
    #[serde(default)]
    pub region_code: String,
    #[serde(default)]
    pub region: String,
    pub portfolio_links: Vec<FreelancerLink>,
    pub contact_links: Vec<FreelancerLink>,
    pub image_url: Option<String>,
    pub author: FreelancerAuthor,
    pub created_at: String,
    pub updated_at: String,
    pub html_url: String,
    pub likes: u64,
    pub state: String,
    #[serde(default = "default_membership_tier")]
    pub membership_tier: String,
    #[serde(default)]
    pub membership_badge: Option<String>,
    #[serde(default)]
    pub sponsored: bool,
    #[serde(default)]
    pub sponsored_until: Option<String>,
}

fn default_membership_tier() -> String {
    "free".into()
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FreelancerFeed {
    pub state: String,
    pub message: Option<String>,
    pub repository_url: String,
    pub page: u32,
    pub has_more: bool,
    pub posts: Vec<FreelancerPost>,
}

#[derive(Debug, Clone, Serialize)]
struct FreelancerRefreshEvent {
    page: u32,
    sort: String,
    creator: Option<String>,
    feed: FreelancerFeed,
}

#[derive(Debug, Clone, Serialize)]
pub struct FreelancerEntitlements {
    pub tier: String,
    pub label: String,
    pub badge_label: Option<String>,
    pub active_post_limit: usize,
    pub summary_max_chars: usize,
    pub description_max_chars: usize,
    pub boost_credits_per_cycle: u32,
    pub boost_duration_days: u32,
    pub boosts_remaining: u32,
    pub sponsored_available: bool,
    pub credits_eligible: bool,
    pub credits_rank: u32,
    pub source: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct FreelancerAccountStatus {
    pub active_posts: usize,
    pub active_post_limit: usize,
    pub can_create: bool,
    pub tier: String,
    pub boosts_remaining: u32,
}

#[derive(Debug, Clone, Deserialize)]
struct FreelancerSnapshot {
    schema: u32,
    #[serde(default)]
    invalid_managed_count: usize,
    #[serde(default)]
    posts: Vec<FreelancerPost>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct PublicFeedCacheEntry {
    page: u32,
    sort: String,
    cached_at: String,
    has_more: bool,
    posts: Vec<FreelancerPost>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
struct PublicFeedCache {
    schema: u32,
    entries: Vec<PublicFeedCacheEntry>,
}

#[derive(Debug, Clone, Serialize)]
pub struct FreelancerReactionState {
    pub liked: bool,
    pub likes: u64,
}

#[derive(Debug, Clone, Deserialize)]
pub struct FreelancerReactionLookup {
    pub number: u64,
    pub channel: String,
}

#[derive(Debug, Deserialize)]
struct IssueUser {
    id: u64,
    login: String,
    avatar_url: String,
    html_url: String,
}

#[derive(Debug, Default, Deserialize)]
struct ReactionSummary {
    #[serde(default)]
    heart: u64,
}

#[derive(Debug, Deserialize)]
struct IssueLabel {
    name: String,
}

#[derive(Debug, Deserialize)]
struct IssueRow {
    number: u64,
    title: String,
    body: Option<String>,
    state: String,
    html_url: String,
    user: Option<IssueUser>,
    created_at: String,
    updated_at: String,
    #[serde(default)]
    reactions: ReactionSummary,
    #[serde(default)]
    pull_request: Option<Value>,
    #[serde(default)]
    labels: Vec<IssueLabel>,
}

#[derive(Debug, Deserialize)]
struct ReactionRow {
    id: u64,
    content: String,
    user: Option<IssueUser>,
}

fn public_repository() -> (&'static str, &'static str) {
    (
        crate::jingu::GITHUB_OWNER,
        crate::jingu::PUBLIC_FREELANCERS_REPOSITORY,
    )
}

fn repository_url() -> String {
    let (owner, repo) = public_repository();
    format!("https://github.com/{owner}/{repo}")
}

#[derive(Clone)]
struct RepositoryTarget {
    owner: String,
    repo: String,
    token: Option<String>,
    channel: &'static str,
}

#[derive(Debug, Default)]
struct RepositoryFeedPage {
    posts: Vec<FreelancerPost>,
    has_more: bool,
    invalid_managed: usize,
}

async fn repository_target(channel: &str, authenticated: bool) -> Result<RepositoryTarget, String> {
    if !channel.eq_ignore_ascii_case("public") {
        return Err(
            "O canal Freelancer TEST foi aposentado. Publique somente no catálogo público.".into(),
        );
    }
    let (owner, repo) = public_repository();
    let token = if authenticated {
        Some(crate::github::access_token().await?)
    } else {
        None
    };
    Ok(RepositoryTarget {
        owner: owner.to_string(),
        repo: repo.to_string(),
        token,
        channel: "public",
    })
}

fn api_url(path: &str) -> String {
    format!("https://api.github.com{path}")
}

fn client() -> Result<reqwest::Client, String> {
    static CLIENT: OnceLock<reqwest::Client> = OnceLock::new();
    if let Some(client) = CLIENT.get() {
        return Ok(client.clone());
    }
    let built = reqwest::Client::builder()
        .user_agent(format!("JinguHub/{}", crate::jingu::PRODUCT_VERSION))
        .connect_timeout(Duration::from_secs(4))
        .timeout(Duration::from_secs(12))
        .pool_idle_timeout(Duration::from_secs(300))
        .pool_max_idle_per_host(8)
        .tcp_keepalive(Duration::from_secs(30))
        .build()
        .map_err(|error| format!("Falha ao preparar conexão com GitHub: {error}"))?;
    let _ = CLIENT.set(built.clone());
    Ok(CLIENT.get().cloned().unwrap_or(built))
}

fn request(
    client: &reqwest::Client,
    method: Method,
    url: &str,
    token: Option<&str>,
) -> reqwest::RequestBuilder {
    let mut builder = client
        .request(method, url)
        .header("Accept", "application/vnd.github+json")
        .header("X-GitHub-Api-Version", crate::jingu::GITHUB_API_VERSION);
    if let Some(token) = token.filter(|value| !value.trim().is_empty()) {
        builder = builder.bearer_auth(token);
    }
    builder
}

fn validate_https_optional(value: &Option<String>, field: &str) -> Result<(), String> {
    if let Some(value) = value {
        let value = value.trim();
        if value.is_empty() {
            return Ok(());
        }
        let valid = value.len() <= 2_048
            && reqwest::Url::parse(value).ok().is_some_and(|url| {
                url.scheme() == "https"
                    && url.host_str().is_some()
                    && url.username().is_empty()
                    && url.password().is_none()
            });
        if !valid {
            return Err(format!(
                "{field} deve ser um link HTTPS válido e sem credenciais."
            ));
        }
    }
    Ok(())
}

fn normalize_link(mut link: FreelancerLink) -> FreelancerLink {
    link.kind = link.kind.trim().to_ascii_lowercase();
    link.label = link.label.trim().to_string();
    link.value = link.value.trim().to_string();
    link
}

fn contact_label(kind: &str) -> Option<&'static str> {
    match kind {
        "email" => Some("E-mail"),
        "discord" => Some("Discord"),
        "whatsapp" => Some("WhatsApp"),
        "telegram" => Some("Telegram"),
        "github" => Some("GitHub"),
        "linkedin" => Some("LinkedIn"),
        "instagram" => Some("Instagram"),
        "website" => Some("Site"),
        _ => None,
    }
}

fn normalize_contact_link(link: FreelancerLink) -> FreelancerLink {
    let mut link = normalize_link(link);
    if let Some(label) = contact_label(&link.kind) {
        link.label = label.to_string();
    }
    link
}

fn parsed_https(value: &str) -> Option<reqwest::Url> {
    let url = reqwest::Url::parse(value.trim()).ok()?;
    if url.scheme() != "https"
        || url.username() != ""
        || url.password().is_some()
        || url.host_str().is_none()
    {
        return None;
    }
    Some(url)
}

fn path_segments(url: &reqwest::Url) -> Vec<&str> {
    url.path_segments()
        .map(|parts| parts.filter(|part| !part.is_empty()).collect())
        .unwrap_or_default()
}

fn valid_email_address(value: &str) -> bool {
    let value = value.trim();
    if value.len() > 254 || value.chars().any(char::is_whitespace) {
        return false;
    }
    let mut parts = value.split('@');
    let local = parts.next().unwrap_or("");
    let domain = parts.next().unwrap_or("");
    !local.is_empty()
        && local.len() <= 64
        && !domain.is_empty()
        && domain.contains('.')
        && parts.next().is_none()
        && domain.split('.').all(|part| {
            !part.is_empty() && part.chars().all(|c| c.is_ascii_alphanumeric() || c == '-')
        })
}

fn validate_contact_link(link: &FreelancerLink) -> Result<(), String> {
    let expected_label =
        contact_label(&link.kind).ok_or_else(|| "Forma de contato não suportada.".to_string())?;
    if link.label != expected_label {
        return Err(
            "O rótulo da forma de contato é definido automaticamente pelo Jingu Hub.".into(),
        );
    }
    if link.value.is_empty() || link.value.len() > 2_048 {
        return Err("Forma de contato vazia ou muito longa.".into());
    }
    match link.kind.as_str() {
        "email" => {
            let value = link
                .value
                .strip_prefix("mailto:")
                .ok_or_else(|| "E-mail deve usar um link mailto válido.".to_string())?;
            if !valid_email_address(value) {
                return Err("Informe um e-mail válido.".into());
            }
        }
        "whatsapp" => {
            let url = parsed_https(&link.value)
                .ok_or_else(|| "WhatsApp deve usar um link HTTPS oficial wa.me.".to_string())?;
            if url.host_str() != Some("wa.me") || url.query().is_some() || url.fragment().is_some()
            {
                return Err("WhatsApp deve usar um link oficial https://wa.me/<número>.".into());
            }
            let parts = path_segments(&url);
            if parts.len() != 1
                || !(8..=15).contains(&parts[0].len())
                || parts[0].starts_with('0')
                || !parts[0].chars().all(|c| c.is_ascii_digit())
            {
                return Err("WhatsApp deve apontar diretamente para uma conversa via wa.me com número internacional.".into());
            }
        }
        "discord" => {
            let url = parsed_https(&link.value)
                .ok_or_else(|| "Discord deve usar um link HTTPS oficial.".to_string())?;
            if !matches!(
                url.host_str(),
                Some("discord.com") | Some("www.discord.com")
            ) || url.query().is_some()
                || url.fragment().is_some()
            {
                return Err("Discord deve usar https://discord.com/users/<id>.".into());
            }
            let parts = path_segments(&url);
            if parts.len() != 2
                || parts[0] != "users"
                || !(15..=22).contains(&parts[1].len())
                || !parts[1].chars().all(|c| c.is_ascii_digit())
            {
                return Err(
                    "Discord deve apontar para um usuário em https://discord.com/users/<id>."
                        .into(),
                );
            }
        }
        "telegram" => {
            let url = parsed_https(&link.value)
                .ok_or_else(|| "Telegram deve usar um link HTTPS oficial t.me.".to_string())?;
            if !matches!(url.host_str(), Some("t.me") | Some("www.t.me"))
                || url.query().is_some()
                || url.fragment().is_some()
            {
                return Err("Telegram deve usar https://t.me/<usuário>.".into());
            }
            let parts = path_segments(&url);
            if parts.len() != 1
                || !(5..=32).contains(&parts[0].len())
                || !parts[0]
                    .chars()
                    .all(|c| c.is_ascii_alphanumeric() || c == '_')
            {
                return Err("Telegram deve apontar para um usuário válido em t.me.".into());
            }
        }
        "github" => {
            let url = parsed_https(&link.value)
                .ok_or_else(|| "GitHub deve usar um link HTTPS oficial.".to_string())?;
            let parts = path_segments(&url);
            if url.host_str() != Some("github.com")
                || parts.len() != 1
                || parts[0].len() > 39
                || !parts[0]
                    .chars()
                    .all(|c| c.is_ascii_alphanumeric() || c == '-')
            {
                return Err(
                    "GitHub deve apontar para um perfil em https://github.com/<usuário>.".into(),
                );
            }
        }
        "linkedin" => {
            let url = parsed_https(&link.value)
                .ok_or_else(|| "LinkedIn deve usar um link HTTPS oficial.".to_string())?;
            let parts = path_segments(&url);
            if !matches!(
                url.host_str(),
                Some("linkedin.com") | Some("www.linkedin.com")
            ) || parts.len() != 2
                || parts[0] != "in"
                || parts[1].is_empty()
            {
                return Err(
                    "LinkedIn deve apontar para um perfil em https://www.linkedin.com/in/<perfil>."
                        .into(),
                );
            }
        }
        "instagram" => {
            let url = parsed_https(&link.value)
                .ok_or_else(|| "Instagram deve usar um link HTTPS oficial.".to_string())?;
            let parts = path_segments(&url);
            if !matches!(
                url.host_str(),
                Some("instagram.com") | Some("www.instagram.com")
            ) || parts.len() != 1
                || parts[0].len() > 30
                || !parts[0]
                    .chars()
                    .all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '.')
            {
                return Err(
                    "Instagram deve apontar para um perfil em https://www.instagram.com/<usuário>."
                        .into(),
                );
            }
        }
        "website" => {
            if parsed_https(&link.value).is_none() {
                return Err("Site deve usar um link HTTPS válido.".into());
            }
        }
        _ => unreachable!(),
    }
    Ok(())
}

fn validate_portfolio_link(link: &FreelancerLink) -> Result<(), String> {
    if link.kind.is_empty() || link.kind.len() > 30 || link.label.chars().count() > 48 {
        return Err("Tipo/rótulo de link inválido.".into());
    }
    if link.value.is_empty() || link.value.len() > 2_048 {
        return Err("Link de portfólio vazio ou muito longo.".into());
    }
    let supported = [
        "website",
        "portfolio",
        "artstation",
        "behance",
        "itchio",
        "github",
        "linkedin",
        "other",
    ];
    if !supported.contains(&link.kind.as_str()) {
        return Err("Tipo de link de portfólio não suportado.".into());
    }
    let url = parsed_https(&link.value)
        .ok_or_else(|| "Links de portfólio devem usar HTTPS.".to_string())?;
    let host = url.host_str().unwrap_or_default();
    let domain_ok = match link.kind.as_str() {
        "artstation" => host == "artstation.com" || host.ends_with(".artstation.com"),
        "behance" => host == "behance.net" || host.ends_with(".behance.net"),
        "itchio" => host == "itch.io" || host.ends_with(".itch.io"),
        "github" => host == "github.com",
        "linkedin" => host == "linkedin.com" || host == "www.linkedin.com",
        _ => true,
    };
    if !domain_ok {
        return Err("O domínio do link não corresponde ao tipo selecionado.".into());
    }
    Ok(())
}

fn validate_link(link: &FreelancerLink, contact: bool) -> Result<(), String> {
    if contact {
        validate_contact_link(link)
    } else {
        validate_portfolio_link(link)
    }
}

#[tauri::command]
pub fn freelancers_open_contact(kind: String, value: String) -> Result<(), String> {
    let kind = kind.trim().to_ascii_lowercase();
    let label =
        contact_label(&kind).ok_or_else(|| "Forma de contato não suportada.".to_string())?;
    let link = normalize_contact_link(FreelancerLink {
        kind,
        label: label.to_string(),
        value,
    });
    validate_contact_link(&link)?;
    tauri_plugin_opener::open_url(&link.value, None::<&str>)
        .map_err(|error| format!("Não foi possível abrir esta forma de contato: {error}"))
}

fn valid_display_id(value: &str) -> bool {
    let raw = value.trim();
    raw.len() == DISPLAY_ID_CHARS + 2
        && raw.starts_with("F-")
        && raw[2..]
            .chars()
            .all(|c| c.is_ascii_uppercase() || c.is_ascii_digit())
}

fn random_display_id() -> String {
    let uuid = uuid::Uuid::new_v4();
    let bytes = uuid.as_bytes();
    let alphabet = b"ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let mut out = String::with_capacity(DISPLAY_ID_CHARS + 2);
    out.push_str("F-");
    for index in 0..DISPLAY_ID_CHARS {
        let mixed = bytes[index] ^ bytes[index + 8];
        out.push(alphabet[(mixed as usize) % alphabet.len()] as char);
    }
    out
}

fn normalized_input(
    mut input: FreelancerPostInput,
    profile: &crate::membership::MembershipProfile,
) -> Result<FreelancerPostInput, String> {
    input.title = input.title.trim().to_string();
    input.summary = input.summary.trim().to_string();
    input.description = input.description.trim().to_string();
    input.kind = input.kind.trim().to_ascii_lowercase();
    input.compensation = input.compensation.trim().to_ascii_lowercase();
    input.country_code = input.country_code.trim().to_ascii_uppercase();
    input.region_code = input.region_code.trim().to_ascii_uppercase();
    input.areas = input
        .areas
        .into_iter()
        .map(|area| area.trim().to_ascii_lowercase())
        .filter(|area| !area.is_empty())
        .collect();
    input.areas.sort();
    input.areas.dedup();
    input.portfolio_links = input
        .portfolio_links
        .into_iter()
        .map(normalize_link)
        .filter(|link| !link.value.is_empty())
        .collect();
    input.contact_links = input
        .contact_links
        .into_iter()
        .map(normalize_contact_link)
        .filter(|link| !link.value.is_empty())
        .collect();
    input.image_url = input
        .image_url
        .take()
        .map(|entry| entry.trim().to_string())
        .filter(|entry| !entry.is_empty());

    let title_len = input.title.chars().count();
    let summary_len = input.summary.chars().count();
    let description_len = input.description.chars().count();
    debug_assert!(profile.summary_max_chars >= FREE_SUMMARY_MAX);
    debug_assert!(profile.description_max_chars >= FREE_DESCRIPTION_MAX);
    if !(4..=120).contains(&title_len) {
        return Err("O título deve ter entre 4 e 120 caracteres.".into());
    }
    if !(10..=profile.summary_max_chars).contains(&summary_len) {
        return Err(format!(
            "O resumo deve ter entre 10 e {} caracteres no plano atual.",
            profile.summary_max_chars
        ));
    }
    if !(20..=profile.description_max_chars).contains(&description_len) {
        return Err(format!(
            "A descrição deve ter entre 20 e {} caracteres no plano atual.",
            profile.description_max_chars
        ));
    }
    let _ = resolve_geography(&input.country_code, &input.region_code)?;
    if !ALLOWED_KINDS.contains(&input.kind.as_str()) {
        return Err("Tipo de anúncio inválido.".into());
    }
    if !ALLOWED_COMPENSATION.contains(&input.compensation.as_str()) {
        return Err("Forma de colaboração inválida.".into());
    }
    if input.areas.is_empty() || input.areas.len() > 6 {
        return Err("Selecione de 1 a 6 áreas.".into());
    }
    if input
        .areas
        .iter()
        .any(|area| !ALLOWED_AREAS.contains(&area.as_str()))
    {
        return Err("O anúncio contém uma área não suportada.".into());
    }
    if input.portfolio_links.len() > 8 || input.contact_links.len() > 8 {
        return Err("Use no máximo 8 links de portfólio e 8 formas de contato.".into());
    }
    for link in &input.portfolio_links {
        validate_link(link, false)?;
    }
    for link in &input.contact_links {
        validate_link(link, true)?;
    }
    validate_https_optional(&input.image_url, "Imagem")?;
    Ok(input)
}

fn metadata_from_input(
    input: &FreelancerPostInput,
    display_id: &str,
) -> Result<FreelancerMetadata, String> {
    let (country_code, country, region_code, region) =
        resolve_geography(&input.country_code, &input.region_code)?;
    Ok(FreelancerMetadata {
        schema: CURRENT_SCHEMA,
        display_id: display_id.to_string(),
        summary: input.summary.clone(),
        kind: input.kind.clone(),
        compensation: input.compensation.clone(),
        areas: input.areas.clone(),
        country_code,
        country,
        region_code,
        region,
        portfolio_links: input.portfolio_links.clone(),
        contact_links: input.contact_links.clone(),
        image_url: input.image_url.clone(),
    })
}

fn encode_marker(metadata: &FreelancerMetadata) -> Result<String, String> {
    let bytes = serde_json::to_vec(metadata).map_err(|error| error.to_string())?;
    Ok(format!(
        "{MARKER_PREFIX}{}{MARKER_SUFFIX}",
        URL_SAFE_NO_PAD.encode(bytes)
    ))
}

fn metadata_is_valid(metadata: &FreelancerMetadata) -> bool {
    if metadata.schema != CURRENT_SCHEMA || !valid_display_id(&metadata.display_id) {
        return false;
    }
    let unique_areas = metadata.areas.iter().collect::<HashSet<_>>();
    let geo_ok = resolve_geography(&metadata.country_code, &metadata.region_code)
        .map(|(_, country, _, region)| country == metadata.country && region == metadata.region)
        .unwrap_or(false);
    geo_ok
        && (10..=ABSOLUTE_SUMMARY_MAX).contains(&metadata.summary.chars().count())
        && ALLOWED_KINDS.contains(&metadata.kind.as_str())
        && ALLOWED_COMPENSATION.contains(&metadata.compensation.as_str())
        && !metadata.areas.is_empty()
        && metadata.areas.len() <= 6
        && unique_areas.len() == metadata.areas.len()
        && metadata
            .areas
            .iter()
            .all(|area| ALLOWED_AREAS.contains(&area.as_str()))
        && metadata.portfolio_links.len() <= 8
        && metadata.contact_links.len() <= 8
        && metadata
            .portfolio_links
            .iter()
            .all(|link| validate_portfolio_link(link).is_ok())
        && metadata
            .contact_links
            .iter()
            .all(|link| validate_contact_link(link).is_ok())
        && validate_https_optional(&metadata.image_url, "Imagem").is_ok()
}

#[cfg(test)]
fn decode_marker(body: &str) -> Option<FreelancerMetadata> {
    let start = body.find(MARKER_PREFIX)? + MARKER_PREFIX.len();
    let suffix = body.get(start..)?.find(MARKER_SUFFIX)? + start;
    let encoded = body.get(start..suffix)?.trim();
    if encoded.len() > 16_384 {
        return None;
    }
    let bytes = URL_SAFE_NO_PAD.decode(encoded).ok()?;
    let metadata: FreelancerMetadata = serde_json::from_slice(&bytes).ok()?;
    metadata_is_valid(&metadata).then_some(metadata)
}

fn raw_marker_value(body: &str) -> Option<Value> {
    let start = body.find(MARKER_PREFIX)? + MARKER_PREFIX.len();
    let suffix = body.get(start..)?.find(MARKER_SUFFIX)? + start;
    let encoded = body.get(start..suffix)?.trim();
    if encoded.len() > 16_384 {
        return None;
    }
    let bytes = URL_SAFE_NO_PAD.decode(encoded).ok()?;
    serde_json::from_slice(&bytes).ok()
}

fn legacy_display_id(issue_number: u64) -> String {
    const ALPHABET: &[u8] = b"ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let mut value = issue_number
        .wrapping_mul(0x9E37_79B1_85EB_CA87)
        .rotate_left(17);
    let mut out = String::with_capacity(DISPLAY_ID_CHARS + 2);
    out.push_str("F-");
    for _ in 0..DISPLAY_ID_CHARS {
        out.push(ALPHABET[(value % ALPHABET.len() as u64) as usize] as char);
        value /= ALPHABET.len() as u64;
    }
    out
}

fn compatible_geography(raw: &Value, source_schema: u32) -> (String, String, String, String) {
    if source_schema == CURRENT_SCHEMA {
        return (
            raw.get("country_code")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .to_string(),
            raw.get("country")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .to_string(),
            raw.get("region_code")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .to_string(),
            raw.get("region")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .to_string(),
        );
    }
    let country_name = raw
        .get("country")
        .and_then(Value::as_str)
        .unwrap_or_default()
        .trim();
    let region_name = raw
        .get("region")
        .and_then(Value::as_str)
        .unwrap_or_default()
        .trim();
    if country_name.is_empty() {
        return (String::new(), String::new(), String::new(), String::new());
    }
    if let Some(country) = geography()
        .countries
        .iter()
        .find(|item| item.name.eq_ignore_ascii_case(country_name))
    {
        if country.subdivisions.is_empty() {
            if region_name.is_empty() {
                return (
                    country.code.clone(),
                    country.name.clone(),
                    String::new(),
                    String::new(),
                );
            }
        } else if let Some(region) = country
            .subdivisions
            .iter()
            .find(|item| item.name.eq_ignore_ascii_case(region_name))
        {
            return (
                country.code.clone(),
                country.name.clone(),
                region.code.clone(),
                region.name.clone(),
            );
        }
    }
    // Historical schemas used display names without stable ISO identifiers. Keep
    // those names visible, but never invent a code that could be mistaken for a
    // canonical schema-5 geography value.
    (
        String::new(),
        country_name.to_string(),
        String::new(),
        region_name.to_string(),
    )
}

fn compatible_portfolio_link(link: FreelancerLink) -> Option<FreelancerLink> {
    let mut link = normalize_link(link);
    if validate_portfolio_link(&link).is_ok() {
        return Some(link);
    }
    if parsed_https(&link.value).is_some() {
        link.kind = "other".into();
        if link.label.is_empty() {
            link.label = "Link".into();
        }
        return validate_portfolio_link(&link).is_ok().then_some(link);
    }
    None
}

fn compatible_contact_link(link: FreelancerLink) -> Option<FreelancerLink> {
    let link = normalize_contact_link(link);
    if validate_contact_link(&link).is_ok() {
        return Some(link);
    }
    if let Some(address) = link.value.strip_prefix("mailto:") {
        if valid_email_address(address) {
            return Some(FreelancerLink {
                kind: "email".into(),
                label: "E-mail".into(),
                value: format!("mailto:{address}"),
            });
        }
    }
    if parsed_https(&link.value).is_some() {
        return Some(FreelancerLink {
            kind: "website".into(),
            label: "Site".into(),
            value: link.value,
        });
    }
    None
}

fn legacy_links(raw: &Value, key: &str, contact: bool) -> Vec<FreelancerLink> {
    let rows = raw
        .get(key)
        .cloned()
        .and_then(|value| serde_json::from_value::<Vec<FreelancerLink>>(value).ok())
        .unwrap_or_default();
    rows.into_iter()
        .take(8)
        .filter_map(|link| {
            if contact {
                compatible_contact_link(link)
            } else {
                compatible_portfolio_link(link)
            }
        })
        .collect()
}

fn decode_marker_compatible(body: &str, issue_number: u64) -> Option<(FreelancerMetadata, u32)> {
    let raw = raw_marker_value(body)?;
    let source_schema = u32::try_from(raw.get("schema")?.as_u64()?).ok()?;
    if source_schema >= CURRENT_SCHEMA {
        // The compatibility core is permanent. Future major
        // contracts may add fields freely; if they change the core they must
        // embed `compat_v5`. Old clients read that stable projection and never
        // rewrite/downgrade the newer marker. Serde intentionally ignores
        // additive unknown fields.
        let mut compatible = if source_schema > CURRENT_SCHEMA {
            raw.get("compat_v5").cloned().unwrap_or_else(|| raw.clone())
        } else {
            raw.clone()
        };
        if source_schema > CURRENT_SCHEMA {
            compatible["schema"] = Value::from(CURRENT_SCHEMA);
        }
        let metadata: FreelancerMetadata = serde_json::from_value(compatible).ok()?;
        return metadata_is_valid(&metadata).then_some((metadata, source_schema));
    }
    if source_schema == 0 {
        return None;
    }

    let summary = raw.get("summary")?.as_str()?.trim().to_string();
    let summary_max = match source_schema {
        1 | 2 => 280,
        3 => 180,
        4 => ABSOLUTE_SUMMARY_MAX,
        _ => return None,
    };
    if !(10..=summary_max).contains(&summary.chars().count()) {
        return None;
    }
    let kind = raw.get("kind")?.as_str()?.trim().to_ascii_lowercase();
    let compensation = raw
        .get("compensation")?
        .as_str()?
        .trim()
        .to_ascii_lowercase();
    if !ALLOWED_KINDS.contains(&kind.as_str())
        || !ALLOWED_COMPENSATION.contains(&compensation.as_str())
    {
        return None;
    }
    let areas = raw
        .get("areas")
        .cloned()
        .and_then(|value| serde_json::from_value::<Vec<String>>(value).ok())?
        .into_iter()
        .map(|area| area.trim().to_ascii_lowercase())
        .collect::<Vec<_>>();
    let unique = areas.iter().collect::<HashSet<_>>();
    if areas.is_empty()
        || areas.len() > 6
        || unique.len() != areas.len()
        || areas
            .iter()
            .any(|area| !ALLOWED_AREAS.contains(&area.as_str()))
    {
        return None;
    }

    let display_id = raw
        .get("display_id")
        .and_then(Value::as_str)
        .map(str::trim)
        .filter(|value| valid_display_id(value))
        .map(str::to_string)
        .unwrap_or_else(|| legacy_display_id(issue_number));
    let (country_code, country, region_code, region) = compatible_geography(&raw, source_schema);

    let mut portfolio_links = if source_schema == 1 {
        raw.get("portfolio_url")
            .and_then(Value::as_str)
            .filter(|value| parsed_https(value).is_some())
            .map(|value| {
                vec![FreelancerLink {
                    kind: "portfolio".into(),
                    label: "Portfólio".into(),
                    value: value.trim().to_string(),
                }]
            })
            .unwrap_or_default()
    } else {
        legacy_links(&raw, "portfolio_links", false)
    };
    portfolio_links.truncate(8);

    let mut contact_links = if source_schema == 1 {
        raw.get("contact_url")
            .and_then(Value::as_str)
            .filter(|value| parsed_https(value).is_some())
            .map(|value| {
                vec![FreelancerLink {
                    kind: "website".into(),
                    label: "Site".into(),
                    value: value.trim().to_string(),
                }]
            })
            .unwrap_or_default()
    } else {
        legacy_links(&raw, "contact_links", true)
    };
    contact_links.truncate(8);

    let image_url = raw
        .get("image_url")
        .and_then(Value::as_str)
        .map(str::trim)
        .filter(|value| !value.is_empty() && parsed_https(value).is_some())
        .map(str::to_string);

    Some((
        FreelancerMetadata {
            // Normalize legacy metadata in-memory to the current shape. We keep
            // the source schema separately so no caller mistakes this for an
            // on-disk migration that has already happened.
            schema: CURRENT_SCHEMA,
            display_id,
            summary,
            kind,
            compensation,
            areas,
            country_code,
            country,
            region_code,
            region,
            portfolio_links,
            contact_links,
            image_url,
        },
        source_schema,
    ))
}

fn managed_display_id_from_issue(issue: &IssueRow) -> Option<String> {
    let body = issue.body.as_deref().unwrap_or_default();
    managed_display_id_from_body(body).or_else(|| {
        let schema = u32::try_from(
            raw_marker_value(body).and_then(|value| value.get("schema").and_then(Value::as_u64))?,
        )
        .ok()?;
        (schema == 1 || schema == 2).then(|| legacy_display_id(issue.number))
    })
}

fn managed_display_id_from_body(body: &str) -> Option<String> {
    if let Some(start) = body.find(DELETED_MARKER_PREFIX) {
        let start = start + DELETED_MARKER_PREFIX.len();
        let end = body.get(start..)?.find(MARKER_SUFFIX)? + start;
        let candidate = body.get(start..end)?.trim();
        if valid_display_id(candidate) {
            return Some(candidate.to_string());
        }
    }
    raw_marker_value(body)
        .and_then(|value| {
            value
                .get("display_id")
                .and_then(Value::as_str)
                .or_else(|| {
                    value
                        .get("compat_v5")
                        .and_then(|compat| compat.get("display_id"))
                        .and_then(Value::as_str)
                })
                .map(str::to_string)
        })
        .filter(|value| valid_display_id(value))
}

fn managed_body(body: &str) -> bool {
    body.contains(MARKER_PREFIX)
        || body.contains(DELETED_MARKER_PREFIX)
        || body.contains(LEGACY_MANAGED_FOOTER)
}

fn managed_issue(issue: &IssueRow) -> bool {
    issue.pull_request.is_none() && managed_body(issue.body.as_deref().unwrap_or_default())
}

fn reconciled_plan_tier(issue: &IssueRow) -> Option<&str> {
    issue.labels.iter().find_map(|label| {
        label
            .name
            .strip_prefix("jingu-plan:")
            .and_then(|tier| matches!(tier, "free" | "bronze" | "silver" | "gold").then_some(tier))
    })
}

fn issue_reconciliation_ready(issue: &IssueRow) -> bool {
    let blocked = issue.labels.iter().any(|label| {
        matches!(
            label.name.as_str(),
            "jingu:invalid" | "jingu:quota-excess" | "jingu:reconcile-pending"
        )
    });
    !blocked && reconciled_plan_tier(issue).is_some()
}

fn body_from_input(input: &FreelancerPostInput, display_id: &str) -> Result<String, String> {
    let metadata = metadata_from_input(input, display_id)?;
    let marker = encode_marker(&metadata)?;
    let mut body = format!("{marker}\n\n{}\n\n{DETAILS_MARKER}", input.description);
    let location = if metadata.region.is_empty() {
        metadata.country.clone()
    } else {
        format!("{} - {}", metadata.region, metadata.country)
    };
    body.push_str(&format!("\n\n**Localização:** {location}"));
    if !input.portfolio_links.is_empty() {
        body.push_str("\n\n**Portfólio:**");
        for link in &input.portfolio_links {
            body.push_str(&format!(
                "\n- {}: {}",
                if link.label.is_empty() {
                    &link.kind
                } else {
                    &link.label
                },
                link.value
            ));
        }
    }
    if !input.contact_links.is_empty() {
        body.push_str("\n\n**Contato:**");
        for link in &input.contact_links {
            body.push_str(&format!("\n- {}: {}", link.label, link.value));
        }
    }
    if let Some(url) = &input.image_url {
        body.push_str(&format!("\n\n![Imagem do anúncio]({url})"));
    }
    body.push_str("\n\n---\nPublicado pelo Jingu Hub. O anunciante é responsável pelo conteúdo, contato, negociação, pagamentos e eventual contratação.");
    Ok(body)
}

fn description_from_body(body: &str) -> String {
    let after_marker = if let Some(start) = body.find(MARKER_PREFIX) {
        let marker_end = body[start..]
            .find(MARKER_SUFFIX)
            .map(|offset| start + offset + MARKER_SUFFIX.len())
            .unwrap_or(0);
        &body[marker_end..]
    } else {
        body
    };
    after_marker
        .split(DETAILS_MARKER)
        .next()
        .unwrap_or(after_marker)
        .trim()
        .to_string()
}

fn issue_to_post(issue: IssueRow, channel: &str) -> Option<FreelancerPost> {
    if issue.pull_request.is_some() || !(4..=120).contains(&issue.title.chars().count()) {
        return None;
    }
    let labels = issue
        .labels
        .iter()
        .map(|label| label.name.as_str())
        .collect::<HashSet<_>>();
    if labels.contains("jingu:invalid")
        || labels.contains("jingu:quota-excess")
        || (labels.contains("jingu:reconcile-pending")
            && !labels.iter().any(|label| label.starts_with("jingu-plan:")))
    {
        return None;
    }
    let body = issue.body.clone().unwrap_or_default();
    let (metadata, source_schema) = decode_marker_compatible(&body, issue.number)?;
    let description = description_from_body(&body);
    let description_max = if source_schema == 3 {
        FREE_DESCRIPTION_MAX
    } else {
        ABSOLUTE_DESCRIPTION_MAX
    };
    if !(20..=description_max).contains(&description.chars().count()) {
        return None;
    }
    let display_id = metadata.display_id.clone();
    let membership_tier = reconciled_plan_tier(&issue)
        .map(str::to_string)
        .unwrap_or_else(|| "free".into());
    // Borrow the complete issue before moving `issue.user`; this keeps cargo check
    // clean and avoids a partial-move use-after-move error (E0382).
    let author = issue.user?;
    let membership_badge = crate::membership::badge_for_tier(&membership_tier).map(str::to_string);
    let sponsored = issue
        .labels
        .iter()
        .any(|label| label.name == "jingu:sponsored");
    Some(FreelancerPost {
        number: issue.number,
        display_id,
        channel: channel.to_string(),
        title: issue.title,
        summary: metadata.summary,
        description,
        kind: metadata.kind,
        compensation: metadata.compensation,
        areas: metadata.areas,
        country_code: metadata.country_code,
        country: metadata.country,
        region_code: metadata.region_code,
        region: metadata.region,
        portfolio_links: metadata.portfolio_links,
        contact_links: metadata.contact_links,
        image_url: metadata.image_url,
        author: FreelancerAuthor {
            id: author.id,
            login: author.login,
            avatar_url: author.avatar_url,
            html_url: author.html_url,
        },
        created_at: issue.created_at,
        updated_at: issue.updated_at,
        html_url: issue.html_url,
        likes: issue.reactions.heart,
        state: issue.state,
        membership_tier,
        membership_badge,
        sponsored,
        sponsored_until: None,
    })
}

async fn enrich_current_memberships(posts: &mut [FreelancerPost]) {
    let ids = posts.iter().map(|post| post.author.id).collect::<Vec<_>>();
    if ids.is_empty() {
        return;
    }
    let profiles = crate::membership::public_profiles_by_ids(&ids).await;
    if profiles.is_empty() {
        return;
    }
    for post in posts {
        if let Some(profile) = profiles.get(&post.author.id) {
            post.membership_tier = profile.tier.clone();
            post.membership_badge = profile.badge_label.clone();
        }
    }
}

fn public_cache_path(app: &AppHandle) -> std::path::PathBuf {
    crate::paths::app_data_dir(app).join(PUBLIC_CACHE_FILE)
}

fn public_only_posts(posts: impl IntoIterator<Item = FreelancerPost>) -> Vec<FreelancerPost> {
    posts
        .into_iter()
        .filter(|post| post.channel == "public")
        .collect()
}

fn load_public_cache(app: &AppHandle, page: u32, sort: &str) -> Option<PublicFeedCacheEntry> {
    let cache: PublicFeedCache = crate::persist::read_json(&public_cache_path(app));
    if cache.schema != PUBLIC_CACHE_SCHEMA {
        return None;
    }
    cache.entries.into_iter().find_map(|mut entry| {
        if entry.page != page || entry.sort != sort {
            return None;
        }
        // Defense in depth: the continuity cache is public-only by design. Even
        // a stale/corrupted cache file can never rehydrate TEST rows.
        entry.posts = public_only_posts(entry.posts);
        Some(entry)
    })
}

fn save_public_cache(
    app: &AppHandle,
    page: u32,
    sort: &str,
    has_more: bool,
    posts: &[FreelancerPost],
) {
    // Never persist a private row even if a caller accidentally passes a mixed feed.
    let public_posts = public_only_posts(posts.iter().cloned());

    let path = public_cache_path(app);
    let mut cache: PublicFeedCache = crate::persist::read_json(&path);
    if cache.schema != PUBLIC_CACHE_SCHEMA {
        cache = PublicFeedCache {
            schema: PUBLIC_CACHE_SCHEMA,
            entries: Vec::new(),
        };
    }
    cache
        .entries
        .retain(|entry| !(entry.page == page && entry.sort == sort));
    cache.entries.insert(
        0,
        PublicFeedCacheEntry {
            page,
            sort: sort.to_string(),
            cached_at: chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, true),
            has_more,
            posts: public_posts,
        },
    );
    cache.entries.truncate(PUBLIC_CACHE_ENTRIES);
    if let Err(error) = crate::persist::write_json(&path, &cache) {
        crate::startup::log(format!(
            "WARNING freelancers public cache write failed: {error}"
        ));
    }
}

fn degraded_feed(entry: PublicFeedCacheEntry, page: u32) -> FreelancerFeed {
    FreelancerFeed {
        state: "degraded".into(),
        message: Some(format!(
            "O GitHub está temporariamente indisponível. Exibindo a última cópia pública validada salva neste dispositivo ({}). Recursos que exigem escrita no GitHub permanecem indisponíveis até a recuperação do serviço.",
            entry.cached_at
        )),
        repository_url: repository_url(),
        page,
        has_more: entry.has_more,
        posts: entry.posts,
    }
}

fn fast_cached_feed(entry: PublicFeedCacheEntry, page: u32) -> FreelancerFeed {
    FreelancerFeed {
        state: "cache".into(),
        message: None,
        repository_url: repository_url(),
        page,
        has_more: entry.has_more,
        posts: entry.posts,
    }
}

fn empty_feed(state: &str, message: Option<String>, page: u32) -> FreelancerFeed {
    FreelancerFeed {
        state: state.into(),
        message,
        repository_url: repository_url(),
        page,
        has_more: false,
        posts: Vec::new(),
    }
}

async fn github_error(response: reqwest::Response, fallback: &str, authenticated: bool) -> String {
    let status = response.status();
    let remaining = response
        .headers()
        .get("x-ratelimit-remaining")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_string();
    let reset = response
        .headers()
        .get("x-ratelimit-reset")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_string();
    let text = response.text().await.unwrap_or_default();
    let detail = crate::startup::redact_text(
        &serde_json::from_str::<Value>(&text)
            .ok()
            .and_then(|value| {
                value
                    .get("message")
                    .and_then(Value::as_str)
                    .map(str::to_string)
            })
            .unwrap_or_else(|| fallback.to_string()),
    );
    if status == StatusCode::FORBIDDEN
        && (remaining == "0" || detail.to_ascii_lowercase().contains("rate limit"))
    {
        return if reset.is_empty() {
            "O limite temporário de requisições do GitHub foi atingido. Se você estiver conectado, atualize a sessão; caso contrário, tente novamente em alguns minutos.".into()
        } else {
            format!("O limite temporário de requisições do GitHub foi atingido (reset Unix: {reset}). Tente novamente em alguns minutos.")
        };
    }
    if status == StatusCode::TOO_MANY_REQUESTS || crate::github::is_transient_status(status) {
        return crate::github::friendly_http_error(status, &text, "o carregamento de Freelancers");
    }
    if status == StatusCode::UNAUTHORIZED {
        if authenticated {
            return crate::github::friendly_http_error(
                status,
                &text,
                "uma operação autenticada de Freelancers",
            );
        }
        return "O GitHub recusou temporariamente a consulta pública de Freelancers (HTTP 401). Nenhuma credencial da sua conta foi enviada; tente Atualizar novamente.".into();
    }
    if status == StatusCode::NOT_FOUND {
        return "O recurso solicitado não existe ou sua conta não possui acesso a ele no GitHub."
            .into();
    }
    if status == StatusCode::FORBIDDEN {
        return if authenticated {
            format!("O GitHub recusou esta operação (403). Verifique as permissões da GitHub App para este repositório. Detalhe: {detail}")
        } else {
            "O GitHub recusou temporariamente a consulta pública de Freelancers (HTTP 403). Tente novamente mais tarde.".into()
        };
    }
    format!("GitHub HTTP {status}: {detail}")
}

async fn require_issue_owner(number: u64, channel: &str, token: &str) -> Result<IssueRow, String> {
    let current =
        crate::github::cached_user().ok_or_else(|| "Entre no GitHub primeiro.".to_string())?;
    let target = repository_target(channel, true).await?;
    let url = api_url(&format!(
        "/repos/{}/{}/issues/{number}",
        target.owner, target.repo
    ));
    let response = crate::github::send_with_retry(
        request(&client()?, Method::GET, &url, Some(token)),
        "a validação do anúncio de Freelancer",
    )
    .await?;
    if !response.status().is_success() {
        return Err(github_error(response, "Não foi possível abrir o anúncio.", true).await);
    }
    let issue: IssueRow = response.json().await.map_err(|error| error.to_string())?;
    let issue_user = issue
        .user
        .as_ref()
        .ok_or_else(|| "Anúncio sem autor válido.".to_string())?;
    if issue_user.id != current.id
        || decode_marker_compatible(issue.body.as_deref().unwrap_or_default(), issue.number)
            .is_none()
    {
        return Err(
            "Você só pode alterar seus próprios anúncios publicados pelo Jingu Hub.".into(),
        );
    }
    Ok(issue)
}

async fn fetch_repository_posts(
    target: &RepositoryTarget,
    page: u32,
    sort: &str,
    creator: Option<&str>,
) -> Result<RepositoryFeedPage, String> {
    let creator = creator
        .map(|value| value.trim().trim_start_matches('@'))
        .filter(|value| !value.is_empty())
        .filter(|value| {
            value.len() <= 39 && value.chars().all(|c| c.is_ascii_alphanumeric() || c == '-')
        });
    let creator_query = creator
        .map(|value| format!("&creator={value}"))
        .unwrap_or_default();
    let url = api_url(&format!(
        "/repos/{}/{}/issues?state=open&sort={sort}&direction=desc&per_page={PER_PAGE}&page={page}{creator_query}",
        target.owner, target.repo
    ));
    let response = crate::github::send_with_retry(
        request(&client()?, Method::GET, &url, target.token.as_deref()),
        "o carregamento de Freelancers",
    )
    .await?;
    if target.channel == "public" && response.status() == StatusCode::CONFLICT {
        return Ok(RepositoryFeedPage::default());
    }
    if !response.status().is_success() {
        return Err(github_error(
            response,
            "Falha ao carregar anúncios.",
            target.token.is_some(),
        )
        .await);
    }
    let rows: Vec<IssueRow> = response.json().await.map_err(|error| error.to_string())?;
    let source_count = rows.len();
    let mut posts = Vec::new();
    let mut invalid_managed = 0usize;
    for issue in rows {
        let managed = managed_issue(&issue);
        if managed && !issue_reconciliation_ready(&issue) {
            invalid_managed = invalid_managed.saturating_add(1);
            continue;
        }
        if let Some(post) = issue_to_post(issue, target.channel) {
            posts.push(post);
        } else if managed {
            invalid_managed = invalid_managed.saturating_add(1);
        }
    }
    Ok(RepositoryFeedPage {
        posts,
        has_more: source_count == PER_PAGE as usize,
        invalid_managed,
    })
}

async fn continuity_public_feed(
    page: u32,
    sort: &str,
    creator: Option<&str>,
    degraded: bool,
    fresh: bool,
) -> Result<FreelancerFeed, String> {
    // Ask Continuity for only the requested 30-row public page.
    // The edge response also carries current membership tiers in one D1 batch,
    // avoiding a full-snapshot transfer and N+1 membership lookups.
    let creator = creator
        .map(|value| value.trim().trim_start_matches('@'))
        .filter(|value| {
            !value.is_empty()
                && value.len() <= 39
                && value
                    .chars()
                    .all(|character| character.is_ascii_alphanumeric() || character == '-')
        });
    let mut fast_path = format!("/v1/freelancers/feed?page={page}&sort={sort}");
    if fresh {
        fast_path.push_str("&fresh=1");
    }
    if let Some(login) = creator {
        fast_path.push_str("&creator=");
        fast_path.push_str(login);
    }
    if let Ok(value) = crate::continuity::request_json(Method::GET, &fast_path, None, None).await {
        if let Ok(mut feed) = serde_json::from_value::<FreelancerFeed>(value) {
            feed.posts = public_only_posts(feed.posts);
            feed.repository_url = repository_url();
            if degraded {
                feed.state = "continuity".into();
                feed.message = Some("GitHub indisponível. Exibindo a projeção pública validada do Jingu Continuity; operações de escrita permanecem desabilitadas.".into());
            } else if feed.state != "degraded" {
                feed.state = "edge".into();
                feed.message = None;
            }
            return Ok(feed);
        }
    }

    // Continuity is a canonical compatibility projection. Future additive
    // snapshot envelopes remain readable as long as their stable post core can
    // still deserialize; older raw source contracts are migrated before ingest.
    let value = crate::continuity::request_json(
        Method::GET,
        if fresh {
            "/v1/snapshots/freelancers?fresh=1"
        } else {
            "/v1/snapshots/freelancers"
        },
        None,
        None,
    )
    .await?;
    let payload = value
        .get("payload")
        .cloned()
        .ok_or_else(|| "Snapshot público de Freelancers ausente.".to_string())?;
    let mut snapshot: FreelancerSnapshot = serde_json::from_value(payload)
        .map_err(|error| format!("Snapshot público de Freelancers inválido: {error}"))?;
    if snapshot.schema < CURRENT_SCHEMA {
        return Err(
            "Snapshot público de Freelancers ainda não foi migrado pelo serviço de continuidade."
                .into(),
        );
    }
    snapshot.posts = public_only_posts(snapshot.posts);
    if let Some(login) = creator {
        snapshot
            .posts
            .retain(|post| post.author.login.eq_ignore_ascii_case(login));
    }
    snapshot.posts.sort_by(|a, b| {
        let left = if sort == "updated" {
            &a.updated_at
        } else {
            &a.created_at
        };
        let right = if sort == "updated" {
            &b.updated_at
        } else {
            &b.created_at
        };
        right.cmp(left)
    });
    let start = ((page - 1) as usize).saturating_mul(PER_PAGE as usize);
    let end = (start + PER_PAGE as usize).min(snapshot.posts.len());
    let has_more = end < snapshot.posts.len();
    let mut posts = if start < snapshot.posts.len() {
        snapshot.posts[start..end].to_vec()
    } else {
        Vec::new()
    };
    enrich_current_memberships(&mut posts).await;
    let invalid_managed = snapshot.invalid_managed_count;
    if invalid_managed > 0 {
        crate::startup::log(format!(
            "Freelancers compatibility projection isolated {invalid_managed} managed row(s)"
        ));
    }
    Ok(FreelancerFeed {
        state: if degraded {
            "continuity".into()
        } else {
            "edge".into()
        },
        message: if degraded {
            Some("GitHub indisponível. Exibindo a projeção pública validada do Jingu Continuity; operações de escrita permanecem desabilitadas.".into())
        } else {
            None
        },
        repository_url: repository_url(),
        page,
        has_more,
        posts,
    })
}

async fn github_public_feed_fallback(
    app: &AppHandle,
    page: u32,
    sort: &str,
    creator: Option<&str>,
) -> FreelancerFeed {
    // Explicit/manual refreshes and post-mutation reconciliation should prefer
    // the signed-in user's authenticated GitHub request when available. That
    // gives the UI an authoritative source-of-truth read immediately after a
    // write instead of waiting for the asynchronous Continuity mirror. Public
    // anonymous browsing still works without credentials.
    let authenticated = crate::github::cached_user().is_some();
    let public = match repository_target("public", authenticated).await {
        Ok(target) => target,
        Err(error) => {
            crate::startup::log(format!("Freelancers public target unavailable: {error}"));
            if creator.is_none() {
                if let Some(cached) = load_public_cache(app, page, sort) {
                    return degraded_feed(cached, page);
                }
            }
            return empty_feed("error", Some(error), page);
        }
    };
    let public_page = match fetch_repository_posts(&public, page, sort, creator).await {
        Ok(value) => value,
        Err(error) => {
            crate::startup::log(format!("Freelancers GitHub fallback unavailable: {error}"));
            if creator.is_none() {
                if let Some(cached) = load_public_cache(app, page, sort) {
                    return degraded_feed(cached, page);
                }
            }
            let state = if error.to_ascii_lowercase().contains("conex")
                || error.to_ascii_lowercase().contains("timeout")
            {
                "offline"
            } else {
                "error"
            };
            return empty_feed(state, Some(error), page);
        }
    };
    let invalid_managed = public_page.invalid_managed;
    let mut posts = public_page.posts;
    posts.sort_by(|a, b| {
        let left = if sort == "updated" {
            &a.updated_at
        } else {
            &a.created_at
        };
        let right = if sort == "updated" {
            &b.updated_at
        } else {
            &b.created_at
        };
        right.cmp(left)
    });
    enrich_current_memberships(&mut posts).await;
    if creator.is_none() {
        save_public_cache(app, page, sort, public_page.has_more, &posts);
    }
    FreelancerFeed {
        state: if invalid_managed > 0 { "degraded".into() } else { "github-fallback".into() },
        message: (invalid_managed > 0).then(|| format!("{invalid_managed} anúncio(s) gerenciado(s) possuem contrato incompatível e foram isolados até a reconciliação.")),
        repository_url: repository_url(), page, has_more: public_page.has_more, posts,
    }
}

async fn live_feed(
    app: &AppHandle,
    page: u32,
    sort: &str,
    creator: Option<&str>,
    fresh: bool,
) -> FreelancerFeed {
    // Public reads are served by the materialized Cloudflare/D1 projection.
    // GitHub remains canonical for writes and repository workflows, but it is
    // deliberately kept off the normal Hub read path to minimize latency and
    // GitHub rate-limit pressure. A manual refresh bypasses edge cache/replicas.
    if crate::continuity::base_url().is_some() {
        match continuity_public_feed(page, sort, creator, false, fresh).await {
            Ok(feed) => {
                if creator.is_none() {
                    save_public_cache(app, page, sort, feed.has_more, &feed.posts);
                }
                return feed;
            }
            Err(error) => crate::startup::log(format!(
                "Freelancers Continuity read unavailable; GitHub fallback engaged: {error}"
            )),
        }
    }
    github_public_feed_fallback(app, page, sort, creator).await
}

fn active_refreshes() -> &'static Mutex<HashSet<String>> {
    static ACTIVE: OnceLock<Mutex<HashSet<String>>> = OnceLock::new();
    ACTIVE.get_or_init(|| Mutex::new(HashSet::new()))
}

fn spawn_live_refresh(app: AppHandle, page: u32, sort: String, creator: Option<String>) {
    let key = format!("{page}|{sort}|{}", creator.as_deref().unwrap_or(""));
    {
        let mut guard = active_refreshes()
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        if !guard.insert(key.clone()) {
            return;
        }
    }
    tauri::async_runtime::spawn(async move {
        // Background browsing refresh follows the same read-optimized path as
        // Community: local cache -> Continuity/D1 -> GitHub fallback. Explicit
        // Refresh and post-mutation reconciliation remain GitHub-authoritative.
        // This keeps latency low without consuming authenticated API quota or
        // exposing any private identity/token to the public projection.
        let feed = live_feed(&app, page, &sort, creator.as_deref(), false).await;
        let event = FreelancerRefreshEvent {
            page,
            sort,
            creator,
            feed,
        };
        let _ = app.emit("jingu-freelancers-refreshed", event);
        active_refreshes()
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .remove(&key);
    });
}

fn spawn_public_cache_reconcile(app: AppHandle) {
    // A successful GitHub mutation should be visible on the same machine even
    // while GitHub Actions is still propagating the public snapshot to D1. The
    // authoritative GitHub read warms both default public sort caches without
    // blocking the mutation response.
    tauri::async_runtime::spawn(async move {
        let created = github_public_feed_fallback(&app, 1, "created", None).await;
        let _ = app.emit(
            "jingu-freelancers-refreshed",
            FreelancerRefreshEvent {
                page: 1,
                sort: "created".into(),
                creator: None,
                feed: created,
            },
        );
        let _ = github_public_feed_fallback(&app, 1, "updated", None).await;
    });
}

pub(crate) fn prewarm(app: AppHandle) {
    // Prewarm only the public Continuity projection. Never spend GitHub quota
    // during startup just to make the browsing view feel warm.
    tauri::async_runtime::spawn(async move {
        if load_public_cache(&app, 1, "created").is_some()
            || crate::continuity::base_url().is_none()
        {
            return;
        }
        if let Ok(feed) = continuity_public_feed(1, "created", None, false, false).await {
            save_public_cache(&app, 1, "created", feed.has_more, &feed.posts);
        }
    });
}

#[tauri::command]
pub async fn freelancers_fetch(
    app: AppHandle,
    page: Option<u32>,
    sort: Option<String>,
    creator: Option<String>,
    force_refresh: Option<bool>,
) -> FreelancerFeed {
    let page = page.unwrap_or(1).clamp(1, 100);
    let sort = match sort.as_deref() {
        Some("updated") => "updated",
        _ => "created",
    };
    let creator = creator
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty());
    let force_refresh = force_refresh.unwrap_or(false);

    // Public browsing is cache-first. A validated local page is returned in a
    // few milliseconds and GitHub refreshes silently in the background.
    if !force_refresh && creator.is_none() {
        if let Some(cached) = load_public_cache(&app, page, sort) {
            spawn_live_refresh(app.clone(), page, sort.to_string(), None);
            return fast_cached_feed(cached, page);
        }

        // First run: use the read-optimized Cloudflare snapshot as the fast
        // path, then reconcile against GitHub in the background.
        if crate::continuity::base_url().is_some() {
            if let Ok(feed) = continuity_public_feed(page, sort, None, false, false).await {
                save_public_cache(&app, page, sort, feed.has_more, &feed.posts);
                spawn_live_refresh(app.clone(), page, sort.to_string(), None);
                return feed;
            }
        }
    }

    if force_refresh {
        // “Atualizar” is an explicit source-of-truth operation. Continuity is
        // deliberately optimized for hot reads and can lag GitHub by the few
        // seconds required for Actions to reconcile a write. Query GitHub first
        // here so a just-created/closed listing is reflected immediately; only
        // fall back to a primary Continuity read if GitHub itself is unavailable.
        let github = github_public_feed_fallback(&app, page, sort, creator).await;
        if !matches!(github.state.as_str(), "error" | "offline") {
            return github;
        }
        if crate::continuity::base_url().is_some() {
            if let Ok(feed) = continuity_public_feed(page, sort, creator, false, true).await {
                if creator.is_none() {
                    save_public_cache(&app, page, sort, feed.has_more, &feed.posts);
                }
                return feed;
            }
        }
        return github;
    }

    live_feed(&app, page, sort, creator, false).await
}

async fn active_posts_for_target(
    target: &RepositoryTarget,
    login: &str,
    token: &str,
) -> Result<usize, String> {
    const MAX_CREATOR_PAGES: usize = 3;
    let creator = login.trim().trim_start_matches('@');
    let mut managed_count = 0usize;
    let mut completed = false;
    for page in 1..=MAX_CREATOR_PAGES {
        let url = api_url(&format!(
            "/repos/{}/{}/issues?state=open&creator={creator}&per_page=100&page={page}",
            target.owner, target.repo
        ));
        let response = crate::github::send_with_retry(
            request(&client()?, Method::GET, &url, Some(token)),
            "a verificação do limite de anúncios",
        )
        .await?;
        if !response.status().is_success() {
            return Err(github_error(
                response,
                "Não foi possível verificar seus anúncios ativos.",
                true,
            )
            .await);
        }
        let rows: Vec<IssueRow> = response.json().await.map_err(|e| e.to_string())?;
        let count = rows.len();
        managed_count =
            managed_count.saturating_add(rows.iter().filter(|issue| managed_issue(issue)).count());
        if count < 100 {
            completed = true;
            break;
        }
    }
    if !completed {
        return Err(format!(
            "O GitHub retornou pelo menos {} Issues abertas para @{creator}; o Hub recusou calcular o limite de anúncios a partir de uma lista truncada.",
            MAX_CREATOR_PAGES * 100
        ));
    }
    Ok(managed_count)
}

async fn active_posts_for_current_user(token: &str) -> Result<usize, String> {
    let user =
        crate::github::cached_user().ok_or_else(|| "Entre no GitHub primeiro.".to_string())?;
    let public = repository_target("public", true).await?;
    active_posts_for_target(&public, &user.login, token).await
}

async fn allocate_display_id(token: &str) -> Result<String, String> {
    const MAX_ID_SCAN_PAGES: usize = 100;
    let public = repository_target("public", true).await?;
    let mut used = HashSet::new();
    let mut public_complete = false;
    for page in 1..=MAX_ID_SCAN_PAGES {
        let url = api_url(&format!(
            "/repos/{}/{}/issues?state=open&per_page=100&page={page}",
            public.owner, public.repo
        ));
        let response = crate::github::send_with_retry(
            request(&client()?, Method::GET, &url, Some(token)),
            "a alocação do ID do anúncio",
        )
        .await?;
        if !response.status().is_success() {
            return Err(github_error(
                response,
                "Não foi possível reservar um ID para o anúncio.",
                true,
            )
            .await);
        }
        let rows: Vec<IssueRow> = response.json().await.map_err(|e| e.to_string())?;
        let count = rows.len();
        for row in rows {
            if let Some(display_id) = managed_display_id_from_issue(&row) {
                used.insert(display_id);
            }
        }
        if count < 100 {
            public_complete = true;
            break;
        }
    }
    if !public_complete {
        return Err(format!(
            "O catálogo público excedeu {} Issues abertas; o Hub recusou alocar um ID usando um inventário truncado.",
            MAX_ID_SCAN_PAGES * 100
        ));
    }

    for _ in 0..32 {
        let candidate = random_display_id();
        if !used.contains(&candidate) {
            return Ok(candidate);
        }
    }
    Err("Não foi possível reservar um identificador único para o anúncio. Tente novamente.".into())
}

fn entitlements_from_profile(
    profile: crate::membership::MembershipProfile,
) -> FreelancerEntitlements {
    FreelancerEntitlements {
        tier: profile.tier,
        label: profile.label,
        badge_label: profile.badge_label,
        active_post_limit: profile.active_post_limit,
        summary_max_chars: profile.summary_max_chars,
        description_max_chars: profile.description_max_chars,
        boost_credits_per_cycle: profile.boost_credits_per_cycle,
        boost_duration_days: profile.boost_duration_days,
        boosts_remaining: profile.boosts_remaining,
        sponsored_available: profile.sponsored_available,
        credits_eligible: profile.credits_eligible,
        credits_rank: profile.credits_rank,
        source: profile.source,
    }
}

#[tauri::command]
pub async fn freelancers_entitlements() -> FreelancerEntitlements {
    entitlements_from_profile(crate::membership::display_profile(false).await)
}

#[tauri::command]
pub async fn freelancers_account_status(
    force_refresh: Option<bool>,
) -> Result<FreelancerAccountStatus, String> {
    let user =
        crate::github::cached_user().ok_or_else(|| "Entre no GitHub primeiro.".to_string())?;
    let force_refresh = force_refresh.unwrap_or(false);
    // Normal tab opening stays Continuity-fast. Explicit refresh and successful
    // create/delete transitions request the canonical GitHub count so the quota
    // banner cannot visibly lag the list that was just mutated. Enforcement in
    // freelancers_create() remains GitHub-authoritative regardless of this UI flag.
    let profile = crate::membership::display_profile(force_refresh).await;
    let active = if force_refresh {
        let token = crate::github::access_token().await?;
        active_posts_for_current_user(&token).await?
    } else {
        match continuity_public_feed(1, "created", Some(&user.login), false, false).await {
            Ok(feed) if !feed.has_more => feed.posts.len(),
            _ => {
                let token = crate::github::access_token().await?;
                active_posts_for_current_user(&token).await?
            }
        }
    };
    Ok(FreelancerAccountStatus {
        active_posts: active,
        active_post_limit: profile.active_post_limit,
        can_create: active < profile.active_post_limit,
        tier: profile.tier,
        boosts_remaining: profile.boosts_remaining,
    })
}

#[tauri::command]
pub async fn freelancers_create(
    app: AppHandle,
    input: FreelancerPostInput,
    channel: Option<String>,
) -> Result<FreelancerPost, String> {
    let profile = crate::membership::current_profile().await;
    let input = normalized_input(input, &profile)?;
    if channel
        .as_deref()
        .is_some_and(|value| !value.eq_ignore_ascii_case("public"))
    {
        return Err("O canal Freelancer TEST foi aposentado.".into());
    }
    let channel = "public";
    let token = crate::github::access_token().await?;
    let active = active_posts_for_current_user(&token).await?;
    if active >= profile.active_post_limit {
        return Err(format!("O plano atual permite {} anúncio(s) ativo(s) por usuário. Apague um anúncio em Meus anúncios antes de criar outro.", profile.active_post_limit));
    }
    let display_id = allocate_display_id(&token).await?;
    let body = body_from_input(&input, &display_id)?;
    let target = repository_target(channel, true).await?;
    let url = api_url(&format!("/repos/{}/{}/issues", target.owner, target.repo));
    let response = crate::github::send_once(
        request(&client()?, Method::POST, &url, Some(&token))
            .json(&json!({"title": input.title, "body": body})),
        "a publicação do anúncio Freelancer",
    )
    .await?;
    if !response.status().is_success() {
        return Err(
            github_error(
                response,
                "Não foi possível publicar o anúncio. Verifique se a GitHub App tem permissão Issues: write nesse repositório.",
                true,
            )
            .await,
        );
    }
    let issue: IssueRow = response.json().await.map_err(|error| error.to_string())?;
    let post = issue_to_post(issue, channel).ok_or_else(|| {
        "O GitHub criou o Issue, mas a resposta não corresponde a um anúncio Jingu válido."
            .to_string()
    })?;
    spawn_public_cache_reconcile(app);
    Ok(post)
}

#[tauri::command]
pub async fn freelancers_close(app: AppHandle, number: u64, channel: String) -> Result<(), String> {
    if !channel.eq_ignore_ascii_case("public") {
        return Err("O canal Freelancer TEST foi aposentado.".into());
    }
    let token = crate::github::access_token().await?;
    let issue = require_issue_owner(number, "public", &token).await?;
    decode_marker_compatible(issue.body.as_deref().unwrap_or_default(), issue.number)
        .filter(|(metadata, _)| valid_display_id(&metadata.display_id))
        .ok_or_else(|| "O anúncio não possui metadados Jingu válidos para remoção.".to_string())?;
    // Preserve all public content until the repository-owned archive workflow has
    // copied and verified it in the private archive. Only then is the public Issue deleted.
    let target = repository_target("public", true).await?;
    let url = api_url(&format!(
        "/repos/{}/{}/issues/{number}",
        target.owner, target.repo
    ));
    let response = crate::github::send_once(
        request(&client()?, Method::PATCH, &url, Some(&token)).json(&json!({"state":"closed"})),
        "o encerramento do anúncio Freelancer",
    )
    .await?;
    if !response.status().is_success() {
        return Err(github_error(response, "Não foi possível encerrar o anúncio.", true).await);
    }
    spawn_public_cache_reconcile(app);
    Ok(())
}

async fn issue_reactions(
    number: u64,
    channel: &str,
    token: &str,
) -> Result<Vec<ReactionRow>, String> {
    let target = repository_target(channel, true).await?;
    let url = api_url(&format!(
        "/repos/{}/{}/issues/{number}/reactions?content=heart&per_page=100",
        target.owner, target.repo
    ));
    let response = crate::github::send_with_retry(
        request(&client()?, Method::GET, &url, Some(token)),
        "a consulta de reações do Freelancer",
    )
    .await?;
    if !response.status().is_success() {
        return Err(github_error(response, "Não foi possível consultar as reações.", true).await);
    }
    response.json().await.map_err(|error| error.to_string())
}

async fn batch_reaction_states_for_target(
    target: &RepositoryTarget,
    numbers: &[u64],
) -> Result<HashMap<String, FreelancerReactionState>, String> {
    if numbers.is_empty() {
        return Ok(HashMap::new());
    }
    let token = target
        .token
        .as_deref()
        .ok_or_else(|| "Entre no GitHub para consultar suas curtidas.".to_string())?;
    let mut fields = String::new();
    for (index, number) in numbers.iter().enumerate() {
        fields.push_str(&format!(
            "i{index}:issue(number:{number}){{reactionGroups{{content viewerHasReacted reactors{{totalCount}}}}}}"
        ));
    }
    let query = format!(
        "query($owner:String!,$name:String!){{repository(owner:$owner,name:$name){{{fields}}}}}"
    );
    let response = crate::github::send_with_retry(
        request(
            &client()?,
            Method::POST,
            "https://api.github.com/graphql",
            Some(token),
        )
        .json(&json!({
            "query": query,
            "variables": { "owner": target.owner.as_str(), "name": target.repo.as_str() }
        })),
        "a consulta GraphQL de curtidas em lote",
    )
    .await?;
    if !response.status().is_success() {
        return Err(github_error(response, "Falha ao consultar curtidas em lote.", true).await);
    }
    let payload: Value = response.json().await.map_err(|error| error.to_string())?;
    let repository = payload
        .get("data")
        .and_then(|value| value.get("repository"))
        .and_then(Value::as_object)
        .ok_or_else(|| "Resposta GraphQL de curtidas inválida.".to_string())?;
    let mut out = HashMap::new();
    for (index, number) in numbers.iter().enumerate() {
        let groups = repository
            .get(&format!("i{index}"))
            .and_then(|issue| issue.get("reactionGroups"))
            .and_then(Value::as_array);
        let heart = groups.and_then(|rows| {
            rows.iter()
                .find(|row| row.get("content").and_then(Value::as_str) == Some("HEART"))
        });
        out.insert(
            format!("{}:{number}", target.channel),
            FreelancerReactionState {
                liked: heart
                    .and_then(|row| row.get("viewerHasReacted"))
                    .and_then(Value::as_bool)
                    .unwrap_or(false),
                likes: heart
                    .and_then(|row| row.get("reactors"))
                    .and_then(|reactors| reactors.get("totalCount"))
                    .and_then(Value::as_u64)
                    .unwrap_or(0),
            },
        );
    }
    Ok(out)
}

#[tauri::command]
pub async fn freelancers_reaction_states(
    lookups: Vec<FreelancerReactionLookup>,
) -> Result<HashMap<String, FreelancerReactionState>, String> {
    if lookups.len() > 30 {
        return Err("Consulte no máximo 30 estados de curtida por vez.".into());
    }
    if crate::github::cached_user().is_none() {
        return Ok(HashMap::new());
    }
    let mut numbers = Vec::new();
    for lookup in lookups {
        if lookup.number == 0 || !lookup.channel.eq_ignore_ascii_case("public") {
            continue;
        }
        if !numbers.contains(&lookup.number) {
            numbers.push(lookup.number);
        }
    }
    if numbers.is_empty() {
        return Ok(HashMap::new());
    }
    let target = repository_target("public", true).await?;
    batch_reaction_states_for_target(&target, &numbers).await
}

#[tauri::command]
pub async fn freelancers_reaction_state(
    number: u64,
    channel: String,
) -> Result<FreelancerReactionState, String> {
    let user =
        crate::github::cached_user().ok_or_else(|| "Entre no GitHub primeiro.".to_string())?;
    let token = crate::github::access_token().await?;
    if !channel.eq_ignore_ascii_case("public") {
        return Err("O canal Freelancer TEST foi aposentado.".into());
    }
    let rows = issue_reactions(number, "public", &token).await?;
    Ok(FreelancerReactionState {
        liked: rows.iter().any(|row| {
            row.content == "heart" && row.user.as_ref().map(|item| item.id) == Some(user.id)
        }),
        likes: rows.iter().filter(|row| row.content == "heart").count() as u64,
    })
}

#[tauri::command]
pub async fn freelancers_toggle_like(
    number: u64,
    channel: String,
) -> Result<FreelancerReactionState, String> {
    let user =
        crate::github::cached_user().ok_or_else(|| "Entre no GitHub primeiro.".to_string())?;
    let token = crate::github::access_token().await?;
    if !channel.eq_ignore_ascii_case("public") {
        return Err("O canal Freelancer TEST foi aposentado.".into());
    }
    let rows = issue_reactions(number, "public", &token).await?;
    let existing = rows.iter().find(|row| {
        row.content == "heart" && row.user.as_ref().map(|item| item.id) == Some(user.id)
    });
    let target = repository_target("public", true).await?;
    let owner = &target.owner;
    let repo = &target.repo;
    if let Some(reaction) = existing {
        let url = api_url(&format!(
            "/repos/{owner}/{repo}/issues/{number}/reactions/{}",
            reaction.id
        ));
        let response = crate::github::send_once(
            request(&client()?, Method::DELETE, &url, Some(&token)),
            "a remoção de reação do Freelancer",
        )
        .await?;
        if response.status() != StatusCode::NO_CONTENT {
            return Err(github_error(response, "Não foi possível remover a reação.", true).await);
        }
        return Ok(FreelancerReactionState {
            liked: false,
            likes: rows
                .iter()
                .filter(|row| row.content == "heart")
                .count()
                .saturating_sub(1) as u64,
        });
    }

    let url = api_url(&format!("/repos/{owner}/{repo}/issues/{number}/reactions"));
    let response = crate::github::send_once(
        request(&client()?, Method::POST, &url, Some(&token)).json(&json!({"content":"heart"})),
        "a criação de reação do Freelancer",
    )
    .await?;
    if !response.status().is_success() {
        return Err(
            github_error(
                response,
                "Não foi possível reagir ao anúncio. Verifique se a GitHub App tem permissão Issues: write nesse repositório.",
                true,
            )
            .await,
        );
    }
    Ok(FreelancerReactionState {
        liked: true,
        likes: rows.iter().filter(|row| row.content == "heart").count() as u64 + 1,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn input() -> FreelancerPostInput {
        FreelancerPostInput {
            title: "Procuro artista 2D".into(),
            summary: "Projeto indie procura artista para colaboração remunerada.".into(),
            description: "Descrição suficientemente longa para validar corretamente o anúncio."
                .into(),
            kind: "recruiting".into(),
            compensation: "paid".into(),
            areas: vec!["art-2d".into()],
            country_code: "BR".into(),
            region_code: "BR-PI".into(),
            portfolio_links: vec![FreelancerLink {
                kind: "portfolio".into(),
                label: "Site".into(),
                value: "https://example.com/portfolio".into(),
            }],
            contact_links: vec![FreelancerLink {
                kind: "email".into(),
                label: "qualquer rótulo do usuário".into(),
                value: "mailto:dev@example.com".into(),
            }],
            image_url: None,
        }
    }

    #[test]
    fn metadata_round_trip() {
        let input = normalized_input(input(), &crate::membership::free_profile()).unwrap();
        let body = body_from_input(&input, "F-ABC2345").unwrap();
        let metadata = decode_marker(&body).unwrap();
        assert_eq!(metadata.kind, "recruiting");
        assert_eq!(metadata.areas, vec!["art-2d"]);
        assert_eq!(description_from_body(&body), input.description);
    }

    #[test]
    fn rejects_non_https_links() {
        let mut value = input();
        value.contact_links = vec![FreelancerLink {
            kind: "website".into(),
            label: "Contato".into(),
            value: "javascript:alert(1)".into(),
        }];
        assert!(normalized_input(value, &crate::membership::free_profile()).is_err());
    }

    #[test]
    fn canonicalizes_contact_labels_and_accepts_valid_geography() {
        let normalized = normalized_input(input(), &crate::membership::free_profile()).unwrap();
        assert_eq!(normalized.country_code, "BR");
        assert_eq!(normalized.region_code, "BR-PI");
        assert_eq!(normalized.contact_links[0].label, "E-mail");
    }

    #[test]
    fn rejects_unknown_country_or_wrong_region() {
        let mut bad_country = input();
        bad_country.country_code = "ZZ".into();
        assert!(normalized_input(bad_country, &crate::membership::free_profile()).is_err());

        let mut bad_region = input();
        bad_region.region_code = "US-CA".into();
        assert!(normalized_input(bad_region, &crate::membership::free_profile()).is_err());
    }

    #[test]
    fn rejects_contact_domain_lookalikes() {
        for (kind, value) in [
            ("whatsapp", "https://wa.me.example.com/5511999999999"),
            (
                "discord",
                "https://discord.com.example.com/users/123456789012345678",
            ),
            ("telegram", "https://t.me.example.com/tester"),
            ("github", "https://github.com.example.com/tester"),
            ("linkedin", "https://linkedin.com.example.com/in/tester"),
            ("instagram", "https://instagram.com.example.com/tester"),
        ] {
            let mut value_input = input();
            value_input.contact_links = vec![FreelancerLink {
                kind: kind.into(),
                label: "ignored".into(),
                value: value.into(),
            }];
            assert!(
                normalized_input(value_input, &crate::membership::free_profile()).is_err(),
                "{kind}"
            );
        }
    }

    fn cached_post(channel: &str, number: u64) -> FreelancerPost {
        FreelancerPost {
            number,
            display_id: format!("F-{number:07}"),
            channel: channel.into(),
            title: "Anúncio válido".into(),
            summary: "Resumo válido".into(),
            description: "Descrição suficientemente longa para o teste de cache público.".into(),
            kind: "recruiting".into(),
            compensation: "paid".into(),
            areas: vec!["programming".into()],
            country_code: "BR".into(),
            country: "Brasil".into(),
            region_code: "BR-PI".into(),
            region: "Piauí".into(),
            portfolio_links: vec![],
            contact_links: vec![],
            image_url: None,
            author: FreelancerAuthor {
                id: 1,
                login: "tester".into(),
                avatar_url: "https://example.com/a.png".into(),
                html_url: "https://example.com/tester".into(),
            },
            created_at: "2026-08-17T00:00:00Z".into(),
            updated_at: "2026-08-17T00:00:00Z".into(),
            html_url: "https://example.com/issue".into(),
            likes: 0,
            state: "open".into(),
            membership_tier: "free".into(),
            membership_badge: None,
            sponsored: false,
            sponsored_until: None,
        }
    }

    #[test]
    fn continuity_cache_never_keeps_test_rows() {
        let rows = public_only_posts(vec![cached_post("public", 1), cached_post("test", 2)]);
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].channel, "public");
        assert_eq!(rows[0].number, 1);
    }

    fn managed_test_issue(body: String) -> IssueRow {
        IssueRow {
            number: 9,
            title: "Legacy listing".into(),
            body: Some(body),
            state: "open".into(),
            html_url: "https://github.com/JinguEngine/JinguHub-Freelancers/issues/9".into(),
            user: Some(IssueUser {
                id: 99,
                login: "legacy-user".into(),
                avatar_url: "https://avatars.githubusercontent.com/u/99?v=4".into(),
                html_url: "https://github.com/legacy-user".into(),
            }),
            created_at: "2026-08-01T00:00:00Z".into(),
            updated_at: "2026-08-01T00:00:00Z".into(),
            reactions: ReactionSummary::default(),
            pull_request: None,
            labels: vec![],
        }
    }

    #[test]
    fn repair36_legacy_footer_remains_managed_for_inventory() {
        let issue = managed_test_issue(format!("Descrição antiga.\n\n{LEGACY_MANAGED_FOOTER}"));
        assert!(managed_issue(&issue));
        assert!(issue_to_post(issue, "public").is_none());
    }

    #[test]
    fn repair39_schema4_remains_readable_and_normalizes_geography() {
        let raw = serde_json::json!({
            "schema": 4,
            "display_id": "F-ABC2345",
            "summary": "Resumo legado ainda compatível",
            "kind": "seeking",
            "compensation": "paid",
            "areas": ["programming"],
            "country": "Brazil",
            "region": "Maranhão",
            "portfolio_links": [],
            "contact_links": [{
                "kind": "instagram",
                "label": "Instagram",
                "value": "https://instagram.com/legacy-user"
            }],
            "image_url": null
        });
        let marker = format!(
            "{MARKER_PREFIX}{}{MARKER_SUFFIX}",
            URL_SAFE_NO_PAD.encode(serde_json::to_vec(&raw).unwrap())
        );
        let mut issue = managed_test_issue(format!(
            "{marker}\n\nDescrição legado suficientemente longa para permanecer visível."
        ));
        issue.labels = vec![IssueLabel {
            name: "jingu-plan:free".into(),
        }];
        assert!(issue_reconciliation_ready(&issue));
        let post = issue_to_post(issue, "public").expect("schema 4 should stay readable");
        assert_eq!(post.display_id, "F-ABC2345");
        assert_eq!(post.country_code, "BR");
        assert_eq!(post.country, "Brazil");
        assert_eq!(post.region_code, "BR-MA");
        assert_eq!(post.region, "Maranhão");
        assert_eq!(post.membership_tier, "free");
    }

    #[test]
    fn repair39_schema1_gets_deterministic_id_without_rewriting_issue() {
        let raw = serde_json::json!({
            "schema": 1,
            "summary": "Resumo antigo ainda suportado",
            "kind": "seeking",
            "compensation": "paid",
            "areas": ["programming"],
            "country": "País histórico",
            "region": "Região histórica",
            "portfolio_url": "https://example.com/portfolio",
            "contact_url": "https://example.com/contact"
        });
        let marker = format!(
            "{MARKER_PREFIX}{}{MARKER_SUFFIX}",
            URL_SAFE_NO_PAD.encode(serde_json::to_vec(&raw).unwrap())
        );
        let issue = managed_test_issue(format!(
            "{marker}\n\nDescrição antiga suficientemente longa para o adaptador de compatibilidade."
        ));
        let (metadata, source_schema) =
            decode_marker_compatible(issue.body.as_deref().unwrap_or_default(), issue.number)
                .expect("schema 1 should stay readable");
        assert_eq!(source_schema, 1);
        assert_eq!(metadata.display_id, legacy_display_id(issue.number));
        assert!(metadata.country_code.is_empty());
        assert_eq!(metadata.country, "País histórico");
    }

    #[test]
    fn repair39_future_schema_is_preserved_but_not_rendered() {
        let raw = serde_json::json!({
            "schema": CURRENT_SCHEMA + 1,
            "display_id": "F-ABC2345"
        });
        let marker = format!(
            "{MARKER_PREFIX}{}{MARKER_SUFFIX}",
            URL_SAFE_NO_PAD.encode(serde_json::to_vec(&raw).unwrap())
        );
        let issue = managed_test_issue(marker);
        assert!(managed_issue(&issue));
        assert!(
            decode_marker_compatible(issue.body.as_deref().unwrap_or_default(), issue.number)
                .is_none()
        );
    }

    #[test]
    fn repair39_direct_feed_requires_authoritative_plan_label() {
        let mut issue = managed_test_issue(LEGACY_MANAGED_FOOTER.to_string());
        assert!(!issue_reconciliation_ready(&issue));
        issue.labels.push(IssueLabel {
            name: "jingu-plan:bronze".into(),
        });
        assert!(issue_reconciliation_ready(&issue));
        issue.labels.push(IssueLabel {
            name: "jingu:reconcile-pending".into(),
        });
        assert!(!issue_reconciliation_ready(&issue));
    }
    #[test]
    fn repair36_invalid_marker_reserves_display_id_without_becoming_valid_post() {
        let raw = serde_json::json!({"schema":4,"display_id":"F-ABC2345"});
        let marker = format!(
            "{MARKER_PREFIX}{}{MARKER_SUFFIX}",
            URL_SAFE_NO_PAD.encode(serde_json::to_vec(&raw).unwrap())
        );
        let issue = managed_test_issue(marker.clone());
        assert!(managed_issue(&issue));
        assert_eq!(
            managed_display_id_from_body(&marker).as_deref(),
            Some("F-ABC2345")
        );
        assert!(issue_to_post(issue, "public").is_none());
    }
}

#[derive(Debug, Clone, Deserialize)]
pub struct FreelancerReportInput {
    pub number: u64,
    pub channel: String,
    pub reason: String,
    pub detail: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct FreelancerReportResult {
    pub issue_number: u64,
    pub html_url: String,
}

#[tauri::command]
pub async fn freelancers_report(
    input: FreelancerReportInput,
) -> Result<FreelancerReportResult, String> {
    let reason = input.reason.trim();
    let detail = input.detail.trim();
    if input.number == 0
        || reason.is_empty()
        || reason.chars().count() > 80
        || detail.chars().count() > 1000
    {
        return Err("Denúncia inválida.".into());
    }
    let user = crate::github::cached_user()
        .ok_or_else(|| "Entre no GitHub para denunciar um anúncio.".to_string())?;
    let token = crate::github::access_token().await?;
    if !input.channel.eq_ignore_ascii_case("public") {
        return Err("O canal Freelancer TEST foi aposentado.".into());
    }
    let target = repository_target("public", true).await?;
    let owner = &target.owner;
    let repo = &target.repo;
    let client = client()?;
    // Do not depend on moderation labels here: ordinary GitHub users can create
    // Issues but cannot reliably assign repository labels. The organization-owned
    // workflow labels reports asynchronously. Author-scoped marker scanning keeps
    // duplicate detection correct even before that workflow runs.
    let list_url = api_url(&format!(
        "/repos/{owner}/{repo}/issues?state=open&creator={}&per_page=100",
        user.login
    ));
    let existing = crate::github::send_with_retry(
        request(&client, Method::GET, &list_url, Some(&token)),
        "a verificação de denúncia duplicada",
    )
    .await?;
    if existing.status().is_success() {
        if let Ok(rows) = existing.json::<Vec<IssueRow>>().await {
            let marker = format!(
                "JINGU_REPORT_V1 target={} reporter={}",
                input.number, user.id
            );
            if rows
                .iter()
                .any(|row| row.body.as_deref().unwrap_or_default().contains(&marker))
            {
                return Err("Você já possui uma denúncia aberta para este anúncio.".into());
            }
        }
    }
    let body = format!(
        "<!-- JINGU_REPORT_V1 target={} reporter={} -->\n\n**Anúncio:** #{}\n**Motivo:** {}\n\n{}\n\n---\nDenúncia enviada pelo Jingu Hub. A equipe Jingu revisará o conteúdo.",
        input.number, user.id, input.number, reason, if detail.is_empty() { "Sem detalhes adicionais." } else { detail }
    );
    let create_url = api_url(&format!("/repos/{owner}/{repo}/issues"));
    let response = crate::github::send_once(
        request(&client, Method::POST, &create_url, Some(&token)).json(&json!({
            "title": format!("[Denúncia] anúncio #{}", input.number),
            "body": body
        })),
        "o envio da denúncia do Freelancer",
    )
    .await?;
    let status = response.status();
    let value: Value = response.json().await.map_err(|e| e.to_string())?;
    if !status.is_success() {
        return Err(format!(
            "GitHub recusou a denúncia (HTTP {status}): {}",
            value
                .get("message")
                .and_then(Value::as_str)
                .unwrap_or("erro desconhecido")
        ));
    }
    Ok(FreelancerReportResult {
        issue_number: value
            .get("number")
            .and_then(Value::as_u64)
            .ok_or_else(|| "GitHub não retornou o número da denúncia.".to_string())?,
        html_url: value
            .get("html_url")
            .and_then(Value::as_str)
            .unwrap_or_default()
            .to_string(),
    })
}
