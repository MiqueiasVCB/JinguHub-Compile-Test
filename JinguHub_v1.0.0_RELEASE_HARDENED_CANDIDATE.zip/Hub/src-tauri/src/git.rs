/**************************************************************************/
/*  git.rs                                                              */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use crate::git_helpers;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GitStatus {
    pub branch: Option<String>,
    pub has_uncommitted: bool,
    pub is_repo: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GitBranchInfo {
    pub name: String,
    pub is_current: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GitChangedFile {
    pub path: String,
    /// Two-character porcelain status (index + worktree), e.g. "M ", " M", "??".
    pub status: String,
    pub staged: bool,
    pub unstaged: bool,
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn check_is_repo(path: &str) -> bool {
    let dir = PathBuf::from(path);
    // A Jingu project is managed as its own repository. Treating a parent
    // repository as the project's repository can stage/commit files outside
    // the project when a user keeps several projects in one parent checkout.
    // `.git` may be either a directory or a worktree marker file.
    dir.join(".git").exists()
}

fn friendly_git_error(stderr: &str, path: &str) -> String {
    let lower = stderr.to_lowercase();

    if lower.contains("xcode-select")
        || lower.contains("no developer tools")
        || lower.contains("command line developer tools")
    {
        return format!(
            concat!(
                "macOS needs the Xcode Command Line Tools before Git will run.\n\n",
                "Install them, then initialize the repository from the Git panel:\n",
                "  xcode-select --install\n\n",
                "Raw error:\n{}",
            ),
            stderr.trim()
        );
    }
    if lower.contains("please tell me who you are")
        || (lower.contains("user.email") && lower.contains("user.name"))
    {
        return format!(
            concat!(
                "Git doesn't know who you are yet, so it couldn't commit.\n\n",
                "Set your identity, then commit from the Git panel:\n",
                "  git config --global user.name \"Your Name\"\n",
                "  git config --global user.email \"you@example.com\"\n\n",
                "Raw error:\n{}",
            ),
            stderr.trim()
        );
    }

    if lower.contains("host key verification failed") {
        return format!(
            concat!(
                "SSH host key not verified.\n\n",
                "This happens when connecting to a server for the first time.\n",
                "To fix it, open a terminal and run:\n",
                "  ssh -T git@github.com\n",
                "(or your hosting provider). Type 'yes' to accept the key.\n\n",
                "Raw error:\n{}",
            ),
            stderr.trim()
        );
    }
    if lower.contains("permission denied")
        || (lower.contains("publickey") && lower.contains("authentication"))
    {
        return format!(
            concat!(
                "SSH authentication failed.\n\n",
                "Your SSH key isn't set up correctly. To fix it:\n",
                "  1. Generate a key: ssh-keygen -t ed25519\n",
                "  2. Add it to your SSH agent: ssh-add ~/.ssh/id_ed25519\n",
                "  3. Add the public key to your Git hosting account\n\n",
                "Raw error:\n{}",
            ),
            stderr.trim()
        );
    }
    if lower.contains("could not read from remote") || lower.contains("repository not found") {
        return format!(
            concat!(
                "Repositório remoto não encontrado ou sem acesso.\n\n",
                "Confirme se a GitHub App Jingu Engine tem acesso a este repositório e se Contents está como leitura e gravação.\n",
                "Se a instalação usa repositórios selecionados, adicione este repositório e entre novamente no Hub.\n\n",
                "Raw error:\n{}",
            ),
            stderr.trim()
        );
    }
    if lower.contains("authentication failed") {
        return format!(
            concat!(
                "A autenticação GitHub falhou.\n\n",
                "O Jingu Hub usa temporariamente o token da GitHub App somente no processo Git.\n",
                "Saia e entre novamente no GitHub e confirme o acesso da instalação ao repositório.\n\n",
                "Raw error:\n{}",
            ),
            stderr.trim()
        );
    }
    if lower.contains("connection refused") {
        return format!(
            concat!(
                "Connection refused.\n\n",
                "The remote server is not reachable.\n\n",
                "Raw error:\n{}",
            ),
            stderr.trim()
        );
    }
    if lower.contains("could not resolve host") {
        return format!(
            concat!(
                "Could not resolve hostname.\n\n",
                "The remote server address couldn't be found.\n\n",
                "Raw error:\n{}",
            ),
            stderr.trim()
        );
    }
    if lower.contains("timed out") || lower.contains("timeout") {
        return format!(
            concat!(
                "Connection timed out.\n\n",
                "The server took too long to respond.\n\n",
                "Raw error:\n{}",
            ),
            stderr.trim()
        );
    }
    if lower.contains("merge conflict")
        || (lower.contains("conflict") && lower.contains("merge"))
        || lower.contains("automatic merge failed")
    {
        let conflicted = get_merge_conflict_files_for_path_internal(path).unwrap_or_default();
        if !conflicted.is_empty() {
            let files_list = conflicted.join("\n  · ");
            return format!(
                concat!(
                    "Merge conflicts detected.\n\n",
                    "The following files have conflicts:\n",
                    "  · {}\n\n",
                    "You can resolve them using the conflict resolver below,\n",
                    "or by opening a terminal and editing each file manually.\n",
                    "After resolving, stage and commit the changes.\n\n",
                    "Raw error:\n{}",
                ),
                files_list,
                stderr.trim()
            );
        }
        return format!(
            concat!(
                "Merge conflicts detected.\n\n",
                "There are conflicts that need to be resolved before the merge can complete.\n",
                "Open a terminal in the project folder and use 'git status' to see them.\n\n",
                "Raw error:\n{}",
            ),
            stderr.trim()
        );
    }
    if lower.contains("non-fast-forward")
        || lower.contains("[rejected]")
        || (lower.contains("failed to push") && lower.contains("fetch first"))
    {
        return format!(
            concat!(
                "Push rejected, your local branch is behind the remote.\n\n",
                "Use the Pull button first to get the latest changes, then try pushing again.\n\n",
                "Raw error:\n{}",
            ),
            stderr.trim()
        );
    }
    format!(
        concat!("Git operation failed.\n\n", "Raw error:\n{}",),
        stderr.trim()
    )
}

fn get_merge_conflict_files_for_path_internal(path: &str) -> Result<Vec<String>, String> {
    if !check_is_repo(path) {
        return Err("Este projeto não é um repositório Git.".into());
    }
    let stdout = git_helpers::git_cmd(path, ["diff", "--name-only", "--diff-filter=U"])
        .map_err(|e| e.to_string())?;
    Ok(stdout
        .lines()
        .filter(|l| !l.trim().is_empty())
        .map(|l| l.trim().to_string())
        .collect())
}

fn repo_base_name(url: &str) -> String {
    let trimmed = url.trim().trim_end_matches('/').trim_end_matches(".git");
    trimmed
        .split('/')
        .next_back()
        .filter(|s| !s.is_empty())
        .unwrap_or("repo")
        .to_string()
}

fn validate_git_remote_input(url: &str) -> Result<(), String> {
    if url.is_empty() || url.trim() != url {
        return Err("Informe uma URL Git válida, sem espaços no início ou no fim.".into());
    }
    if url.starts_with('-') || url.chars().any(char::is_control) {
        return Err("A URL Git contém uma opção ou caractere de controle não permitido.".into());
    }
    Ok(())
}

fn switch_branch_args(name: &str) -> [&str; 3] {
    ["switch", "--", name]
}

fn create_branch_args(name: &str) -> [&str; 3] {
    ["branch", "--", name]
}

// ---------------------------------------------------------------------------
// Status (custom parsing)
// ---------------------------------------------------------------------------

fn get_git_status_for_path(path: &str) -> GitStatus {
    if !check_is_repo(path) {
        return GitStatus {
            branch: None,
            has_uncommitted: false,
            is_repo: false,
        };
    }

    let output = git_helpers::git_raw(path, ["status", "--porcelain", "--branch"]).ok();

    match output {
        Some(out) => {
            let stdout = git_helpers::output_stdout(&out);
            let mut branch: Option<String> = None;
            let mut has_uncommitted = false;

            for (i, line) in stdout.lines().enumerate() {
                let trimmed = line.trim();
                if trimmed.is_empty() {
                    continue;
                }
                if i == 0 && trimmed.starts_with("## ") {
                    let branch_info = &trimmed[3..];
                    if !branch_info.starts_with("HEAD (no branch)") && !branch_info.is_empty() {
                        let name = branch_info
                            .split("...")
                            .next()
                            .unwrap_or(branch_info)
                            .split('[')
                            .next()
                            .unwrap_or(branch_info)
                            .trim();
                        if !name.is_empty() {
                            branch = Some(name.to_string());
                        }
                    }
                } else {
                    has_uncommitted = true;
                }
            }
            GitStatus {
                branch,
                has_uncommitted,
                is_repo: true,
            }
        }
        None => GitStatus {
            branch: None,
            has_uncommitted: false,
            is_repo: true,
        },
    }
}

fn ensure_commit_identity(_app: &tauri::AppHandle, path: &str) -> Result<(), String> {
    let name_ok = git_helpers::git_raw(path, ["config", "--get", "user.name"])
        .map(|o| o.status.success() && !git_helpers::output_stdout(&o).trim().is_empty())
        .unwrap_or(false);
    let email_ok = git_helpers::git_raw(path, ["config", "--get", "user.email"])
        .map(|o| o.status.success() && !git_helpers::output_stdout(&o).trim().is_empty())
        .unwrap_or(false);
    if name_ok && email_ok {
        return Ok(());
    }
    let Some((name, email)) = crate::github::current_identity_for_git() else {
        return Err("O Git precisa de um nome e e-mail para criar commits. Entre no GitHub pelo Jingu Hub ou configure user.name/user.email no Git.".into());
    };
    if !name_ok {
        git_helpers::git_cmd(path, ["config", "user.name", name.as_str()])
            .map_err(|e| friendly_git_error(&e.to_string(), path))?;
    }
    if !email_ok {
        git_helpers::git_cmd(path, ["config", "user.email", email.as_str()])
            .map_err(|e| friendly_git_error(&e.to_string(), path))?;
    }
    Ok(())
}

async fn authenticated_remote_cmd(
    _app: &tauri::AppHandle,
    path: &str,
    args: &[&str],
) -> Result<String, String> {
    let remote = git_helpers::git_cmd(path, ["remote", "get-url", "origin"])
        .map_err(|_| "O repositório não possui um remote 'origin'.".to_string())?;
    let github_https = remote.trim().starts_with("https://github.com/");
    let output = if github_https {
        let require_write = args.first().is_some_and(|op| *op == "push");
        crate::github::assert_repository_access(&remote, require_write).await?;
        let token = crate::github::access_token().await?;
        git_helpers::git_authenticated_raw(path, args.iter().copied(), &token)
            .map_err(|e| e.to_string())?
    } else {
        git_helpers::git_raw(path, args.iter().copied()).map_err(|e| e.to_string())?
    };
    if !output.status.success() {
        let stderr = git_helpers::output_stderr(&output);
        let stdout = git_helpers::output_stdout(&output);
        let detail = if stderr.trim().is_empty() {
            stdout
        } else {
            stderr
        };
        return Err(friendly_git_error(&detail, path));
    }
    let stdout = git_helpers::output_stdout(&output);
    let stderr = git_helpers::output_stderr(&output);
    Ok(if stdout.trim().is_empty() {
        stderr.trim().to_string()
    } else {
        stdout.trim().to_string()
    })
}

// ---------------------------------------------------------------------------
// Commands
// ---------------------------------------------------------------------------

#[tauri::command]
pub fn get_git_status(path: String) -> GitStatus {
    get_git_status_for_path(&path)
}

#[tauri::command]
pub async fn git_pull(app: tauri::AppHandle, path: String) -> Result<String, String> {
    if !check_is_repo(&path) {
        return Err("Este projeto ainda não possui um repositório Git.".into());
    }
    authenticated_remote_cmd(&app, &path, &["pull", "--ff-only"]).await
}

#[tauri::command]
pub async fn git_push(
    app: tauri::AppHandle,
    path: String,
    force: Option<bool>,
) -> Result<String, String> {
    if !check_is_repo(&path) {
        return Err("Este projeto ainda não possui um repositório Git.".into());
    }
    let branch =
        git_helpers::git_cmd(&path, ["branch", "--show-current"]).map_err(|e| e.to_string())?;
    if branch.trim().is_empty() {
        return Err("Não há uma ramificação ativa para enviar ao GitHub.".into());
    }
    let has_upstream = git_helpers::git_raw(
        &path,
        ["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"],
    )
    .map(|o| o.status.success())
    .unwrap_or(false);
    let mut args: Vec<&str> = vec!["push"];
    if force.unwrap_or(false) {
        args.push("--force-with-lease");
    }
    if !has_upstream {
        args.extend(["--set-upstream", "origin", branch.trim()]);
    }
    authenticated_remote_cmd(&app, &path, &args).await
}

#[tauri::command]
pub fn git_remote_url(path: String) -> Result<String, String> {
    if !check_is_repo(&path) {
        return Err("Este projeto não é um repositório Git.".into());
    }

    let raw = git_helpers::git_cmd(&path, ["remote", "get-url", "origin"])
        .map_err(|_| "Nenhum remote 'origin' está configurado.".to_string())?;

    if raw.is_empty() {
        return Err("Nenhum remote 'origin' está configurado.".into());
    }

    fn to_web_url(url: &str) -> String {
        let url = url.trim_end_matches(".git").trim_end_matches('/');
        if let Some(rest) = url.strip_prefix("git@") {
            if let Some((host, path)) = rest.split_once(':') {
                return format!("https://{}/{}", host, path.trim_start_matches('/'));
            }
        }
        if url.starts_with("https://") || url.starts_with("http://") {
            return url.to_string();
        }
        if let Some(rest) = url.strip_prefix("git://") {
            return format!("https://{}", rest);
        }
        url.to_string()
    }

    Ok(to_web_url(&raw))
}

#[tauri::command]
pub async fn git_fetch(app: tauri::AppHandle, path: String) -> Result<String, String> {
    if !check_is_repo(&path) {
        return Err("Este projeto ainda não possui um repositório Git.".into());
    }
    authenticated_remote_cmd(&app, &path, &["fetch", "--prune"]).await
}

#[tauri::command]
pub fn git_list_branches(path: String) -> Result<Vec<GitBranchInfo>, String> {
    if !check_is_repo(&path) {
        return Err("Este projeto não é um repositório Git.".into());
    }
    let stdout = git_helpers::git_cmd(&path, ["branch", "--format=%(refname:short)|||%(HEAD)"])
        .map_err(|e| e.to_string())?;

    let branches: Vec<GitBranchInfo> = stdout
        .lines()
        .filter(|l| !l.trim().is_empty())
        .filter_map(|line| {
            let parts: Vec<&str> = line.splitn(2, "|||").collect();
            if parts.len() < 2 {
                return None;
            }
            Some(GitBranchInfo {
                name: parts[0].to_string(),
                is_current: parts[1].trim() == "*",
            })
        })
        .collect();

    Ok(branches)
}

#[tauri::command]
pub fn git_switch_branch(path: String, name: String) -> Result<(), String> {
    if !check_is_repo(&path) {
        return Err("Este projeto não é um repositório Git.".into());
    }
    git_helpers::git_cmd(&path, switch_branch_args(&name)).map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
pub fn git_create_branch(path: String, name: String) -> Result<(), String> {
    if !check_is_repo(&path) {
        return Err("Este projeto não é um repositório Git.".into());
    }
    git_helpers::git_cmd(&path, create_branch_args(&name)).map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
pub fn git_changed_files(path: String) -> Result<Vec<GitChangedFile>, String> {
    if !check_is_repo(&path) {
        return Err("Este projeto não é um repositório Git.".into());
    }
    let stdout =
        git_helpers::git_cmd(&path, ["status", "--porcelain"]).map_err(|e| e.to_string())?;

    let files: Vec<GitChangedFile> = stdout
        .lines()
        .filter(|l| !l.trim().is_empty())
        .filter_map(|line| {
            let status = line.get(..2)?.to_string();
            let bytes = status.as_bytes();
            let index = bytes.first().copied().unwrap_or(b' ');
            let worktree = bytes.get(1).copied().unwrap_or(b' ');
            let file_path = line.get(3..)?.to_string();
            if status.trim().is_empty() && file_path.is_empty() {
                None
            } else {
                Some(GitChangedFile {
                    path: file_path,
                    staged: index != b' ' && index != b'?',
                    unstaged: worktree != b' ' || status == "??",
                    status,
                })
            }
        })
        .collect();

    Ok(files)
}

#[tauri::command]
pub fn git_init(path: String) -> Result<String, String> {
    let dir = PathBuf::from(&path);
    if !dir.exists() {
        return Err("O caminho informado não existe.".into());
    }
    if check_is_repo(&path) {
        return Err("Este projeto já possui um repositório Git.".into());
    }

    let stdout = git_helpers::git_command()
        .args(["init", "--initial-branch=main", &path])
        .output()
        .map_err(|e| format!("Não foi possível inicializar o Git: {e}"))
        .and_then(|out| {
            if !out.status.success() {
                let stderr = String::from_utf8_lossy(&out.stderr).trim().to_string();
                return Err(format!("Falha ao inicializar o Git: {stderr}"));
            }
            Ok(String::from_utf8_lossy(&out.stdout).trim().to_string())
        })?;
    Ok(stdout)
}

#[tauri::command]
pub fn git_stage_all(path: String) -> Result<(), String> {
    if !check_is_repo(&path) {
        return Err("Este projeto ainda não possui um repositório Git.".into());
    }
    git_helpers::git_cmd(&path, ["add", "--all"])
        .map_err(|e| friendly_git_error(&e.to_string(), &path))?;
    Ok(())
}

#[tauri::command]
pub fn git_unstage_all(path: String) -> Result<(), String> {
    if !check_is_repo(&path) {
        return Err("Este projeto ainda não possui um repositório Git.".into());
    }
    let head_exists = git_helpers::git_raw(&path, ["rev-parse", "--verify", "HEAD"])
        .map(|o| o.status.success())
        .unwrap_or(false);
    if head_exists {
        git_helpers::git_cmd(&path, ["reset", "HEAD", "--"])
            .map_err(|e| friendly_git_error(&e.to_string(), &path))?;
    } else {
        // Unborn branch: remove paths from the index while keeping working tree files.
        git_helpers::git_cmd(&path, ["rm", "--cached", "-r", "--ignore-unmatch", "."])
            .map_err(|e| friendly_git_error(&e.to_string(), &path))?;
    }
    Ok(())
}

#[tauri::command]
pub fn git_stage_file(path: String, file_path: String) -> Result<(), String> {
    if !check_is_repo(&path) {
        return Err("Este projeto não é um repositório Git.".into());
    }
    git_helpers::git_cmd(&path, ["add", "--", &file_path]).map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
pub fn git_unstage_file(path: String, file_path: String) -> Result<(), String> {
    if !check_is_repo(&path) {
        return Err("Este projeto não é um repositório Git.".into());
    }

    let head_exists = git_helpers::git_raw(&path, ["rev-parse", "--verify", "HEAD"])
        .map(|output| output.status.success())
        .unwrap_or(false);

    if head_exists {
        git_helpers::git_cmd(&path, ["restore", "--staged", "--", &file_path])
            .map_err(|e| friendly_git_error(&e.to_string(), &path))?;
    } else {
        // Before the first commit there is no HEAD for `git restore --staged` to use.
        // Remove only this path from the index while preserving the working-tree file.
        git_helpers::git_cmd(
            &path,
            ["rm", "--cached", "--ignore-unmatch", "--", &file_path],
        )
        .map_err(|e| friendly_git_error(&e.to_string(), &path))?;
    }
    Ok(())
}

#[tauri::command]
pub fn git_commit(
    app: tauri::AppHandle,
    path: String,
    message: String,
    amend: bool,
) -> Result<String, String> {
    if !check_is_repo(&path) {
        return Err("Este projeto ainda não possui um repositório Git.".into());
    }
    if message.trim().is_empty() {
        return Err("Informe uma mensagem para o commit.".into());
    }
    ensure_commit_identity(&app, &path)?;
    let staged = git_helpers::git_raw(&path, ["diff", "--cached", "--quiet"])
        .map(|o| !o.status.success())
        .unwrap_or(false);
    if !staged && !amend {
        return Err("Nenhuma alteração está preparada para commit. Selecione arquivos ou use “Preparar tudo” primeiro.".into());
    }

    let mut args = vec!["commit", "-m", &message];
    if amend {
        args.push("--amend");
    }

    let output = git_helpers::git_raw(&path, &args).map_err(|e| e.to_string())?;

    if !output.status.success() {
        let stderr = git_helpers::output_stderr(&output).trim().to_string();
        let stdout = git_helpers::output_stdout(&output).trim().to_string();
        let detail = if !stderr.is_empty() {
            stderr
        } else if !stdout.is_empty() {
            stdout
        } else {
            "Erro desconhecido. Execute 'git commit' no terminal para obter mais detalhes."
                .to_string()
        };
        return Err(friendly_git_error(&detail, &path));
    }

    Ok(git_helpers::output_stdout(&output).trim().to_string())
}

#[tauri::command]
pub fn git_set_remote(path: String, url: String) -> Result<(), String> {
    if !check_is_repo(&path) {
        return Err("Este projeto não é um repositório Git.".into());
    }
    validate_git_remote_input(&url)?;

    let remotes = git_helpers::git_cmd(&path, ["remote"]).unwrap_or_default();
    let has_origin = remotes.lines().any(|l| l.trim() == "origin");

    let verb = if has_origin { "set-url" } else { "add" };
    git_helpers::git_cmd(&path, ["remote", verb, "origin", &url]).map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
pub fn git_remove_remote(path: String) -> Result<(), String> {
    if !check_is_repo(&path) {
        return Err("Este projeto não é um repositório Git.".into());
    }
    let remotes = git_helpers::git_cmd(&path, ["remote"]).unwrap_or_default();
    if !remotes.lines().any(|line| line.trim() == "origin") {
        return Ok(());
    }
    git_helpers::git_cmd(&path, ["remote", "remove", "origin"]).map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
pub async fn clone_repo(
    app: tauri::AppHandle,
    url: String,
    dest: String,
) -> Result<String, String> {
    validate_git_remote_input(&url)?;
    if !url.contains("://") && !url.contains('@') {
        return Err("Informe uma URL Git válida.".into());
    }
    if url.contains('@') && url.starts_with("http") {
        return Err(
            "URLs HTTP com credenciais embutidas são bloqueadas. Use a URL limpa do repositório."
                .into(),
        );
    }

    let dest_path = PathBuf::from(&dest);
    let settings = crate::settings::read_settings(&app);
    let folder_name = crate::projects::apply_naming_convention(
        &repo_base_name(&url),
        &settings.directory_naming_convention,
    );

    let clone_target = dest_path.join(&folder_name);
    if clone_target.exists() {
        return Err(format!("A pasta '{folder_name}' já existe neste local."));
    }

    let github_https = url.starts_with("https://github.com/");
    let clone_target_string = clone_target.to_string_lossy().to_string();
    let output = if github_https {
        crate::github::assert_repository_access(&url, false).await?;
        let token = crate::github::access_token().await?;
        git_helpers::git_authenticated_raw(
            &dest,
            ["clone", "--", url.as_str(), clone_target_string.as_str()],
            &token,
        )
        .map_err(|e| format!("Não foi possível executar o Git: {e}"))?
    } else {
        git_helpers::git_command()
            .arg("clone")
            .arg("--")
            .arg(&url)
            .arg(&clone_target)
            .output()
            .map_err(|e| format!("Não foi possível executar o Git: {e}"))?
    };

    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr).trim().to_string();
        return Err(friendly_git_error(&stderr, &dest));
    }

    Ok(clone_target.to_string_lossy().to_string())
}

// ---------------------------------------------------------------------------
// Terminal / log opening (not git commands per se)
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Diff (complex parsing)
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn repo_base_name_extraction() {
        assert_eq!(
            repo_base_name("https://github.com/user/my-game.git"),
            "my-game"
        );
        assert_eq!(repo_base_name("git@github.com:user/My Repo.git"), "My Repo");
        assert_eq!(repo_base_name("https://github.com/user/repo"), "repo");
        assert_eq!(repo_base_name("https://github.com/user/repo.git/"), "repo");
        assert_eq!(repo_base_name("https://github.com/user/"), "user");
        assert_eq!(repo_base_name("https://github.com"), "github.com");
    }

    #[test]
    fn clone_folder_name_follows_convention() {
        let name = repo_base_name("https://github.com/user/New Game.git");
        assert_eq!(name, "New Game");
        assert_eq!(
            crate::projects::apply_naming_convention(&name, "kebab-case"),
            "new-game"
        );
        assert_eq!(
            crate::projects::apply_naming_convention(&name, "PascalCase"),
            "NewGame"
        );
        assert_eq!(
            crate::projects::apply_naming_convention(&name, "keep"),
            "New Game"
        );
    }

    #[test]
    fn git_user_inputs_cannot_be_reinterpreted_as_options() {
        assert_eq!(switch_branch_args("--detach"), ["switch", "--", "--detach"]);
        assert_eq!(create_branch_args("--help"), ["branch", "--", "--help"]);
        assert!(validate_git_remote_input("--upload-pack=malicious@host").is_err());
        assert!(validate_git_remote_input("https://example.invalid/repo.git\n--config=x").is_err());
        assert!(validate_git_remote_input("https://example.invalid/repo.git").is_ok());
    }
}
