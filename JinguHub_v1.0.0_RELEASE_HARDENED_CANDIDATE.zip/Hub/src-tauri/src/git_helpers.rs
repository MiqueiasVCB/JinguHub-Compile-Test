/**************************************************************************/
/*  git_helpers.rs                                                      */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use std::ffi::OsStr;
use std::process::Command;

#[cfg(target_os = "windows")]
use std::os::windows::process::CommandExt;

#[cfg(target_os = "windows")]
use crate::terminal::CREATE_NO_WINDOW;

use crate::error::{AppError, AppResult};

pub fn git_command() -> Command {
    #[allow(unused_mut)]
    let mut cmd = Command::new("git");
    #[cfg(target_os = "windows")]
    cmd.creation_flags(CREATE_NO_WINDOW);
    cmd
}

pub fn git_cmd<I, S>(working_dir: &str, args: I) -> AppResult<String>
where
    I: IntoIterator<Item = S>,
    S: AsRef<OsStr>,
{
    let output = git_command().args(args).current_dir(working_dir).output()?;

    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr).trim().to_string();
        return Err(AppError::Message(stderr));
    }

    Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
}

pub fn git_raw<I, S>(working_dir: &str, args: I) -> AppResult<std::process::Output>
where
    I: IntoIterator<Item = S>,
    S: AsRef<OsStr>,
{
    git_command()
        .args(args)
        .current_dir(working_dir)
        .output()
        .map_err(AppError::from)
}

pub fn output_stdout(output: &std::process::Output) -> String {
    String::from_utf8_lossy(&output.stdout).to_string()
}

pub fn output_stderr(output: &std::process::Output) -> String {
    String::from_utf8_lossy(&output.stderr).to_string()
}

/// Execute a Git command against an HTTPS remote using a GitHub App user token
/// without putting the token in argv or the configured remote URL.
pub fn git_authenticated_raw<I, S>(
    working_dir: &str,
    args: I,
    token: &str,
) -> AppResult<std::process::Output>
where
    I: IntoIterator<Item = S>,
    S: AsRef<OsStr>,
{
    if token.trim().is_empty() {
        return Err(AppError::Message(
            "GitHub access token is unavailable".into(),
        ));
    }

    let nonce = format!("{}-{}", std::process::id(), uuid::Uuid::new_v4());
    #[cfg(target_os = "windows")]
    let askpass = std::env::temp_dir().join(format!("jingu-askpass-{nonce}.cmd"));
    #[cfg(not(target_os = "windows"))]
    let askpass = std::env::temp_dir().join(format!("jingu-askpass-{nonce}.sh"));

    #[cfg(target_os = "windows")]
    let script = "@echo off\r\nsetlocal\r\necho %~1 | findstr /I \"Username\" >nul\r\nif %errorlevel%==0 (\r\n  echo x-access-token\r\n) else (\r\n  echo %JINGU_GITHUB_TOKEN%\r\n)\r\n";
    #[cfg(not(target_os = "windows"))]
    let script = "#!/bin/sh\ncase \"$1\" in\n  *Username*|*username*) printf '%s\\n' 'x-access-token' ;;\n  *) printf '%s\\n' \"$JINGU_GITHUB_TOKEN\" ;;\nesac\n";

    std::fs::write(&askpass, script)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mut perms = std::fs::metadata(&askpass)?.permissions();
        perms.set_mode(0o700);
        std::fs::set_permissions(&askpass, perms)?;
    }

    let output = git_command()
        .args(args)
        .current_dir(working_dir)
        .env("GIT_ASKPASS", &askpass)
        .env("GIT_ASKPASS_REQUIRE", "force")
        .env("GIT_TERMINAL_PROMPT", "0")
        .env("JINGU_GITHUB_TOKEN", token)
        .output();

    let _ = std::fs::remove_file(&askpass);
    output.map_err(AppError::from)
}
