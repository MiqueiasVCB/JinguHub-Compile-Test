/**************************************************************************/
/*  github.rs                                                           */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use crate::{credentials, jingu};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::fmt::Write as _;
use std::sync::{
    atomic::{AtomicBool, Ordering},
    Mutex, OnceLock,
};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use tokio::sync::Mutex as AsyncMutex;

const SESSION_KEY: &str = "github-app-device-session-r12";
const SESSION_SCHEMA: u32 = 12;
const REFRESH_SAFETY_SECS: i64 = 5 * 60;
const SESSION_REMOTE_VALIDATION_TTL: Duration = Duration::from_secs(90);
static REMEMBER_LOGIN: AtomicBool = AtomicBool::new(true);

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GitHubUser {
    pub id: u64,
    pub login: String,
    pub name: Option<String>,
    pub avatar_url: String,
    pub html_url: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct StoredSession {
    schema: u32,
    client_id: String,
    app_slug: String,
    access_token: String,
    #[serde(default)]
    refresh_token: Option<String>,
    access_expires_at: i64,
    #[serde(default)]
    refresh_expires_at: Option<i64>,
    user: GitHubUser,
}

#[derive(Default)]
struct SessionState {
    loaded: bool,
    session: Option<StoredSession>,
    generation: u64,
}

fn state() -> &'static Mutex<SessionState> {
    static STATE: OnceLock<Mutex<SessionState>> = OnceLock::new();
    STATE.get_or_init(|| Mutex::new(SessionState::default()))
}

#[derive(Debug, Clone)]
struct SessionRemoteValidation {
    user_id: u64,
    validated_at: Instant,
}

fn session_remote_validation() -> &'static Mutex<Option<SessionRemoteValidation>> {
    static CACHE: OnceLock<Mutex<Option<SessionRemoteValidation>>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(None))
}

fn session_remote_validation_gate() -> &'static AsyncMutex<()> {
    static GATE: OnceLock<AsyncMutex<()>> = OnceLock::new();
    GATE.get_or_init(|| AsyncMutex::new(()))
}

fn clear_session_remote_validation() {
    *session_remote_validation()
        .lock()
        .unwrap_or_else(|error| error.into_inner()) = None;
}

fn session_was_recently_validated(user_id: u64) -> bool {
    session_remote_validation()
        .lock()
        .unwrap_or_else(|error| error.into_inner())
        .as_ref()
        .is_some_and(|entry| {
            entry.user_id == user_id
                && entry.validated_at.elapsed() <= SESSION_REMOTE_VALIDATION_TTL
        })
}

fn mark_session_remotely_validated(user_id: u64) {
    *session_remote_validation()
        .lock()
        .unwrap_or_else(|error| error.into_inner()) = Some(SessionRemoteValidation {
        user_id,
        validated_at: Instant::now(),
    });
}

#[derive(Debug, Clone, Serialize)]
pub struct DeviceFlowStart {
    pub device_code: String,
    pub user_code: String,
    pub verification_uri: String,
    pub expires_in: u64,
    pub interval: u64,
}

#[derive(Debug, Clone, Serialize)]
pub struct DevicePollResult {
    pub status: String,
    pub message: Option<String>,
    pub user: Option<GitHubUser>,
    pub interval: Option<u64>,
}

#[derive(Debug, Clone, Serialize)]
pub struct InstallationStatus {
    pub installed: bool,
    pub installation_id: Option<u64>,
    pub account_login: Option<String>,
    pub repository_selection: Option<String>,
    pub administration: Option<String>,
    pub contents: Option<String>,
    pub can_create_repositories: bool,
    pub can_use_git: bool,
    pub install_url: String,
    pub personal_installed: bool,
    pub personal_repository_selection: Option<String>,
    pub organization_installed: bool,
    pub organization_repository_selection: Option<String>,
    pub organization_account_login: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GitHubRepository {
    pub id: u64,
    pub name: String,
    pub full_name: String,
    pub private: bool,
    pub html_url: String,
    pub clone_url: String,
    pub default_branch: String,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct GitHubPrivateAccess {
    pub engine_test_releases: bool,
    pub hub_test_releases: bool,
    pub any: bool,
}

#[derive(Debug, Clone, Copy)]
pub(crate) enum PrivateResource {
    EngineReleases,
    HubReleases,
}

#[derive(Debug, Clone, Default)]
pub(crate) struct PrivateRepositories {
    pub engine_releases: Option<String>,
    pub hub_releases: Option<String>,
}

#[derive(Debug, Clone)]
pub(crate) struct AuthorizedPrivateRepository {
    pub repository: String,
    pub token: String,
}

#[derive(Debug, Clone)]
struct PrivateRepoCacheEntry {
    login: String,
    fetched_at: Instant,
    repositories: PrivateRepositories,
}

#[derive(Debug, Clone)]
struct InstallationsCacheEntry {
    login: String,
    fetched_at: Instant,
    installations: Vec<Value>,
    etag: Option<String>,
}

fn installations_cache() -> &'static Mutex<Option<InstallationsCacheEntry>> {
    static CACHE: OnceLock<Mutex<Option<InstallationsCacheEntry>>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(None))
}

fn installations_refresh_gate() -> &'static AsyncMutex<()> {
    static GATE: OnceLock<AsyncMutex<()>> = OnceLock::new();
    GATE.get_or_init(|| AsyncMutex::new(()))
}

fn clear_installations_cache() {
    let mut guard = installations_cache()
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    *guard = None;
}

fn private_repo_cache() -> &'static Mutex<Option<PrivateRepoCacheEntry>> {
    static CACHE: OnceLock<Mutex<Option<PrivateRepoCacheEntry>>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(None))
}

fn private_repo_refresh_gate() -> &'static AsyncMutex<()> {
    static GATE: OnceLock<AsyncMutex<()>> = OnceLock::new();
    GATE.get_or_init(|| AsyncMutex::new(()))
}

fn clear_private_repo_cache() {
    let mut guard = private_repo_cache()
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    *guard = None;
}

#[derive(Debug, Clone, Serialize)]
pub struct GitHubRemoteStatus {
    /// reachable | read_only | missing | inaccessible | missing_or_inaccessible | external
    pub state: String,
    pub owner: Option<String>,
    pub repository: Option<String>,
    pub html_url: Option<String>,
    pub can_push: bool,
    pub message: Option<String>,
}

#[derive(Debug, Default)]
struct ApiRateLimitState {
    blocked_until: Option<Instant>,
    reset_epoch: Option<u64>,
}

fn api_rate_limit_state() -> &'static Mutex<ApiRateLimitState> {
    static STATE: OnceLock<Mutex<ApiRateLimitState>> = OnceLock::new();
    STATE.get_or_init(|| Mutex::new(ApiRateLimitState::default()))
}

fn api_request_gate() -> &'static AsyncMutex<()> {
    static GATE: OnceLock<AsyncMutex<()>> = OnceLock::new();
    GATE.get_or_init(|| AsyncMutex::new(()))
}

fn last_mutating_api_request() -> &'static Mutex<Option<Instant>> {
    static LAST: OnceLock<Mutex<Option<Instant>>> = OnceLock::new();
    LAST.get_or_init(|| Mutex::new(None))
}

fn github_api_mutation(builder: &reqwest::RequestBuilder) -> bool {
    builder
        .try_clone()
        .and_then(|request| request.build().ok())
        .is_some_and(|request| {
            request
                .url()
                .host_str()
                .is_some_and(|host| host.eq_ignore_ascii_case("api.github.com"))
                && !matches!(request.method().as_str(), "GET" | "HEAD" | "OPTIONS")
        })
}

async fn pace_mutating_api_request() {
    // GitHub recommends at least one second between mutating REST requests to
    // reduce secondary-rate-limit pressure. The global API gate makes this
    // spacing deterministic even when several UI actions/background tasks race.
    let wait = {
        let guard = last_mutating_api_request()
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        guard
            .as_ref()
            .and_then(|last| Duration::from_secs(1).checked_sub(last.elapsed()))
    };
    if let Some(wait) = wait {
        tokio::time::sleep(wait).await;
    }
    *last_mutating_api_request()
        .lock()
        .unwrap_or_else(|error| error.into_inner()) = Some(Instant::now());
}

fn unix_now_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

fn github_api_builder(builder: &reqwest::RequestBuilder) -> bool {
    builder
        .try_clone()
        .and_then(|request| request.build().ok())
        .and_then(|request| request.url().host_str().map(str::to_string))
        .is_some_and(|host| host.eq_ignore_ascii_case("api.github.com"))
}

fn rate_limit_delay_secs(
    status: reqwest::StatusCode,
    headers: &reqwest::header::HeaderMap,
    now_epoch: u64,
) -> Option<u64> {
    let retry_after = headers
        .get(reqwest::header::RETRY_AFTER)
        .and_then(|value| value.to_str().ok())
        .and_then(|value| value.trim().parse::<u64>().ok());
    if let Some(delay) = retry_after {
        return Some(delay.clamp(1, 86_400));
    }
    let remaining_zero = headers
        .get("x-ratelimit-remaining")
        .and_then(|value| value.to_str().ok())
        .is_some_and(|value| value.trim() == "0");
    if remaining_zero {
        if let Some(reset) = headers
            .get("x-ratelimit-reset")
            .and_then(|value| value.to_str().ok())
            .and_then(|value| value.trim().parse::<u64>().ok())
        {
            return Some(reset.saturating_sub(now_epoch).clamp(1, 86_400));
        }
        return Some(60);
    }
    (status == reqwest::StatusCode::TOO_MANY_REQUESTS).then_some(60)
}

fn register_rate_limit(delay_secs: u64, reset_epoch: Option<u64>, context: &str) {
    let delay_secs = delay_secs.clamp(1, 86_400);
    let mut guard = api_rate_limit_state()
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    let candidate = Instant::now() + Duration::from_secs(delay_secs);
    if guard
        .blocked_until
        .is_none_or(|current| candidate > current)
    {
        guard.blocked_until = Some(candidate);
        guard.reset_epoch = reset_epoch;
    }
    crate::startup::log(format!(
        "GitHub API cooldown armed for {delay_secs}s during {context}; requests will fail fast until reset"
    ));
}

fn observe_rate_limit(response: &reqwest::Response, context: &str) {
    if !response
        .url()
        .host_str()
        .is_some_and(|host| host.eq_ignore_ascii_case("api.github.com"))
    {
        return;
    }
    let now_epoch = unix_now_secs();
    if let Some(delay) = rate_limit_delay_secs(response.status(), response.headers(), now_epoch) {
        let reset = response
            .headers()
            .get("x-ratelimit-reset")
            .and_then(|value| value.to_str().ok())
            .and_then(|value| value.trim().parse::<u64>().ok());
        register_rate_limit(delay, reset, context);
    }
}

fn rate_limit_cooldown_error() -> Option<String> {
    let mut guard = api_rate_limit_state()
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    let blocked_until = guard.blocked_until?;
    let now = Instant::now();
    if blocked_until <= now {
        guard.blocked_until = None;
        guard.reset_epoch = None;
        return None;
    }
    let seconds = blocked_until.duration_since(now).as_secs().max(1);
    Some(format!(
        "O limite temporário da API do GitHub foi atingido. O Jingu pausou novas consultas automaticamente por aproximadamente {seconds}s para respeitar o reset do GitHub."
    ))
}

fn now() -> i64 {
    chrono::Utc::now().timestamp()
}

fn client() -> Result<reqwest::Client, String> {
    static CLIENT: OnceLock<reqwest::Client> = OnceLock::new();
    if let Some(client) = CLIENT.get() {
        return Ok(client.clone());
    }
    let built = reqwest::Client::builder()
        .user_agent(format!("JinguHub/{}", jingu::PRODUCT_VERSION))
        .connect_timeout(std::time::Duration::from_secs(4))
        .timeout(std::time::Duration::from_secs(12))
        .pool_idle_timeout(std::time::Duration::from_secs(300))
        .pool_max_idle_per_host(8)
        .tcp_keepalive(std::time::Duration::from_secs(30))
        .build()
        .map_err(|e| e.to_string())?;
    let _ = CLIENT.set(built.clone());
    Ok(CLIENT.get().cloned().unwrap_or(built))
}

fn api_request(
    client: &reqwest::Client,
    method: reqwest::Method,
    url: &str,
    token: &str,
) -> reqwest::RequestBuilder {
    client
        .request(method, url)
        .header("Accept", "application/vnd.github+json")
        .header("X-GitHub-Api-Version", jingu::GITHUB_API_VERSION)
        .bearer_auth(token)
}

fn form_encode_component(value: &str) -> String {
    let mut encoded = String::with_capacity(value.len());
    for byte in value.bytes() {
        match byte {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'*' | b'-' | b'.' | b'_' => {
                encoded.push(byte as char)
            }
            b' ' => encoded.push('+'),
            _ => {
                // Writing to a String cannot fail. Keep the Result intentionally ignored.
                let _ = write!(&mut encoded, "%{byte:02X}");
            }
        }
    }
    encoded
}

fn form_body(fields: &[(&str, &str)]) -> String {
    let mut body = String::new();
    for (index, (key, value)) in fields.iter().enumerate() {
        if index > 0 {
            body.push('&');
        }
        body.push_str(&form_encode_component(key));
        body.push('=');
        body.push_str(&form_encode_component(value));
    }
    body
}

fn oauth_form_request(
    client: &reqwest::Client,
    url: &str,
    fields: &[(&str, &str)],
) -> reqwest::RequestBuilder {
    client
        .post(url)
        .header("Accept", "application/json")
        .header(
            reqwest::header::CONTENT_TYPE,
            "application/x-www-form-urlencoded",
        )
        .body(form_body(fields))
}

fn parse_api_message(body: &str) -> String {
    serde_json::from_str::<Value>(body)
        .ok()
        .and_then(|v| v.get("message").and_then(Value::as_str).map(str::to_string))
        .filter(|s| !s.trim().is_empty())
        .unwrap_or_else(|| body.trim().to_string())
}

pub(crate) fn is_transient_status(status: reqwest::StatusCode) -> bool {
    matches!(status.as_u16(), 500 | 502..=504)
}

pub(crate) fn friendly_http_error(
    status: reqwest::StatusCode,
    body: &str,
    context: &str,
) -> String {
    let detail = parse_api_message(body);
    let safe_detail = crate::startup::redact_text(&detail)
        .chars()
        .take(320)
        .collect::<String>();
    crate::startup::log(format!(
        "GitHub HTTP {status} during {context}: {safe_detail}"
    ));
    match status.as_u16() {
        500 | 502..=504 => format!(
            "O GitHub está temporariamente indisponível ({status}) durante {context}. O Jingu Hub preservou sua sessão e continuará usando dados locais/cache quando possível."
        ),
        401 => "Sua sessão do GitHub expirou ou foi revogada. Entre novamente.".into(),
        403 if detail.to_ascii_lowercase().contains("rate limit") => {
            register_rate_limit(60, None, context);
            "O limite temporário da API do GitHub foi atingido. O Jingu pausou novas consultas automaticamente antes de tentar novamente.".into()
        },
        429 => {
            register_rate_limit(60, None, context);
            "O GitHub pediu uma pausa temporária nas consultas. O Jingu respeitará o intervalo antes de tentar novamente.".into()
        },
        403 => format!("O GitHub recusou {context}. Revise as permissões e o acesso da GitHub App."),
        404 => format!("O recurso necessário para {context} não foi encontrado ou não está disponível para sua conta."),
        _ => format!("GitHub HTTP {status} durante {context}: {safe_detail}"),
    }
}

pub(crate) async fn send_with_retry(
    builder: reqwest::RequestBuilder,
    context: &str,
) -> Result<reqwest::Response, String> {
    const DELAYS_MS: [u64; 3] = [350, 900, 1_800];
    let mut attempt = 0usize;
    let github_api = github_api_builder(&builder);
    let github_mutation = github_api_mutation(&builder);
    let request_token = request_bearer_token(&builder);

    loop {
        let request = builder.try_clone().ok_or_else(|| {
            format!("Não foi possível repetir a requisição do GitHub durante {context}.")
        })?;
        let outcome = if github_api {
            // Serialize GitHub REST/GraphQL traffic in-process. This prevents the
            // Hub's background refreshes, installation checks and foreground UI
            // from producing a secondary-rate-limit burst at the same instant.
            let _gate = api_request_gate().lock().await;
            if let Some(error) = rate_limit_cooldown_error() {
                return Err(error);
            }
            if github_mutation {
                pace_mutating_api_request().await;
            }
            let outcome = request.send().await;
            if let Ok(response) = outcome.as_ref() {
                observe_rate_limit(response, context);
                if response.status() == reqwest::StatusCode::UNAUTHORIZED {
                    // A 401 from api.github.com is authoritative: the cached OAuth
                    // credential is no longer usable. Clear it immediately so
                    // later public reads can fall back to anonymous access and
                    // private capabilities fail closed instead of retrying a
                    // revoked token throughout the process lifetime.
                    if let Some(token) = request_token.as_deref() {
                        invalidate_session(token);
                    }
                    crate::startup::log(format!(
                        "GitHub session invalidated after HTTP 401 during {context}"
                    ));
                }
            }
            outcome
        } else {
            request.send().await
        };

        match outcome {
            Ok(response) if is_transient_status(response.status()) => {
                if let Some(&delay_ms) = DELAYS_MS.get(attempt) {
                    crate::startup::log(format!(
                        "GitHub transient HTTP {} during {context}; retry {}/{}",
                        response.status(),
                        attempt + 1,
                        DELAYS_MS.len()
                    ));
                    attempt += 1;
                    tokio::time::sleep(std::time::Duration::from_millis(delay_ms)).await;
                    continue;
                }
                return Ok(response);
            }
            Ok(response) => return Ok(response),
            Err(error) if error.is_timeout() || error.is_connect() => {
                if let Some(&delay_ms) = DELAYS_MS.get(attempt) {
                    crate::startup::log(format!(
                        "GitHub transient network error during {context}; retry {}/{}: {error}",
                        attempt + 1,
                        DELAYS_MS.len()
                    ));
                    attempt += 1;
                    tokio::time::sleep(std::time::Duration::from_millis(delay_ms)).await;
                    continue;
                }
                crate::startup::log(format!(
                    "GitHub request failed during {context} after retries: {error}"
                ));
                return Err(format!(
                    "Não foi possível comunicar com o GitHub durante {context}. Sua sessão foi preservada. Detalhe: {error}"
                ));
            }
            Err(error) => {
                crate::startup::log(format!("GitHub request failed during {context}: {error}"));
                return Err(format!(
                    "Não foi possível comunicar com o GitHub durante {context}. Sua sessão foi preservada. Detalhe: {error}"
                ));
            }
        }
    }
}

/// Send a GitHub request exactly once. Use for operations whose effects may have
/// reached GitHub even when the client sees a timeout (repository creation,
/// Issue/reaction mutations, etc.). It shares the same global cooldown, serial
/// API gate and one-second mutation pacing as safe reads, but never replays.
pub(crate) async fn send_once(
    builder: reqwest::RequestBuilder,
    context: &str,
) -> Result<reqwest::Response, String> {
    let github_api = github_api_builder(&builder);
    let github_mutation = github_api_mutation(&builder);
    let request_token = request_bearer_token(&builder);
    let outcome = if github_api {
        let _gate = api_request_gate().lock().await;
        if let Some(error) = rate_limit_cooldown_error() {
            return Err(error);
        }
        if github_mutation {
            pace_mutating_api_request().await;
        }
        let outcome = builder.send().await;
        if let Ok(response) = outcome.as_ref() {
            observe_rate_limit(response, context);
            if response.status() == reqwest::StatusCode::UNAUTHORIZED {
                if let Some(token) = request_token.as_deref() {
                    invalidate_session(token);
                }
                crate::startup::log(format!(
                    "GitHub session invalidated after HTTP 401 during {context}"
                ));
            }
        }
        outcome
    } else {
        builder.send().await
    };
    outcome.map_err(|error| {
        crate::startup::log(format!(
            "GitHub request failed during {context} without automatic retry: {error}"
        ));
        format!(
            "Não foi possível comunicar com o GitHub durante {context}. A operação não foi repetida automaticamente. Detalhe: {error}"
        )
    })
}

/// Perform a public GitHub GET using the signed-in user's higher primary
/// rate-limit budget when available. If GitHub authoritatively rejects that
/// credential with 401, retry this *public* read once without Authorization.
/// This helper must never be used for private/restricted resources.
pub(crate) async fn send_public_github_get_with_optional_auth(
    client: &reqwest::Client,
    url: &str,
    accept: &'static str,
    token: Option<&str>,
    context: &str,
) -> Result<reqwest::Response, String> {
    let build = |credential: Option<&str>| {
        let mut request = crate::jingu::release_get(client, url, accept);
        if let Some(credential) = credential {
            request = request.bearer_auth(credential);
        }
        request
    };
    let response = send_with_retry(build(token), context).await?;
    if token.is_some() && response.status() == reqwest::StatusCode::UNAUTHORIZED {
        crate::startup::log(format!(
            "Public GitHub read received HTTP 401 during {context}; retrying once anonymously"
        ));
        return send_with_retry(build(None), context).await;
    }
    Ok(response)
}

fn session_persistence_enabled() -> bool {
    REMEMBER_LOGIN.load(Ordering::Relaxed)
}

/// Configure whether the OAuth session may survive a process restart.
/// Disabling persistence never signs the user out of the current process; it
/// only removes the durable credential and keeps subsequent tokens in memory.
pub(crate) fn configure_session_persistence(remember: bool) -> Result<(), String> {
    if remember {
        let current = state()
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .session
            .clone();
        if let Some(session) = current {
            let serialized = serde_json::to_string(&session).map_err(|e| e.to_string())?;
            credentials::store(SESSION_KEY, &serialized)?;
        }
        REMEMBER_LOGIN.store(true, Ordering::Relaxed);
    } else {
        REMEMBER_LOGIN.store(false, Ordering::Relaxed);
        if let Err(error) = credentials::erase(SESSION_KEY) {
            crate::startup::log(format!(
                "WARNING: could not remove persisted GitHub session while disabling remember-login: {error}"
            ));
        }
    }
    Ok(())
}

fn load_stored_session() -> Option<StoredSession> {
    if !session_persistence_enabled() {
        return None;
    }
    let raw = credentials::load(SESSION_KEY)?;
    let session: StoredSession = serde_json::from_str(&raw).ok()?;
    if session.schema != SESSION_SCHEMA
        || session.client_id != jingu::GITHUB_APP_CLIENT_ID
        || session.app_slug != jingu::GITHUB_APP_SLUG
        || session.access_token.trim().is_empty()
    {
        let _ = credentials::erase(SESSION_KEY);
        return None;
    }
    Some(session)
}

fn get_session_clone() -> Option<StoredSession> {
    get_session_snapshot().map(|(session, _)| session)
}

fn get_session_snapshot() -> Option<(StoredSession, u64)> {
    let mut guard = state().lock().unwrap_or_else(|e| e.into_inner());
    if !guard.loaded {
        guard.session = load_stored_session();
        guard.loaded = true;
    }
    guard
        .session
        .clone()
        .map(|session| (session, guard.generation))
}

fn commit_session(
    state: &mut SessionState,
    session: StoredSession,
    expected_generation: u64,
    persist: impl FnOnce(&StoredSession) -> Result<(), String>,
) -> Result<(), String> {
    if state.generation != expected_generation {
        return Err("A sessão mudou durante a operação; resposta de login descartada.".into());
    }
    persist(&session)?;
    state.loaded = true;
    state.session = Some(session);
    state.generation = state.generation.wrapping_add(1);
    Ok(())
}

fn set_session(session: StoredSession, expected_generation: u64) -> Result<(), String> {
    let mut guard = state().lock().unwrap_or_else(|e| e.into_inner());
    commit_session(&mut guard, session, expected_generation, |session| {
        if session_persistence_enabled() {
            let serialized = serde_json::to_string(session).map_err(|e| e.to_string())?;
            credentials::store(SESSION_KEY, &serialized)?;
        }
        Ok(())
    })?;
    drop(guard);
    clear_session_remote_validation();
    clear_private_repo_cache();
    clear_installations_cache();
    crate::membership::clear_display_cache();
    Ok(())
}

fn request_bearer_token(builder: &reqwest::RequestBuilder) -> Option<String> {
    let request = builder.try_clone()?.build().ok()?;
    let header = request
        .headers()
        .get(reqwest::header::AUTHORIZATION)?
        .to_str()
        .ok()?;
    header.strip_prefix("Bearer ").map(str::to_owned)
}

fn clear_matching_session(
    state: &mut SessionState,
    expected_token: Option<&str>,
    erase: impl FnOnce() -> Result<(), String>,
) -> Result<bool, String> {
    if expected_token.is_some_and(|token| {
        state
            .session
            .as_ref()
            .is_none_or(|session| session.access_token != token)
    }) {
        return Ok(false);
    }
    let result = erase();
    state.generation = state.generation.wrapping_add(1);
    state.loaded = true;
    state.session = None;
    result.map(|()| true)
}

fn clear_session_matching(expected_token: Option<&str>) -> Result<(), String> {
    let mut guard = state().lock().unwrap_or_else(|e| e.into_inner());
    let result = clear_matching_session(&mut guard, expected_token, || {
        credentials::erase(SESSION_KEY)
    });
    drop(guard);
    if matches!(result, Ok(false)) {
        return Ok(());
    }
    clear_session_remote_validation();
    clear_private_repo_cache();
    clear_installations_cache();
    crate::membership::clear_display_cache();
    result.map(|_| ())
}

fn clear_session() -> Result<(), String> {
    clear_session_matching(None)
}

pub(crate) fn invalidate_session(token: &str) {
    let _ = clear_session_matching(Some(token));
}

async fn fetch_user(token: &str) -> Result<GitHubUser, String> {
    let c = client()?;
    let resp = send_with_retry(
        api_request(
            &c,
            reqwest::Method::GET,
            "https://api.github.com/user",
            token,
        ),
        "a validação da conta",
    )
    .await?;
    let status = resp.status();
    let body = resp.text().await.unwrap_or_default();
    if !status.is_success() {
        return Err(friendly_http_error(status, &body, "a validação da conta"));
    }
    serde_json::from_str::<GitHubUser>(&body)
        .map_err(|e| format!("Resposta de perfil inválida do GitHub: {e}"))
}

async fn refresh(mut session: StoredSession, generation: u64) -> Result<StoredSession, String> {
    let Some(refresh_token) = session.refresh_token.clone().filter(|s| !s.is_empty()) else {
        if session.access_expires_at <= now() {
            return Err("A sessão do GitHub expirou. Entre novamente.".into());
        }
        return Ok(session);
    };
    if session
        .refresh_expires_at
        .is_some_and(|expiry| expiry <= now())
    {
        return Err("A sessão do GitHub expirou. Entre novamente.".into());
    }
    let c = client()?;
    // Refresh tokens may rotate. A timeout can happen after GitHub accepted the
    // request, so replaying the same refresh blindly can invalidate/reuse a
    // one-time credential. Preserve the current session and let the next user
    // action retry explicitly instead of creating an ambiguous OAuth side effect.
    let resp = oauth_form_request(
        &c,
        "https://github.com/login/oauth/access_token",
        &[
            ("client_id", jingu::GITHUB_APP_CLIENT_ID),
            ("grant_type", "refresh_token"),
            ("refresh_token", refresh_token.as_str()),
        ],
    )
    .send()
    .await
    .map_err(|error| {
        crate::startup::log(format!(
            "GitHub OAuth refresh failed without automatic retry: {error}"
        ));
        format!(
            "Não foi possível renovar a sessão porque o GitHub está indisponível. Sua sessão foi preservada e a renovação não será repetida automaticamente. Detalhe: {error}"
        )
    })?;
    let status = resp.status();
    let body = resp.text().await.unwrap_or_default();
    if !status.is_success() {
        if status == reqwest::StatusCode::UNAUTHORIZED {
            invalidate_session(&session.access_token);
        }
        return Err(friendly_http_error(status, &body, "a renovação da sessão"));
    }
    let value: Value = serde_json::from_str(&body)
        .map_err(|e| format!("Resposta OAuth inválida do GitHub: {e}"))?;
    if let Some(error) = value.get("error").and_then(Value::as_str) {
        let desc = value
            .get("error_description")
            .and_then(Value::as_str)
            .unwrap_or(error);
        if error == "incorrect_client_credentials" {
            invalidate_session(&session.access_token);
            return Err("A autorização salva do GitHub não é mais compatível com a configuração atual da App Jingu. Entre novamente.".into());
        }
        return Err(desc.to_string());
    }
    session.access_token = value
        .get("access_token")
        .and_then(Value::as_str)
        .unwrap_or("")
        .to_string();
    if session.access_token.is_empty() {
        return Err("O GitHub não retornou um access token.".into());
    }
    let access_secs = value
        .get("expires_in")
        .and_then(Value::as_i64)
        .unwrap_or(8 * 60 * 60);
    session.access_expires_at = now() + access_secs;
    if let Some(new_refresh) = value.get("refresh_token").and_then(Value::as_str) {
        session.refresh_token = Some(new_refresh.to_string());
    }
    if let Some(refresh_secs) = value
        .get("refresh_token_expires_in")
        .and_then(Value::as_i64)
    {
        session.refresh_expires_at = Some(now() + refresh_secs);
    }
    set_session(session.clone(), generation)?;
    Ok(session)
}

pub async fn access_token() -> Result<String, String> {
    static REFRESH_GATE: AsyncMutex<()> = AsyncMutex::const_new(());
    let _refresh_guard = REFRESH_GATE.lock().await;
    let (mut session, generation) =
        get_session_snapshot().ok_or_else(|| "Entre no GitHub primeiro.".to_string())?;
    if session.access_expires_at <= now() + REFRESH_SAFETY_SECS {
        match refresh(session.clone(), generation).await {
            Ok(new_session) => session = new_session,
            // Keep the stored refresh token on transient network/API failures so
            // the next operation can retry. Explicit sign-out is the operation
            // that guarantees removal from the native secure credential store.
            Err(e) => return Err(e),
        }
    }
    Ok(session.access_token)
}

pub fn cached_user() -> Option<GitHubUser> {
    get_session_clone().map(|s| s.user)
}

fn parse_github_remote(remote: &str) -> Option<(String, String)> {
    let trimmed = remote.trim();
    let raw = if let Some(raw) = trimmed.strip_prefix("https://github.com/") {
        if raw.contains('@') || raw.contains('?') || raw.contains('#') {
            return None;
        }
        raw
    } else {
        trimmed.strip_prefix("git@github.com:")?
    };
    let raw = raw
        .trim_end_matches('/')
        .strip_suffix(".git")
        .unwrap_or(raw.trim_end_matches('/'));
    let mut parts = raw.split('/');
    let owner = parts.next()?.trim();
    let repo = parts.next()?.trim();
    if owner.is_empty() || repo.is_empty() || parts.next().is_some() {
        return None;
    }
    Some((owner.to_string(), repo.to_string()))
}

async fn repository_remote_status(remote: &str) -> Result<GitHubRemoteStatus, String> {
    let Some((owner, repo)) = parse_github_remote(remote) else {
        return Ok(GitHubRemoteStatus {
            state: "external".into(),
            owner: None,
            repository: None,
            html_url: None,
            can_push: false,
            message: None,
        });
    };

    let html_url = format!("https://github.com/{owner}/{repo}");
    let token = access_token().await?;
    let c = client()?;
    let url = format!("https://api.github.com/repos/{owner}/{repo}");
    let resp = send_with_retry(
        api_request(&c, reqwest::Method::GET, &url, &token),
        "a validação do repositório remoto",
    )
    .await?;
    let status = resp.status();
    let body = resp.text().await.unwrap_or_default();

    if status.is_success() {
        let value = serde_json::from_str::<Value>(&body).unwrap_or(Value::Null);
        let can_push = value
            .get("permissions")
            .and_then(|v| v.get("push"))
            .and_then(Value::as_bool)
            .unwrap_or(false);
        return Ok(GitHubRemoteStatus {
            state: if can_push { "reachable" } else { "read_only" }.into(),
            owner: Some(owner),
            repository: Some(repo),
            html_url: value
                .get("html_url")
                .and_then(Value::as_str)
                .map(str::to_string)
                .or(Some(html_url)),
            can_push,
            message: None,
        });
    }

    if status == reqwest::StatusCode::NOT_FOUND {
        // GitHub deliberately returns 404 for both a missing private resource and
        // a private resource hidden from the current token. We only call a 404
        // definitely `missing` when the signed-in user owns the repository and
        // the personal installation covers ALL repositories with Contents access.
        // In every other case the UI preserves the origin and reports the
        // ambiguity instead of destroying local configuration.
        let signed_in = cached_user();
        let installation = github_installation_status_inner(false).await.ok();
        let definitely_missing = signed_in.as_ref().is_some_and(|user| {
            user.login.eq_ignore_ascii_case(&owner)
                && installation.as_ref().is_some_and(|install| {
                    install
                        .account_login
                        .as_deref()
                        .is_some_and(|login| login.eq_ignore_ascii_case(&user.login))
                        && install.repository_selection.as_deref() == Some("all")
                        && install.can_use_git
                })
        });
        return Ok(GitHubRemoteStatus {
            state: if definitely_missing {
                "missing"
            } else {
                "missing_or_inaccessible"
            }
            .into(),
            owner: Some(owner),
            repository: Some(repo),
            html_url: Some(html_url),
            can_push: false,
            message: Some(if definitely_missing {
                "O origin local aponta para um repositório que não existe mais no GitHub.".into()
            } else {
                "O GitHub retornou 404. Para repositórios privados isso pode significar que o repositório foi removido ou que a instalação da App não possui acesso.".into()
            }),
        });
    }

    if status == reqwest::StatusCode::FORBIDDEN || status == reqwest::StatusCode::UNAUTHORIZED {
        return Ok(GitHubRemoteStatus {
            state: "inaccessible".into(),
            owner: Some(owner),
            repository: Some(repo),
            html_url: Some(html_url),
            can_push: false,
            message: Some(format!(
                "O GitHub recusou o acesso a este repositório (HTTP {status}): {}",
                parse_api_message(&body)
            )),
        });
    }

    Err(format!(
        "Não foi possível validar {owner}/{repo} no GitHub (HTTP {status}): {}",
        parse_api_message(&body)
    ))
}

#[tauri::command]
pub async fn github_remote_status(remote: String) -> Result<GitHubRemoteStatus, String> {
    repository_remote_status(&remote).await
}

/// Confirms that the configured `origin` still resolves and that the current
/// GitHub App token has the access required by the requested Git operation.
pub async fn assert_repository_access(remote: &str, require_write: bool) -> Result<(), String> {
    let status = repository_remote_status(remote).await?;
    match status.state.as_str() {
        "external" | "reachable" => Ok(()),
        "read_only" if !require_write => Ok(()),
        "read_only" => Err(
            "Sua conta/App pode ler este repositório, mas não possui permissão de gravação. Revise Contents: Read and write e o acesso da instalação.".into(),
        ),
        "missing" => Err(
            "O remote origin aponta para um repositório que foi removido do GitHub. O projeto e os commits locais continuam intactos; remova ou substitua o origin e crie/vincule um novo repositório.".into(),
        ),
        "missing_or_inaccessible" => Err(
            "O GitHub não encontrou o repositório remoto. Ele pode ter sido removido ou pode estar fora do acesso concedido à GitHub App. Revise ‘Acesso aos repositórios’ antes de remover o origin.".into(),
        ),
        "inaccessible" => Err(status.message.unwrap_or_else(|| {
            "A GitHub App não possui acesso ao repositório remoto.".into()
        })),
        _ => Err("O estado do repositório remoto é inválido.".into()),
    }
}

#[tauri::command]
pub async fn github_session() -> Result<Option<GitHubUser>, String> {
    let Some(session) = get_session_clone() else {
        return Ok(None);
    };
    if session.access_expires_at <= now() + REFRESH_SAFETY_SECS {
        access_token().await?;
    }

    let Some(current) = get_session_clone() else {
        return Ok(None);
    };
    if session_was_recently_validated(current.user.id) {
        return Ok(Some(current.user));
    }

    // Focus/visibility and multiple views can all ask for the session at once.
    // Coalesce them so a single /user request proves the remembered identity.
    let _validation_guard = session_remote_validation_gate().lock().await;
    let Some(current) = get_session_clone() else {
        return Ok(None);
    };
    if session_was_recently_validated(current.user.id) {
        return Ok(Some(current.user));
    }

    let token = access_token().await?;
    let (current, generation) = get_session_snapshot().ok_or("A sessão foi encerrada.")?;
    if current.access_token != token {
        return Err("A sessão mudou durante a validação.".into());
    }
    let remote_user = fetch_user(&token).await?;
    if remote_user.id != current.user.id {
        // A token resolving to another identity must never inherit local state
        // from the previously remembered account. Fail closed and require login.
        invalidate_session(&token);
        return Err("A sessão salva do GitHub mudou de identidade. Entre novamente.".into());
    }

    let changed = remote_user.login != current.user.login
        || remote_user.name != current.user.name
        || remote_user.avatar_url != current.user.avatar_url
        || remote_user.html_url != current.user.html_url;
    if changed {
        let mut refreshed = current;
        refreshed.user = remote_user.clone();
        set_session(refreshed, generation)?;
    }
    if get_session_clone().is_none_or(|session| session.access_token != token) {
        return Err("A sessão mudou durante a validação.".into());
    }
    mark_session_remotely_validated(remote_user.id);
    Ok(Some(remote_user))
}

#[tauri::command]
pub async fn github_begin_device_flow() -> Result<DeviceFlowStart, String> {
    let c = client()?;
    let resp = send_with_retry(
        oauth_form_request(
            &c,
            "https://github.com/login/device/code",
            &[("client_id", jingu::GITHUB_APP_CLIENT_ID)],
        ),
        "o início do login",
    )
    .await?;
    let status = resp.status();
    let body = resp.text().await.unwrap_or_default();
    if !status.is_success() {
        return Err(friendly_http_error(status, &body, "o início do login"));
    }
    let value: Value =
        serde_json::from_str(&body).map_err(|e| format!("Resposta Device Flow inválida: {e}"))?;
    let device_code = value
        .get("device_code")
        .and_then(Value::as_str)
        .unwrap_or("")
        .to_string();
    let user_code = value
        .get("user_code")
        .and_then(Value::as_str)
        .unwrap_or("")
        .to_string();
    let verification_uri = value
        .get("verification_uri")
        .and_then(Value::as_str)
        .unwrap_or(jingu::GITHUB_DEVICE_URL)
        .to_string();
    if device_code.is_empty() || user_code.is_empty() {
        return Err("O GitHub não retornou um código de dispositivo válido.".into());
    }
    Ok(DeviceFlowStart {
        device_code,
        user_code,
        verification_uri,
        expires_in: value
            .get("expires_in")
            .and_then(Value::as_u64)
            .unwrap_or(900),
        interval: value
            .get("interval")
            .and_then(Value::as_u64)
            .unwrap_or(5)
            .clamp(5, 120),
    })
}

#[tauri::command]
pub async fn github_poll_device_flow(device_code: String) -> Result<DevicePollResult, String> {
    let generation = state().lock().unwrap_or_else(|e| e.into_inner()).generation;
    if device_code.trim().is_empty() {
        return Err("Código de dispositivo ausente.".into());
    }
    let c = client()?;
    let resp = send_with_retry(
        oauth_form_request(
            &c,
            "https://github.com/login/oauth/access_token",
            &[
                ("client_id", jingu::GITHUB_APP_CLIENT_ID),
                ("device_code", device_code.as_str()),
                ("grant_type", "urn:ietf:params:oauth:grant-type:device_code"),
            ],
        ),
        "a autorização do login",
    )
    .await?;
    let status = resp.status();
    let body = resp.text().await.unwrap_or_default();
    if !status.is_success() {
        return Err(friendly_http_error(status, &body, "a autorização do login"));
    }
    let value: Value = serde_json::from_str(&body)
        .map_err(|e| format!("Resposta OAuth inválida do GitHub: {e}"))?;
    if let Some(error) = value.get("error").and_then(Value::as_str) {
        let message = value
            .get("error_description")
            .and_then(Value::as_str)
            .map(str::to_string);
        return Ok(match error {
            "authorization_pending" => DevicePollResult {
                status: "pending".into(),
                message,
                user: None,
                interval: None,
            },
            "slow_down" => DevicePollResult {
                status: "slow_down".into(),
                message,
                user: None,
                interval: Some(5),
            },
            "expired_token" => DevicePollResult {
                status: "expired".into(),
                message,
                user: None,
                interval: None,
            },
            "access_denied" => DevicePollResult {
                status: "denied".into(),
                message,
                user: None,
                interval: None,
            },
            "incorrect_client_credentials" => DevicePollResult {
                status: "error".into(),
                message: Some("A configuração da GitHub App Jingu não foi aceita pelo GitHub. Revise o Client ID da App e tente novamente.".into()),
                user: None,
                interval: None,
            },
            other => DevicePollResult {
                status: "error".into(),
                message: Some(message.unwrap_or_else(|| other.to_string())),
                user: None,
                interval: None,
            },
        });
    }
    let access_token = value
        .get("access_token")
        .and_then(Value::as_str)
        .unwrap_or("")
        .to_string();
    if access_token.is_empty() {
        return Err("O GitHub não retornou um access token.".into());
    }
    let access_secs = value
        .get("expires_in")
        .and_then(Value::as_i64)
        .unwrap_or(8 * 60 * 60);
    let refresh_token = value
        .get("refresh_token")
        .and_then(Value::as_str)
        .map(str::to_string);
    let refresh_expires_at = value
        .get("refresh_token_expires_in")
        .and_then(Value::as_i64)
        .map(|v| now() + v);
    let user = fetch_user(&access_token).await?;
    let session = StoredSession {
        schema: SESSION_SCHEMA,
        client_id: jingu::GITHUB_APP_CLIENT_ID.into(),
        app_slug: jingu::GITHUB_APP_SLUG.into(),
        access_token,
        refresh_token,
        access_expires_at: now() + access_secs,
        refresh_expires_at,
        user: user.clone(),
    };
    set_session(session, generation)?;
    Ok(DevicePollResult {
        status: "authorized".into(),
        message: None,
        user: Some(user),
        interval: None,
    })
}

#[tauri::command]
pub fn github_sign_out() -> Result<(), String> {
    clear_session()
}

fn classify_private_test_repository(name: &str) -> Option<PrivateResource> {
    let normalized = name.trim().to_ascii_lowercase();
    if !normalized.ends_with("-test") {
        return None;
    }
    if !normalized.contains("release") {
        return None;
    }
    if normalized.contains("engine") {
        return Some(PrivateResource::EngineReleases);
    }
    if normalized.contains("hub") {
        return Some(PrivateResource::HubReleases);
    }
    None
}

fn assign_unique(slot: &mut Option<String>, candidate: String, ambiguous: &mut bool) {
    match slot {
        None => *slot = Some(candidate),
        Some(existing) if existing == &candidate => {}
        Some(_) => {
            *slot = None;
            *ambiguous = true;
        }
    }
}

async fn user_installations(token: &str) -> Result<Vec<Value>, String> {
    const TTL: Duration = Duration::from_secs(60);
    const MAX_PAGES: usize = 100;
    let login = cached_user().map(|user| user.login).unwrap_or_default();
    let read_cache = || {
        installations_cache()
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .clone()
    };
    if let Some(entry) = read_cache().as_ref() {
        if entry.login.eq_ignore_ascii_case(&login) && entry.fetched_at.elapsed() <= TTL {
            return Ok(entry.installations.clone());
        }
    }

    // GitHub explicitly recommends serial API requests to avoid secondary rate
    // limits. Coalesce concurrent refreshes from the GitHub screen and the
    // private-capability watchdog, then re-check the cache after taking the gate.
    let _refresh = installations_refresh_gate().lock().await;
    let cached = read_cache();
    if let Some(entry) = cached.as_ref() {
        if entry.login.eq_ignore_ascii_case(&login) && entry.fetched_at.elapsed() <= TTL {
            return Ok(entry.installations.clone());
        }
    }

    let c = client()?;
    let mut installations = Vec::new();
    let mut first_page_etag: Option<String> = None;
    let mut advertised_total: Option<usize> = None;
    let mut completed = false;

    for page in 1..=MAX_PAGES {
        let url = format!("https://api.github.com/user/installations?per_page=100&page={page}");
        let mut request = api_request(&c, reqwest::Method::GET, &url, token);
        // A page-specific ETag cannot prove that later pages are unchanged. Use
        // conditional GET only when the last complete result was a single page.
        if page == 1 {
            if let Some(etag) = cached
                .as_ref()
                .filter(|entry| {
                    entry.login.eq_ignore_ascii_case(&login) && entry.installations.len() < 100
                })
                .and_then(|entry| entry.etag.as_deref())
            {
                request = request.header("If-None-Match", etag);
            }
        }
        let response = send_with_retry(request, "a consulta da instalação da GitHub App").await?;
        let status = response.status();
        if page == 1 && status == reqwest::StatusCode::NOT_MODIFIED {
            if let Some(mut entry) = cached.clone().filter(|entry| {
                entry.login.eq_ignore_ascii_case(&login) && entry.installations.len() < 100
            }) {
                entry.fetched_at = Instant::now();
                let result = entry.installations.clone();
                *installations_cache()
                    .lock()
                    .unwrap_or_else(|error| error.into_inner()) = Some(entry);
                return Ok(result);
            }
            return Err(
                "O GitHub retornou 304 sem um cache completo de instalações de página única."
                    .into(),
            );
        }
        if page == 1 {
            first_page_etag = response
                .headers()
                .get("etag")
                .and_then(|value| value.to_str().ok())
                .map(str::to_string);
        }
        let body = response.text().await.unwrap_or_default();
        if !status.is_success() {
            return Err(friendly_http_error(
                status,
                &body,
                "a consulta da instalação da GitHub App",
            ));
        }
        let value: Value = serde_json::from_str(&body)
            .map_err(|e| format!("Resposta de instalação inválida: {e}"))?;
        if page == 1 {
            advertised_total = value
                .get("total_count")
                .and_then(Value::as_u64)
                .and_then(|value| usize::try_from(value).ok());
        }
        let page_rows = value
            .get("installations")
            .and_then(Value::as_array)
            .cloned()
            .ok_or_else(|| "Resposta de instalação não contém installations válido.".to_string())?;
        let count = page_rows.len();
        installations.extend(page_rows);
        let total_reached = advertised_total.is_some_and(|total| installations.len() >= total);
        if count < 100 || total_reached {
            completed = true;
            break;
        }
    }

    if !completed {
        return Err(format!(
            "A lista de instalações do GitHub excedeu o limite defensivo de {MAX_PAGES} páginas; o Hub recusou concluir incorretamente que a Jingu App não está instalada."
        ));
    }
    if let Some(total) = advertised_total {
        if installations.len() < total {
            return Err(format!(
                "O GitHub informou {total} instalações, mas apenas {} foram recebidas; a detecção da Jingu App foi interrompida para evitar falso negativo.",
                installations.len()
            ));
        }
    }

    *installations_cache()
        .lock()
        .unwrap_or_else(|error| error.into_inner()) = Some(InstallationsCacheEntry {
        login,
        fetched_at: Instant::now(),
        installations: installations.clone(),
        etag: first_page_etag,
    });
    Ok(installations)
}

/// Discover private TEST resources from the repositories that GitHub exposes to
/// this user *through this GitHub App installation*. The Hub contains no TEST
/// repository names. If GitHub does not return a private repository here, the
/// Hub cannot infer, display or query it.
pub(crate) async fn private_repositories() -> Result<PrivateRepositories, String> {
    let Some(session) = get_session_clone() else {
        return Ok(PrivateRepositories::default());
    };
    {
        let guard = private_repo_cache()
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        if let Some(entry) = guard.as_ref() {
            if entry.login.eq_ignore_ascii_case(&session.user.login)
                && entry.fetched_at.elapsed() <= Duration::from_secs(60)
            {
                return Ok(entry.repositories.clone());
            }
        }
    }

    // Only one private-repository refresh may enumerate GitHub at a time. Other
    // callers wait for that result and consume the shared 60-second cache.
    let _refresh = private_repo_refresh_gate().lock().await;
    {
        let guard = private_repo_cache()
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        if let Some(entry) = guard.as_ref() {
            if entry.login.eq_ignore_ascii_case(&session.user.login)
                && entry.fetched_at.elapsed() <= Duration::from_secs(60)
            {
                return Ok(entry.repositories.clone());
            }
        }
    }

    let token = access_token().await?;
    let c = client()?;
    let installations = user_installations(&token).await?;
    let installation_id = installations.iter().find_map(|installation| {
        let app_ok =
            installation.get("app_slug").and_then(Value::as_str) == Some(jingu::GITHUB_APP_SLUG);
        let org_ok = installation
            .get("account")
            .and_then(|a| a.get("login"))
            .and_then(Value::as_str)
            .is_some_and(|login| login.eq_ignore_ascii_case(jingu::GITHUB_OWNER));
        (app_ok && org_ok)
            .then(|| installation.get("id").and_then(Value::as_u64))
            .flatten()
    });
    let Some(installation_id) = installation_id else {
        return Ok(PrivateRepositories::default());
    };

    const MAX_REPOSITORY_PAGES: usize = 100;
    let mut found = PrivateRepositories::default();
    let mut ambiguous_engine = false;
    let mut ambiguous_hub = false;
    let mut advertised_total: Option<usize> = None;
    let mut rows_seen = 0usize;
    let mut completed = false;
    for page in 1..=MAX_REPOSITORY_PAGES {
        let url = format!(
            "https://api.github.com/user/installations/{installation_id}/repositories?per_page=100&page={page}"
        );
        let response = send_with_retry(
            api_request(&c, reqwest::Method::GET, &url, &token),
            "a enumeração de repositórios autorizados",
        )
        .await?;
        let status = response.status();
        let body = response.text().await.unwrap_or_default();
        if status == reqwest::StatusCode::NOT_FOUND {
            // Installation access may have been removed between the installation
            // inventory and this request. Fail closed: expose no private TEST data.
            return Ok(PrivateRepositories::default());
        }
        if !status.is_success() {
            return Err(friendly_http_error(
                status,
                &body,
                "a enumeração de repositórios autorizados pela GitHub App",
            ));
        }
        let value: Value = serde_json::from_str(&body)
            .map_err(|e| format!("Resposta de repositórios inválida: {e}"))?;
        if page == 1 {
            advertised_total = value
                .get("total_count")
                .and_then(Value::as_u64)
                .and_then(|value| usize::try_from(value).ok());
        }
        let rows = value
            .get("repositories")
            .and_then(Value::as_array)
            .cloned()
            .ok_or_else(|| {
                "Resposta de repositórios não contém repositories válido.".to_string()
            })?;
        let count = rows.len();
        rows_seen += count;
        for row in rows {
            if row.get("private").and_then(Value::as_bool) != Some(true) {
                continue;
            }
            let Some(full_name) = row.get("full_name").and_then(Value::as_str) else {
                continue;
            };
            let Some((owner, name)) = full_name.split_once('/') else {
                continue;
            };
            if !owner.eq_ignore_ascii_case(jingu::GITHUB_OWNER) {
                continue;
            }
            match classify_private_test_repository(name) {
                Some(PrivateResource::EngineReleases) if !ambiguous_engine => assign_unique(
                    &mut found.engine_releases,
                    name.to_string(),
                    &mut ambiguous_engine,
                ),
                Some(PrivateResource::HubReleases) if !ambiguous_hub => assign_unique(
                    &mut found.hub_releases,
                    name.to_string(),
                    &mut ambiguous_hub,
                ),
                _ => {}
            }
        }
        let total_reached = advertised_total.is_some_and(|total| rows_seen >= total);
        if count < 100 || total_reached {
            completed = true;
            break;
        }
    }
    if !completed {
        return Err(format!(
            "A instalação da GitHub App expõe mais de {} repositórios paginados; o Hub interrompeu a enumeração em vez de concluir incorretamente que um recurso TEST não existe.",
            MAX_REPOSITORY_PAGES * 100
        ));
    }
    if let Some(total) = advertised_total {
        if rows_seen < total {
            return Err(format!(
                "O GitHub informou {total} repositórios autorizados, mas apenas {rows_seen} foram recebidos; recursos privados foram ocultados para evitar uma decisão incompleta."
            ));
        }
    }
    {
        let mut guard = private_repo_cache()
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        *guard = Some(PrivateRepoCacheEntry {
            login: session.user.login,
            fetched_at: Instant::now(),
            repositories: found.clone(),
        });
    }
    Ok(found)
}

pub(crate) async fn authorized_private_repository(
    resource: PrivateResource,
) -> Result<Option<AuthorizedPrivateRepository>, String> {
    let repositories = private_repositories().await?;
    let repository = match resource {
        PrivateResource::EngineReleases => repositories.engine_releases,
        PrivateResource::HubReleases => repositories.hub_releases,
    };
    let Some(repository) = repository else {
        return Ok(None);
    };
    let token = access_token().await?;
    Ok(Some(AuthorizedPrivateRepository { repository, token }))
}

#[tauri::command]
pub async fn github_private_access() -> Result<GitHubPrivateAccess, String> {
    let repositories = private_repositories().await?;
    let engine_test_releases = repositories.engine_releases.is_some();
    let hub_test_releases = repositories.hub_releases.is_some();
    Ok(GitHubPrivateAccess {
        engine_test_releases,
        hub_test_releases,
        any: engine_test_releases || hub_test_releases,
    })
}

async fn github_installation_status_inner(
    force_refresh: bool,
) -> Result<InstallationStatus, String> {
    if force_refresh {
        clear_installations_cache();
        clear_private_repo_cache();
    }
    let token = access_token().await?;
    let installations = user_installations(&token).await?;
    let signed_in_login = cached_user().map(|user| user.login);
    let matching: Vec<&Value> = installations
        .iter()
        .filter(|installation| {
            installation.get("app_slug").and_then(Value::as_str) == Some(jingu::GITHUB_APP_SLUG)
        })
        .collect();

    let personal = signed_in_login.as_deref().and_then(|login| {
        matching.iter().copied().find(|installation| {
            installation
                .get("account")
                .and_then(|account| account.get("login"))
                .and_then(Value::as_str)
                .is_some_and(|account| account.eq_ignore_ascii_case(login))
        })
    });
    let organization = matching.iter().copied().find(|installation| {
        installation
            .get("account")
            .and_then(|account| account.get("login"))
            .and_then(Value::as_str)
            .is_some_and(|account| account.eq_ignore_ascii_case(jingu::GITHUB_OWNER))
    });
    let selected = personal
        .or(organization)
        .or_else(|| matching.first().copied());

    let selection_of = |installation: Option<&Value>| {
        installation
            .and_then(|item| item.get("repository_selection"))
            .and_then(Value::as_str)
            .map(str::to_string)
    };
    let account_of = |installation: Option<&Value>| {
        installation
            .and_then(|item| item.get("account"))
            .and_then(|account| account.get("login"))
            .and_then(Value::as_str)
            .map(str::to_string)
    };
    let permission_of = |installation: Option<&Value>, key: &str| {
        installation
            .and_then(|item| item.get("permissions"))
            .and_then(Value::as_object)
            .and_then(|permissions| permissions.get(key))
            .and_then(Value::as_str)
            .map(str::to_string)
    };

    let personal_admin = permission_of(personal, "administration");
    let personal_contents = permission_of(personal, "contents");
    let organization_contents = permission_of(organization, "contents");
    let can_create_repositories = personal.is_some() && personal_admin.as_deref() == Some("write");
    let can_use_git = personal_contents.as_deref() == Some("write")
        || organization_contents.as_deref() == Some("write");

    if let Some(installation) = selected {
        return Ok(InstallationStatus {
            installed: true,
            installation_id: installation.get("id").and_then(Value::as_u64),
            account_login: account_of(Some(installation)),
            repository_selection: selection_of(Some(installation)),
            administration: permission_of(Some(installation), "administration"),
            contents: permission_of(Some(installation), "contents"),
            can_create_repositories,
            can_use_git,
            install_url: jingu::GITHUB_INSTALL_URL.into(),
            personal_installed: personal.is_some(),
            personal_repository_selection: selection_of(personal),
            organization_installed: organization.is_some(),
            organization_repository_selection: selection_of(organization),
            organization_account_login: account_of(organization),
        });
    }
    Ok(InstallationStatus {
        installed: false,
        installation_id: None,
        account_login: None,
        repository_selection: None,
        administration: None,
        contents: None,
        can_create_repositories: false,
        can_use_git: false,
        install_url: jingu::GITHUB_INSTALL_URL.into(),
        personal_installed: false,
        personal_repository_selection: None,
        organization_installed: false,
        organization_repository_selection: None,
        organization_account_login: None,
    })
}

#[tauri::command]
pub async fn github_installation_status(
    force_refresh: Option<bool>,
) -> Result<InstallationStatus, String> {
    github_installation_status_inner(force_refresh.unwrap_or(false)).await
}

#[tauri::command]
pub async fn github_create_repository(
    name: String,
    description: Option<String>,
    private: bool,
) -> Result<GitHubRepository, String> {
    let name = name.trim();
    if name.is_empty() || name.len() > 100 {
        return Err("Informe um nome de repositório válido.".into());
    }
    if name
        .chars()
        .any(|c| !(c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.')))
    {
        return Err("O nome do repositório contém caracteres não suportados.".into());
    }
    let installation = github_installation_status_inner(true).await?;
    if !installation.installed {
        return Err("A GitHub App Jingu Engine ainda não está instalada nesta conta. Abra “Acesso aos repositórios” e instale a App.".into());
    }
    if !installation.can_create_repositories {
        return Err("A instalação da Jingu Engine ainda não possui Administração: leitura e gravação. Aprove as permissões atualizadas no GitHub e entre novamente.".into());
    }
    if !installation.can_use_git {
        return Err("A instalação da Jingu Engine ainda não possui Contents: leitura e gravação. Aprove as permissões atualizadas no GitHub e entre novamente.".into());
    }
    let signed_in = cached_user().ok_or_else(|| "Entre no GitHub primeiro.".to_string())?;
    if installation.account_login.as_deref() != Some(signed_in.login.as_str()) {
        return Err("Para criar um repositório na sua conta, instale a GitHub App Jingu Engine também na sua conta pessoal. Instalações somente em organizações continuam válidas para trabalhar nos repositórios dessas organizações.".into());
    }
    let token = access_token().await?;
    let c = client()?;
    let mut payload = serde_json::Map::new();
    payload.insert("name".into(), Value::String(name.to_string()));
    payload.insert("private".into(), Value::Bool(private));
    payload.insert("auto_init".into(), Value::Bool(false));
    if let Some(desc) = description.filter(|d| !d.trim().is_empty()) {
        payload.insert("description".into(), Value::String(desc.trim().to_string()));
    }
    let resp = send_once(
        api_request(
            &c,
            reqwest::Method::POST,
            "https://api.github.com/user/repos",
            &token,
        )
        .json(&payload),
        "a criação de repositório",
    )
    .await?;
    let status = resp.status();
    let accepted = resp
        .headers()
        .get("x-accepted-github-permissions")
        .and_then(|v| v.to_str().ok())
        .map(str::to_string);
    let body = resp.text().await.unwrap_or_default();
    if !status.is_success() {
        let mut message = friendly_http_error(status, &body, "a criação de repositório");
        if let Some(p) = accepted {
            message.push_str(&format!(" Permissões aceitas pelo endpoint: {p}."));
        }
        return Err(message);
    }
    serde_json::from_str::<GitHubRepository>(&body)
        .map_err(|e| format!("Resposta de criação de repositório inválida: {e}"))
}

#[tauri::command]
pub async fn github_list_accessible_repositories() -> Result<Vec<GitHubRepository>, String> {
    let token = access_token().await?;
    let c = client()?;
    const MAX_REPOSITORY_PAGES: usize = 100;
    let mut repos = Vec::new();
    let mut completed = false;
    for page in 1..=MAX_REPOSITORY_PAGES {
        let url = format!("https://api.github.com/user/repos?per_page=100&page={page}&sort=updated&affiliation=owner,collaborator,organization_member");
        let resp = send_with_retry(
            api_request(&c, reqwest::Method::GET, &url, &token),
            "a listagem de repositórios",
        )
        .await?;
        let status = resp.status();
        let body = resp.text().await.unwrap_or_default();
        if !status.is_success() {
            return Err(friendly_http_error(
                status,
                &body,
                "a listagem de repositórios",
            ));
        }
        let page_repos: Vec<GitHubRepository> = serde_json::from_str(&body)
            .map_err(|e| format!("Resposta inválida ao listar repositórios: {e}"))?;
        let count = page_repos.len();
        repos.extend(page_repos);
        if count < 100 {
            completed = true;
            break;
        }
    }
    if !completed {
        return Err(format!(
            "Sua conta excedeu o limite defensivo de {} repositórios paginados; o Hub recusou retornar uma lista silenciosamente truncada.",
            MAX_REPOSITORY_PAGES * 100
        ));
    }
    Ok(repos)
}

pub fn current_identity_for_git() -> Option<(String, String)> {
    let user = cached_user()?;
    let name = user
        .name
        .clone()
        .filter(|s| !s.trim().is_empty())
        .unwrap_or_else(|| user.login.clone());
    let email = format!("{}+{}@users.noreply.github.com", user.id, user.login);
    Some((name, email))
}

#[cfg(test)]
mod tests {
    fn fixture_session() -> super::StoredSession {
        super::StoredSession {
            schema: super::SESSION_SCHEMA,
            client_id: "fixture".into(),
            app_slug: "fixture".into(),
            access_token: "fixture-only".into(),
            refresh_token: None,
            access_expires_at: 0,
            refresh_expires_at: None,
            user: super::GitHubUser {
                id: 1,
                login: "fixture".into(),
                name: None,
                avatar_url: String::new(),
                html_url: String::new(),
            },
        }
    }

    #[test]
    fn stale_unauthorized_response_preserves_new_credentials() {
        let mut state = super::SessionState {
            loaded: true,
            session: Some(fixture_session()),
            generation: 4,
        };
        assert!(
            !super::clear_matching_session(&mut state, Some("old-token"), || {
                panic!("stale response must not erase credentials")
            })
            .unwrap()
        );
        assert_eq!(state.generation, 4);
        assert!(state.session.is_some());
        let mut erased = false;
        assert!(
            super::clear_matching_session(&mut state, Some("fixture-only"), || {
                erased = true;
                Ok(())
            })
            .unwrap()
        );
        assert!(erased);
        assert!(state.session.is_none());
        assert_eq!(state.generation, 5);
        let request = reqwest::Client::new()
            .get("https://api.github.com/user")
            .bearer_auth("fixture-only");
        assert_eq!(
            super::request_bearer_token(&request).as_deref(),
            Some("fixture-only")
        );
    }

    #[test]
    fn stale_oauth_response_cannot_restore_or_persist_a_signed_out_session() {
        let mut state = super::SessionState {
            loaded: true,
            session: None,
            generation: 2,
        };
        let mut persisted = false;
        let result = super::commit_session(&mut state, fixture_session(), 1, |_| {
            persisted = true;
            Ok(())
        });
        assert!(result.is_err());
        assert!(!persisted);
        assert!(state.session.is_none());
        assert_eq!(state.generation, 2);
    }

    #[test]
    fn oauth_commit_is_transactional_and_rejects_duplicate_response() {
        let mut state = super::SessionState::default();
        assert!(
            super::commit_session(&mut state, fixture_session(), 0, |_| Err(
                "fixture storage failure".into()
            ))
            .is_err()
        );
        assert!(state.session.is_none());
        assert_eq!(state.generation, 0);
        super::commit_session(&mut state, fixture_session(), 0, |_| Ok(())).unwrap();
        assert_eq!(state.generation, 1);
        assert!(
            super::commit_session(&mut state, fixture_session(), 0, |_| panic!(
                "stale persistence must not execute"
            ))
            .is_err()
        );
        assert_eq!(state.session.unwrap().user.id, 1);
    }
    use super::{
        assign_unique, classify_private_test_repository, form_body, is_transient_status,
        parse_api_message, parse_github_remote, rate_limit_delay_secs, PrivateResource,
    };
    use reqwest::{header::HeaderMap, StatusCode};

    #[test]
    fn parses_supported_github_remotes() {
        assert_eq!(
            parse_github_remote("https://github.com/MiqueiasVCB/jingu-qa.git"),
            Some(("MiqueiasVCB".into(), "jingu-qa".into()))
        );
        assert_eq!(
            parse_github_remote("git@github.com:MiqueiasVCB/jingu-qa.git"),
            Some(("MiqueiasVCB".into(), "jingu-qa".into()))
        );
    }

    #[test]
    fn rejects_credentials_or_non_github_remotes() {
        assert!(parse_github_remote("https://token@github.com/owner/repo.git").is_none());
        assert!(parse_github_remote("https://example.com/owner/repo.git").is_none());
    }
    #[test]
    fn honors_retry_after_before_rate_limit_reset() {
        let mut headers = HeaderMap::new();
        headers.insert("retry-after", "37".parse().unwrap());
        headers.insert("x-ratelimit-remaining", "0".parse().unwrap());
        headers.insert("x-ratelimit-reset", "9999999999".parse().unwrap());
        assert_eq!(
            rate_limit_delay_secs(StatusCode::FORBIDDEN, &headers, 100),
            Some(37)
        );
    }

    #[test]
    fn computes_primary_rate_limit_reset_delay() {
        let mut headers = HeaderMap::new();
        headers.insert("x-ratelimit-remaining", "0".parse().unwrap());
        headers.insert("x-ratelimit-reset", "130".parse().unwrap());
        assert_eq!(
            rate_limit_delay_secs(StatusCode::FORBIDDEN, &headers, 100),
            Some(30)
        );
    }

    #[test]
    fn too_many_requests_without_headers_gets_safe_cooldown() {
        assert_eq!(
            rate_limit_delay_secs(StatusCode::TOO_MANY_REQUESTS, &HeaderMap::new(), 100),
            Some(60)
        );
    }

    #[test]
    fn retry_after_is_safely_capped_at_one_day() {
        let mut headers = HeaderMap::new();
        headers.insert("retry-after", "999999".parse().unwrap());
        assert_eq!(
            rate_limit_delay_secs(StatusCode::TOO_MANY_REQUESTS, &headers, 100),
            Some(86_400)
        );
    }

    #[test]
    fn oauth_form_encoding_is_utf8_safe_and_does_not_allow_field_injection() {
        assert_eq!(
            form_body(&[("client id", "ç 日本&admin=true"), ("device_code", "A/B+C")]),
            "client+id=%C3%A7+%E6%97%A5%E6%9C%AC%26admin%3Dtrue&device_code=A%2FB%2BC"
        );
    }

    #[test]
    fn github_status_and_error_body_classification_is_exact() {
        for status in [500, 502, 503, 504] {
            assert!(is_transient_status(StatusCode::from_u16(status).unwrap()));
        }
        for status in [200, 201, 202, 204, 400, 401, 403, 404, 409, 422, 429, 501] {
            assert!(!is_transient_status(StatusCode::from_u16(status).unwrap()));
        }
        assert_eq!(
            parse_api_message(r#"{"message":"rate limited"}"#),
            "rate limited"
        );
        assert_eq!(parse_api_message("not-json"), "not-json");
        assert_eq!(parse_api_message(r#"{"message":""}"#), r#"{"message":""}"#);
    }

    #[test]
    fn private_test_repository_discovery_fails_closed_on_ambiguity() {
        assert!(matches!(
            classify_private_test_repository("Jingu-Engine-Releases-TEST"),
            Some(PrivateResource::EngineReleases)
        ));
        assert!(matches!(
            classify_private_test_repository("jingu-hub-release-test"),
            Some(PrivateResource::HubReleases)
        ));
        assert!(classify_private_test_repository("jingu-engine-releases").is_none());
        assert!(classify_private_test_repository("other-private-test").is_none());

        let mut slot = None;
        let mut ambiguous = false;
        assign_unique(&mut slot, "first".into(), &mut ambiguous);
        assign_unique(&mut slot, "second".into(), &mut ambiguous);
        assert!(ambiguous);
        assert!(slot.is_none());
    }
}
