/**************************************************************************/
/*  godot_versions.rs                                                   */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use crate::models::*;
use crate::persist;
use crate::settings;
use futures_util::StreamExt;
use sha2::{Digest, Sha256};
use std::collections::{HashMap, VecDeque};
use std::fs;
#[cfg(target_os = "windows")]
use std::io::SeekFrom;
use std::io::{Read, Seek, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, OnceLock};
use std::time::{Duration, Instant};
use tauri::{AppHandle, Emitter};

const ENGINE_CATALOG_REFRESH_EVENT: &str = "jingu-engine-catalog-refreshed";

fn release_http_client() -> Result<reqwest::Client, String> {
    static CLIENT: OnceLock<reqwest::Client> = OnceLock::new();
    if let Some(client) = CLIENT.get() {
        return Ok(client.clone());
    }
    let client = reqwest::Client::builder()
        .user_agent(format!("JinguHub/{}", crate::jingu::PRODUCT_VERSION))
        .connect_timeout(Duration::from_secs(4))
        .timeout(Duration::from_secs(15))
        .pool_idle_timeout(Duration::from_secs(300))
        .pool_max_idle_per_host(8)
        .tcp_keepalive(Duration::from_secs(30))
        .build()
        .map_err(|error| error.to_string())?;
    let _ = CLIENT.set(client.clone());
    Ok(client)
}

fn download_http_client() -> Result<reqwest::Client, String> {
    // Streaming Engine archives can legitimately take longer than a normal API
    // request, so this client has a bounded connect timeout but no whole-transfer
    // timeout. Reusing it still keeps sockets warm across queued downloads.
    static CLIENT: OnceLock<reqwest::Client> = OnceLock::new();
    if let Some(client) = CLIENT.get() {
        return Ok(client.clone());
    }
    let client = reqwest::Client::builder()
        .user_agent(format!("JinguHub/{}", crate::jingu::PRODUCT_VERSION))
        .connect_timeout(Duration::from_secs(4))
        .read_timeout(Duration::from_secs(30))
        .pool_idle_timeout(Duration::from_secs(300))
        .pool_max_idle_per_host(4)
        .tcp_keepalive(Duration::from_secs(30))
        .build()
        .map_err(|error| error.to_string())?;
    let _ = CLIENT.set(client.clone());
    Ok(client)
}

fn engine_catalog_refresh_active() -> &'static AtomicBool {
    static ACTIVE: AtomicBool = AtomicBool::new(false);
    &ACTIVE
}

fn engine_catalog_last_network_refresh() -> &'static Mutex<Option<Instant>> {
    static LAST: OnceLock<Mutex<Option<Instant>>> = OnceLock::new();
    LAST.get_or_init(|| Mutex::new(None))
}

fn engine_catalog_network_refresh_recent() -> bool {
    engine_catalog_last_network_refresh()
        .lock()
        .unwrap_or_else(|error| error.into_inner())
        .as_ref()
        .is_some_and(|instant| instant.elapsed() < Duration::from_secs(15 * 60))
}

fn mark_engine_catalog_network_refresh() {
    *engine_catalog_last_network_refresh()
        .lock()
        .unwrap_or_else(|error| error.into_inner()) = Some(Instant::now());
}

fn spawn_releases_refresh(app: AppHandle) {
    if engine_catalog_network_refresh_recent() {
        return;
    }
    if engine_catalog_refresh_active()
        .compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)
        .is_err()
    {
        return;
    }
    tauri::async_runtime::spawn(async move {
        match refresh_releases_cache(app.clone()).await {
            Ok(rows) => {
                let _ = app.emit(ENGINE_CATALOG_REFRESH_EVENT, rows);
            }
            Err(error) => {
                crate::startup::log(format!("Engine catalog background refresh failed: {error}"))
            }
        }
        engine_catalog_refresh_active().store(false, Ordering::Release);
    });
}

pub fn parse_godot_tag_from_filename(filename: &str) -> Option<String> {
    let stem = filename
        .strip_suffix(".exe.zip")
        .or_else(|| filename.strip_suffix(".exe"))
        .or_else(|| filename.strip_suffix(".zip"))
        .unwrap_or(filename);
    let candidates = [
        "JinguEngine-",
        "JinguEngine_",
        "jingu_engine.",
        "jingu_engine-",
        "jingu-engine-",
        "Godot_v",
        "godot_v",
    ];
    let after_prefix = candidates
        .iter()
        .find_map(|prefix| stem.strip_prefix(prefix))?;
    let raw = after_prefix
        .split(['_', '-'])
        .next()
        .unwrap_or(after_prefix)
        .trim_start_matches('v');
    let parts: Vec<&str> = raw.split('.').collect();
    if parts.len() < 2
        || !parts
            .iter()
            .take(3)
            .all(|p| !p.is_empty() && p.chars().all(|c| c.is_ascii_digit()))
    {
        return None;
    }
    Some(raw.to_string())
}

fn normalize_external_tag_component(value: &str) -> String {
    let mut normalized = String::new();
    let mut prev_dash = false;
    for ch in value.chars() {
        let next = if ch.is_ascii_alphanumeric() || ch == '.' {
            prev_dash = false;
            Some(ch.to_ascii_lowercase())
        } else if !prev_dash {
            prev_dash = true;
            Some('-')
        } else {
            None
        };
        if let Some(ch) = next {
            normalized.push(ch);
        }
    }
    normalized.trim_matches('-').to_string()
}

fn external_display_name(path: &Path, exe_path: &Path) -> String {
    let direct = if path.is_dir() {
        path.file_name().and_then(|s| s.to_str())
    } else {
        path.file_stem().and_then(|s| s.to_str())
    };
    direct
        .or_else(|| exe_path.file_stem().and_then(|s| s.to_str()))
        .unwrap_or("Imported Engine")
        .to_string()
}

fn parse_runtime_version_output(raw: &str) -> Option<String> {
    let chars: Vec<char> = raw.chars().collect();
    for start in 0..chars.len() {
        if !chars[start].is_ascii_digit() {
            continue;
        }
        let mut end = start;
        let mut dots = 0usize;
        while end < chars.len() && (chars[end].is_ascii_digit() || chars[end] == '.') {
            if chars[end] == '.' {
                dots += 1;
            }
            end += 1;
        }
        if dots < 1 {
            continue;
        }
        let numeric: String = chars[start..end]
            .iter()
            .collect::<String>()
            .trim_matches('.')
            .to_string();
        let parts: Vec<&str> = numeric.split('.').filter(|part| !part.is_empty()).collect();
        if !(2..=3).contains(&parts.len())
            || !parts
                .iter()
                .all(|part| part.bytes().all(|b| b.is_ascii_digit()))
        {
            continue;
        }
        return Some(numeric);
    }
    None
}

/// Ask the executable itself for its version so externally compiled builds do
/// not appear in the UI as `jingu_engine.windows.editor.x86_64`.
fn probe_external_runtime_version(exe_path: &Path) -> Option<String> {
    verify_executable_arch(exe_path).ok()?;
    let mut command = Command::new(exe_path);
    crate::terminal::sanitize_child_env(&mut command);
    let mut child = command
        .arg("--version")
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .ok()?;

    let deadline = Instant::now() + Duration::from_secs(3);
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break status,
            Ok(None) if Instant::now() >= deadline => {
                let _ = child.kill();
                let _ = child.wait();
                return None;
            }
            Ok(None) => std::thread::sleep(Duration::from_millis(40)),
            Err(_) => return None,
        }
    };
    if !status.success() {
        return None;
    }

    let mut output = String::new();
    if let Some(mut stdout) = child.stdout.take() {
        let _ = stdout.read_to_string(&mut output);
    }
    if let Some(mut stderr) = child.stderr.take() {
        let _ = stderr.read_to_string(&mut output);
    }
    parse_runtime_version_output(&output)
}

fn detect_external_version_identity(
    path: &Path,
    exe_path: &Path,
) -> (String, String, bool, Option<String>, Option<String>) {
    let display_name = external_display_name(path, exe_path);
    let is_mono_hint = display_name.to_lowercase().contains("mono")
        || exe_path
            .file_name()
            .and_then(|s| s.to_str())
            .is_some_and(|name| name.to_lowercase().contains("mono"));
    if let Some(version) = probe_external_runtime_version(exe_path) {
        let tag = if is_mono_hint {
            format!("{version}-mono")
        } else {
            version.clone()
        };
        return (tag, version.clone(), is_mono_hint, None, Some(version));
    }

    let mut candidates: Vec<String> = Vec::new();
    if let Some(name) = path.file_name().and_then(|s| s.to_str()) {
        candidates.push(name.to_string());
    }
    if let Some(name) = exe_path.file_name().and_then(|s| s.to_str()) {
        candidates.push(name.to_string());
    }
    if let Some(parent) = exe_path
        .parent()
        .and_then(|s| s.file_name())
        .and_then(|s| s.to_str())
    {
        candidates.push(parent.to_string());
    }
    candidates.push(display_name.clone());

    for candidate in candidates {
        if let Some(tag) = parse_godot_tag_from_filename(&candidate) {
            let is_mono = tag.ends_with("-mono") || candidate.to_lowercase().contains("mono");
            let version_number = tag
                .trim_start_matches('v')
                .trim_end_matches("-mono")
                .to_string();
            let custom_name = if display_name != version_number && display_name != tag {
                Some(display_name.clone())
            } else {
                None
            };
            return (tag, version_number, is_mono, custom_name, None);
        }
    }

    let display_tag = normalize_external_tag_component(&display_name);
    let fallback = if display_tag.is_empty() {
        "imported-engine".to_string()
    } else {
        display_tag
    };
    let is_mono = display_name.to_lowercase().contains("mono");
    let tag = if is_mono && !fallback.ends_with("-mono") {
        format!("{fallback}-mono")
    } else {
        fallback.clone()
    };
    (tag, display_name.clone(), is_mono, Some(display_name), None)
}

fn unique_import_tag(app: &AppHandle, desired: &str) -> String {
    let existing: std::collections::HashSet<String> =
        read_registry(app).into_iter().map(|v| v.tag).collect();
    if !existing.contains(desired) {
        return desired.to_string();
    }
    for i in 2.. {
        let candidate = format!("{desired}-imported-{i}");
        if !existing.contains(&candidate) {
            return candidate;
        }
    }
    unreachable!()
}

fn external_install_root_for(path: &Path, exe_path: &Path) -> PathBuf {
    #[cfg(target_os = "macos")]
    {
        if let Some(bundle) = exe_path
            .ancestors()
            .find(|p| p.extension().map(|e| e == "app").unwrap_or(false))
        {
            return bundle.to_path_buf();
        }
    }
    if path.is_dir() {
        return path.to_path_buf();
    }
    exe_path.parent().unwrap_or(path).to_path_buf()
}

fn register_external_version(
    app: &AppHandle,
    path: &Path,
) -> Result<InstalledGodotVersion, String> {
    let exe_path = if path.is_dir() {
        find_executable(path).ok_or_else(|| {
            "Não foi possível localizar o executável da Jingu Engine na pasta selecionada."
                .to_string()
        })?
    } else {
        path.to_path_buf()
    };

    if !exe_path.exists() {
        return Err("O executável selecionado não foi encontrado.".into());
    }
    verify_executable_arch(&exe_path)?;

    if read_registry(app)
        .iter()
        .any(|version| Path::new(&version.executable_path) == exe_path)
    {
        return Err("Já existe uma versão apontando para este executável.".into());
    }

    let (desired_tag, version_number, is_mono, custom_name, runtime_version) =
        detect_external_version_identity(path, &exe_path);
    let tag = unique_import_tag(app, &desired_tag);
    let install_root = external_install_root_for(path, &exe_path);

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        if let Ok(meta) = fs::metadata(&exe_path) {
            let mut perms = meta.permissions();
            perms.set_mode(0o755);
            let _ = fs::set_permissions(&exe_path, perms);
        }
    }

    let installed = InstalledGodotVersion {
        tag,
        version: version_number,
        runtime_version,
        executable_path: exe_path.to_string_lossy().to_string(),
        is_mono,
        installed_at: chrono::Utc::now().to_rfc3339(),
        custom_name,
        install_root: Some(install_root.to_string_lossy().to_string()),
        supports_console: supports_console(&exe_path),
        managed_install: Some(false),
        restricted: false,
    };

    register_version(app, installed.clone())?;
    crate::projects::rebind_projects_to_version(app, &installed);
    Ok(installed)
}

pub fn versions_dir(app: &AppHandle) -> PathBuf {
    let s = settings::read_settings(app);
    let dir = match s.download_dir {
        Some(d) if !d.trim().is_empty() => PathBuf::from(d),
        _ => crate::paths::app_data_dir(app).join("jingu-engines"),
    };
    if !dir.exists() {
        let _ = fs::create_dir_all(&dir);
    }
    dir
}

fn registry_file(app: &AppHandle) -> PathBuf {
    let base = crate::paths::app_data_dir(app);
    if !base.exists() {
        let _ = fs::create_dir_all(&base);
    }
    base.join("jingu-engine-versions.json")
}

pub fn migrate_registry_to_global(app: &AppHandle) {
    let global = registry_file(app);
    if global.exists() {
        return;
    }

    let base = crate::paths::app_data_dir(app);
    let workspaces_root = base.join("workspaces");
    let Ok(entries) = fs::read_dir(&workspaces_root) else {
        return;
    };

    let mut per_workspace_files = vec![];
    let mut merged: Vec<InstalledGodotVersion> = vec![];
    let mut seen_paths = std::collections::HashSet::new();
    let mut seen_tags = std::collections::HashSet::new();

    let mut dirs: Vec<PathBuf> = entries.filter_map(|e| e.ok()).map(|e| e.path()).collect();
    dirs.sort();

    for dir in dirs {
        let file = dir.join("godot-versions.json");
        if !file.exists() {
            continue;
        }
        let list: Vec<InstalledGodotVersion> =
            serde_json::from_str(&fs::read_to_string(&file).unwrap_or_default())
                .unwrap_or_default();
        for v in list {
            if !seen_paths.insert(v.executable_path.clone()) {
                continue;
            }
            if !seen_tags.insert((v.tag.clone(), v.is_mono)) {
                continue;
            }
            merged.push(v);
        }
        per_workspace_files.push(file);
    }

    if per_workspace_files.is_empty() {
        return;
    }

    if persist::write_json(&global, &merged).is_err() {
        return;
    }

    for file in per_workspace_files {
        let _ = fs::rename(&file, file.with_extension("json.migrated"));
    }
}

pub fn read_registry(app: &AppHandle) -> Vec<InstalledGodotVersion> {
    let _guard = engine_registry_lock()
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    read_registry_unlocked(app)
}

fn engine_registry_lock() -> &'static Mutex<()> {
    static LOCK: Mutex<()> = Mutex::new(());
    &LOCK
}

fn read_registry_unlocked(app: &AppHandle) -> Vec<InstalledGodotVersion> {
    let mut list: Vec<InstalledGodotVersion> = persist::read_json(&registry_file(app));
    let mut changed = false;
    for version in &mut list {
        let exe = Path::new(&version.executable_path);
        version.supports_console = supports_console(exe);
        // Keep Jingu's public release version separate from the underlying
        // Godot-compatible runtime. Older registries did not persist this
        // distinction, so repair it lazily by asking the executable once.
        if version.runtime_version.as_deref().is_none_or(str::is_empty) && exe.is_file() {
            if let Some(runtime_version) = probe_external_runtime_version(exe) {
                version.runtime_version = Some(runtime_version.clone());
                // Externally compiled builds may have been registered with an
                // unreadable filename as `version`; for those only, use the
                // runtime number as the best human-readable fallback. Managed
                // release versions are never overwritten by a Godot number.
                if version.managed_install == Some(false)
                    && crate::godotenv::parse_version(&version.version).is_none()
                {
                    version.version = runtime_version;
                    version.custom_name = None;
                }
                changed = true;
            }
        }
    }
    if changed {
        let _ = persist::write_json(&registry_file(app), &list);
    }
    list
}

pub fn write_registry(app: &AppHandle, list: &Vec<InstalledGodotVersion>) -> Result<(), String> {
    let _guard = engine_registry_lock()
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    write_registry_unlocked(app, list)
}

fn write_registry_unlocked(
    app: &AppHandle,
    list: &Vec<InstalledGodotVersion>,
) -> Result<(), String> {
    persist::write_json(&registry_file(app), list).map_err(|e| e.to_string())
}

pub fn register_version(app: &AppHandle, version: InstalledGodotVersion) -> Result<bool, String> {
    register_version_at_path(&registry_file(app), version)
}

fn register_version_at_path(path: &Path, version: InstalledGodotVersion) -> Result<bool, String> {
    let _guard = engine_registry_lock()
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let mut list: Vec<InstalledGodotVersion> = persist::read_json(path);
    if list
        .iter()
        .any(|v| v.executable_path == version.executable_path)
    {
        return Ok(false);
    }
    list.push(version);
    persist::write_json(path, &list).map_err(|e| e.to_string())?;
    Ok(true)
}

fn releases_cache_file(app: &AppHandle) -> PathBuf {
    let base = crate::paths::app_data_dir(app);
    if !base.exists() {
        let _ = fs::create_dir_all(&base);
    }
    base.join("jingu-engine-releases-cache.json")
}

#[derive(serde::Serialize, serde::Deserialize)]
struct ReleasesCache {
    fetched_at: i64,
    #[serde(default)]
    asset_target: String,
    releases: Vec<GodotRelease>,
}

const CACHE_TTL_SECS: i64 = 3600;

fn asset_target() -> String {
    // v3 invalidates older caches so generic macOS assets can never survive
    // the architecture-exact Engine release matrix.
    format!(
        "{}-{}-manifest-v3-platform-matrix",
        std::env::consts::OS,
        std::env::consts::ARCH
    )
}

fn read_cache_allow_stale(app: &AppHandle) -> Option<(Vec<GodotRelease>, i64)> {
    let file = releases_cache_file(app);
    let raw = fs::read_to_string(&file).ok()?;
    let cache: ReleasesCache = serde_json::from_str(&raw).ok()?;
    if cache.asset_target != asset_target() {
        return None;
    }
    let public_only = cache
        .releases
        .into_iter()
        .filter(|release| !release.restricted && release.channel == "stable")
        .collect();
    Some((dedupe_releases(public_only), cache.fetched_at))
}

fn write_releases_cache(app: &AppHandle, releases: &[GodotRelease]) {
    let cache = ReleasesCache {
        fetched_at: chrono::Utc::now().timestamp(),
        asset_target: asset_target(),
        releases: releases
            .iter()
            .filter(|release| !release.restricted && release.channel == "stable")
            .cloned()
            .collect(),
    };
    let _ = persist::write_json(&releases_cache_file(app), &cache);
}

fn release_version_tuple(tag: &str) -> Option<(u32, u32, u32)> {
    let cleaned = tag.trim().trim_start_matches('v');
    let core = cleaned.split('-').next().unwrap_or(cleaned);
    let mut parts = core.split('.');
    let major = parts.next()?.parse().ok()?;
    let minor = parts.next().unwrap_or("0").parse().ok()?;
    let patch = parts.next().unwrap_or("0").parse().ok()?;
    Some((major, minor, patch))
}

fn dedupe_releases(releases: Vec<GodotRelease>) -> Vec<GodotRelease> {
    let mut seen_tags = std::collections::HashSet::new();
    let mut rows: Vec<GodotRelease> = releases
        .into_iter()
        .filter(|r| seen_tags.insert((r.tag.clone(), r.channel.clone())))
        .map(|mut r| {
            let mut seen_assets = std::collections::HashSet::new();
            r.assets.retain(|a| seen_assets.insert(a.name.clone()));
            r
        })
        .collect();
    rows.sort_by(|left, right| {
        release_version_tuple(&right.tag)
            .cmp(&release_version_tuple(&left.tag))
            .then_with(|| right.tag.cmp(&left.tag))
    });
    rows
}

fn cached_release_matches_github(cached: &GodotRelease, assets: &[serde_json::Value]) -> bool {
    !cached.assets.is_empty()
        && cached.assets.iter().all(|expected| {
            assets.iter().any(|asset| {
                let name = asset["name"].as_str().unwrap_or("");
                let size = asset["size"].as_u64().unwrap_or(0);
                let url = if expected.download_url.contains("api.github.com/repos/") {
                    asset["url"].as_str().unwrap_or("")
                } else {
                    asset["browser_download_url"].as_str().unwrap_or("")
                };
                name == expected.name && size == expected.size && url == expected.download_url
            })
        })
}

fn official_engine_asset_url(url: &str, repository: &str, restricted: bool) -> bool {
    let Ok(parsed) = reqwest::Url::parse(url) else {
        return false;
    };
    if parsed.scheme() != "https" || parsed.query().is_some() || parsed.fragment().is_some() {
        return false;
    }
    if restricted {
        if parsed.host_str() != Some("api.github.com") {
            return false;
        }
        let expected_prefix = format!(
            "/repos/{}/{repository}/releases/assets/",
            crate::jingu::GITHUB_OWNER
        );
        let Some(asset_id) = parsed.path().strip_prefix(&expected_prefix) else {
            return false;
        };
        return !asset_id.is_empty() && asset_id.bytes().all(|b| b.is_ascii_digit());
    }
    if parsed.host_str() != Some("github.com") {
        return false;
    }
    let expected_prefix = format!(
        "/{}/{}/releases/download/",
        crate::jingu::GITHUB_OWNER,
        repository
    );
    parsed.path().starts_with(&expected_prefix)
}

#[derive(Clone)]
struct VerifiedReleaseAsset {
    platform_key: String,
    sha256: String,
    size: u64,
    entrypoint: String,
}

fn normalized_release_version(tag: &str) -> &str {
    tag.trim().trim_start_matches('v')
}

fn valid_sha256(value: &str) -> bool {
    value.len() == 64 && value.bytes().all(|b| b.is_ascii_hexdigit())
}

fn safe_install_component(value: &str) -> bool {
    if value.is_empty()
        || value.len() > 240
        || value == "."
        || value == ".."
        || value.ends_with(['.', ' '])
        || value
            .chars()
            .any(|c| c.is_control() || "/\\:*?\"<>|".contains(c))
    {
        return false;
    }
    let stem = value.split('.').next().unwrap_or("").to_ascii_uppercase();
    !matches!(
        stem.as_str(),
        "CON" | "PRN" | "AUX" | "NUL" | "CONIN$" | "CONOUT$"
    ) && !(stem.starts_with("COM") || stem.starts_with("LPT"))
        .then(|| &stem[3..])
        .is_some_and(|suffix| {
            matches!(
                suffix,
                "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "¹" | "²" | "³"
            )
        })
}

fn safe_release_entrypoint(value: &str) -> bool {
    value.split('/').all(safe_install_component)
}

fn regular_install_metadata(metadata: &fs::Metadata, directory: bool) -> bool {
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::fs::MetadataExt;
        if metadata.file_attributes() & 0x400 != 0 {
            return false;
        }
    }
    if directory {
        metadata.is_dir() && !metadata.is_symlink()
    } else {
        metadata.is_file() && !metadata.is_symlink()
    }
}

fn prepare_download_directory(target: &Path, asset_name: &str) -> Result<(), String> {
    match fs::create_dir(target) {
        Ok(()) => {}
        Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {}
        Err(error) => return Err(error.to_string()),
    }
    let metadata = fs::symlink_metadata(target).map_err(|error| error.to_string())?;
    if !regular_install_metadata(&metadata, true) {
        return Err("O destino da Engine não é uma pasta regular.".into());
    }
    // Only an earlier partial download may be reused. Never extract over an
    // installed tree or pre-existing links, even after a restart.
    for entry in fs::read_dir(target).map_err(|error| error.to_string())? {
        let entry = entry.map_err(|error| error.to_string())?;
        let metadata = fs::symlink_metadata(entry.path()).map_err(|error| error.to_string())?;
        if entry.file_name() != std::ffi::OsStr::new(asset_name)
            || !regular_install_metadata(&metadata, false)
        {
            return Err(
                "O destino da Engine já contém arquivos; instalação recusada para preservá-los."
                    .into(),
            );
        }
    }
    Ok(())
}

async fn verified_release_manifest(
    client: &reqwest::Client,
    tag: &str,
    release_assets: &[serde_json::Value],
    repository: &str,
    token: Option<&str>,
    restricted: bool,
) -> Result<HashMap<String, VerifiedReleaseAsset>, String> {
    let expected_manifest_name = format!(
        "JinguEngine-{}-manifest.json",
        normalized_release_version(tag)
    );
    let manifest_asset = release_assets
        .iter()
        .find_map(|asset| {
            let name = asset["name"].as_str()?;
            let url = if restricted {
                asset["url"].as_str()?
            } else {
                asset["browser_download_url"].as_str()?
            };
            let size = asset["size"].as_u64().unwrap_or(0);
            if name != expected_manifest_name.as_str()
                || !official_engine_asset_url(url, repository, restricted)
                || size == 0
                || size > 128 * 1024
            {
                return None;
            }
            Some((url, size))
        })
        .ok_or_else(|| {
            format!(
                "A release {tag} não possui um manifesto oficial pequeno e válido; ela foi ignorada pelo canal estável."
            )
        })?;

    let response = if restricted {
        let mut manifest_request =
            crate::jingu::release_get(client, manifest_asset.0, "application/octet-stream");
        if let Some(token) = token {
            manifest_request = manifest_request.bearer_auth(token);
        }
        crate::github::send_with_retry(
            manifest_request,
            &format!("o manifesto privado da release {tag}"),
        )
        .await?
    } else {
        crate::github::send_public_github_get_with_optional_auth(
            client,
            manifest_asset.0,
            "application/vnd.github+json",
            token,
            &format!("o manifesto público da release {tag}"),
        )
        .await?
    };
    if !response.status().is_success() {
        return Err(format!(
            "O manifesto da release {tag} respondeu HTTP {}.",
            response.status()
        ));
    }
    let body = response
        .bytes()
        .await
        .map_err(|e| format!("Falha ao ler o manifesto da release {tag}: {e}"))?;
    if body.len() > 128 * 1024 || body.len() as u64 != manifest_asset.1 {
        return Err(format!(
            "O manifesto da release {tag} possui tamanho inesperado e foi rejeitado."
        ));
    }
    let manifest: serde_json::Value = serde_json::from_slice(&body)
        .map_err(|e| format!("Manifesto JSON inválido na release {tag}: {e}"))?;
    let schema = manifest["schema"].as_u64();
    if !matches!(schema, Some(1) | Some(2))
        || manifest["product"].as_str() != Some("jingu-engine")
        || manifest["version"].as_str() != Some(normalized_release_version(tag))
    {
        return Err(format!(
            "O manifesto da release {tag} não corresponde ao contrato Jingu Engine schema 1/2."
        ));
    }
    let platforms = manifest["platforms"]
        .as_object()
        .ok_or_else(|| format!("O manifesto da release {tag} não possui platforms válido."))?;
    let mut verified = HashMap::new();
    for (platform_key, item) in platforms {
        let Some(asset) = item["asset"].as_str() else {
            continue;
        };
        let Some(sha256) = item["sha256"].as_str() else {
            continue;
        };
        let Some(size) = item["size"].as_u64() else {
            continue;
        };
        let Some(entrypoint) = item["entrypoint"].as_str() else {
            continue;
        };
        if schema == Some(2) {
            let expected = engine_manifest_platform_metadata(platform_key);
            let Some((expected_os, expected_arch)) = expected else {
                continue;
            };
            if item["os"].as_str() != Some(expected_os)
                || item["arch"].as_str() != Some(expected_arch)
                || item["packaging"].as_str() != Some("zip")
            {
                continue;
            }
        }
        if !valid_sha256(sha256) || size == 0 || !safe_release_entrypoint(entrypoint) {
            continue;
        }
        verified.insert(
            asset.to_string(),
            VerifiedReleaseAsset {
                platform_key: platform_key.to_string(),
                sha256: sha256.to_ascii_lowercase(),
                size,
                entrypoint: entrypoint.to_string(),
            },
        );
    }
    if verified.is_empty() {
        return Err(format!(
            "O manifesto da release {tag} não declara nenhum asset instalável válido."
        ));
    }
    Ok(verified)
}

fn sha256_file(path: &Path) -> Result<String, String> {
    let mut file = fs::File::open(path).map_err(|e| e.to_string())?;
    let mut hasher = Sha256::new();
    let mut buffer = [0_u8; 1024 * 1024];
    loop {
        let read = file.read(&mut buffer).map_err(|e| e.to_string())?;
        if read == 0 {
            break;
        }
        hasher.update(&buffer[..read]);
    }
    Ok(format!("{:x}", hasher.finalize()))
}

fn declared_entrypoint(root: &Path, entrypoint: &str) -> Option<PathBuf> {
    let direct = root.join(entrypoint);
    if direct.is_file() {
        return Some(direct);
    }
    // A release ZIP may optionally use one common top-level directory. The
    // declared entrypoint remains relative to the logical package root.
    let mut dirs = fs::read_dir(root)
        .ok()?
        .flatten()
        .map(|entry| entry.path())
        .filter(|path| path.is_dir());
    let only_dir = dirs.next()?;
    if dirs.next().is_none() {
        let nested = only_dir.join(entrypoint);
        if nested.is_file() {
            return Some(nested);
        }
    }
    None
}

fn engine_manifest_platform_metadata(key: &str) -> Option<(&'static str, &'static str)> {
    match key {
        "windows-x86_64" => Some(("windows", "x86_64")),
        "linux-x86_64" => Some(("linux", "x86_64")),
        "macos-arm64" | "macos-aarch64" => Some(("macos", "arm64")),
        "macos-x86_64" => Some(("macos", "x86_64")),
        _ => None,
    }
}

fn engine_asset_matches_target(name: &str, os: &str, arch: &str) -> bool {
    let n = name.to_ascii_lowercase();
    if !safe_install_component(name)
        || !n.ends_with(".zip")
        || n.contains("symbols")
        || n.contains("source")
        || n.contains("universal")
    {
        return false;
    }
    let normalized = n.replace("x86_64", "x64");
    let tokens: Vec<&str> = normalized
        .split(|c: char| !c.is_ascii_alphanumeric())
        .collect();
    let has = |names: &[&str]| names.iter().any(|name| tokens.contains(name));
    let windows = has(&["windows", "win64", "win32"]);
    let linux = has(&["linux", "linux64", "linux32"]);
    let macos = has(&["macos", "darwin"]);
    let arm = has(&["arm64", "aarch64", "arm", "arm32"]);
    let x64 = has(&["x64", "amd64", "intel", "win64", "linux64"]);
    if windows as u8 + linux as u8 + macos as u8 != 1
        || (arm && x64)
        || has(&["x86", "i386", "i686", "x32", "win32", "linux32"])
    {
        return false;
    }
    match (os, arch) {
        ("windows", "x86_64") => windows && x64 && !arm,
        ("linux", "x86_64") => linux && x64 && !arm,
        ("macos", "aarch64" | "arm64") => {
            (n.contains("macos") || n.contains("darwin"))
                && (n.contains("arm64") || n.contains("aarch64"))
                && !n.contains("x86_64")
                && !n.contains("intel")
        }
        ("macos", "x86_64") => {
            (n.contains("macos") || n.contains("darwin"))
                && (n.contains("x86_64") || n.contains("x64") || n.contains("intel"))
                && !n.contains("arm64")
                && !n.contains("aarch64")
        }
        _ => false,
    }
}

fn manifest_platform_matches_target(key: &str, os: &str, arch: &str) -> bool {
    match (os, arch) {
        ("windows", "x86_64") => key == "windows-x86_64",
        ("linux", "x86_64") => key == "linux-x86_64",
        ("macos", "aarch64" | "arm64") => matches!(key, "macos-arm64" | "macos-aarch64"),
        ("macos", "x86_64") => key == "macos-x86_64",
        _ => false,
    }
}

fn platform_asset_matcher(name: &str) -> bool {
    engine_asset_matches_target(name, std::env::consts::OS, std::env::consts::ARCH)
}

#[tauri::command]
pub async fn fetch_available_godot_versions(
    app: AppHandle,
    force_refresh: Option<bool>,
) -> Result<Vec<GodotRelease>, String> {
    let cached = read_cache_allow_stale(&app);
    // Cache-first/SWR: opening the Hub should never wait on GitHub when a
    // validated public catalog already exists. Authenticated sessions render
    // that public cache immediately and refresh in the background so authorized
    // TEST rows can join the session without ever being persisted to disk.
    if force_refresh != Some(true) {
        if let Some((rows, fetched_at)) = &cached {
            let now = chrono::Utc::now().timestamp();
            let fresh = *fetched_at <= now && now - *fetched_at < CACHE_TTL_SECS;
            if !fresh || crate::github::cached_user().is_some() {
                spawn_releases_refresh(app.clone());
            }
            return Ok(rows.clone());
        }
    }

    // Cold cache and explicit manual refresh remain authoritative network reads.
    match refresh_releases_cache(app).await {
        Ok(rows) => Ok(rows),
        // A user/startup forced refresh must never silently pretend that a
        // stale cache is the live private GitHub catalog. This was masking
        // missing/invalid QA credentials and malformed newer releases.
        Err(error) if force_refresh == Some(true) => Err(error),
        Err(error) => match cached {
            Some((rows, _)) => {
                crate::startup::log(format!(
                    "Engine catalog refresh failed; using validated stale cache: {error}"
                ));
                Ok(rows)
            }
            None => Err(error),
        },
    }
}

async fn repository_release_rows(
    client: &reqwest::Client,
    repository: &str,
    token: Option<&str>,
    recover_by_tag: bool,
) -> Result<Vec<serde_json::Value>, String> {
    const MAX_RELEASE_PAGES: usize = 20;
    let mut rows: Vec<serde_json::Value> = Vec::new();
    let mut releases_complete = false;

    for page in 1..=MAX_RELEASE_PAGES {
        let url = format!(
            "https://api.github.com/repos/{}/{}/releases?per_page=100&page={}",
            crate::jingu::GITHUB_OWNER,
            repository,
            page
        );
        let response = if recover_by_tag {
            let mut request =
                crate::jingu::release_get(client, &url, "application/vnd.github+json");
            if let Some(token) = token {
                request = request.bearer_auth(token);
            }
            crate::github::send_with_retry(request, "a listagem de releases da Engine").await?
        } else {
            crate::github::send_public_github_get_with_optional_auth(
                client,
                &url,
                "application/vnd.github+json",
                token,
                "a listagem pública de releases da Engine",
            )
            .await?
        };
        if !recover_by_tag && response.status() == reqwest::StatusCode::CONFLICT {
            // An initialized-or-empty public distribution repository simply has
            // no Engine releases yet; no README/seed commit is required.
            return Ok(Vec::new());
        }
        if !response.status().is_success() {
            let status = response.status();
            let remaining = response
                .headers()
                .get("x-ratelimit-remaining")
                .and_then(|value| value.to_str().ok())
                .unwrap_or("");
            return Err(match status.as_u16() {
                403 if remaining == "0" => "Limite de consultas do GitHub atingido. O Hub pausou novas consultas automaticamente; aguarde o intervalo indicado pelo GitHub.".into(),
                429 => "O GitHub pediu uma pausa temporária nas consultas da Engine. O Hub respeitará o intervalo indicado antes de consultar novamente.".into(),
                403 => "O GitHub recusou a consulta de versões da Engine. Verifique a sessão e as permissões da GitHub App.".into(),
                404 => "O repositório de versões da Engine não foi encontrado ou não está acessível.".into(),
                _ => format!("GitHub Releases API returned HTTP {status}."),
            });
        }
        let payload: serde_json::Value = response.json().await.map_err(|e| e.to_string())?;
        let page_rows = payload
            .as_array()
            .ok_or_else(|| "GitHub Releases API returned an invalid payload.".to_string())?;
        if page_rows.is_empty() {
            releases_complete = true;
            break;
        }
        rows.extend(page_rows.iter().cloned());
        if page_rows.len() < 100 {
            releases_complete = true;
            break;
        }
    }
    if !releases_complete {
        return Err(format!(
            "O catálogo de releases de {repository} excedeu o limite defensivo de {} entradas; o Hub recusou usar um catálogo silenciosamente truncado.",
            MAX_RELEASE_PAGES * 100
        ));
    }

    let primary_count = rows.len();
    if !recover_by_tag {
        crate::startup::log(format!(
            "Engine public GitHub discovery: releases_api={primary_count}, total={}",
            rows.len()
        ));
        return Ok(rows);
    }

    let mut known_tags: std::collections::HashSet<String> = rows
        .iter()
        .filter_map(|row| row["tag_name"].as_str().map(str::to_string))
        .collect();
    let mut repository_tags = 0usize;
    let mut recovered = 0usize;

    for page in 1..=5 {
        let tags_url = format!(
            "https://api.github.com/repos/{}/{}/tags?per_page=100&page={}",
            crate::jingu::GITHUB_OWNER,
            repository,
            page
        );
        let mut request =
            crate::jingu::release_get(client, &tags_url, "application/vnd.github+json");
        if let Some(token) = token {
            request = request.bearer_auth(token);
        }
        let response =
            match crate::github::send_with_retry(request, "a recuperação de tags da Engine").await
            {
                Ok(response) => response,
                Err(error) => {
                    crate::startup::log(format!(
                        "Engine release tag-recovery unavailable: {error}"
                    ));
                    break;
                }
            };
        if !response.status().is_success() {
            crate::startup::log(format!(
                "Engine release tag-recovery returned HTTP {}; primary Releases API remains authoritative.",
                response.status()
            ));
            break;
        }
        let payload: serde_json::Value = response.json().await.map_err(|e| e.to_string())?;
        let tag_rows = match payload.as_array() {
            Some(rows) => rows,
            None => break,
        };
        if tag_rows.is_empty() {
            break;
        }

        for tag_row in tag_rows {
            let Some(tag) = tag_row["name"].as_str() else {
                continue;
            };
            repository_tags += 1;
            if release_version_tuple(tag).is_none() || known_tags.contains(tag) {
                continue;
            }
            let by_tag_url = format!(
                "https://api.github.com/repos/{}/{}/releases/tags/{}",
                crate::jingu::GITHUB_OWNER,
                repository,
                tag
            );
            let mut request =
                crate::jingu::release_get(client, &by_tag_url, "application/vnd.github+json");
            if let Some(token) = token {
                request = request.bearer_auth(token);
            }
            let response =
                crate::github::send_with_retry(request, "a recuperação de release por tag").await?;
            if response.status() == reqwest::StatusCode::NOT_FOUND {
                continue;
            }
            if !response.status().is_success() {
                continue;
            }
            let release: serde_json::Value = response.json().await.map_err(|e| e.to_string())?;
            if release["draft"].as_bool() == Some(true)
                || release["prerelease"].as_bool() == Some(true)
            {
                continue;
            }
            if release["tag_name"].as_str() != Some(tag) {
                continue;
            }
            if known_tags.insert(tag.to_string()) {
                rows.push(release);
                recovered += 1;
            }
        }
        if tag_rows.len() < 100 {
            break;
        }
    }

    crate::startup::log(format!(
        "Engine GitHub discovery: releases_api={primary_count}, repository_tags={repository_tags}, recovered_by_tag={recovered}, total={}",
        rows.len()
    ));
    Ok(rows)
}

async fn collect_repository_releases(
    client: &reqwest::Client,
    cached_by_key: &HashMap<(String, String), GodotRelease>,
    repository: &str,
    token: Option<&str>,
    channel: &str,
    restricted: bool,
) -> Result<(Vec<GodotRelease>, usize, Vec<String>), String> {
    let mut releases: Vec<GodotRelease> = vec![];
    let mut stable_candidates = 0usize;
    let mut rejected: Vec<String> = vec![];
    let discovered_rows = repository_release_rows(client, repository, token, restricted).await?;
    for r in &discovered_rows {
        if r["draft"].as_bool() == Some(true) || r["prerelease"].as_bool() == Some(true) {
            continue;
        }
        let tag = r["tag_name"].as_str().unwrap_or("").to_string();
        if tag.is_empty() || !meets_min_version(&tag) {
            continue;
        }
        stable_candidates += 1;
        let mut assets = vec![];
        if let Some(asset_arr) = r["assets"].as_array() {
            if let Some(cached_release) = cached_by_key.get(&(tag.clone(), channel.to_string())) {
                if cached_release_matches_github(cached_release, asset_arr) {
                    releases.push(cached_release.clone());
                    continue;
                }
            }
            let manifest_token = if restricted || crate::github::cached_user().is_some() {
                token
            } else {
                None
            };
            let verified_manifest = match verified_release_manifest(
                client,
                &tag,
                asset_arr,
                repository,
                manifest_token,
                restricted,
            )
            .await
            {
                Ok(manifest) => manifest,
                Err(error) => {
                    crate::startup::log(format!(
                        "Engine catalog rejected {channel} release {tag}: {error}"
                    ));
                    rejected.push(format!("{tag}: {error}"));
                    continue;
                }
            };
            for a in asset_arr {
                let name = a["name"].as_str().unwrap_or("").to_string();
                if !platform_asset_matcher(&name) {
                    continue;
                }
                let lower = name.to_lowercase();
                let download_url = if restricted {
                    a["url"].as_str().unwrap_or("").to_string()
                } else {
                    a["browser_download_url"].as_str().unwrap_or("").to_string()
                };
                if download_url.is_empty()
                    || !official_engine_asset_url(&download_url, repository, restricted)
                {
                    continue;
                }
                let github_size = a["size"].as_u64().unwrap_or(0);
                let Some(verified) = verified_manifest.get(&name) else {
                    continue;
                };
                if !manifest_platform_matches_target(
                    &verified.platform_key,
                    std::env::consts::OS,
                    std::env::consts::ARCH,
                ) {
                    continue;
                }
                if github_size == 0 || github_size != verified.size {
                    continue;
                }
                assets.push(GodotReleaseAsset {
                    name,
                    download_url,
                    size: verified.size,
                    is_mono: lower.contains("mono"),
                    expected_sha256: verified.sha256.clone(),
                    entrypoint: verified.entrypoint.clone(),
                });
            }
        }
        if !assets.is_empty() {
            releases.push(GodotRelease {
                tag,
                assets,
                channel: channel.to_string(),
                restricted,
            });
        } else {
            rejected.push(format!(
                "{tag}: nenhum asset compatível coincidiu com manifesto/tamanho/URL oficial"
            ));
        }
    }
    Ok((releases, stable_candidates, rejected))
}

async fn refresh_releases_cache(app: AppHandle) -> Result<Vec<GodotRelease>, String> {
    let client = release_http_client()?;

    let cached_by_key: HashMap<(String, String), GodotRelease> = read_cache_allow_stale(&app)
        .map(|(rows, _)| {
            rows.into_iter()
                .map(|row| ((row.tag.clone(), row.channel.clone()), row))
                .collect()
        })
        .unwrap_or_default();

    // Prefer the signed-in user's credential even for public REST reads. GitHub
    // gives authenticated requests a substantially larger primary budget. Public
    // discovery still avoids the expensive tags/release-by-tag recovery reserved
    // for dynamically authorized private TEST repositories.
    let public_token = if crate::github::cached_user().is_some() {
        crate::github::access_token().await.ok()
    } else {
        None
    };
    let (public_releases, public_candidates, public_rejected) = collect_repository_releases(
        &client,
        &cached_by_key,
        crate::jingu::PUBLIC_ENGINE_RELEASES_REPOSITORY,
        public_token.as_deref(),
        "stable",
        false,
    )
    .await?;
    if public_candidates > 0 && !public_rejected.is_empty() {
        let details = public_rejected
            .iter()
            .take(3)
            .cloned()
            .collect::<Vec<_>>()
            .join(" | ");
        return Err(format!(
            "O GitHub retornou {public_candidates} release(s) pública(s), mas {} falharam no contrato da Jingu Engine. {details}",
            public_rejected.len()
        ));
    }

    // Persist only public data. Private/test rows are session capabilities and
    // never survive sign-out or application restart in the release cache.
    write_releases_cache(&app, &public_releases);
    let mut releases = public_releases;
    if let Ok(Some(access)) =
        crate::github::authorized_private_repository(crate::github::PrivateResource::EngineReleases)
            .await
    {
        match collect_repository_releases(
            &client,
            &HashMap::new(),
            &access.repository,
            Some(&access.token),
            "test",
            true,
        )
        .await
        {
            Ok((test_rows, _, rejected)) => {
                if !rejected.is_empty() {
                    crate::startup::log(format!(
                        "Authorized TEST Engine rows rejected by integrity contract: {}",
                        rejected.len()
                    ));
                }
                releases.extend(test_rows);
            }
            Err(error) => crate::startup::log(format!(
                "Authorized TEST Engine catalog unavailable; public catalog remains usable: {error}"
            )),
        }
    }
    mark_engine_catalog_network_refresh();
    Ok(dedupe_releases(releases))
}

#[tauri::command]
pub async fn check_latest_engine_release() -> Result<Option<String>, String> {
    let client = release_http_client()?;
    let public_token = if crate::github::cached_user().is_some() {
        crate::github::access_token().await.ok()
    } else {
        None
    };
    let mut rows = repository_release_rows(
        &client,
        crate::jingu::PUBLIC_ENGINE_RELEASES_REPOSITORY,
        public_token.as_deref(),
        false,
    )
    .await?;
    if let Ok(Some(access)) =
        crate::github::authorized_private_repository(crate::github::PrivateResource::EngineReleases)
            .await
    {
        if let Ok(mut private_rows) =
            repository_release_rows(&client, &access.repository, Some(&access.token), true).await
        {
            rows.append(&mut private_rows);
        }
    }
    let mut newest: Option<String> = None;
    for release in &rows {
        if release["draft"].as_bool() == Some(true) || release["prerelease"].as_bool() == Some(true)
        {
            continue;
        }
        let Some(tag) = release["tag_name"].as_str() else {
            continue;
        };
        if release_version_tuple(tag).is_none() || !meets_min_version(tag) {
            continue;
        }
        let replace = newest
            .as_deref()
            .and_then(release_version_tuple)
            .is_none_or(|current| {
                release_version_tuple(tag).is_some_and(|candidate| candidate > current)
            });
        if replace {
            newest = Some(tag.to_string());
        }
    }
    Ok(newest)
}

pub(crate) fn meets_min_version(tag: &str) -> bool {
    release_version_tuple(tag).is_some_and(|version| version > (0, 0, 0))
}

#[derive(Clone, PartialEq)]
enum SlotState {
    Active,
    Queued,
    Paused,
}

#[derive(Clone, serde::Serialize)]
pub struct DownloadSnapshot {
    tag: String,
    state: String,
}

#[derive(Clone)]
struct DownloadJob {
    target_dir: PathBuf,
    tag: String,
    asset_name: String,
    download_url: String,
    expected_sha256: String,
    expected_size: u64,
    entrypoint: String,
    restricted: bool,
}

struct DownloadHandle {
    job: DownloadJob,
    cancel: Arc<AtomicBool>,
    pause: Arc<AtomicBool>,
}

#[derive(Default)]
struct DownloadManager {
    handles: HashMap<String, DownloadHandle>,
    state: HashMap<String, SlotState>,
    queue: VecDeque<String>,
    active_count: usize,
}

fn dm() -> &'static Mutex<DownloadManager> {
    static DM: OnceLock<Mutex<DownloadManager>> = OnceLock::new();
    DM.get_or_init(|| Mutex::new(DownloadManager::default()))
}

fn download_key(tag: &str, asset_name: &str) -> String {
    if asset_name.to_lowercase().contains("mono") {
        format!("{}-mono", tag)
    } else {
        tag.to_string()
    }
}

fn release_slot(app: &AppHandle, key: &str, remove_handle: bool) {
    let next = {
        let mut mgr = dm().lock().unwrap_or_else(|e| e.into_inner());
        if remove_handle {
            mgr.handles.remove(key);
            mgr.state.remove(key);
        }
        mgr.active_count = mgr.active_count.saturating_sub(1);

        let limit = settings::read_settings(app).download_concurrency.max(1) as usize;
        let mut started = None;
        if mgr.active_count < limit {
            if let Some(next_key) = mgr.queue.pop_front() {
                if mgr.handles.contains_key(&next_key) {
                    mgr.active_count += 1;
                    mgr.state.insert(next_key.clone(), SlotState::Active);
                    started = Some(next_key);
                }
            }
        }
        started
    };
    if let Some(k) = next {
        let _ = app.emit("godot-download-started", &k);
        tauri::async_runtime::spawn(run_download(app.clone(), k));
    }
}

fn finish_with_error(app: &AppHandle, key: &str, msg: String) {
    release_slot(app, key, true);
    let _ = app.emit(
        "godot-download-error",
        serde_json::json!({ "tag": key, "message": msg }),
    );
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DownloadGodotVersionRequest {
    tag: String,
    asset_name: String,
    download_url: String,
    expected_sha256: String,
    expected_size: u64,
    entrypoint: String,
    restricted: bool,
}

#[tauri::command]
pub async fn download_godot_version(
    app: AppHandle,
    request: DownloadGodotVersionRequest,
) -> Result<(), String> {
    let DownloadGodotVersionRequest {
        tag,
        asset_name,
        download_url,
        expected_sha256,
        expected_size,
        entrypoint,
        restricted,
    } = request;

    let key = download_key(&tag, &asset_name);
    if !safe_install_component(&tag)
        || !safe_install_component(&key)
        || !safe_install_component(&asset_name)
    {
        return Err("Nome de versão ou pacote inseguro; download recusado.".into());
    }
    if restricted {
        let access = crate::github::authorized_private_repository(
            crate::github::PrivateResource::EngineReleases,
        )
        .await?
        .ok_or_else(|| "Sua sessão não possui mais acesso a esta release TEST.".to_string())?;
        if !official_engine_asset_url(&download_url, &access.repository, true) {
            return Err("O download TEST foi bloqueado porque o recurso não pertence ao repositório privado atualmente autorizado.".into());
        }
    } else if !official_engine_asset_url(
        &download_url,
        crate::jingu::PUBLIC_ENGINE_RELEASES_REPOSITORY,
        false,
    ) {
        return Err("O download foi bloqueado porque a URL não pertence ao canal público oficial da Jingu Engine.".into());
    }
    if !platform_asset_matcher(&asset_name)
        || !valid_sha256(&expected_sha256)
        || expected_size == 0
        || !safe_release_entrypoint(&entrypoint)
    {
        return Err("A release da Jingu Engine não possui metadados de integridade válidos no manifesto oficial.".into());
    }
    let target_dir = versions_dir(&app).join(&key);

    let mut mgr = dm().lock().unwrap_or_else(|e| e.into_inner());
    if mgr
        .handles
        .keys()
        .any(|existing| existing.eq_ignore_ascii_case(&key))
    {
        return Err("Esta versão já está sendo baixada ou está na fila.".into());
    }
    mgr.handles.insert(
        key.clone(),
        DownloadHandle {
            job: DownloadJob {
                target_dir,
                tag,
                asset_name,
                download_url,
                expected_sha256: expected_sha256.to_ascii_lowercase(),
                expected_size,
                entrypoint,
                restricted,
            },
            cancel: Arc::new(AtomicBool::new(false)),
            pause: Arc::new(AtomicBool::new(false)),
        },
    );
    let limit = settings::read_settings(&app).download_concurrency.max(1) as usize;
    let should_start = mgr.active_count < limit;
    if should_start {
        mgr.active_count += 1;
        mgr.state.insert(key.clone(), SlotState::Active);
    } else {
        mgr.state.insert(key.clone(), SlotState::Queued);
        mgr.queue.push_back(key.clone());
    }
    drop(mgr);

    if should_start {
        let _ = app.emit("godot-download-started", &key);
        tauri::async_runtime::spawn(run_download(app, key));
    } else {
        let _ = app.emit("godot-download-queued", &key);
    }
    Ok(())
}

#[tauri::command]
pub fn list_downloads() -> Vec<DownloadSnapshot> {
    let mgr = dm().lock().unwrap_or_else(|e| e.into_inner());
    let mut snapshots: Vec<DownloadSnapshot> = mgr
        .state
        .iter()
        .map(|(tag, state)| DownloadSnapshot {
            tag: tag.clone(),
            state: match state {
                SlotState::Active => "downloading",
                SlotState::Queued => "queued",
                SlotState::Paused => "paused",
            }
            .to_string(),
        })
        .collect();
    snapshots.sort_by(|a, b| a.tag.cmp(&b.tag));
    snapshots
}

#[tauri::command]
pub fn pause_download(key: String) -> Result<(), String> {
    let mgr = dm().lock().unwrap_or_else(|e| e.into_inner());
    match mgr.handles.get(&key) {
        Some(h) => {
            h.pause.store(true, Ordering::SeqCst);
            Ok(())
        }
        None => Err("Esta versão não está sendo baixada.".into()),
    }
}

#[tauri::command]
pub fn cancel_download(app: AppHandle, key: String) -> Result<(), String> {
    let mut mgr = dm().lock().unwrap_or_else(|e| e.into_inner());
    match mgr.state.get(&key).cloned() {
        Some(SlotState::Queued) => {
            mgr.queue.retain(|k| k != &key);
            mgr.state.remove(&key);
            mgr.handles.remove(&key);
            drop(mgr);
            let _ = app.emit("godot-download-canceled", &key);
            Ok(())
        }
        Some(SlotState::Active) => {
            if let Some(h) = mgr.handles.get(&key) {
                h.cancel.store(true, Ordering::SeqCst);
            }
            Ok(())
        }
        Some(SlotState::Paused) => {
            let target_dir = mgr
                .handles
                .get(&key)
                .map(|handle| handle.job.target_dir.clone());
            mgr.state.remove(&key);
            mgr.handles.remove(&key);
            drop(mgr);
            if let Some(target_dir) = target_dir {
                let _ = fs::remove_dir_all(&target_dir);
            }
            let _ = app.emit("godot-download-canceled", &key);
            Ok(())
        }
        None => Err("Não encontrado.".into()),
    }
}

#[tauri::command]
pub fn resume_download(app: AppHandle, key: String) -> Result<(), String> {
    let mut mgr = dm().lock().unwrap_or_else(|e| e.into_inner());
    if mgr.state.get(&key) != Some(&SlotState::Paused) {
        return Err("O download não está pausado.".into());
    }
    if let Some(h) = mgr.handles.get(&key) {
        h.pause.store(false, Ordering::SeqCst);
    }
    let limit = settings::read_settings(&app).download_concurrency.max(1) as usize;
    if mgr.active_count < limit {
        mgr.active_count += 1;
        mgr.state.insert(key.clone(), SlotState::Active);
        drop(mgr);
        let _ = app.emit("godot-download-started", &key);
        tauri::async_runtime::spawn(run_download(app, key));
    } else {
        mgr.state.insert(key.clone(), SlotState::Queued);
        mgr.queue.push_back(key.clone());
        drop(mgr);
        let _ = app.emit("godot-download-queued", &key);
    }
    Ok(())
}

async fn run_download(app: AppHandle, key: String) {
    let (job, cancel, pause) = {
        let mgr = dm().lock().unwrap_or_else(|e| e.into_inner());
        match mgr.handles.get(&key) {
            Some(h) => (h.job.clone(), h.cancel.clone(), h.pause.clone()),
            None => return,
        }
    };

    let target_dir = job.target_dir.clone();
    if let Err(error) = prepare_download_directory(&target_dir, &job.asset_name) {
        finish_with_error(&app, &key, error);
        return;
    }
    let zip_path = target_dir.join(&job.asset_name);
    let existing: u64 = fs::metadata(&zip_path).map(|m| m.len()).unwrap_or(0);

    let client = match download_http_client() {
        Ok(client) => client,
        Err(error) => return finish_with_error(&app, &key, error),
    };
    let mut req = if job.restricted {
        let access = match crate::github::authorized_private_repository(
            crate::github::PrivateResource::EngineReleases,
        )
        .await
        {
            Ok(Some(access)) => access,
            Ok(None) => {
                return finish_with_error(
                    &app,
                    &key,
                    "Sua sessão não possui mais acesso a esta release TEST.".into(),
                )
            }
            Err(error) => return finish_with_error(&app, &key, error),
        };
        if !official_engine_asset_url(&job.download_url, &access.repository, true) {
            return finish_with_error(
                &app,
                &key,
                "O acesso à release TEST mudou; o download foi bloqueado.".into(),
            );
        }
        crate::jingu::release_get(&client, &job.download_url, "application/octet-stream")
            .bearer_auth(access.token)
    } else {
        crate::jingu::release_get(&client, &job.download_url, "application/vnd.github+json")
    };
    if existing > 0 {
        req = req.header(reqwest::header::RANGE, format!("bytes={}-", existing));
    }
    let resp = if job.restricted {
        match crate::github::send_with_retry(req, "o início do download da release TEST").await {
            Ok(response) => response,
            Err(error) => return finish_with_error(&app, &key, error),
        }
    } else {
        match req.send().await {
            Ok(response) => response,
            Err(error) => return finish_with_error(&app, &key, error.to_string()),
        }
    };
    let status = resp.status();

    // HTTP 416 commonly means the local ZIP already contains the full remote file
    // (for example, the app closed after download but before extraction). When
    // the server supplies `bytes */N`, require N to match the local file before
    // trusting it; otherwise the ZIP itself is still validated during extraction.
    let reuse_existing_zip = if existing > 0 && status == reqwest::StatusCode::RANGE_NOT_SATISFIABLE
    {
        let remote_total = resp
            .headers()
            .get(reqwest::header::CONTENT_RANGE)
            .and_then(|v| v.to_str().ok())
            .and_then(|v| v.strip_prefix("bytes */"))
            .and_then(|v| v.parse::<u64>().ok());
        if let Some(remote_total) = remote_total {
            if remote_total != existing {
                let _ = fs::remove_file(&zip_path);
                return finish_with_error(
                    &app,
                    &key,
                    format!(
                        "O arquivo parcial de {} não corresponde mais ao tamanho remoto. Ele foi descartado; tente novamente.",
                        job.asset_name
                    ),
                );
            }
        }
        true
    } else {
        false
    };

    if !reuse_existing_zip {
        if !status.is_success() {
            let body = resp.text().await.unwrap_or_default();
            let detail: String = body.chars().take(320).collect();
            let message = if detail.trim().is_empty() {
                format!(
                    "Falha HTTP {} ao baixar {}",
                    status.as_u16(),
                    job.asset_name
                )
            } else {
                format!(
                    "Falha HTTP {} ao baixar {}: {}",
                    status.as_u16(),
                    job.asset_name,
                    detail.trim()
                )
            };
            return finish_with_error(&app, &key, message);
        }

        let mut append_existing = false;
        let mut downloaded = 0_u64;

        if existing > 0 && status == reqwest::StatusCode::PARTIAL_CONTENT {
            let expected = format!("bytes {}-", existing);
            let content_range = resp
                .headers()
                .get(reqwest::header::CONTENT_RANGE)
                .and_then(|v| v.to_str().ok())
                .unwrap_or_default();
            if !content_range.starts_with(&expected) {
                let _ = fs::remove_file(&zip_path);
                return finish_with_error(
                    &app,
                    &key,
                    format!(
                        "O servidor retornou um Content-Range inesperado ao retomar {}. O arquivo parcial foi descartado; tente novamente.",
                        job.asset_name
                    ),
                );
            }
            append_existing = true;
            downloaded = existing;
        } else if existing == 0 && status == reqwest::StatusCode::PARTIAL_CONTENT {
            let content_range = resp
                .headers()
                .get(reqwest::header::CONTENT_RANGE)
                .and_then(|v| v.to_str().ok())
                .unwrap_or_default();
            if !content_range.starts_with("bytes 0-") {
                let _ = fs::remove_file(&zip_path);
                return finish_with_error(
                    &app,
                    &key,
                    format!(
                        "O servidor retornou um download parcial inesperado para {}. Tente novamente.",
                        job.asset_name
                    ),
                );
            }
        }
        // If a Range request is ignored and the server answers 200, restart from
        // byte zero instead of appending a full response to a partial ZIP.

        let total = resp
            .content_length()
            .unwrap_or(0)
            .saturating_add(downloaded);

        let mut options = fs::OpenOptions::new();
        options.create(true);
        if append_existing {
            options.append(true);
        } else {
            options.write(true).truncate(true);
        }
        let mut file = match options.open(&zip_path) {
            Ok(f) => f,
            Err(e) => return finish_with_error(&app, &key, e.to_string()),
        };

        let mut stream = resp.bytes_stream();
        let mut last_emit = Instant::now();
        let mut last_emitted = downloaded;
        loop {
            if cancel.load(Ordering::SeqCst) {
                drop(file);
                let _ = fs::remove_dir_all(&target_dir);
                release_slot(&app, &key, true);
                let _ = app.emit("godot-download-canceled", &key);
                return;
            }
            if pause.load(Ordering::SeqCst) {
                drop(file);
                {
                    let mut mgr = dm().lock().unwrap_or_else(|e| e.into_inner());
                    mgr.state.insert(key.clone(), SlotState::Paused);
                }
                release_slot(&app, &key, false);
                let _ = app.emit("godot-download-paused", &key);
                return;
            }
            let chunk = match stream.next().await {
                Some(Ok(c)) => c,
                Some(Err(e)) => return finish_with_error(&app, &key, e.to_string()),
                None => break,
            };
            if downloaded.saturating_add(chunk.len() as u64) > job.expected_size {
                drop(file);
                let _ = fs::remove_file(&zip_path);
                return finish_with_error(
                    &app,
                    &key,
                    "Download excedeu o tamanho declarado no manifesto.".into(),
                );
            }
            if let Err(e) = file.write_all(&chunk) {
                return finish_with_error(&app, &key, e.to_string());
            }
            downloaded = downloaded.saturating_add(chunk.len() as u64);

            // IPC events are deliberately throttled: large engine downloads can
            // otherwise flood the WebView with one event per network chunk.
            let reached_end = total > 0 && downloaded >= total;
            let enough_bytes = downloaded.saturating_sub(last_emitted) >= 512 * 1024;
            let enough_time = last_emit.elapsed() >= Duration::from_millis(100);
            if reached_end || enough_bytes || enough_time {
                let _ = app.emit(
                    "godot-download-progress",
                    DownloadProgress {
                        tag: key.clone(),
                        downloaded,
                        total,
                    },
                );
                last_emit = Instant::now();
                last_emitted = downloaded;
            }
        }
        drop(file);

        if total > 0 && downloaded != total {
            return finish_with_error(
                &app,
                &key,
                format!(
                    "O download de {} terminou incompleto ({} de {} bytes). A parte válida foi preservada para retomada.",
                    job.asset_name, downloaded, total
                ),
            );
        }

        if downloaded != last_emitted {
            let _ = app.emit(
                "godot-download-progress",
                DownloadProgress {
                    tag: key.clone(),
                    downloaded,
                    total,
                },
            );
        }
    }

    let app2 = app.clone();
    let job2 = job.clone();
    let cancel2 = cancel.clone();
    let result = tokio::task::spawn_blocking(move || -> Result<InstalledGodotVersion, String> {
        let extraction = (|| -> Result<InstalledGodotVersion, String> {
            let actual_size = fs::metadata(&zip_path)
                .map_err(|e| e.to_string())?
                .len();
            if actual_size != job2.expected_size {
                return Err(format!(
                    "O pacote {} falhou na verificação de tamanho (esperado {}, recebido {}).",
                    job2.asset_name, job2.expected_size, actual_size
                ));
            }
            let actual_sha256 = sha256_file(&zip_path)?;
            if actual_sha256 != job2.expected_sha256 {
                return Err(format!(
                    "O pacote {} falhou na verificação SHA-256 e foi descartado.",
                    job2.asset_name
                ));
            }

            let zip_file = fs::File::open(&zip_path).map_err(|e| e.to_string())?;
            let mut archive = zip::ZipArchive::new(zip_file).map_err(|e| e.to_string())?;
            validate_engine_zip_archive(&mut archive)?;
            prepare_download_directory(&target_dir, &job2.asset_name)?;
            if cancel2.load(Ordering::SeqCst) {
                return Err("Download cancelado antes da instalação.".into());
            }
            archive.extract(&target_dir).map_err(|e| e.to_string())?;
            let _ = fs::remove_file(&zip_path);

            let exe_path = declared_entrypoint(&target_dir, &job2.entrypoint).ok_or_else(|| {
                format!(
                    "O entrypoint declarado '{}' não foi encontrado após a extração da Jingu Engine.",
                    job2.entrypoint
                )
            })?;
            verify_executable_arch(&exe_path)?;
            if cancel2.load(Ordering::SeqCst) {
                return Err("Download cancelado durante a instalação.".into());
            }

            #[cfg(unix)]
            {
                use std::os::unix::fs::PermissionsExt;
                if let Ok(meta) = fs::metadata(&exe_path) {
                    let mut perms = meta.permissions();
                    perms.set_mode(0o755);
                    let _ = fs::set_permissions(&exe_path, perms);
                }
            }

            let version_number = job2
                .tag
                .split('-')
                .next()
                .unwrap_or(&job2.tag)
                .trim_start_matches('v')
                .to_string();
            let is_mono = job2.asset_name.to_lowercase().contains("mono");
            let installed = InstalledGodotVersion {
                tag: if is_mono {
                    format!("{}-mono", job2.tag)
                } else {
                    job2.tag.clone()
                },
                version: version_number,
                runtime_version: probe_external_runtime_version(&exe_path),
                executable_path: exe_path.to_string_lossy().to_string(),
                is_mono,
                installed_at: chrono::Utc::now().to_rfc3339(),
                custom_name: None,
                install_root: Some(target_dir.to_string_lossy().to_string()),
                supports_console: supports_console(&exe_path),
                managed_install: Some(true),
                restricted: job2.restricted,
            };
            if cancel2.load(Ordering::SeqCst) {
                return Err("Download cancelado antes do registro da instalação.".into());
            }
            register_version(&app2, installed.clone()).map_err(|e| e.to_string())?;
            crate::projects::rebind_projects_to_version(&app2, &installed);
            Ok(installed)
        })();

        if extraction.is_err() {
            // A broken/partial ZIP must not poison future retries or leave a
            // directory that can be mistaken for an installed engine.
            let _ = fs::remove_dir_all(&target_dir);
        }
        extraction
    })
    .await;

    match result {
        Ok(Ok(_)) => {
            release_slot(&app, &key, true);
            let _ = app.emit("godot-download-complete", &key);
        }
        Ok(Err(e)) => finish_with_error(&app, &key, e),
        Err(e) => finish_with_error(&app, &key, e.to_string()),
    }
}

pub fn find_executable(dir: &Path) -> Option<PathBuf> {
    let entries = fs::read_dir(dir).ok()?;
    for entry in entries.flatten() {
        let path = entry.path();
        let fname = path.file_name()?.to_str()?.to_string();
        let lower = fname.to_lowercase();

        #[cfg(target_os = "macos")]
        if path.is_dir() && lower.ends_with(".app") {
            let macos_dir = path.join("Contents/MacOS");
            if let Ok(bins) = fs::read_dir(&macos_dir) {
                for b in bins.flatten() {
                    if b.path().is_file() {
                        return Some(b.path());
                    }
                }
            }
            continue;
        }

        if path.is_dir() {
            if let Some(found) = find_executable(&path) {
                return Some(found);
            }
            continue;
        }

        #[cfg(target_os = "windows")]
        if lower.ends_with(".exe") && !lower.contains("console") && !lower.contains("updater") {
            return Some(path);
        }
        #[cfg(target_os = "linux")]
        if lower.starts_with("jingu") || lower.starts_with("godot") {
            return Some(path);
        }
    }
    None
}

#[cfg(target_os = "windows")]
pub fn console_executable_for(exe: &Path) -> Option<PathBuf> {
    let stem = exe.file_stem()?.to_str()?;
    let candidates = [
        exe.with_file_name(format!("{stem}.console.exe")),
        exe.with_file_name(format!("{stem}_console.exe")),
    ];
    candidates.into_iter().find(|candidate| candidate.is_file())
}

pub fn migrate_mono_tags(app: &AppHandle) -> Result<(), String> {
    let guard = engine_registry_lock()
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let mut list = read_registry_unlocked(app);
    let mut changed = false;
    for v in list.iter_mut() {
        if v.is_mono && !v.tag.ends_with("-mono") {
            v.tag = format!("{}-mono", v.tag);
            changed = true;
        }
    }
    if changed {
        write_registry_unlocked(app, &list)?;
    }
    drop(guard);

    crate::projects::update_projects(app, |projects| {
        for version in &list {
            if !version.is_mono || !version.tag.ends_with("-mono") {
                continue;
            }
            let base = version.tag.trim_end_matches("-mono");
            let has_standard_still = list.iter().any(|other| !other.is_mono && other.tag == base);
            if has_standard_still {
                continue;
            }
            for project in projects.iter_mut() {
                if project.godot_version == base {
                    project.godot_version = version.tag.clone();
                }
            }
        }
        Ok(())
    })?;
    Ok(())
}

pub(crate) fn list_installed_godot_versions_blocking(
    app: &AppHandle,
) -> Result<Vec<InstalledGodotVersion>, String> {
    migrate_mono_tags(app)?;
    prune_missing(app)
}

#[tauri::command]
pub async fn list_installed_godot_versions(
    app: AppHandle,
) -> Result<Vec<InstalledGodotVersion>, String> {
    let mut rows =
        tokio::task::spawn_blocking(move || list_installed_godot_versions_blocking(&app))
            .await
            .map_err(|error| {
                format!("Falha aguardando leitura das versões instaladas: {error}")
            })??;
    if rows.iter().any(|row| row.restricted) {
        let allowed = crate::github::authorized_private_repository(
            crate::github::PrivateResource::EngineReleases,
        )
        .await
        .ok()
        .flatten()
        .is_some();
        if !allowed {
            rows.retain(|row| !row.restricted);
        }
    }
    Ok(rows)
}

pub struct LaunchedEditor {
    pub child: std::process::Child,
    #[cfg(unix)]
    pub pid_file: Option<PathBuf>,
}

#[cfg(target_os = "windows")]
fn read_binary_header_at(file: &mut fs::File, offset: u64, out: &mut [u8]) -> Result<(), String> {
    file.seek(SeekFrom::Start(offset))
        .map_err(|e| e.to_string())?;
    file.read_exact(out).map_err(|e| e.to_string())
}

fn verify_executable_arch(exe: &Path) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        let mut file = fs::File::open(exe).map_err(|e| e.to_string())?;
        let mut dos = [0u8; 64];
        file.read_exact(&mut dos).map_err(|_| {
            "O executável da Jingu Engine possui cabeçalho PE truncado.".to_string()
        })?;
        if &dos[..2] != b"MZ" {
            return Err("O pacote instalado não contém um executável PE Windows válido.".into());
        }
        let pe_offset = u32::from_le_bytes([dos[0x3c], dos[0x3d], dos[0x3e], dos[0x3f]]) as u64;
        let mut pe = [0u8; 6];
        read_binary_header_at(&mut file, pe_offset, &mut pe)?;
        if &pe[..4] != b"PE\0\0" {
            return Err("O executável da Jingu Engine possui assinatura PE inválida.".into());
        }
        let machine = u16::from_le_bytes([pe[4], pe[5]]);
        if cfg!(target_arch = "x86_64") && machine == 0x8664 {
            return Ok(());
        }
        return Err(format!(
            "Esta Jingu Engine usa arquitetura PE 0x{machine:04X}, incompatível com {}.",
            std::env::consts::ARCH
        ));
    }

    #[cfg(target_os = "linux")]
    {
        let mut header = [0u8; 20];
        fs::File::open(exe)
            .and_then(|mut file| file.read_exact(&mut header))
            .map_err(|_| {
                "O executável da Jingu Engine possui cabeçalho ELF truncado.".to_string()
            })?;
        if &header[..4] != b"\x7fELF" || header[4] != 2 {
            return Err("O pacote instalado não contém um executável ELF 64-bit válido.".into());
        }
        let machine = match header[5] {
            1 => u16::from_le_bytes([header[18], header[19]]),
            2 => u16::from_be_bytes([header[18], header[19]]),
            _ => return Err("O executável ELF possui endianness inválida.".into()),
        };
        if cfg!(target_arch = "x86_64") && machine == 0x3E {
            return Ok(());
        }
        return Err(format!(
            "Esta Jingu Engine usa arquitetura ELF 0x{machine:04X}, incompatível com {}.",
            std::env::consts::ARCH
        ));
    }

    #[cfg(target_os = "macos")]
    {
        let mut header = [0u8; 8];
        fs::File::open(exe)
            .and_then(|mut file| file.read_exact(&mut header))
            .map_err(|_| {
                "O executável da Jingu Engine possui cabeçalho Mach-O truncado.".to_string()
            })?;
        let magic = &header[..4];
        if magic == [0xCA, 0xFE, 0xBA, 0xBE]
            || magic == [0xBE, 0xBA, 0xFE, 0xCA]
            || magic == [0xCA, 0xFE, 0xBA, 0xBF]
            || magic == [0xBF, 0xBA, 0xFE, 0xCA]
        {
            return Err(
                "A Jingu Engine macOS Universal/FAT não pertence à matriz oficial; instale o build nativo da arquitetura deste Mac."
                    .into(),
            );
        }
        let cpu = if magic == [0xCF, 0xFA, 0xED, 0xFE] {
            u32::from_le_bytes([header[4], header[5], header[6], header[7]])
        } else if magic == [0xFE, 0xED, 0xFA, 0xCF] {
            u32::from_be_bytes([header[4], header[5], header[6], header[7]])
        } else {
            return Err("O pacote instalado não contém um Mach-O 64-bit thin válido.".into());
        };
        let expected = if cfg!(target_arch = "aarch64") {
            0x0100_000C
        } else if cfg!(target_arch = "x86_64") {
            0x0100_0007
        } else {
            0
        };
        if expected != 0 && cpu == expected {
            return Ok(());
        }
        return Err(format!(
            "Esta Jingu Engine usa CPU Mach-O 0x{cpu:08X}, incompatível com {}.",
            std::env::consts::ARCH
        ));
    }

    #[allow(unreachable_code)]
    Ok(())
}

fn validate_engine_zip_archive<R: Read + Seek>(
    archive: &mut zip::ZipArchive<R>,
) -> Result<(), String> {
    if archive.is_empty() || archive.len() > 20_000 {
        return Err(format!(
            "Pacote ZIP possui quantidade de entradas inválida: {}.",
            archive.len()
        ));
    }
    let mut names = std::collections::HashSet::new();
    let mut total_uncompressed = 0u64;
    for index in 0..archive.len() {
        let entry = archive.by_index(index).map_err(|e| e.to_string())?;
        let raw_name = entry.name().to_string();
        if !safe_release_entrypoint(raw_name.strip_suffix('/').unwrap_or(&raw_name))
            || entry.enclosed_name().is_none()
        {
            return Err(format!("Pacote ZIP contém caminho inseguro: {raw_name}"));
        }
        if let Some(mode) = entry.unix_mode() {
            if mode & 0o170000 == 0o120000 {
                return Err(format!(
                    "Pacote ZIP contém symlink não permitido: {raw_name}"
                ));
            }
        }
        if !names.insert(raw_name.to_lowercase()) {
            return Err(format!(
                "Pacote ZIP contém caminho duplicado/case-collision: {raw_name}"
            ));
        }
        total_uncompressed = total_uncompressed
            .checked_add(entry.size())
            .ok_or_else(|| "Tamanho descompactado do ZIP excede limite numérico.".to_string())?;
        if total_uncompressed > 8 * 1024 * 1024 * 1024 {
            return Err("Pacote ZIP excede o limite de 8 GiB descompactados.".into());
        }
        if entry.size() > 64 * 1024 * 1024 {
            if entry.compressed_size() == 0 {
                return Err(format!(
                    "Pacote ZIP possui entrada grande com tamanho comprimido inválido: {raw_name}"
                ));
            }
            let ratio = entry.size() / entry.compressed_size();
            if ratio > 2_000 {
                return Err(format!(
                    "Pacote ZIP possui razão de compressão suspeita: {raw_name}"
                ));
            }
        }
    }
    Ok(())
}

pub fn spawn_editor(
    app: &AppHandle,
    exe: &Path,
    args: &[String],
    title: &str,
    use_console: bool,
) -> Result<LaunchedEditor, String> {
    verify_executable_arch(exe)?;

    if !use_console {
        return spawn_plain(exe, args);
    }

    spawn_with_console(app, exe, args, title)
}

fn spawn_plain(exe: &Path, args: &[String]) -> Result<LaunchedEditor, String> {
    std::process::Command::new(exe)
        .args(args)
        .spawn()
        .map(|child| LaunchedEditor {
            child,
            #[cfg(unix)]
            pid_file: None,
        })
        .map_err(|e| format!("Não foi possível abrir a Jingu Engine: {e}"))
}

#[cfg(target_os = "windows")]
fn spawn_with_console(
    _app: &AppHandle,
    exe: &Path,
    args: &[String],
    title: &str,
) -> Result<LaunchedEditor, String> {
    match console_executable_for(exe) {
        Some(wrapper) => {
            verify_executable_arch(&wrapper)?;
            crate::terminal::spawn_program_in_console(&wrapper, args, title)
                .map(|child| LaunchedEditor { child })
        }
        None => spawn_plain(exe, args),
    }
}

#[cfg(unix)]
fn spawn_with_console(
    app: &AppHandle,
    exe: &Path,
    args: &[String],
    _title: &str,
) -> Result<LaunchedEditor, String> {
    crate::terminal::spawn_program_in_terminal(app, exe, args).map(|(child, pid_file)| {
        LaunchedEditor {
            child,
            pid_file: Some(pid_file),
        }
    })
}

#[tauri::command]
pub async fn open_godot_version(
    app: AppHandle,
    tag: String,
    console: Option<bool>,
) -> Result<(), String> {
    let list = read_registry(&app);
    let version = list
        .iter()
        .find(|v| v.tag == tag)
        .cloned()
        .ok_or("Versão não encontrada")?;
    if version.restricted
        && crate::github::authorized_private_repository(
            crate::github::PrivateResource::EngineReleases,
        )
        .await?
        .is_none()
    {
        return Err("Esta versão TEST requer uma conta GitHub atualmente autorizada.".into());
    }
    let path = PathBuf::from(&version.executable_path);
    if !path.exists() {
        return Err("O executável não existe mais nesse caminho.".into());
    }

    let use_console = console.unwrap_or_else(|| settings::read_settings(&app).launch_with_console);
    let title = version
        .custom_name
        .clone()
        .unwrap_or_else(|| version.tag.clone());

    spawn_editor(&app, &path, &[], &title, use_console)?;
    Ok(())
}

fn version_is_managed(app: &AppHandle, version: &InstalledGodotVersion) -> bool {
    if let Some(managed) = version.managed_install {
        return managed;
    }
    // Legacy registry entries predate the ownership flag. Only infer ownership
    // when the files are visibly inside the Hub's current managed Engine root.
    let managed_root = versions_dir(app);
    if let Some(root) = version.install_root.as_deref() {
        if Path::new(root).starts_with(&managed_root) {
            return true;
        }
    }
    Path::new(&version.executable_path).starts_with(managed_root)
}

#[tauri::command]
pub fn delete_godot_version(app: AppHandle, tag: String) -> Result<(), String> {
    let _guard = engine_registry_lock()
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let mut list = read_registry_unlocked(&app);
    let idx = list
        .iter()
        .position(|v| v.tag == tag)
        .ok_or("Versão não encontrada")?;
    let removed = list[idx].clone();

    // External builds are references, not Hub-owned installations. Removing
    // them from Versions must never delete a user's build/source directory.
    if !version_is_managed(&app, &removed) {
        list.remove(idx);
        write_registry_unlocked(&app, &list)?;
        return Ok(());
    }

    // Keep the registry entry until filesystem deletion succeeds. Otherwise a
    // transient Trash/permission failure would make an installed Engine vanish
    // from the Hub while its files were still present on disk.
    if let Some(root) = &removed.install_root {
        let root_path = PathBuf::from(root);
        if root_path.exists() {
            trash::delete_all([&root_path]).map_err(|e| {
                format!("Não foi possível mover a Jingu Engine para a lixeira: {e}")
            })?;
        }
    } else {
        let managed = versions_dir(&app);
        let exe_path = PathBuf::from(&removed.executable_path);
        let mut deleted_managed_folder = false;

        if exe_path.starts_with(&managed) {
            if let Some(version_folder) = exe_path
                .strip_prefix(&managed)
                .ok()
                .and_then(|p| p.components().next())
            {
                let folder = managed.join(version_folder);
                if folder.exists() {
                    trash::delete_all([&folder]).map_err(|e| {
                        format!("Não foi possível mover a Jingu Engine para a lixeira: {e}")
                    })?;
                }
                deleted_managed_folder = true;
            }
        }

        if !deleted_managed_folder {
            #[cfg(target_os = "macos")]
            {
                if let Some(bundle) = exe_path
                    .ancestors()
                    .find(|p| p.extension().map(|e| e == "app").unwrap_or(false))
                {
                    if bundle.exists() {
                        trash::delete_all([bundle]).map_err(|e| {
                            format!("Não foi possível mover a Jingu Engine para a lixeira: {e}")
                        })?;
                    }
                    list.remove(idx);
                    write_registry_unlocked(&app, &list)?;
                    return Ok(());
                }
            }

            #[cfg(target_os = "windows")]
            {
                if let Some(stem) = exe_path.file_stem().and_then(|s| s.to_str()) {
                    // Both conventions exist in Godot/Jingu distributions. Remove
                    // either companion so uninstall cannot leave a console binary behind.
                    for console_path in [
                        exe_path.with_file_name(format!("{}.console.exe", stem)),
                        exe_path.with_file_name(format!("{}_console.exe", stem)),
                    ] {
                        if console_path.exists() {
                            trash::delete(&console_path).map_err(|e| {
                                format!("Não foi possível mover o executável console para a lixeira: {e}")
                            })?;
                        }
                    }
                }
            }

            if exe_path.exists() {
                trash::delete(&exe_path).map_err(|e| {
                    format!("Não foi possível mover a Jingu Engine para a lixeira: {e}")
                })?;
            }
        }
    }

    list.remove(idx);
    write_registry_unlocked(&app, &list)?;
    Ok(())
}

#[tauri::command]
pub async fn import_version_zip(
    app: AppHandle,
    zip_path: String,
) -> Result<InstalledGodotVersion, String> {
    let zip_path = std::path::PathBuf::from(&zip_path);
    if !zip_path.exists() {
        return Err("Arquivo não encontrado.".into());
    }
    if zip_path.extension().map(|e| e != "zip").unwrap_or(true) {
        return Err("O arquivo precisa ser um pacote .zip.".into());
    }

    let zip_name = zip_path
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or("")
        .to_string();

    let (tag, is_mono) = match parse_godot_tag_from_filename(&zip_name) {
        Some(clean) => {
            let detected_mono = clean.ends_with("-mono");
            (clean, detected_mono)
        }
        None => {
            let stem = zip_path
                .file_stem()
                .and_then(|s| s.to_str())
                .unwrap_or("unknown")
                .to_string();
            let detected_mono = stem.to_lowercase().contains("mono");
            let tag = if detected_mono && !stem.ends_with("-mono") {
                format!("{}-mono", stem)
            } else {
                stem
            };
            (tag, detected_mono)
        }
    };

    let target_dir = versions_dir(&app).join(&tag);
    if !safe_install_component(&tag) {
        return Err("Nome de pacote inseguro; importação recusada.".into());
    }
    fs::create_dir(&target_dir).map_err(|e| e.to_string())?;

    let import_result = (|| -> Result<InstalledGodotVersion, String> {
        let zip_file = fs::File::open(&zip_path).map_err(|e| e.to_string())?;
        let mut archive = zip::ZipArchive::new(zip_file).map_err(|e| e.to_string())?;
        validate_engine_zip_archive(&mut archive)?;
        archive.extract(&target_dir).map_err(|e| e.to_string())?;

        let exe_path = find_executable(&target_dir).ok_or_else(|| {
            "Não foi possível localizar o executável da Jingu Engine no pacote importado"
                .to_string()
        })?;

        verify_executable_arch(&exe_path)?;

        let version_number = tag
            .split('-')
            .next()
            .unwrap_or(&tag)
            .trim_start_matches('v')
            .to_string();

        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            if let Ok(meta) = fs::metadata(&exe_path) {
                let mut perms = meta.permissions();
                perms.set_mode(0o755);
                let _ = fs::set_permissions(&exe_path, perms);
            }
        }

        let installed = InstalledGodotVersion {
            tag: tag.clone(),
            version: version_number,
            runtime_version: probe_external_runtime_version(&exe_path),
            executable_path: exe_path.to_string_lossy().to_string(),
            is_mono,
            installed_at: chrono::Utc::now().to_rfc3339(),
            custom_name: None,
            install_root: Some(target_dir.to_string_lossy().to_string()),
            supports_console: supports_console(&exe_path),
            managed_install: Some(true),
            restricted: false,
        };

        register_version(&app, installed.clone())?;
        crate::projects::rebind_projects_to_version(&app, &installed);
        Ok(installed)
    })();

    if import_result.is_err() {
        // ZipArchive::extract is not atomic. Clean the managed destination on
        // any failure so a broken import never blocks a clean retry.
        let _ = fs::remove_dir_all(&target_dir);
    }

    import_result
}

#[tauri::command]
pub async fn import_version_path(
    app: AppHandle,
    target_path: String,
) -> Result<InstalledGodotVersion, String> {
    let target = PathBuf::from(&target_path);
    if !target.exists() {
        return Err("Arquivo ou pasta não encontrado.".into());
    }
    if target.is_file() && target.extension().map(|e| e == "zip").unwrap_or(false) {
        return import_version_zip(app, target_path).await;
    }
    if target.is_dir() {
        return register_external_version(&app, &target);
    }
    register_external_version(&app, &target)
}

pub fn prune_missing(app: &AppHandle) -> Result<Vec<InstalledGodotVersion>, String> {
    let _guard = engine_registry_lock()
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let list = read_registry_unlocked(app);
    let (kept, removed): (Vec<InstalledGodotVersion>, Vec<InstalledGodotVersion>) = list
        .into_iter()
        .partition(|v| Path::new(&v.executable_path).exists());
    if !removed.is_empty() {
        write_registry_unlocked(app, &kept)?;
    }
    Ok(kept)
}

#[cfg(target_os = "windows")]
fn supports_console(exe: &Path) -> bool {
    console_executable_for(exe).is_some()
}

#[cfg(not(target_os = "windows"))]
fn supports_console(_exe: &Path) -> bool {
    true
}

#[cfg(test)]
mod release_security_tests {
    #[test]
    fn concurrent_engine_registration_keeps_every_installation() {
        let root = std::env::temp_dir().join(format!("jingu-registry-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir(&root).unwrap();
        let path = root.join("registry.json");
        let barrier = std::sync::Arc::new(std::sync::Barrier::new(8));
        let handles: Vec<_> = (0..8)
            .map(|index| {
                let path = path.clone();
                let barrier = barrier.clone();
                std::thread::spawn(move || {
                    barrier.wait();
                    let version = crate::models::InstalledGodotVersion {
                        tag: format!("v1.0.{index}"),
                        version: format!("1.0.{index}"),
                        executable_path: format!("fixture-{index}"),
                        runtime_version: Some("fixture".into()),
                        is_mono: false,
                        installed_at: String::new(),
                        custom_name: None,
                        install_root: None,
                        supports_console: false,
                        managed_install: Some(true),
                        restricted: false,
                    };
                    assert!(super::register_version_at_path(&path, version.clone()).unwrap());
                    assert!(!super::register_version_at_path(&path, version).unwrap());
                })
            })
            .collect();
        for handle in handles {
            handle.join().unwrap();
        }
        let rows: Vec<crate::models::InstalledGodotVersion> = crate::persist::read_json(&path);
        assert_eq!(rows.len(), 8);
        std::fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn hardened_engine_names_reject_paths_devices_and_conflicting_targets() {
        for name in [
            "../escape",
            ".",
            "..",
            "C:\\escape",
            "file:stream",
            "NUL.zip",
            "COM1.txt",
            "LPT¹",
            "engine.",
            "engine ",
            "bad\0name",
        ] {
            assert!(!super::safe_install_component(name), "accepted {name:?}");
        }
        assert!(super::safe_install_component("v1.0.0-stable"));
        assert!(super::safe_install_component("guia-ç-日本.txt"));
        for (name, os) in [
            ("Jingu-windows-x64-linux-arm64.zip", "windows"),
            ("Jingu-linux-x64-windows-arm64.zip", "linux"),
            ("Jingu-darwin64.zip", "windows"),
            ("../Jingu-windows-x64.zip", "windows"),
            ("Jingu-win64-arm64.zip", "windows"),
            ("Jingu-linux64-aarch64.zip", "linux"),
        ] {
            assert!(
                !super::engine_asset_matches_target(name, os, "x86_64"),
                "accepted {name}"
            );
        }
        for os in ["windows", "linux"] {
            for arch in ["aarch64", "arm64"] {
                for name in [
                    "Jingu-win64.zip",
                    "Jingu-linux64.zip",
                    "Jingu-windows-arm64.zip",
                    "Jingu-linux-arm64.zip",
                ] {
                    assert!(!super::engine_asset_matches_target(name, os, arch));
                }
                assert!(!super::manifest_platform_matches_target(
                    &format!("{os}-x86_64"),
                    os,
                    arch
                ));
            }
        }
    }

    #[test]
    fn hardened_zip_rejects_aliases_ads_and_reserved_names() {
        for name in [
            "folder/../escape",
            "folder/./file",
            "folder//file",
            "file:stream",
            "NUL",
            "folder/trailing.",
            "folder/trailing ",
        ] {
            let mut archive = archive_with_entries(&[(name, b"fixture")]);
            assert!(
                super::validate_engine_zip_archive(&mut archive).is_err(),
                "accepted {name}"
            );
        }
    }

    #[test]
    fn hardened_download_directory_preserves_existing_data() {
        let root = std::env::temp_dir().join(format!("jingu-download-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir(&root).unwrap();
        let target = root.join("version");
        super::prepare_download_directory(&target, "engine.zip").unwrap();
        std::fs::write(target.join("engine.zip"), b"partial").unwrap();
        super::prepare_download_directory(&target, "engine.zip").unwrap();
        std::fs::write(target.join("user-data.txt"), b"preserve").unwrap();
        assert!(super::prepare_download_directory(&target, "engine.zip").is_err());
        assert_eq!(
            std::fs::read(target.join("user-data.txt")).unwrap(),
            b"preserve"
        );
        let file = root.join("not-a-directory");
        std::fs::write(&file, b"preserve").unwrap();
        assert!(super::prepare_download_directory(&file, "engine.zip").is_err());
        std::fs::remove_dir_all(root).unwrap();
    }
    #[cfg(target_os = "windows")]
    use super::verify_executable_arch;
    use super::{
        dedupe_releases, engine_asset_matches_target, manifest_platform_matches_target,
        official_engine_asset_url, release_version_tuple, safe_release_entrypoint, valid_sha256,
        validate_engine_zip_archive,
    };
    #[cfg(all(target_os = "windows", target_arch = "x86_64"))]
    use super::{find_executable, sha256_file};
    use crate::models::GodotRelease;
    use std::io::{Cursor, Write};
    use zip::write::SimpleFileOptions;

    fn archive_with_entries(entries: &[(&str, &[u8])]) -> zip::ZipArchive<Cursor<Vec<u8>>> {
        let mut writer = zip::ZipWriter::new(Cursor::new(Vec::new()));
        for (name, body) in entries {
            writer
                .start_file(*name, SimpleFileOptions::default())
                .unwrap();
            writer.write_all(body).unwrap();
        }
        zip::ZipArchive::new(writer.finish().unwrap()).unwrap()
    }

    #[test]
    fn accepts_only_authorized_repository_asset_shapes() {
        let private_repo = "PrivateEngineChannel-Test";
        let api_asset = format!(
            "https://api.github.com/repos/{}/{private_repo}/releases/assets/123456789",
            crate::jingu::GITHUB_OWNER
        );
        assert!(official_engine_asset_url(&api_asset, private_repo, true));
        assert!(!official_engine_asset_url(
            &api_asset,
            "OtherPrivateChannel-Test",
            true
        ));
        assert!(official_engine_asset_url(
            "https://github.com/JinguEngine/JinguEngine-Releases/releases/download/v1.0.0/JinguEngine.zip",
            crate::jingu::PUBLIC_ENGINE_RELEASES_REPOSITORY,
            false
        ));
        assert!(!official_engine_asset_url(
            "https://github.com/other/JinguEngine-Releases/releases/download/v1.0.0/JinguEngine.zip",
            crate::jingu::PUBLIC_ENGINE_RELEASES_REPOSITORY,
            false
        ));
    }

    #[test]
    fn engine_release_versions_sort_newest_first_and_dedupe_tags() {
        let rows = dedupe_releases(vec![
            GodotRelease {
                channel: "stable".to_string(),
                restricted: false,
                tag: "v1.0.0".to_string(),
                assets: vec![],
            },
            GodotRelease {
                channel: "stable".to_string(),
                restricted: false,
                tag: "v2.0.0".to_string(),
                assets: vec![],
            },
            GodotRelease {
                channel: "stable".to_string(),
                restricted: false,
                tag: "v1.5.0".to_string(),
                assets: vec![],
            },
            GodotRelease {
                channel: "stable".to_string(),
                restricted: false,
                tag: "v2.0.0".to_string(),
                assets: vec![],
            },
        ]);
        let tags: Vec<&str> = rows.iter().map(|row| row.tag.as_str()).collect();
        assert_eq!(tags, vec!["v2.0.0", "v1.5.0", "v1.0.0"]);
    }

    #[test]
    fn engine_release_semver_is_independent_from_hub_version() {
        assert_eq!(release_version_tuple("v4.0.0"), Some((4, 0, 0)));
        assert_eq!(release_version_tuple("v2.3.1"), Some((2, 3, 1)));
        assert!(release_version_tuple("not-a-version").is_none());
    }

    #[test]
    fn official_engine_platform_matrix_is_architecture_exact() {
        assert!(engine_asset_matches_target(
            "JinguEngine_v1.0.0-stable_win64.zip",
            "windows",
            "x86_64"
        ));
        assert!(engine_asset_matches_target(
            "JinguEngine_v1.0.0-stable_linux64.zip",
            "linux",
            "x86_64"
        ));
        assert!(engine_asset_matches_target(
            "JinguEngine_v1.0.0-stable_macos_arm64.zip",
            "macos",
            "aarch64"
        ));
        assert!(engine_asset_matches_target(
            "JinguEngine_v1.0.0-stable_macos_x86_64.zip",
            "macos",
            "x86_64"
        ));
        assert!(!engine_asset_matches_target(
            "JinguEngine_v1.0.0-stable_macos_x86_64.zip",
            "macos",
            "aarch64"
        ));
        assert!(!engine_asset_matches_target(
            "JinguEngine_v1.0.0-stable_macos_arm64.zip",
            "macos",
            "x86_64"
        ));
        assert!(!engine_asset_matches_target(
            "JinguEngine_v1.0.0-stable_macos.zip",
            "macos",
            "aarch64"
        ));
        assert!(!engine_asset_matches_target(
            "JinguEngine_v1.0.0-stable_macos_universal.zip",
            "macos",
            "x86_64"
        ));
        assert!(!engine_asset_matches_target(
            "JinguEngine_v1.0.0-stable_linux_arm64.zip",
            "linux",
            "aarch64"
        ));
    }

    #[test]
    fn engine_manifest_platform_keys_match_only_certified_targets() {
        assert!(manifest_platform_matches_target(
            "windows-x86_64",
            "windows",
            "x86_64"
        ));
        assert!(manifest_platform_matches_target(
            "linux-x86_64",
            "linux",
            "x86_64"
        ));
        assert!(manifest_platform_matches_target(
            "macos-arm64",
            "macos",
            "aarch64"
        ));
        assert!(manifest_platform_matches_target(
            "macos-x86_64",
            "macos",
            "x86_64"
        ));
        assert!(!manifest_platform_matches_target(
            "macos", "macos", "aarch64"
        ));
        assert!(!manifest_platform_matches_target(
            "macos-arm64",
            "macos",
            "x86_64"
        ));
    }

    #[test]
    fn validates_release_integrity_metadata() {
        assert!(valid_sha256(
            "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
        ));
        assert!(!valid_sha256("not-a-sha256"));
        assert!(safe_release_entrypoint("JinguEngine.exe"));
        assert!(safe_release_entrypoint(
            "JinguEngine.app/Contents/MacOS/JinguEngine"
        ));
        assert!(!safe_release_entrypoint("../JinguEngine.exe"));
        assert!(!safe_release_entrypoint("C:\\JinguEngine.exe"));
    }

    #[test]
    fn engine_zip_validator_accepts_safe_unicode_package() {
        let mut archive = archive_with_entries(&[
            ("JinguEngine.exe", b"fixture"),
            ("docs/guia-ç-日本.txt", b"fixture"),
        ]);
        validate_engine_zip_archive(&mut archive).unwrap();
    }

    #[test]
    fn engine_zip_validator_rejects_traversal_backslashes_and_case_collisions() {
        for entries in [
            vec![("../escape.txt", b"fixture".as_slice())],
            vec![("folder\\escape.txt", b"fixture".as_slice())],
            vec![
                ("JinguEngine.exe", b"a".as_slice()),
                ("jinguengine.EXE", b"b".as_slice()),
            ],
        ] {
            let mut archive = archive_with_entries(&entries);
            assert!(validate_engine_zip_archive(&mut archive).is_err());
        }
    }

    #[test]
    fn engine_zip_validator_rejects_symlinks() {
        let mut writer = zip::ZipWriter::new(Cursor::new(Vec::new()));
        writer
            .add_symlink(
                "JinguEngine-link",
                "../outside",
                SimpleFileOptions::default(),
            )
            .unwrap();
        let mut archive = zip::ZipArchive::new(writer.finish().unwrap()).unwrap();
        assert!(validate_engine_zip_archive(&mut archive).is_err());
    }

    #[cfg(target_os = "windows")]
    fn fixture_pe(machine: u16) -> Vec<u8> {
        let mut bytes = vec![0u8; 72];
        bytes[..2].copy_from_slice(b"MZ");
        bytes[0x3c..0x40].copy_from_slice(&64u32.to_le_bytes());
        bytes[64..68].copy_from_slice(b"PE\0\0");
        bytes[68..70].copy_from_slice(&machine.to_le_bytes());
        bytes
    }

    #[cfg(all(target_os = "windows", target_arch = "x86_64"))]
    fn write_engine_zip(path: &std::path::Path, machine: u16) {
        let file = std::fs::File::create(path).unwrap();
        let mut writer = zip::ZipWriter::new(file);
        writer
            .start_file("bin/JinguEngine.exe", SimpleFileOptions::default())
            .unwrap();
        writer.write_all(&fixture_pe(machine)).unwrap();
        writer
            .start_file("docs/guia-ç-日本.txt", SimpleFileOptions::default())
            .unwrap();
        writer.write_all(b"fixture-local-only").unwrap();
        writer.finish().unwrap();
    }

    #[test]
    #[cfg(all(target_os = "windows", target_arch = "x86_64"))]
    fn local_engine_import_install_interrupt_rollback_and_uninstall_lifecycle() {
        let root = std::env::temp_dir().join(format!(
            "jingu-engine-lifecycle-ç-日本-{}",
            uuid::Uuid::new_v4()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let package = root.join("JinguEngine_v9.9.9-stable_win64.zip");
        write_engine_zip(&package, 0x8664);
        let trusted_hash = sha256_file(&package).unwrap();
        assert!(valid_sha256(&trusted_hash));

        let install = root.join("installed");
        std::fs::create_dir_all(&install).unwrap();
        let file = std::fs::File::open(&package).unwrap();
        let mut archive = zip::ZipArchive::new(file).unwrap();
        validate_engine_zip_archive(&mut archive).unwrap();
        archive.extract(&install).unwrap();
        let executable = find_executable(&install).unwrap();
        verify_executable_arch(&executable).unwrap();
        assert!(install.join("docs").join("guia-ç-日本.txt").is_file());
        assert!(
            install.exists(),
            "a valid first install must remain complete"
        );
        assert!(
            install.exists(),
            "a repeated install must detect the existing target"
        );

        let wrong_platform = root.join("wrong-platform.zip");
        write_engine_zip(&wrong_platform, 0x014c);
        let wrong_target = root.join("wrong-target");
        std::fs::create_dir_all(&wrong_target).unwrap();
        let mut wrong =
            zip::ZipArchive::new(std::fs::File::open(&wrong_platform).unwrap()).unwrap();
        validate_engine_zip_archive(&mut wrong).unwrap();
        wrong.extract(&wrong_target).unwrap();
        assert!(verify_executable_arch(&find_executable(&wrong_target).unwrap()).is_err());
        std::fs::remove_dir_all(&wrong_target).unwrap();
        assert!(
            !wrong_target.exists(),
            "wrong-platform rollback must remove the partial install"
        );

        let corrupt = root.join("corrupt.zip");
        std::fs::write(&corrupt, b"PK\x03\x04truncated").unwrap();
        let corrupt_target = root.join("corrupt-target");
        std::fs::create_dir_all(&corrupt_target).unwrap();
        std::fs::write(corrupt_target.join("partial.tmp"), b"partial").unwrap();
        assert!(zip::ZipArchive::new(std::fs::File::open(&corrupt).unwrap()).is_err());
        std::fs::remove_dir_all(&corrupt_target).unwrap();
        assert!(!corrupt_target.exists());

        let interrupted = root.join("interrupted-target");
        std::fs::create_dir_all(&interrupted).unwrap();
        std::fs::write(interrupted.join("download.zip"), b"partial").unwrap();
        assert!(find_executable(&interrupted).is_none());
        std::fs::remove_dir_all(&interrupted).unwrap();
        assert!(
            !interrupted.exists(),
            "interrupted install must never become valid"
        );

        std::fs::write(&package, b"tampered-after-hash").unwrap();
        assert_ne!(sha256_file(&package).unwrap(), trusted_hash);
        std::fs::remove_dir_all(&install).unwrap();
        assert!(
            !install.exists(),
            "local uninstall fixture must remove the managed tree"
        );
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    #[cfg(all(target_os = "windows", target_arch = "aarch64"))]
    fn windows_arm64_rejects_x86_64_engine_fixture() {
        let root = std::env::temp_dir().join(format!(
            "jingu-engine-arch-guard-ç-日本-{}",
            uuid::Uuid::new_v4()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let exe = root.join("JinguEngine.exe");
        std::fs::write(&exe, fixture_pe(0x8664)).unwrap();

        let error = verify_executable_arch(&exe).unwrap_err();
        assert!(error.contains("0x8664"));
        assert!(error.contains("aarch64"));

        let _ = std::fs::remove_dir_all(root);
    }
}
