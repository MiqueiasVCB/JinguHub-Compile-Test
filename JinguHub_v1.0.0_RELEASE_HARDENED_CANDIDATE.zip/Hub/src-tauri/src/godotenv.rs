/**************************************************************************/
/*  godotenv.rs                                                         */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use crate::models::InstalledGodotVersion;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct GodotVersionNumber {
    pub major: u32,
    pub minor: u32,
    pub patch: u32,
    pub label: String,
    pub label_num: i32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DetectedVersion {
    pub number: GodotVersionNumber,
    pub is_dotnet: bool,
}

fn parse_uint(s: &str) -> Option<u32> {
    if s.is_empty() || !s.bytes().all(|b| b.is_ascii_digit()) {
        return None;
    }
    s.parse().ok()
}

pub fn parse_release_version(s: &str) -> Option<GodotVersionNumber> {
    let (num_part, label_part) = s.split_once('-')?;
    let mut num_parts = num_part.split('.');
    let major = parse_uint(num_parts.next()?)?;
    let minor = parse_uint(num_parts.next()?)?;
    let patch = match num_parts.next() {
        Some(p) => {
            if p.starts_with('0') {
                return None;
            }
            parse_uint(p)?
        }
        None => 0,
    };
    if num_parts.next().is_some() {
        return None;
    }
    let (label, label_num) = parse_release_label(label_part)?;
    Some(GodotVersionNumber {
        major,
        minor,
        patch,
        label,
        label_num,
    })
}

fn parse_release_label(label: &str) -> Option<(String, i32)> {
    if label == "stable" {
        return Some(("stable".to_string(), -1));
    }
    let digit_start = label.find(|c: char| c.is_ascii_digit())?;
    let (letters, digits) = label.split_at(digit_start);
    if letters.is_empty() || !letters.bytes().all(|b| b.is_ascii_lowercase()) {
        return None;
    }
    let num = parse_uint(digits)?;
    Some((letters.to_string(), num as i32))
}

pub fn parse_sharp_version(s: &str) -> Option<GodotVersionNumber> {
    let (num_part, label_part) = match s.split_once('-') {
        Some((n, l)) => (n, Some(l)),
        None => (s, None),
    };
    let mut num_parts = num_part.split('.');
    let major = parse_uint(num_parts.next()?)?;
    let minor = parse_uint(num_parts.next()?)?;
    let patch = parse_uint(num_parts.next()?)?;
    if num_parts.next().is_some() {
        return None;
    }
    let (label, label_num) = match label_part {
        None => ("stable".to_string(), -1),
        Some(l) => {
            let (letters, digits) = l.split_once('.')?;
            if letters.is_empty() || !letters.bytes().all(|b| b.is_ascii_lowercase()) {
                return None;
            }
            let num = parse_uint(digits)?;
            (letters.to_string(), num as i32)
        }
    };
    Some(GodotVersionNumber {
        major,
        minor,
        patch,
        label,
        label_num,
    })
}

pub fn parse_version(s: &str) -> Option<GodotVersionNumber> {
    let trimmed = s.trim().trim_start_matches('v');
    parse_release_version(trimmed).or_else(|| parse_sharp_version(trimmed))
}

pub fn parse_installed_tag(tag: &str) -> Option<GodotVersionNumber> {
    let base = tag.trim().trim_end_matches("-mono");
    parse_version(base)
}

pub fn numbers_equal(a: &GodotVersionNumber, b: &GodotVersionNumber) -> bool {
    a.major == b.major
        && a.minor == b.minor
        && a.patch == b.patch
        && a.label == b.label
        && a.label_num == b.label_num
}

pub fn matches_detected(spec: &DetectedVersion, tag: &str) -> bool {
    parse_installed_tag(tag)
        .map(|n| numbers_equal(&spec.number, &n))
        .unwrap_or(false)
}

pub fn best_match<'a>(
    spec: &DetectedVersion,
    versions: &'a [InstalledGodotVersion],
) -> Option<&'a InstalledGodotVersion> {
    versions
        .iter()
        .filter(|v| {
            v.runtime_version
                .as_deref()
                .is_some_and(|runtime| matches_detected(spec, runtime))
                || matches_detected(spec, &v.tag)
                || matches_detected(spec, &v.version)
        })
        .min_by_key(|v| if v.is_mono == spec.is_dotnet { 0 } else { 1 })
}

pub fn project_feature_version(project_path: &str) -> Option<(u32, u32)> {
    let config = crate::projects::project_config_path(project_path)?;
    let content = fs::read_to_string(config).ok()?;
    for line in content.lines() {
        let line = line.trim();
        let Some(rest) = line.strip_prefix("config/features=") else {
            continue;
        };
        let Some(inner) = rest
            .strip_prefix("PackedStringArray(")
            .and_then(|value| value.strip_suffix(')'))
        else {
            continue;
        };
        for value in inner.split(',') {
            let cleaned = value.trim().trim_matches('"');
            let mut parts = cleaned.split('.');
            let Some(major) = parts.next().and_then(parse_uint) else {
                continue;
            };
            let Some(minor) = parts.next().and_then(parse_uint) else {
                continue;
            };
            return Some((major, minor));
        }
    }
    None
}

pub fn project_feature_matches(project_path: &str, version: &InstalledGodotVersion) -> bool {
    let Some((major, minor)) = project_feature_version(project_path) else {
        return false;
    };
    version
        .runtime_version
        .as_deref()
        .into_iter()
        .chain([version.tag.as_str(), version.version.as_str()])
        .filter_map(parse_installed_tag)
        .any(|number| number.major == major && number.minor == minor)
}

pub fn best_project_feature_match<'a>(
    project_path: &str,
    versions: &'a [InstalledGodotVersion],
) -> Option<&'a InstalledGodotVersion> {
    let (major, minor) = project_feature_version(project_path)?;
    versions
        .iter()
        .filter(|version| {
            version
                .runtime_version
                .as_deref()
                .into_iter()
                .chain([version.tag.as_str(), version.version.as_str()])
                .filter_map(parse_installed_tag)
                .any(|number| number.major == major && number.minor == minor)
        })
        .max_by_key(|version| {
            let runtime = version
                .runtime_version
                .as_deref()
                .and_then(parse_installed_tag)
                .or_else(|| parse_installed_tag(&version.tag))
                .or_else(|| parse_installed_tag(&version.version));
            let product =
                parse_installed_tag(&version.version).or_else(|| parse_installed_tag(&version.tag));
            (
                runtime.as_ref().map(|number| number.patch).unwrap_or(0),
                product.as_ref().map(|number| number.major).unwrap_or(0),
                product.as_ref().map(|number| number.minor).unwrap_or(0),
                product.as_ref().map(|number| number.patch).unwrap_or(0),
            )
        })
}

fn ancestor_dirs(start: &Path) -> Vec<PathBuf> {
    let mut dirs = Vec::new();
    let mut current = Some(start.to_path_buf());
    while let Some(dir) = current {
        dirs.push(dir.clone());
        current = dir.parent().map(|p| p.to_path_buf());
    }
    dirs
}

pub fn detect_version(project_path: &str) -> Option<DetectedVersion> {
    let mut globals: Vec<PathBuf> = Vec::new();
    let mut csprojs: Vec<PathBuf> = Vec::new();
    let mut godotrcs: Vec<PathBuf> = Vec::new();

    for dir in ancestor_dirs(Path::new(project_path)) {
        let global = dir.join("global.json");
        if global.is_file() {
            globals.push(global);
        }

        if let Ok(entries) = fs::read_dir(&dir) {
            let mut files: Vec<PathBuf> = entries
                .flatten()
                .filter_map(|e| {
                    let p = e.path();
                    p.extension()
                        .map(|ext| ext == "csproj")
                        .unwrap_or(false)
                        .then_some(p)
                })
                .collect();
            files.sort();
            csprojs.extend(files);
        }

        let godotrc = dir.join(".godotrc");
        if godotrc.is_file() {
            godotrcs.push(godotrc);
        }
    }

    for path in globals.into_iter().chain(csprojs).chain(godotrcs) {
        if let Some(version) = parse_version_file(&path) {
            return Some(version);
        }
    }
    None
}

fn parse_version_file(path: &Path) -> Option<DetectedVersion> {
    let name = path.file_name()?.to_str()?;
    match name {
        "global.json" => parse_global_json(path),
        ".godotrc" => parse_godotrc(path),
        _ => parse_csproj(path),
    }
}

fn parse_global_json(path: &Path) -> Option<DetectedVersion> {
    let content = fs::read_to_string(path).ok()?;
    let json: serde_json::Value = serde_json::from_str(&content).ok()?;
    let version = json.get("msbuild-sdks")?.get("Godot.NET.Sdk")?;
    let version_str = match version {
        serde_json::Value::String(s) => s.clone(),
        serde_json::Value::Number(n) => n.to_string(),
        _ => return None,
    };
    let number = parse_version(&version_str)?;
    Some(DetectedVersion {
        number,
        is_dotnet: true,
    })
}

fn parse_csproj(path: &Path) -> Option<DetectedVersion> {
    let content = fs::read_to_string(path).ok()?;
    let open = content.find("<Project")?;
    let after = &content[open..];
    let close = after.find('>')?;
    let tag = &after[..close];
    let sdk = extract_attr(tag, "Sdk")?;
    let version = sdk.strip_prefix("Godot.NET.Sdk/")?;
    if version.is_empty() {
        return None;
    }
    let number = parse_version(version)?;
    Some(DetectedVersion {
        number,
        is_dotnet: true,
    })
}

fn extract_attr(tag: &str, name: &str) -> Option<String> {
    let bytes = tag.as_bytes();
    let name_bytes = name.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i..].starts_with(name_bytes) {
            let after = i + name_bytes.len();
            if bytes.get(after) == Some(&b'=') {
                if let Some(&q) = bytes.get(after + 1) {
                    if q == b'"' || q == b'\'' {
                        let value = &bytes[after + 2..];
                        if let Some(end) = value.iter().position(|&b| b == q) {
                            return std::str::from_utf8(&value[..end]).ok().map(String::from);
                        }
                    }
                }
            }
        }
        i += 1;
    }
    None
}

fn parse_godotrc(path: &Path) -> Option<DetectedVersion> {
    let content = fs::read_to_string(path).ok()?;
    let line = content.lines().next()?.trim();
    if line.is_empty() {
        return None;
    }
    const NO_DOTNET: [&str; 3] = [" no-dotnet", " non-dotnet", " not-dotnet"];
    let mut is_dotnet = true;
    let mut version = line;
    for suffix in NO_DOTNET {
        if version.ends_with(suffix) {
            is_dotnet = false;
            version = &version[..version.len() - suffix.len()];
            break;
        }
    }
    let number = parse_version(version)?;
    Some(DetectedVersion { number, is_dotnet })
}

pub fn read_jingu_pin(project_dir: &str) -> Option<String> {
    let value = fs::read_to_string(Path::new(project_dir).join(".jingu-version")).ok()?;
    let value = value.trim();
    (!value.is_empty()).then(|| value.to_string())
}

pub fn pin_version(project_dir: &str, tag: &str) -> Result<(), String> {
    let exact = tag.trim();
    if exact.is_empty() {
        return Err("A versão da Jingu Engine não pode ser vazia.".into());
    }

    let root = Path::new(project_dir);
    if !root.is_dir() {
        return Err("A pasta do projeto não existe ou não está acessível.".into());
    }

    // `.jingu-version` is the sole authoritative Jingu Engine binding. Jingu
    // release SemVer and Godot compatibility versions are different concepts;
    // a Jingu release such as 1.0.0 must never be written into `.godotrc` or
    // `global.json`. Those files belong to the project's runtime/.NET needs.
    let pin_path = root.join(".jingu-version");
    let pin_contents = format!("{}\n", exact);
    crate::persist::write_atomic(&pin_path, pin_contents.as_bytes())
        .map_err(|e| format!("Não foi possível gravar .jingu-version: {e}"))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn num(major: u32, minor: u32, patch: u32, label: &str, label_num: i32) -> GodotVersionNumber {
        GodotVersionNumber {
            major,
            minor,
            patch,
            label: label.to_string(),
            label_num,
        }
    }

    // Formatting helpers exist only to verify parser round-trips. They are not
    // part of the Hub runtime API and therefore must not leak into production
    // code as dead functions under the strict `-D warnings` gate.
    fn release_string(n: &GodotVersionNumber) -> String {
        let mut s = format!("{}.{}", n.major, n.minor);
        if n.patch != 0 {
            s.push_str(&format!(".{}", n.patch));
        }
        if n.label == "stable" {
            s.push_str("-stable");
        } else {
            s.push_str(&format!("-{}{}", n.label, n.label_num));
        }
        s
    }

    fn sharp_string(n: &GodotVersionNumber) -> String {
        let mut s = format!("{}.{}.{}", n.major, n.minor, n.patch);
        if n.label != "stable" {
            s.push_str(&format!("-{}.{}", n.label, n.label_num));
        }
        s
    }

    #[test]
    fn parses_release_versions() {
        assert_eq!(
            parse_release_version("4.3-stable"),
            Some(num(4, 3, 0, "stable", -1))
        );
        assert_eq!(
            parse_release_version("4.2.2-stable"),
            Some(num(4, 2, 2, "stable", -1))
        );
        assert_eq!(
            parse_release_version("4.3-rc1"),
            Some(num(4, 3, 0, "rc", 1))
        );
        assert_eq!(
            parse_release_version("4.3-beta2"),
            Some(num(4, 3, 0, "beta", 2))
        );
        assert_eq!(
            parse_release_version("3.5.1-stable"),
            Some(num(3, 5, 1, "stable", -1))
        );
        assert_eq!(parse_release_version("4.3.0-stable"), None);
        assert_eq!(parse_release_version("4.3"), None);
        assert_eq!(parse_release_version("4.3-"), None);
        assert_eq!(parse_release_version("4.3-RC1"), None);
        assert_eq!(parse_release_version("4.3.0-alpha17"), None);
    }

    #[test]
    fn parses_sharp_versions() {
        assert_eq!(
            parse_sharp_version("4.3.0"),
            Some(num(4, 3, 0, "stable", -1))
        );
        assert_eq!(
            parse_sharp_version("4.2.2"),
            Some(num(4, 2, 2, "stable", -1))
        );
        assert_eq!(
            parse_sharp_version("4.3.0-rc.1"),
            Some(num(4, 3, 0, "rc", 1))
        );
        assert_eq!(
            parse_sharp_version("4.3.0-beta.2"),
            Some(num(4, 3, 0, "beta", 2))
        );
        assert_eq!(parse_sharp_version("4.3.0-alpha17"), None);
        assert_eq!(parse_sharp_version("4.3"), None);
    }

    #[test]
    fn parses_installed_tags() {
        assert_eq!(
            parse_installed_tag("4.3-stable"),
            Some(num(4, 3, 0, "stable", -1))
        );
        assert_eq!(
            parse_installed_tag("4.3-stable-mono"),
            Some(num(4, 3, 0, "stable", -1))
        );
        assert_eq!(
            parse_installed_tag("4.2.2-stable-mono"),
            Some(num(4, 2, 2, "stable", -1))
        );
        assert_eq!(
            parse_installed_tag("4.3-rc1-mono"),
            Some(num(4, 3, 0, "rc", 1))
        );
    }

    #[test]
    fn serializers_round_trip() {
        let cases = [
            ("4.3-stable", num(4, 3, 0, "stable", -1)),
            ("4.2.2-stable", num(4, 2, 2, "stable", -1)),
            ("4.3-rc1", num(4, 3, 0, "rc", 1)),
        ];
        for (expected, n) in cases {
            assert_eq!(release_string(&n), expected);
            assert_eq!(parse_version(expected), Some(n.clone()));
        }
        assert_eq!(sharp_string(&num(4, 3, 0, "stable", -1)), "4.3.0");
        assert_eq!(sharp_string(&num(4, 3, 0, "rc", 1)), "4.3.0-rc.1");
        assert_eq!(parse_version("4.3.0-rc.1"), Some(num(4, 3, 0, "rc", 1)));
    }

    fn temp_project() -> PathBuf {
        // Tests run in parallel on Windows, where timestamp granularity can be
        // insufficient to guarantee unique temporary directory names. A UUID
        // makes cleanup by one test unable to race another test's atomic write.
        let dir = std::env::temp_dir().join(format!(
            "jingu_godotenv_test_{}_{}",
            std::process::id(),
            uuid::Uuid::new_v4()
        ));
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    #[test]
    fn parses_godotrc_file() {
        let dir = temp_project();
        let path = dir.join(".godotrc");
        fs::write(&path, "4.3-stable\n").unwrap();
        let v = parse_godotrc(&path).unwrap();
        assert_eq!(v.number, num(4, 3, 0, "stable", -1));
        assert!(v.is_dotnet);

        fs::write(&path, "4.2.2-stable no-dotnet\n").unwrap();
        let v = parse_godotrc(&path).unwrap();
        assert_eq!(v.number, num(4, 2, 2, "stable", -1));
        assert!(!v.is_dotnet);

        fs::write(&path, "4.3-rc1 non-dotnet\n").unwrap();
        let v = parse_godotrc(&path).unwrap();
        assert!(!v.is_dotnet);

        fs::write(&path, "4.3-rc1 not-dotnet\n").unwrap();
        let v = parse_godotrc(&path).unwrap();
        assert!(!v.is_dotnet);

        fs::write(&path, "bogus\n").unwrap();
        assert!(parse_godotrc(&path).is_none());
        fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn parses_global_json_file() {
        let dir = temp_project();
        let path = dir.join("global.json");
        fs::write(
            &path,
            "{\n  \"msbuild-sdks\": {\n    \"Godot.NET.Sdk\": \"4.3.0\"\n  }\n}\n",
        )
        .unwrap();
        let v = parse_global_json(&path).unwrap();
        assert_eq!(v.number, num(4, 3, 0, "stable", -1));
        assert!(v.is_dotnet);

        fs::write(
            &path,
            "{\n  \"msbuild-sdks\": {\n    \"Godot.NET.Sdk\": \"4.3.0-rc.1\"\n  }\n}\n",
        )
        .unwrap();
        let v = parse_global_json(&path).unwrap();
        assert_eq!(v.number, num(4, 3, 0, "rc", 1));

        fs::write(
            &path,
            "{\n  \"sdk\": {\n    \"version\": \"8.0.100\"\n  }\n}\n",
        )
        .unwrap();
        assert!(parse_global_json(&path).is_none());
        fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn parses_csproj_file() {
        let dir = temp_project();
        let path = dir.join("Game.csproj");
        fs::write(
            &path,
            "<Project Sdk=\"Godot.NET.Sdk/4.2.2\">\n  <PropertyGroup/>\n</Project>\n",
        )
        .unwrap();
        let v = parse_csproj(&path).unwrap();
        assert_eq!(v.number, num(4, 2, 2, "stable", -1));
        assert!(v.is_dotnet);

        fs::write(&path, "<Project Sdk=\"Microsoft.NET.Sdk\">\n</Project>\n").unwrap();
        assert!(parse_csproj(&path).is_none());
        fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn detection_precedence_global_beats_godotrc() {
        let dir = temp_project();
        fs::write(
            dir.join("global.json"),
            "{\"msbuild-sdks\":{\"Godot.NET.Sdk\":\"4.3.0\"}}\n",
        )
        .unwrap();
        fs::write(dir.join(".godotrc"), "4.2.2-stable no-dotnet\n").unwrap();
        let v = detect_version(dir.to_str().unwrap()).unwrap();
        assert_eq!(v.number, num(4, 3, 0, "stable", -1));
        assert!(v.is_dotnet);
        fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn detection_precedence_csproj_beats_godotrc() {
        let dir = temp_project();
        fs::write(
            dir.join("Game.csproj"),
            "<Project Sdk=\"Godot.NET.Sdk/4.2.2\"></Project>\n",
        )
        .unwrap();
        fs::write(dir.join(".godotrc"), "4.3-stable no-dotnet\n").unwrap();
        let v = detect_version(dir.to_str().unwrap()).unwrap();
        assert_eq!(v.number, num(4, 2, 2, "stable", -1));
        fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn detection_finds_ancestor_files() {
        let root = temp_project();
        let project = root.join("src");
        fs::create_dir_all(&project).unwrap();
        fs::write(root.join(".godotrc"), "4.3-stable no-dotnet\n").unwrap();
        let v = detect_version(project.to_str().unwrap()).unwrap();
        assert_eq!(v.number, num(4, 3, 0, "stable", -1));
        assert!(!v.is_dotnet);
        fs::remove_dir_all(&root).ok();
    }

    #[test]
    fn detection_none_when_no_files() {
        let dir = temp_project();
        assert!(detect_version(dir.to_str().unwrap()).is_none());
        fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn matching_respects_dotnet_preference() {
        let dir = temp_project();
        fs::write(dir.join(".godotrc"), "4.3-stable no-dotnet\n").unwrap();
        let spec = detect_version(dir.to_str().unwrap()).unwrap();
        let standard = InstalledGodotVersion {
            tag: "4.3-stable".into(),
            version: "4.3".into(),
            runtime_version: Some("4.3.0".into()),
            executable_path: String::new(),
            is_mono: false,
            installed_at: String::new(),
            custom_name: None,
            install_root: None,
            supports_console: true,
            managed_install: None,
            restricted: false,
        };
        let mono = InstalledGodotVersion {
            tag: "4.3-stable-mono".into(),
            version: "4.3".into(),
            runtime_version: Some("4.3.0".into()),
            executable_path: String::new(),
            is_mono: true,
            installed_at: String::new(),
            custom_name: None,
            install_root: None,
            supports_console: true,
            managed_install: None,
            restricted: false,
        };
        assert!(matches_detected(&spec, &standard.tag));
        assert!(matches_detected(&spec, &mono.tag));
        assert_eq!(
            best_match(&spec, &[mono.clone(), standard.clone()])
                .unwrap()
                .tag,
            "4.3-stable"
        );
        assert_eq!(
            best_match(&spec, std::slice::from_ref(&mono)).unwrap().tag,
            "4.3-stable-mono"
        );

        fs::write(dir.join(".godotrc"), "4.3-stable\n").unwrap();
        let dotnet_spec = detect_version(dir.to_str().unwrap()).unwrap();
        assert!(dotnet_spec.is_dotnet);
        assert_eq!(
            best_match(&dotnet_spec, &[standard, mono]).unwrap().tag,
            "4.3-stable-mono"
        );
        fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn project_jingu_feature_detects_and_matches_installed_runtime_version() {
        let dir = temp_project();
        fs::write(
            dir.join("project.jingu"),
            "[application]\nconfig/name=\"Jingu Test\"\nconfig/features=PackedStringArray(\"4.7\", \"GL Compatibility\")\n",
        )
        .unwrap();
        assert_eq!(project_feature_version(dir.to_str().unwrap()), Some((4, 7)));

        let older = InstalledGodotVersion {
            tag: "external-build".into(),
            version: "1.0.0".into(),
            runtime_version: Some("4.7.1".into()),
            executable_path: String::new(),
            is_mono: false,
            installed_at: String::new(),
            custom_name: None,
            install_root: None,
            supports_console: true,
            managed_install: Some(false),
            restricted: false,
        };
        let newer = InstalledGodotVersion {
            tag: "v1.1.0".into(),
            version: "1.1.0".into(),
            runtime_version: Some("4.7.3".into()),
            ..older.clone()
        };
        assert!(project_feature_matches(dir.to_str().unwrap(), &older));
        assert_eq!(
            best_project_feature_match(dir.to_str().unwrap(), &[older, newer])
                .unwrap()
                .version,
            "1.1.0"
        );
        fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn jingu_pin_is_authoritative_and_preserves_compatibility_files() {
        let dir = temp_project();
        fs::write(dir.join(".godotrc"), "4.7-stable no-dotnet\n").unwrap();
        fs::write(
            dir.join("global.json"),
            "{\n  \"msbuild-sdks\": {\n    \"Godot.NET.Sdk\": \"4.7.1\"\n  }\n}\n",
        )
        .unwrap();
        let godotrc_before = fs::read(dir.join(".godotrc")).unwrap();
        let global_before = fs::read(dir.join("global.json")).unwrap();

        pin_version(dir.to_str().unwrap(), "v1.0.0").unwrap();

        assert_eq!(
            fs::read_to_string(dir.join(".jingu-version")).unwrap(),
            "v1.0.0\n"
        );
        assert_eq!(fs::read(dir.join(".godotrc")).unwrap(), godotrc_before);
        assert_eq!(fs::read(dir.join("global.json")).unwrap(), global_before);
        fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn jingu_pin_accepts_external_binding_keys_without_creating_compatibility_files() {
        let dir = temp_project();
        pin_version(dir.to_str().unwrap(), "local-jingu-build").unwrap();
        assert_eq!(
            fs::read_to_string(dir.join(".jingu-version")).unwrap(),
            "local-jingu-build\n"
        );
        assert!(!dir.join(".godotrc").exists());
        assert!(!dir.join("global.json").exists());
        fs::remove_dir_all(&dir).ok();
    }
}
