/**************************************************************************/
/*  hub_releases.rs                                                     */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use serde::Serialize;
use std::sync::{Mutex, OnceLock};
use std::time::{Duration, Instant};
use tokio::sync::Mutex as AsyncMutex;

fn release_http_client() -> Result<reqwest::Client, String> {
    static CLIENT: OnceLock<reqwest::Client> = OnceLock::new();
    if let Some(client) = CLIENT.get() {
        return Ok(client.clone());
    }
    let client = reqwest::Client::builder()
        .user_agent(format!("JinguHub/{}", crate::jingu::PRODUCT_VERSION))
        .connect_timeout(Duration::from_secs(4))
        .timeout(Duration::from_secs(15))
        .pool_idle_timeout(Duration::from_secs(300))
        .pool_max_idle_per_host(8)
        .tcp_keepalive(Duration::from_secs(30))
        .build()
        .map_err(|error| error.to_string())?;
    let _ = CLIENT.set(client.clone());
    Ok(client)
}

#[derive(Debug, Clone, Serialize)]
pub struct HubRuntimeInfo {
    pub version: String,
    pub channel: &'static str,
    pub portable: bool,
}

#[derive(Debug, Clone, Serialize)]
pub struct HubReleaseCheck {
    pub current_version: String,
    pub latest_version: Option<String>,
    pub update_available: bool,
    pub release_url: Option<String>,
    /// Deliberately generic for private releases: never serialize a private repository name.
    pub source: String,
    pub test_channel: bool,
    pub restricted: bool,
    pub uses_user_github_session: bool,
}

#[derive(Debug, Clone)]
struct ReleaseCandidate {
    version: String,
    tuple: (u64, u64, u64),
    release_url: String,
    restricted: bool,
}

#[derive(Debug, Clone)]
struct PublicReleaseCacheEntry {
    fetched_at: Instant,
    candidate: Option<ReleaseCandidate>,
}

fn public_release_cache() -> &'static Mutex<Option<PublicReleaseCacheEntry>> {
    static CACHE: OnceLock<Mutex<Option<PublicReleaseCacheEntry>>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(None))
}

fn public_release_refresh_gate() -> &'static AsyncMutex<()> {
    static GATE: OnceLock<AsyncMutex<()>> = OnceLock::new();
    GATE.get_or_init(|| AsyncMutex::new(()))
}

async fn cached_public_candidate(
    client: &reqwest::Client,
) -> Result<Option<ReleaseCandidate>, String> {
    const TTL: Duration = Duration::from_secs(15 * 60);
    let read_cache = || {
        public_release_cache()
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .clone()
    };
    if let Some(entry) = read_cache() {
        if entry.fetched_at.elapsed() <= TTL {
            return Ok(entry.candidate);
        }
    }
    let _refresh = public_release_refresh_gate().lock().await;
    if let Some(entry) = read_cache() {
        if entry.fetched_at.elapsed() <= TTL {
            return Ok(entry.candidate);
        }
    }
    let stale = read_cache().and_then(|entry| entry.candidate);
    let token = if crate::github::cached_user().is_some() {
        crate::github::access_token().await.ok()
    } else {
        None
    };
    match latest_stable_candidate(
        client,
        crate::jingu::PUBLIC_HUB_RELEASES_REPOSITORY,
        token.as_deref(),
        false,
    )
    .await
    {
        Ok(candidate) => {
            *public_release_cache()
                .lock()
                .unwrap_or_else(|error| error.into_inner()) = Some(PublicReleaseCacheEntry {
                fetched_at: Instant::now(),
                candidate: candidate.clone(),
            });
            Ok(candidate)
        }
        Err(error) => {
            if stale.is_some() {
                crate::startup::log(format!(
                    "Hub public release check failed; using stale in-memory candidate: {error}"
                ));
                Ok(stale)
            } else {
                Err(error)
            }
        }
    }
}

#[tauri::command]
pub fn hub_runtime_info(app: tauri::AppHandle) -> HubRuntimeInfo {
    HubRuntimeInfo {
        version: app.package_info().version.to_string(),
        channel: "unified",
        portable: crate::paths::portable_root().is_some(),
    }
}

fn semver_component(value: &str) -> Option<u64> {
    if value.is_empty() || (value.len() > 1 && value.starts_with('0')) {
        return None;
    }
    value.parse().ok()
}

fn stable_semver(value: &str) -> Option<(u64, u64, u64)> {
    let trimmed = value.trim();
    if trimmed != value {
        return None;
    }
    let cleaned = trimmed.strip_prefix('v').unwrap_or(trimmed);
    if cleaned.is_empty() || cleaned.contains('-') || cleaned.contains('+') {
        return None;
    }
    let mut parts = cleaned.split('.');
    let major = semver_component(parts.next()?)?;
    let minor = semver_component(parts.next()?)?;
    let patch = semver_component(parts.next()?)?;
    if parts.next().is_some() {
        return None;
    }
    Some((major, minor, patch))
}

fn normalized_version(value: &str) -> Option<String> {
    stable_semver(value)?;
    let trimmed = value.trim();
    Some(trimmed.strip_prefix('v').unwrap_or(trimmed).to_string())
}

fn official_hub_release_url(value: &str, repository: &str, tag: &str) -> bool {
    let Ok(parsed) = reqwest::Url::parse(value) else {
        return false;
    };
    if parsed.scheme() != "https" || parsed.host_str() != Some("github.com") {
        return false;
    }
    let expected = format!(
        "/{}/{}/releases/tag/{}",
        crate::jingu::GITHUB_OWNER,
        repository,
        tag
    );
    parsed.path() == expected && parsed.query().is_none() && parsed.fragment().is_none()
}

fn empty_result(current_version: String) -> HubReleaseCheck {
    HubReleaseCheck {
        current_version,
        latest_version: None,
        update_available: false,
        release_url: None,
        source: "public".into(),
        test_channel: false,
        restricted: false,
        uses_user_github_session: false,
    }
}

async fn latest_stable_candidate(
    client: &reqwest::Client,
    repository: &str,
    token: Option<&str>,
    restricted: bool,
) -> Result<Option<ReleaseCandidate>, String> {
    let url = format!(
        "https://api.github.com/repos/{}/{repository}/releases?per_page=100&page=1",
        crate::jingu::GITHUB_OWNER
    );
    let response = if restricted {
        let mut request = crate::jingu::release_get(client, &url, "application/vnd.github+json");
        if let Some(token) = token {
            request = request.bearer_auth(token);
        }
        crate::github::send_with_retry(request, "a consulta de releases privadas do Jingu Hub")
            .await?
    } else {
        crate::github::send_public_github_get_with_optional_auth(
            client,
            &url,
            "application/vnd.github+json",
            token,
            "a consulta de releases públicas do Jingu Hub",
        )
        .await?
    };

    // Private availability is an optional capability. 404/403 must not reveal that
    // a hidden resource exists, and must never break the public channel.
    if restricted
        && matches!(
            response.status(),
            reqwest::StatusCode::NOT_FOUND | reqwest::StatusCode::FORBIDDEN
        )
    {
        return Ok(None);
    }
    if response.status() == reqwest::StatusCode::NOT_FOUND
        || (!restricted && response.status() == reqwest::StatusCode::CONFLICT)
    {
        // GitHub can return 409 for a repository with no Git history yet. A public
        // distribution repository with zero releases is valid and means "nothing published".
        return Ok(None);
    }
    if !response.status().is_success() {
        let status = response.status();
        let remaining = response
            .headers()
            .get("x-ratelimit-remaining")
            .and_then(|value| value.to_str().ok())
            .unwrap_or("");
        return Err(match status.as_u16() {
            403 if remaining == "0" => "Limite de consultas do GitHub atingido. O Hub pausou novas consultas automaticamente; aguarde o intervalo indicado pelo GitHub.".into(),
            429 => "O GitHub pediu uma pausa temporária nas consultas. O Hub respeitará o intervalo indicado antes de consultar novamente.".into(),
            403 => "O GitHub recusou a consulta de versões. Se sua conta estiver vinculada, confira as permissões da GitHub App.".into(),
            _ => format!("GitHub Releases respondeu HTTP {status}."),
        });
    }

    let rows: Vec<serde_json::Value> = response
        .json()
        .await
        .map_err(|error| format!("Resposta inválida do GitHub Releases: {error}"))?;
    let mut newest: Option<ReleaseCandidate> = None;
    for release in rows {
        if release["draft"].as_bool() == Some(true) || release["prerelease"].as_bool() == Some(true)
        {
            continue;
        }
        let Some(tag) = release["tag_name"].as_str() else {
            continue;
        };
        let Some(tuple) = stable_semver(tag) else {
            continue;
        };
        let Some(version) = normalized_version(tag) else {
            continue;
        };
        let Some(release_url) = release["html_url"].as_str() else {
            continue;
        };
        if !official_hub_release_url(release_url, repository, tag) {
            continue;
        }
        let candidate = ReleaseCandidate {
            version,
            tuple,
            release_url: release_url.to_string(),
            restricted,
        };
        if newest
            .as_ref()
            .is_none_or(|current| candidate.tuple > current.tuple)
        {
            newest = Some(candidate);
        }
    }
    Ok(newest)
}

#[tauri::command]
pub async fn check_hub_release(app: tauri::AppHandle) -> Result<HubReleaseCheck, String> {
    let current_version = app.package_info().version.to_string();
    let current = stable_semver(&current_version).ok_or_else(|| {
        format!("Versão instalada do Jingu Hub não é SemVer estável: {current_version}")
    })?;
    let client = release_http_client()?;

    // Public release metadata is cached and coalesced. When the user is signed in,
    // the request prefers that credential for GitHub's larger authenticated API
    // budget; a token-refresh problem still falls back to an anonymous request.
    let public = cached_public_candidate(&client).await?;

    let private = match crate::github::authorized_private_repository(
        crate::github::PrivateResource::HubReleases,
    )
    .await
    {
        Ok(Some(access)) => {
            latest_stable_candidate(&client, &access.repository, Some(&access.token), true)
                .await
                .unwrap_or(None)
        }
        Ok(None) | Err(_) => None,
    };

    let selected = match (public, private) {
        (Some(public), Some(private)) if private.tuple > public.tuple => Some(private),
        (Some(public), _) => Some(public),
        (None, Some(private)) => Some(private),
        (None, None) => None,
    };
    let Some(selected) = selected else {
        return Ok(empty_result(current_version));
    };

    Ok(HubReleaseCheck {
        current_version,
        latest_version: Some(selected.version),
        update_available: selected.tuple > current,
        release_url: Some(selected.release_url),
        source: if selected.restricted {
            "authorized-private-test".into()
        } else {
            "public".into()
        },
        test_channel: selected.restricted,
        restricted: selected.restricted,
        uses_user_github_session: selected.restricted,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn stable_semver_is_strict() {
        assert_eq!(stable_semver("v1.2.3"), Some((1, 2, 3)));
        assert_eq!(stable_semver("1.2.3"), Some((1, 2, 3)));
        assert_eq!(stable_semver("v1.2.3-beta.1"), None);
        assert_eq!(stable_semver("1.2"), None);
        assert_eq!(stable_semver("01.2.3"), None);
    }

    #[test]
    fn stable_semver_rejects_malformed_and_boundary_fuzz_corpus() {
        let invalid = [
            "",
            "v",
            "1",
            "1.2",
            "1.2.3.4",
            ".1.2",
            "1..2",
            "1.2.",
            "+1.2.3",
            "-1.2.3",
            "1.2.3+meta",
            "1.2.3-rc1",
            " 1.2.3",
            "1.2.3 ",
            "v01.2.3",
            "1.02.3",
            "1.2.03",
            "１.2.3",
            "1.２.3",
            "1.2.３",
            "18446744073709551616.0.0",
        ];
        for value in invalid {
            assert_eq!(
                stable_semver(value),
                None,
                "accepted invalid SemVer {value:?}"
            );
        }

        assert_eq!(
            stable_semver("18446744073709551615.0.0"),
            Some((u64::MAX, 0, 0))
        );
        for byte in 0u8..=127 {
            let value = format!("1.2.3{}", char::from(byte));
            if byte.is_ascii_digit() {
                assert_eq!(
                    stable_semver(&value),
                    Some((1, 2, 30 + u64::from(byte - b'0')))
                );
            } else {
                assert_eq!(stable_semver(&value), None, "accepted suffix byte {byte}");
            }
        }
    }

    #[test]
    fn release_url_is_pinned_to_explicit_repository() {
        assert!(official_hub_release_url(
            "https://github.com/JinguEngine/JinguHub-Releases/releases/tag/v1.0.1",
            crate::jingu::PUBLIC_HUB_RELEASES_REPOSITORY,
            "v1.0.1"
        ));
        assert!(!official_hub_release_url(
            "https://github.com/other/JinguHub-Releases/releases/tag/v1.0.1",
            crate::jingu::PUBLIC_HUB_RELEASES_REPOSITORY,
            "v1.0.1"
        ));
    }
}
