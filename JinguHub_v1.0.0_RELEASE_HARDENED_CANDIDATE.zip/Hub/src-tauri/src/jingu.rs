/**************************************************************************/
/*  jingu.rs                                                            */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
pub const PRODUCT_VERSION: &str = env!("CARGO_PKG_VERSION");

pub const GITHUB_OWNER: &str = "JinguEngine";
pub const GITHUB_APP_SLUG: &str = "jingu-engine";
pub const GITHUB_APP_CLIENT_ID: &str = "Iv23liCwoqoZoTf9kKmD";
pub const GITHUB_API_VERSION: &str = "2026-03-10";

pub const PUBLIC_ENGINE_RELEASES_REPOSITORY: &str = "JinguEngine-Releases";
pub const PUBLIC_HUB_RELEASES_REPOSITORY: &str = "JinguHub-Releases";
pub const PUBLIC_FREELANCERS_REPOSITORY: &str = "JinguHub-Freelancers";

pub fn release_get(
    client: &reqwest::Client,
    url: &str,
    accept: &'static str,
) -> reqwest::RequestBuilder {
    client
        .get(url)
        .header("Accept", accept)
        .header("X-GitHub-Api-Version", GITHUB_API_VERSION)
}

pub const GITHUB_INSTALL_URL: &str = "https://github.com/apps/jingu-engine/installations/new";
pub const GITHUB_DEVICE_URL: &str = "https://github.com/login/device";
