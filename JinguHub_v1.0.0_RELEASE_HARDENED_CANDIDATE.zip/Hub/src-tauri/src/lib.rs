/**************************************************************************/
/*  lib.rs                                                              */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
#![allow(linker_messages)]
mod community;
mod continuity;
mod credentials;
mod error;
mod freelancers;
mod git;
mod git_helpers;
mod github;
mod godot_versions;
mod godotenv;
mod hub_releases;
mod jingu;
mod membership;
mod migration;
mod models;
mod paths;
mod payment_browser;
mod persist;
mod platform;
mod projects;
mod release_profile;
mod settings;
pub mod startup;
mod store_browser;
mod terminal;
mod tray;

use serde::Serialize;
use tauri::{Manager, WindowEvent};

#[derive(Debug, Clone, Serialize)]
struct HubBuildProfile {
    version: &'static str,
    channel: &'static str,
    flavor: &'static str,
    product_name: &'static str,
    adaptive_private_access: bool,
}

#[tauri::command]
fn hub_build_profile() -> HubBuildProfile {
    HubBuildProfile {
        version: crate::release_profile::VERSION,
        channel: crate::release_profile::CHANNEL,
        flavor: "unified",
        product_name: "Jingu Hub",
        adaptive_private_access: true,
    }
}

#[tauri::command]
fn open_https_url(url: String) -> Result<(), String> {
    let parsed =
        reqwest::Url::parse(url.trim()).map_err(|_| "Link externo inválido.".to_string())?;
    if parsed.scheme() != "https"
        || parsed.host_str().is_none()
        || parsed.username() != ""
        || parsed.password().is_some()
    {
        return Err("O Jingu Hub só abre links HTTPS sem credenciais embutidas.".into());
    }
    tauri_plugin_opener::open_url(parsed.as_str(), None::<&str>)
        .map_err(|error| format!("Não foi possível abrir o link externo: {error}"))
}

#[tauri::command]
async fn pick_folder(app: tauri::AppHandle) -> Option<String> {
    use tauri_plugin_dialog::DialogExt;
    app.dialog()
        .file()
        .blocking_pick_folder()
        .map(|path| path.to_string())
}

#[tauri::command]
async fn pick_engine_archive_file(app: tauri::AppHandle) -> Option<String> {
    use tauri_plugin_dialog::DialogExt;
    let (tx, rx) = std::sync::mpsc::channel();
    app.dialog()
        .file()
        .add_filter("Jingu Engine packages", &["zip"])
        .pick_file(move |file| {
            let _ = tx.send(file);
        });
    rx.recv().ok().flatten().map(|p| p.to_string())
}

#[tauri::command]
async fn pick_engine_executable_file(app: tauri::AppHandle) -> Option<String> {
    use tauri_plugin_dialog::DialogExt;
    let (tx, rx) = std::sync::mpsc::channel();
    let builder = app.dialog().file();
    #[cfg(target_os = "windows")]
    let builder = builder.add_filter("Executables", &["exe"]);
    builder.pick_file(move |file| {
        let _ = tx.send(file);
    });
    rx.recv().ok().flatten().map(|p| p.to_string())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    platform::prepare_process_environment();
    let app = tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app, _args, _cwd| {
            startup::log("Second-instance activation received");
            tray::show_main_window(app);
        }))
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .plugin(
            tauri_plugin_window_state::Builder::default()
                // Never restore SIZE: a stale/minimal persisted geometry was able
                // to override the intended maximized launch. MAXIMIZED is the only
                // persisted state we need; setup below also reapplies it explicitly.
                .with_state_flags(tauri_plugin_window_state::StateFlags::MAXIMIZED)
                .build(),
        )
        .setup(|app| {
            startup::log("Tauri setup started");
            startup::log(format!(
                "Release channel: {}/{}; authenticated private access is capability-gated",
                crate::jingu::GITHUB_OWNER,
                crate::jingu::PUBLIC_HUB_RELEASES_REPOSITORY
            ));

            let startup_settings = settings::read_settings(app.handle());
            if let Err(error) =
                github::configure_session_persistence(startup_settings.remember_github_login)
            {
                startup::log(format!(
                    "WARNING: GitHub remember-login preference could not be initialized: {error}"
                ));
            }

            // Privacy migration: this release no longer collects checkout name,
            // email or phone. Remove any value saved by an older build from the
            // native credential store; checkout identity is now handled directly
            // by InfinitePay.
            let _ = credentials::erase("payment-checkout-customer-v1");

            // Reliability first: the main window must become visible even if an
            // optional startup service (tray, migrations, etc.) fails later.
            if let Some(window) = app.get_webview_window("main") {
                // Reassert a sane visible state after window-state restoration. The
                // platform maximize operation uses the current monitor work area, so
                // this also behaves correctly across different resolutions/DPI.
                let _ = window.unminimize();
                let _ = window.maximize();
                let _ = window.show();
                let _ = window.set_focus();
                startup::log("Main window made visible and maximized");
            } else {
                startup::log("WARNING: main webview window was not found during setup");
            }

            startup::run_nonfatal_step("engine registry migration", || {
                godot_versions::migrate_registry_to_global(app.handle());
            });
            startup::run_nonfatal_step("legacy workspace storage migration", || {
                migration::migrate_legacy_workspace_storage(app.handle());
            });
            startup::run_nonfatal_step("legacy C++ Hub migration", || {
                migration::migrate_legacy_cpp_hub(app.handle());
            });

            #[cfg(not(target_os = "macos"))]
            {
                if let Some(window) = app.get_webview_window("main") {
                    let _ = window.set_decorations(startup_settings.use_os_decorations);
                }
            }

            app.manage(tray::TrayState(std::sync::Mutex::new(None)));
            app.manage(projects::ActiveProcesses(std::sync::Mutex::new(
                std::collections::HashMap::new(),
            )));

            // Tray integration is optional. A tray/menu failure must never make
            // the launcher itself fail to start.
            match tray::setup_tray(app.handle()) {
                Ok(()) => startup::log("System tray initialized"),
                Err(error) => startup::log(format!("WARNING: system tray disabled: {error}")),
            }
            tray::show_main_window(app.handle());

            // Warm read-heavy public data as soon as the shell is visible. This
            // never blocks startup: the cache is filled in the background so the
            // first visit to Comunidades/Freelancers is normally instant.
            community::prewarm(app.handle().clone());
            freelancers::prewarm(app.handle().clone());
            tauri::async_runtime::spawn(async {
                let _ = membership::display_profile(false).await;
            });

            startup::log("Tauri setup completed");

            Ok(())
        })
        .on_window_event(|window, event| {
            if let WindowEvent::CloseRequested { api, .. } = event {
                if window.label() != "main" {
                    return;
                }

                #[cfg(target_os = "macos")]
                let keep_alive = true;
                #[cfg(not(target_os = "macos"))]
                let keep_alive = settings::read_settings(window.app_handle()).minimize_to_tray
                    && tray::is_available(window.app_handle());

                if keep_alive {
                    api.prevent_close();
                    let _ = window.hide();
                }
            }
        })
        .invoke_handler(tauri::generate_handler![
            hub_build_profile,
            godot_versions::fetch_available_godot_versions,
            godot_versions::check_latest_engine_release,
            godot_versions::download_godot_version,
            godot_versions::list_downloads,
            godot_versions::pause_download,
            godot_versions::resume_download,
            godot_versions::cancel_download,
            godot_versions::list_installed_godot_versions,
            godot_versions::delete_godot_version,
            godot_versions::open_godot_version,
            godot_versions::import_version_zip,
            godot_versions::import_version_path,
            open_https_url,
            community::community_catalog,
            community::community_submit_request,
            community::community_my_requests,
            membership::membership_profile,
            membership::membership_credits_opt_in,
            membership::payment_config,
            membership::payment_price_preview,
            membership::payment_checkout_start,
            membership::supporters_list,
            freelancers::freelancers_entitlements,
            freelancers::freelancers_account_status,
            freelancers::freelancers_fetch,
            freelancers::freelancers_create,
            freelancers::freelancers_close,
            freelancers::freelancers_reaction_state,
            freelancers::freelancers_reaction_states,
            freelancers::freelancers_toggle_like,
            freelancers::freelancers_report,
            freelancers::freelancers_open_contact,
            github::github_session,
            github::github_begin_device_flow,
            github::github_poll_device_flow,
            github::github_sign_out,
            github::github_installation_status,
            github::github_private_access,
            github::github_create_repository,
            github::github_list_accessible_repositories,
            github::github_remote_status,
            hub_releases::hub_runtime_info,
            hub_releases::check_hub_release,
            credentials::credential_store_status,
            projects::list_projects,
            projects::create_project,
            projects::import_project,
            projects::remove_project,
            projects::update_project,
            projects::open_project,
            projects::open_project_folder,
            projects::get_project_icon,
            projects::set_project_engine_version,
            projects::pick_file,
            pick_engine_archive_file,
            pick_engine_executable_file,
            settings::get_settings,
            settings::update_settings,
            paths::get_directory_layout,
            store_browser::store_browser_show,
            store_browser::store_browser_set_bounds,
            store_browser::store_browser_hide,
            store_browser::store_browser_home,
            store_browser::store_browser_back,
            store_browser::store_browser_reload,
            payment_browser::payment_browser_show,
            payment_browser::payment_browser_set_bounds,
            payment_browser::payment_browser_hide,
            payment_browser::payment_browser_reload,
            git::clone_repo,
            git::get_git_status,
            git::git_pull,
            git::git_fetch,
            git::git_push,
            git::git_remote_url,
            git::git_list_branches,
            git::git_switch_branch,
            git::git_create_branch,
            git::git_changed_files,
            git::git_init,
            git::git_stage_all,
            git::git_unstage_all,
            git::git_stage_file,
            git::git_unstage_file,
            git::git_commit,
            git::git_set_remote,
            git::git_remove_remote,
            pick_folder,
        ])
        .build(tauri::generate_context!());

    let app = match app {
        Ok(app) => app,
        Err(error) => {
            startup::fatal(format!(
                "Não foi possível inicializar o runtime Tauri: {error}"
            ));
            return;
        }
    };

    startup::log("Tauri application built; entering event loop");
    app.run(|_app, _event| {
        #[cfg(target_os = "macos")]
        if let tauri::RunEvent::Reopen { .. } = _event {
            tray::show_main_window(_app);
        }
    });
    startup::log("Tauri event loop exited");
}
