/**************************************************************************/
/*  membership.rs                                                       */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use reqwest::Method;
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};
use std::time::{Duration, Instant};
use tauri::{AppHandle, Emitter};

const FREE_ACTIVE_POST_LIMIT: usize = 1;
const FREE_SUMMARY_MAX: usize = 180;
const FREE_DESCRIPTION_MAX: usize = 3_000;
const DISPLAY_CACHE_TTL: Duration = Duration::from_secs(30);
const PUBLIC_BATCH_CACHE_TTL: Duration = Duration::from_secs(30);
const PUBLIC_BATCH_CACHE_MAX: usize = 256;
const PAYMENT_CONFIG_CACHE_TTL: Duration = Duration::from_secs(30);
const PERSISTED_DISPLAY_CACHE_SCHEMA: u32 = 1;
const PERSISTED_DISPLAY_CACHE_MAX_AGE_SECS: i64 = 30 * 24 * 60 * 60;
const PERSISTED_DISPLAY_CACHE_FILE: &str = "membership-display-cache.json";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SupporterPublicEntry {
    pub github_login: String,
    pub avatar_url: String,
    pub tier: String,
    pub badge_label: Option<String>,
    #[serde(default)]
    pub months: u16,
    #[serde(default)]
    pub active: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct SupportersPayload {
    #[serde(default)]
    schema: u32,
    #[serde(default)]
    users: Vec<SupporterPublicEntry>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MembershipProfile {
    pub tier: String,
    pub label: String,
    pub badge_label: Option<String>,
    pub active_post_limit: usize,
    pub summary_max_chars: usize,
    pub description_max_chars: usize,
    pub boost_credits_per_cycle: u32,
    pub boost_duration_days: u32,
    pub boosts_remaining: u32,
    pub sponsored_available: bool,
    pub credits_eligible: bool,
    pub credits_rank: u32,
    #[serde(default)]
    pub status: Option<String>,
    #[serde(default)]
    pub cycle_started_at: Option<String>,
    #[serde(default)]
    pub cycle_ends_at: Option<String>,
    #[serde(default)]
    pub lifetime: bool,
    #[serde(default)]
    pub credits_opt_in: bool,
    pub source: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PaymentConfig {
    pub enabled: bool,
    pub provider: String,
    #[serde(default)]
    pub market: String,
    #[serde(default)]
    pub currency: String,
    #[serde(default)]
    pub environment: String,
    pub duration_days: u32,
    pub manual_renewal: bool,
    #[serde(default)]
    pub prices_minor: HashMap<String, u64>,
    #[serde(default)]
    pub transition_value_prices_minor: HashMap<String, u64>,
    #[serde(default)]
    pub donation: Option<PaymentDonationConfig>,
    #[serde(default)]
    pub support_max_minor: Option<u64>,
    #[serde(default)]
    pub pricing_version: u32,
    #[serde(default)]
    pub allocation_mode: String,
    #[serde(default)]
    pub contribution: Option<PaymentContributionConfig>,
    #[serde(default)]
    pub tier_transition: Option<PaymentTierTransitionConfig>,
    #[serde(default)]
    pub currencies: Vec<PaymentCurrencyOption>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PaymentCurrencyOption {
    pub code: String,
    pub market: String,
    pub provider: Option<String>,
    pub available: bool,
    pub checkout_enabled: bool,
    pub label: String,
    #[serde(default)]
    pub prices_minor: HashMap<String, u64>,
    #[serde(default)]
    pub donation_enabled: bool,
    #[serde(default)]
    pub donation_min_minor: u64,
    #[serde(default)]
    pub amount_mode: String,
    #[serde(default)]
    pub adaptive_currency: bool,
    #[serde(default)]
    pub canonical_currency: String,
    #[serde(default)]
    pub price_source: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PaymentDonationConfig {
    pub enabled: bool,
    pub min_minor: u64,
    pub max_minor: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PaymentContributionConfig {
    pub min_minor: u64,
    pub max_minor: Option<u64>,
    pub plan_threshold_minor: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PaymentTierTransitionConfig {
    pub mode: String,
    pub rounding: String,
    pub requires_new_purchase: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PaymentPricePreview {
    pub schema: u32,
    pub provider: String,
    pub market: String,
    pub tier: String,
    pub plan_units: u64,
    pub billing_currency: String,
    pub billing_amount_minor: u64,
    pub canonical_currency: String,
    pub canonical_amount_minor: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PaymentCheckoutResult {
    pub checkout_url: String,
    pub intent_id: String,
    pub intent_expires_at: String,
    pub provider: String,
    pub market: String,
    pub currency: String,
    #[serde(default)]
    pub billing_currency: String,
    #[serde(default)]
    pub billing_amount_minor: u64,
    #[serde(default)]
    pub canonical_currency: String,
    #[serde(default)]
    pub canonical_amount_minor: u64,
    pub purpose: String,
    pub tier: String,
    pub amount_minor: u64,
    pub base_amount_minor: u64,
    pub support_amount_minor: u64,
    pub pricing_version: u32,
    pub plan_units: u64,
    pub unit_price_minor: u64,
    pub transition_kind: String,
    pub carryover_ms: u64,
    pub projected_expires_at: Option<String>,
}

#[derive(Debug, Clone)]
struct DisplayCacheEntry {
    github_user_id: u64,
    fetched_at: Instant,
    profile: MembershipProfile,
}

#[derive(Debug, Clone)]
struct PublicProfileCacheEntry {
    fetched_at: Instant,
    profile: MembershipProfile,
}

#[derive(Debug, Clone, Deserialize)]
struct PublicMembershipBatchPayload {
    #[serde(default)]
    profiles: HashMap<String, MembershipProfile>,
}

#[derive(Debug, Clone, Deserialize)]
struct StartupBootstrapPayload {
    membership: MembershipProfile,
    payments: PaymentConfig,
}

#[derive(Debug, Clone)]
struct PaymentConfigCacheEntry {
    fetched_at: Instant,
    config: PaymentConfig,
}

fn payment_config_cache() -> &'static Mutex<Option<PaymentConfigCacheEntry>> {
    static CACHE: OnceLock<Mutex<Option<PaymentConfigCacheEntry>>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(None))
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct PersistedDisplayCache {
    schema: u32,
    github_user_id: u64,
    saved_at_unix: i64,
    profile: MembershipProfile,
}

impl Default for PersistedDisplayCache {
    fn default() -> Self {
        Self {
            schema: 0,
            github_user_id: 0,
            saved_at_unix: 0,
            profile: free_profile(),
        }
    }
}

fn persisted_display_cache_path(app: &AppHandle) -> std::path::PathBuf {
    crate::paths::app_data_dir(app).join(PERSISTED_DISPLAY_CACHE_FILE)
}

fn load_persisted_display_cache(app: &AppHandle, github_user_id: u64) -> Option<MembershipProfile> {
    let row: PersistedDisplayCache = crate::persist::read_json(&persisted_display_cache_path(app));
    let now = chrono::Utc::now().timestamp();
    if row.schema != PERSISTED_DISPLAY_CACHE_SCHEMA
        || row.github_user_id != github_user_id
        || row.saved_at_unix <= 0
        || now.saturating_sub(row.saved_at_unix) > PERSISTED_DISPLAY_CACHE_MAX_AGE_SECS
    {
        return None;
    }
    Some(validated(row.profile))
}

fn persist_display_cache(app: &AppHandle, github_user_id: u64, profile: &MembershipProfile) {
    let row = PersistedDisplayCache {
        schema: PERSISTED_DISPLAY_CACHE_SCHEMA,
        github_user_id,
        saved_at_unix: chrono::Utc::now().timestamp(),
        profile: profile.clone(),
    };
    if let Err(error) = crate::persist::write_json(&persisted_display_cache_path(app), &row) {
        crate::startup::log(format!(
            "Membership display cache persistence failed: {error}"
        ));
    }
}

async fn fetch_public_display_profile(
    github_user_id: u64,
    fresh: bool,
) -> Result<MembershipProfile, String> {
    let bootstrap_path = if fresh {
        format!("/v1/bootstrap?github_user_id={github_user_id}&fresh=1")
    } else {
        format!("/v1/bootstrap?github_user_id={github_user_id}")
    };
    if let Ok(value) =
        crate::continuity::request_json(Method::GET, &bootstrap_path, None, None).await
    {
        if let Ok(payload) = serde_json::from_value::<StartupBootstrapPayload>(value) {
            *payment_config_cache()
                .lock()
                .unwrap_or_else(|error| error.into_inner()) = Some(PaymentConfigCacheEntry {
                fetched_at: Instant::now(),
                config: payload.payments,
            });
            return Ok(validated(payload.membership));
        }
    }
    // Backward-compatible fallback lets desktop and Worker be rolled out in either
    // order without making the account badge disappear during deployment.
    let path = if fresh {
        format!("/v1/membership/public-id/{github_user_id}?fresh=1")
    } else {
        format!("/v1/membership/public-id/{github_user_id}")
    };
    let value = crate::continuity::request_json(Method::GET, &path, None, None).await?;
    let profile = serde_json::from_value::<MembershipProfile>(value)
        .map_err(|error| format!("Public membership response invalid: {error}"))?;
    Ok(validated(profile))
}

fn display_cache() -> &'static Mutex<Option<DisplayCacheEntry>> {
    static CACHE: OnceLock<Mutex<Option<DisplayCacheEntry>>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(None))
}

fn public_profile_cache() -> &'static Mutex<HashMap<u64, PublicProfileCacheEntry>> {
    static CACHE: OnceLock<Mutex<HashMap<u64, PublicProfileCacheEntry>>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(HashMap::new()))
}

pub(crate) fn clear_display_cache() {
    let mut guard = display_cache()
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    *guard = None;
}

pub fn free_profile() -> MembershipProfile {
    MembershipProfile {
        tier: "free".into(),
        label: "Gratuito".into(),
        badge_label: None,
        active_post_limit: FREE_ACTIVE_POST_LIMIT,
        summary_max_chars: FREE_SUMMARY_MAX,
        description_max_chars: FREE_DESCRIPTION_MAX,
        boost_credits_per_cycle: 0,
        boost_duration_days: 0,
        boosts_remaining: 0,
        sponsored_available: false,
        credits_eligible: false,
        credits_rank: 0,
        status: Some("inactive".into()),
        cycle_started_at: None,
        cycle_ends_at: None,
        lifetime: false,
        credits_opt_in: false,
        source: "local-free-fallback".into(),
    }
}

fn validated(mut profile: MembershipProfile) -> MembershipProfile {
    let allowed = ["free", "bronze", "silver", "gold"];
    if !allowed.contains(&profile.tier.as_str())
        || !(1..=4).contains(&profile.active_post_limit)
        || !(FREE_SUMMARY_MAX..=320).contains(&profile.summary_max_chars)
        || !(FREE_DESCRIPTION_MAX..=6_500).contains(&profile.description_max_chars)
        || profile.boost_credits_per_cycle > 8
        || profile.boost_duration_days > 31
        || profile.boosts_remaining > 8
        || profile.credits_rank > 3
    {
        return free_profile();
    }
    if profile.tier == "free" {
        return free_profile();
    }
    profile.source = "jingu-membership-service".into();
    profile
}

/// Security-authoritative profile used for paid entitlement enforcement.
/// The Continuity service verifies the GitHub bearer token and resolves the
/// account by GitHub numeric ID, so a username rename cannot move benefits.
pub async fn current_profile() -> MembershipProfile {
    if crate::github::cached_user().is_none() {
        return free_profile();
    }
    let token = match crate::github::access_token().await {
        Ok(value) => value,
        Err(_) => return free_profile(),
    };
    match crate::continuity::request_json(Method::GET, "/v1/membership/me", Some(&token), None)
        .await
    {
        Ok(value) => match serde_json::from_value::<MembershipProfile>(value) {
            Ok(profile) => validated(profile),
            Err(error) => {
                crate::startup::log(format!("Membership response ignored: {error}"));
                free_profile()
            }
        },
        Err(error) => {
            crate::startup::log(format!(
                "Membership service unavailable; using Free entitlements: {error}"
            ));
            free_profile()
        }
    }
}

/// Fast display profile. Uses the durable GitHub numeric user ID instead of
/// login, preserving the plan across username changes while keeping the public
/// read cacheable at Cloudflare's edge.
pub async fn display_profile(force_refresh: bool) -> MembershipProfile {
    let Some(user) = crate::github::cached_user() else {
        clear_display_cache();
        return free_profile();
    };
    let stale = {
        let guard = display_cache()
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        if let Some(entry) = guard
            .as_ref()
            .filter(|entry| entry.github_user_id == user.id)
        {
            if !force_refresh && entry.fetched_at.elapsed() <= DISPLAY_CACHE_TTL {
                return entry.profile.clone();
            }
            Some(entry.profile.clone())
        } else {
            None
        }
    };
    let profile = match fetch_public_display_profile(user.id, force_refresh).await {
        Ok(profile) => profile,
        Err(error) => {
            crate::startup::log(format!(
                "Public membership lookup unavailable; preserving last display profile when available: {error}"
            ));
            return stale.unwrap_or_else(free_profile);
        }
    };
    let mut guard = display_cache()
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    *guard = Some(DisplayCacheEntry {
        github_user_id: user.id,
        fetched_at: Instant::now(),
        profile: profile.clone(),
    });
    profile
}

pub async fn public_profiles_by_ids(ids: &[u64]) -> HashMap<u64, MembershipProfile> {
    let mut unique = ids.iter().copied().filter(|id| *id > 0).collect::<Vec<_>>();
    unique.sort_unstable();
    unique.dedup();
    unique.truncate(50);
    if unique.is_empty() {
        return HashMap::new();
    }

    let mut result = HashMap::new();
    let mut missing = Vec::new();
    {
        let mut cache = public_profile_cache()
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        cache.retain(|_, entry| entry.fetched_at.elapsed() <= PUBLIC_BATCH_CACHE_TTL);
        for id in &unique {
            if let Some(entry) = cache.get(id) {
                result.insert(*id, entry.profile.clone());
            } else {
                missing.push(*id);
            }
        }
    }
    if missing.is_empty() {
        return result;
    }

    let joined = missing
        .iter()
        .map(u64::to_string)
        .collect::<Vec<_>>()
        .join(",");
    let path = format!("/v1/membership/public-batch?ids={joined}");
    let fetched = match crate::continuity::request_json(Method::GET, &path, None, None).await {
        Ok(value) => serde_json::from_value::<PublicMembershipBatchPayload>(value)
            .map_err(|error| error.to_string()),
        Err(error) => Err(error),
    };

    let mut fresh = HashMap::new();
    match fetched {
        Ok(payload) => {
            for id in &missing {
                let profile = payload
                    .profiles
                    .get(&id.to_string())
                    .cloned()
                    .map(validated)
                    .unwrap_or_else(free_profile);
                fresh.insert(*id, profile);
            }
        }
        Err(error) => {
            crate::startup::log(format!(
                "Public membership batch unavailable; preserving feed fallback tiers: {error}"
            ));
            return result;
        }
    }

    {
        let mut cache = public_profile_cache()
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        if cache.len() + fresh.len() > PUBLIC_BATCH_CACHE_MAX {
            cache.clear();
        }
        let now = Instant::now();
        for (id, profile) in &fresh {
            cache.insert(
                *id,
                PublicProfileCacheEntry {
                    fetched_at: now,
                    profile: profile.clone(),
                },
            );
            result.insert(*id, profile.clone());
        }
    }
    result
}

#[tauri::command]
pub async fn membership_profile(app: AppHandle, force_refresh: bool) -> MembershipProfile {
    let Some(user) = crate::github::cached_user() else {
        clear_display_cache();
        return free_profile();
    };
    if !force_refresh {
        {
            let guard = display_cache()
                .lock()
                .unwrap_or_else(|error| error.into_inner());
            if let Some(entry) = guard
                .as_ref()
                .filter(|entry| entry.github_user_id == user.id)
            {
                if entry.fetched_at.elapsed() <= DISPLAY_CACHE_TTL {
                    return entry.profile.clone();
                }
            }
        }
        if let Some(profile) = load_persisted_display_cache(&app, user.id) {
            *display_cache()
                .lock()
                .unwrap_or_else(|error| error.into_inner()) = Some(DisplayCacheEntry {
                github_user_id: user.id,
                fetched_at: Instant::now(),
                profile: profile.clone(),
            });
            // Stale-while-revalidate is display-only. Paid privileges continue to use
            // current_profile(), which always authenticates against Continuity.
            let app_for_refresh = app.clone();
            tauri::async_runtime::spawn(async move {
                if let Ok(fresh) = fetch_public_display_profile(user.id, true).await {
                    *display_cache()
                        .lock()
                        .unwrap_or_else(|error| error.into_inner()) = Some(DisplayCacheEntry {
                        github_user_id: user.id,
                        fetched_at: Instant::now(),
                        profile: fresh.clone(),
                    });
                    persist_display_cache(&app_for_refresh, user.id, &fresh);
                    let _ = app_for_refresh.emit("jingu-membership-refreshed", fresh);
                }
            });
            return profile;
        }
    }
    let profile = display_profile(force_refresh).await;
    persist_display_cache(&app, user.id, &profile);
    profile
}

#[tauri::command]
pub async fn membership_credits_opt_in(enabled: bool) -> Result<MembershipProfile, String> {
    let token = crate::github::access_token().await?;
    crate::continuity::request_json(
        Method::POST,
        "/v1/membership/credits-opt-in",
        Some(&token),
        Some(json!({"enabled": enabled})),
    )
    .await?;
    clear_display_cache();
    Ok(display_profile(true).await)
}

fn fallback_payment_config() -> PaymentConfig {
    PaymentConfig {
        enabled: false,
        provider: "infinitepay".into(),
        market: "BR".into(),
        currency: "BRL".into(),
        environment: "unconfigured".into(),
        duration_days: 31,
        manual_renewal: true,
        prices_minor: HashMap::from([
            ("bronze".into(), 500),
            ("silver".into(), 700),
            ("gold".into(), 1000),
        ]),
        // TierFlow uses the canonical BR ratios for carry-over conversion even
        // when a provider route has a different commercial price book.
        transition_value_prices_minor: HashMap::from([
            ("bronze".into(), 500),
            ("silver".into(), 700),
            ("gold".into(), 1000),
        ]),
        donation: Some(PaymentDonationConfig {
            enabled: true,
            min_minor: 100,
            max_minor: None,
        }),
        support_max_minor: None,
        pricing_version: 3,
        allocation_mode: "max_units_selected_tier".into(),
        contribution: Some(PaymentContributionConfig {
            min_minor: 100,
            max_minor: None,
            plan_threshold_minor: 500,
        }),
        tier_transition: Some(PaymentTierTransitionConfig {
            mode: "immediate_value_proration".into(),
            rounding: "floor_millisecond".into(),
            requires_new_purchase: true,
        }),
        currencies: vec![PaymentCurrencyOption {
            code: "BRL".into(),
            market: "BR".into(),
            provider: Some("infinitepay".into()),
            available: true,
            checkout_enabled: false,
            label: "Real brasileiro (BRL)".into(),
            prices_minor: HashMap::from([
                ("bronze".into(), 500),
                ("silver".into(), 700),
                ("gold".into(), 1000),
            ]),
            donation_enabled: true,
            donation_min_minor: 100,
            amount_mode: "arbitrary".into(),
            adaptive_currency: false,
            canonical_currency: "BRL".into(),
            price_source: "static".into(),
        }],
    }
}

fn public_brl_only_payment_config(mut config: PaymentConfig) -> PaymentConfig {
    // Public v1 is compile-time BRL/InfinitePay-only. Even if the shared Worker
    // later exposes additional providers for private/post-v1 testing, this public
    // client never surfaces or starts checkout for them.
    config.currencies.retain(|route| {
        route.code.eq_ignore_ascii_case("BRL")
            && route.market.eq_ignore_ascii_case("BR")
            && route.provider.as_deref() == Some("infinitepay")
    });
    if config.currencies.is_empty() {
        return fallback_payment_config();
    }
    let route = config.currencies[0].clone();
    config.enabled = route.available && route.checkout_enabled;
    config.provider = "infinitepay".into();
    config.market = "BR".into();
    config.currency = "BRL".into();
    config.prices_minor = route.prices_minor.clone();
    config.currencies = vec![route];
    config
}

#[tauri::command]
pub async fn payment_config(force_refresh: Option<bool>) -> PaymentConfig {
    let force_refresh = force_refresh.unwrap_or(false);
    if !force_refresh {
        let guard = payment_config_cache()
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        if let Some(entry) = guard.as_ref() {
            if entry.fetched_at.elapsed() <= PAYMENT_CONFIG_CACHE_TTL {
                return entry.config.clone();
            }
        }
    }
    let path = if force_refresh {
        "/v1/payments/config?fresh=1"
    } else {
        "/v1/payments/config"
    };
    match crate::continuity::request_json(Method::GET, path, None, None).await {
        Ok(value) => match serde_json::from_value::<PaymentConfig>(value) {
            Ok(config) => {
                let config = public_brl_only_payment_config(config);
                *payment_config_cache()
                    .lock()
                    .unwrap_or_else(|error| error.into_inner()) = Some(PaymentConfigCacheEntry {
                    fetched_at: Instant::now(),
                    config: config.clone(),
                });
                config
            }
            Err(_) => fallback_payment_config(),
        },
        Err(_) => fallback_payment_config(),
    }
}

#[tauri::command]
pub async fn payment_price_preview(
    tier: String,
    currency: String,
    plan_units: u64,
    amount_minor: Option<u64>,
) -> Result<PaymentPricePreview, String> {
    let tier = tier.trim().to_ascii_lowercase();
    if !matches!(tier.as_str(), "bronze" | "silver" | "gold" | "donation") {
        return Err("Plano inválido para prévia de preço.".into());
    }
    let currency = currency.trim().to_ascii_uppercase();
    if currency != "BRL" {
        return Err("A source pública v1 aceita pagamentos somente em BRL.".into());
    }
    if !(1..=1200).contains(&plan_units) {
        return Err("Quantidade de unidades inválida.".into());
    }
    if amount_minor == Some(0) {
        return Err("Valor inválido para prévia de preço.".into());
    }
    let amount_query = amount_minor
        .map(|value| format!("&amount_minor={value}"))
        .unwrap_or_default();
    let path = format!(
        "/v1/payments/preview?tier={tier}&currency={currency}&plan_units={plan_units}{amount_query}"
    );
    let value = crate::continuity::request_json(Method::GET, &path, None, None).await?;
    let preview = serde_json::from_value::<PaymentPricePreview>(value)
        .map_err(|error| format!("Resposta da prévia de preço inválida: {error}"))?;
    let (expected_provider, expected_market, expected_canonical_currency) =
        ("infinitepay", "BR", "BRL");
    let expected_units = if tier == "donation" { 0 } else { plan_units };
    if !preview.tier.eq_ignore_ascii_case(&tier)
        || !preview.billing_currency.eq_ignore_ascii_case(&currency)
        || !preview.provider.eq_ignore_ascii_case(expected_provider)
        || !preview.market.eq_ignore_ascii_case(expected_market)
        || !preview
            .canonical_currency
            .eq_ignore_ascii_case(expected_canonical_currency)
        || preview.plan_units != expected_units
        || preview.billing_amount_minor == 0
        || preview.canonical_amount_minor == 0
        || amount_minor.is_some_and(|expected| preview.canonical_amount_minor != expected)
    {
        return Err("Prévia de preço recusada: resposta inconsistente do servidor.".into());
    }
    Ok(preview)
}

#[tauri::command]
pub async fn payment_checkout_start(
    tier: String,
    amount_minor: Option<u64>,
    currency: Option<String>,
    plan_units: Option<u64>,
) -> Result<PaymentCheckoutResult, String> {
    let tier = tier.trim().to_ascii_lowercase();
    if !matches!(tier.as_str(), "bronze" | "silver" | "gold" | "donation") {
        return Err("Tipo de pagamento inválido.".into());
    }
    let currency = currency
        .unwrap_or_else(|| "BRL".into())
        .trim()
        .to_ascii_uppercase();
    let config = payment_config(Some(true)).await;
    let route = config
        .currencies
        .iter()
        .find(|route| route.code.eq_ignore_ascii_case(&currency) && route.available)
        .ok_or_else(|| "Esta moeda ainda não está disponível para pagamentos.".to_string())?;
    if !route.checkout_enabled {
        return Err("O checkout desta moeda ainda não está habilitado no ambiente atual.".into());
    }
    let market = route.market.clone();
    let expected_provider = route
        .provider
        .as_deref()
        .ok_or_else(|| "Provedor de pagamento indisponível para esta moeda.".to_string())?
        .to_string();
    if expected_provider != "infinitepay" {
        return Err("Provedor de pagamento indisponível para esta moeda.".into());
    }
    if let Some(units) = plan_units {
        if !(1..=1200).contains(&units) {
            return Err("Quantidade de unidades inválida.".into());
        }
    }
    let token = crate::github::access_token().await?;
    let value = crate::continuity::request_json(
        Method::POST,
        "/v1/payments/checkout",
        Some(&token),
        Some(json!({
            "tier": tier,
            "market": market,
            "currency": currency,
            "amount_minor": amount_minor,
            "plan_units": plan_units
        })),
    )
    .await?;
    let result = serde_json::from_value::<PaymentCheckoutResult>(value)
        .map_err(|error| format!("Resposta do checkout inválida: {error}"))?;
    let checkout_url = reqwest::Url::parse(&result.checkout_url)
        .map_err(|_| "Checkout recusado: URL inválida.".to_string())?;
    let trusted_host = matches!(
        checkout_url.host_str(),
        Some("checkout.infinitepay.io") | Some("checkout.infinitepay.com.br")
    );
    if checkout_url.scheme() != "https"
        || checkout_url.username() != ""
        || checkout_url.password().is_some()
        || !trusted_host
    {
        return Err("Checkout recusado: destino do provedor inesperado.".into());
    }
    if !result.currency.eq_ignore_ascii_case(&currency)
        || !result.market.eq_ignore_ascii_case(&market)
        || result.provider != expected_provider
    {
        return Err(
            "Checkout recusado: o provedor retornou uma rota de pagamento inesperada.".into(),
        );
    }
    if !result.billing_currency.is_empty()
        && !result.billing_currency.eq_ignore_ascii_case(&currency)
    {
        return Err("Checkout recusado: moeda de cobrança inesperada.".into());
    }
    if let Some(expected_amount) = amount_minor {
        if result.amount_minor != 0 && result.amount_minor != expected_amount {
            return Err(
                "Checkout recusado: o valor retornado não corresponde ao valor solicitado.".into(),
            );
        }
    }
    clear_display_cache();
    Ok(result)
}

pub fn badge_for_tier(tier: &str) -> Option<&'static str> {
    match tier {
        "bronze" => Some("Bronze"),
        "silver" => Some("Prata"),
        "gold" => Some("Ouro"),
        _ => None,
    }
}

#[tauri::command]
pub async fn supporters_list() -> Result<Vec<SupporterPublicEntry>, String> {
    let value = crate::continuity::request_json(Method::GET, "/v1/supporters", None, None)
        .await
        .map_err(|error| {
            crate::startup::log(format!("Supporters list unavailable: {error}"));
            error
        })?;

    serde_json::from_value::<SupportersPayload>(value)
        .map(|mut payload| {
            // Schema 1 exposed only active supporters and did not include
            // historical month metadata. Keep mixed-version rollouts usable:
            // those rows are safely interpreted as active with one month.
            if payload.schema < 2 {
                for entry in &mut payload.users {
                    entry.months = entry.months.max(1);
                    entry.active = true;
                }
            }
            payload.users
        })
        .map_err(|error| format!("Invalid supporters payload: {error}"))
}
