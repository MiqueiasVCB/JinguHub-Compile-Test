/**************************************************************************/
/*  migration.rs                                                        */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
//! One-shot import of data produced by the pre-R12 C++ JinguHub.
//!
//! The migration is intentionally read-only with respect to the legacy Hub.
//! R12 writes only to its own Tauri application data directory.

use crate::models::{InstalledGodotVersion, Project};
use serde_json::Value;
use std::collections::HashSet;
use std::fs;
use std::path::{Component, Path, PathBuf};
use tauri::AppHandle;
use uuid::Uuid;

fn legacy_root() -> Option<PathBuf> {
    #[cfg(target_os = "windows")]
    {
        let local = std::env::var_os("LOCALAPPDATA")?;
        Some(PathBuf::from(local).join("JinguEngine").join("Hub"))
    }
    #[cfg(not(target_os = "windows"))]
    {
        None
    }
}

fn marker(app: &AppHandle) -> PathBuf {
    crate::paths::app_data_dir(app).join("migration-r12.done")
}

fn project_name(path: &Path) -> String {
    crate::projects::resolve_project_name(path.to_string_lossy().as_ref()).unwrap_or_else(|| {
        path.file_name()
            .and_then(|s| s.to_str())
            .unwrap_or("Projeto Jingu")
            .to_string()
    })
}

fn import_versions(app: &AppHandle, root: &Path) {
    let file = root.join("config").join("install-registry.json");
    let Ok(text) = fs::read_to_string(file) else {
        return;
    };
    let Ok(json) = serde_json::from_str::<Value>(&text) else {
        return;
    };
    let Some(items) = json.get("versions").and_then(Value::as_array) else {
        return;
    };
    let mut registry = crate::godot_versions::read_registry(app);
    let mut seen: HashSet<String> = registry
        .iter()
        .map(|v| v.executable_path.to_lowercase())
        .collect();
    for item in items {
        let version = item
            .get("version")
            .and_then(Value::as_str)
            .unwrap_or("")
            .trim();
        let install_path = item
            .get("install_path")
            .and_then(Value::as_str)
            .unwrap_or("")
            .trim();
        let entrypoint = item
            .get("entrypoint")
            .and_then(Value::as_str)
            .unwrap_or("")
            .trim();
        if version.is_empty() || install_path.is_empty() || entrypoint.is_empty() {
            continue;
        }
        let executable = PathBuf::from(install_path).join(entrypoint);
        if !executable.is_file() {
            continue;
        }
        let executable_path = executable.to_string_lossy().to_string();
        if !seen.insert(executable_path.to_lowercase()) {
            continue;
        }
        registry.push(InstalledGodotVersion {
            tag: version.to_string(),
            version: version.trim_start_matches('v').to_string(),
            runtime_version: None,
            executable_path,
            is_mono: false,
            installed_at: item
                .get("installed_at")
                .and_then(Value::as_str)
                .unwrap_or("")
                .to_string(),
            custom_name: None,
            install_root: Some(install_path.to_string()),
            supports_console: false,
            managed_install: None,
            restricted: false,
        });
    }
    let _ = crate::godot_versions::write_registry(app, &registry);
}

fn import_projects(app: &AppHandle, root: &Path) {
    let file = root.join("config").join("project-versions.json");
    let Ok(text) = fs::read_to_string(file) else {
        return;
    };
    let Ok(json) = serde_json::from_str::<Value>(&text) else {
        return;
    };
    let Some(bindings) = json.get("projects").and_then(Value::as_object) else {
        return;
    };
    let _ = crate::projects::update_projects(app, |projects| {
        let mut seen: HashSet<String> = projects.iter().map(|p| p.path.to_lowercase()).collect();
        for (path, version) in bindings {
            let path = PathBuf::from(path);
            if crate::projects::project_config_path(&path.to_string_lossy()).is_none() {
                continue;
            }
            let path_string = path.to_string_lossy().to_string();
            if !seen.insert(path_string.to_lowercase()) {
                continue;
            }
            let name = project_name(&path);
            projects.push(Project {
                id: Uuid::new_v4().to_string(),
                name,
                path: path_string,
                godot_version: version.as_str().unwrap_or("").to_string(),
                jingu_version: String::new(),
                created_at: chrono::Utc::now().to_rfc3339(),
                last_opened: None,
                category: None,
                pinned: false,
                sort_order: projects.len() as i64,
                launch_arguments: String::new(),
                tags: vec![],
            });
        }
        Ok(())
    });
}

/// R12 inherited GodotHub's workspace-scoped storage even though Jingu never
/// exposed workspaces in its product UI. HF2 flattens the active workspace into
/// the application's global data directory. The legacy files are copied, not
/// deleted, so rollback/recovery remains possible.
fn safe_workspace_id(value: &str) -> Option<&str> {
    let value = value.trim();
    if value.is_empty() || value.contains(['/', '\\']) {
        return None;
    }
    let mut components = Path::new(value).components();
    match (components.next(), components.next()) {
        (Some(Component::Normal(_)), None) => Some(value),
        _ => None,
    }
}

fn migrate_legacy_workspace_files(base: &Path) -> Result<(), String> {
    let state_file = base.join("workspaces.json");
    let state_metadata = match fs::symlink_metadata(&state_file) {
        Ok(metadata) => metadata,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(error) => return Err(format!("could not inspect legacy workspace state: {error}")),
    };
    if !state_metadata.file_type().is_file() {
        return Err("legacy workspace state is not a regular file".into());
    }
    let raw = fs::read(&state_file).map_err(|error| {
        format!(
            "could not read legacy workspace state {}: {error}",
            state_file.display()
        )
    })?;
    let value: Value = serde_json::from_slice(&raw)
        .map_err(|error| format!("legacy workspace state is invalid: {error}"))?;
    let active_id = value
        .get("active_id")
        .and_then(Value::as_str)
        .and_then(safe_workspace_id)
        .ok_or_else(|| "legacy workspace active_id is absent or unsafe".to_string())?;
    let legacy_dir = base.join("workspaces").join(active_id);
    for name in ["settings.json", "projects.json"] {
        let source = legacy_dir.join(name);
        let destination = base.join(name);
        let source_metadata = match fs::symlink_metadata(&source) {
            Ok(metadata) => metadata,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
            Err(error) => {
                return Err(format!(
                    "could not inspect legacy workspace source {}: {error}",
                    source.display()
                ));
            }
        };
        if !source_metadata.file_type().is_file() {
            return Err(format!(
                "legacy workspace source is not a regular file: {}",
                source.display()
            ));
        }
        match fs::symlink_metadata(&destination) {
            Ok(metadata) => {
                if !metadata.file_type().is_file() {
                    return Err(format!(
                        "migration destination is not a regular file: {}",
                        destination.display()
                    ));
                }
                continue;
            }
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => {
                return Err(format!(
                    "could not inspect migration destination {}: {error}",
                    destination.display()
                ));
            }
        }
        let bytes = fs::read(&source).map_err(|error| error.to_string())?;
        crate::persist::write_atomic(&destination, &bytes).map_err(|error| error.to_string())?;
        crate::startup::log(format!(
            "Migrated legacy workspace file {} -> {}",
            source.display(),
            destination.display()
        ));
    }
    Ok(())
}

pub fn migrate_legacy_workspace_storage(app: &AppHandle) {
    let base = crate::paths::app_data_dir(app);
    let marker = base.join("workspace-storage-migrated-r13-hf2.done");
    if marker.exists() {
        return;
    }

    if let Err(error) = migrate_legacy_workspace_files(&base) {
        crate::startup::log(format!(
            "WARNING: legacy workspace migration incomplete; it will be retried on the next launch: {error}"
        ));
        return;
    }

    if let Err(error) = crate::persist::write_atomic(
        &marker,
        b"Jingu Hub R13 HF2 workspace storage migration completed\n",
    ) {
        crate::startup::log(format!(
            "WARNING: could not write workspace migration marker {}: {error}",
            marker.display()
        ));
    }
}

pub fn migrate_legacy_cpp_hub(app: &AppHandle) {
    let marker_path = marker(app);
    if marker_path.exists() {
        return;
    }
    let Some(root) = legacy_root() else {
        return;
    };
    if root.exists() {
        import_versions(app, &root);
        import_projects(app, &root);
    }
    if let Some(parent) = marker_path.parent() {
        let _ = fs::create_dir_all(parent);
    }
    let _ = crate::persist::write_atomic(&marker_path, b"Jingu Hub legacy C++ import completed\n");
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fixture_root(label: &str) -> PathBuf {
        std::env::temp_dir().join(format!("jingu-migration-{label}-{}", Uuid::new_v4()))
    }

    #[test]
    fn workspace_id_is_one_safe_component() {
        assert_eq!(safe_workspace_id("workspace-123"), Some("workspace-123"));
        for value in ["", " ", ".", "..", "../escape", "..\\escape", "a/b", "a\\b"] {
            assert_eq!(safe_workspace_id(value), None, "accepted {value:?}");
        }
    }

    #[test]
    fn legacy_workspace_migration_is_read_only_idempotent_and_unicode_safe() {
        let root = fixture_root("unicode-ç-日本");
        let legacy = root.join("workspaces").join("ativo-ç-日本");
        fs::create_dir_all(&legacy).unwrap();
        fs::write(
            root.join("workspaces.json"),
            r#"{"active_id":"ativo-ç-日本"}"#,
        )
        .unwrap();
        fs::write(legacy.join("settings.json"), br#"{"theme":"dark"}"#).unwrap();
        fs::write(legacy.join("projects.json"), br#"[{"id":"legacy"}]"#).unwrap();

        migrate_legacy_workspace_files(&root).unwrap();
        assert_eq!(
            fs::read(root.join("settings.json")).unwrap(),
            br#"{"theme":"dark"}"#
        );
        assert_eq!(
            fs::read(root.join("projects.json")).unwrap(),
            br#"[{"id":"legacy"}]"#
        );
        assert!(legacy.join("settings.json").is_file());

        fs::write(root.join("settings.json"), br#"{"theme":"owner-new"}"#).unwrap();
        migrate_legacy_workspace_files(&root).unwrap();
        assert_eq!(
            fs::read(root.join("settings.json")).unwrap(),
            br#"{"theme":"owner-new"}"#
        );
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn corrupt_or_escaping_workspace_state_fails_closed_without_copying() {
        let root = fixture_root("corrupt");
        fs::create_dir_all(&root).unwrap();
        fs::write(root.join("workspaces.json"), b"{truncated").unwrap();
        assert!(migrate_legacy_workspace_files(&root).is_err());
        assert!(!root.join("settings.json").exists());

        fs::write(
            root.join("workspaces.json"),
            br#"{"active_id":"..\\..\\outside"}"#,
        )
        .unwrap();
        assert!(migrate_legacy_workspace_files(&root).is_err());
        assert!(!root.join("projects.json").exists());

        fs::write(root.join("workspaces.json"), br#"{"active_id":"active"}"#).unwrap();
        fs::create_dir_all(root.join("workspaces").join("active").join("settings.json")).unwrap();
        assert!(migrate_legacy_workspace_files(&root).is_err());
        assert!(!root.join("settings.json").exists());

        fs::remove_dir_all(root.join("workspaces").join("active").join("settings.json")).unwrap();
        fs::write(
            root.join("workspaces").join("active").join("settings.json"),
            b"legacy",
        )
        .unwrap();
        fs::create_dir_all(root.join("settings.json")).unwrap();
        assert!(migrate_legacy_workspace_files(&root).is_err());
        let _ = fs::remove_dir_all(root);
    }
}
