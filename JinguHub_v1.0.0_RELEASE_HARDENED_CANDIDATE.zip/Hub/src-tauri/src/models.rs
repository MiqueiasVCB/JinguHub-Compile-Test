/**************************************************************************/
/*  models.rs                                                           */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InstalledGodotVersion {
    pub tag: String,
    /// Public Jingu Engine release/version shown to the user.
    pub version: String,
    /// Underlying Godot-compatible runtime version reported by the executable
    /// (for example 4.7.1). This is compatibility metadata, not the Jingu
    /// product version, and is used only to match project feature requirements.
    #[serde(default)]
    pub runtime_version: Option<String>,
    pub executable_path: String,
    pub is_mono: bool,
    pub installed_at: String,
    #[serde(default)]
    pub custom_name: Option<String>,
    #[serde(default)]
    pub install_root: Option<String>,
    #[serde(default)]
    pub supports_console: bool,
    /// Whether the Hub owns the installation files and may delete them.
    /// None is used by legacy registries and is inferred conservatively.
    #[serde(default)]
    pub managed_install: Option<bool>,
    /// True only for an installation obtained from a private TEST release.
    /// Such installations require a currently authorized GitHub session to be listed/launched.
    #[serde(default)]
    pub restricted: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GodotReleaseAsset {
    pub name: String,
    pub download_url: String,
    pub size: u64,
    #[serde(default)]
    pub is_mono: bool,
    /// SHA-256 declared by the official release manifest. Stable catalog
    /// entries without verified metadata are never exposed for installation.
    #[serde(default)]
    pub expected_sha256: String,
    #[serde(default)]
    pub entrypoint: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GodotRelease {
    pub tag: String,
    pub assets: Vec<GodotReleaseAsset>,
    #[serde(default = "default_release_channel")]
    pub channel: String,
    #[serde(default)]
    pub restricted: bool,
}

fn default_release_channel() -> String {
    "stable".to_string()
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Project {
    pub id: String,
    pub name: String,
    pub path: String,
    pub godot_version: String,
    /// Human-readable Jingu Engine version detected from the project/config or
    /// from the bound installation. Kept separate from `godot_version`, which
    /// is the stable installation binding key used to launch the editor.
    #[serde(default)]
    pub jingu_version: String,
    #[serde(default)]
    pub created_at: String,
    pub last_opened: Option<String>,
    #[serde(default)]
    pub category: Option<String>,
    #[serde(default)]
    pub pinned: bool,
    #[serde(default)]
    pub sort_order: i64,
    #[serde(default)]
    pub launch_arguments: String,
    #[serde(default)]
    pub tags: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectUpdate {
    pub name: Option<String>,
    pub godot_version: Option<String>,
    #[serde(default)]
    pub category: Option<String>,
    #[serde(default)]
    pub pinned: Option<bool>,
    #[serde(default)]
    pub launch_arguments: Option<String>,
    #[serde(default)]
    pub tags: Option<Vec<String>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DownloadProgress {
    pub tag: String,
    pub downloaded: u64,
    pub total: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppSettings {
    #[serde(default)]
    pub workspace_root: Option<String>,
    #[serde(default)]
    pub download_dir: Option<String>,
    #[serde(default)]
    pub default_project_location: Option<String>,
    #[serde(default = "default_download_concurrency")]
    pub download_concurrency: u32,
    #[serde(default)]
    pub reduce_motion: bool,
    #[serde(default)]
    pub launch_with_console: bool,
    #[serde(default)]
    pub close_on_project_open: bool,
    #[serde(default = "default_minimize_to_tray")]
    pub minimize_to_tray: bool,
    /// Persist the GitHub OAuth session across application restarts.
    /// Disabled by default: without explicit opt-in the token lives only in memory.
    #[serde(default)]
    pub remember_github_login: bool,
    #[serde(default)]
    pub reopen_after_godot_closes: bool,
    #[serde(default = "default_tray_recent_projects_count")]
    pub tray_recent_projects_count: u32,
    #[serde(default = "default_language")]
    pub language: String,
    #[serde(default = "default_os_decorations")]
    pub use_os_decorations: bool,
    #[serde(default)]
    pub dismissed_project_paths: Vec<String>,
    #[serde(default = "default_naming_convention")]
    pub directory_naming_convention: String,
}

fn default_language() -> String {
    "pt-BR".to_string()
}

fn default_naming_convention() -> String {
    "keep".to_string()
}

fn default_tray_recent_projects_count() -> u32 {
    5
}

fn default_download_concurrency() -> u32 {
    3
}
fn default_minimize_to_tray() -> bool {
    true
}
fn default_os_decorations() -> bool {
    false
}

impl Default for AppSettings {
    fn default() -> Self {
        Self {
            workspace_root: None,
            download_dir: None,
            default_project_location: None,
            download_concurrency: default_download_concurrency(),
            reduce_motion: false,
            launch_with_console: false,
            close_on_project_open: false,
            minimize_to_tray: default_minimize_to_tray(),
            remember_github_login: true,
            reopen_after_godot_closes: false,
            tray_recent_projects_count: default_tray_recent_projects_count(),
            language: default_language(),
            use_os_decorations: default_os_decorations(),
            dismissed_project_paths: vec![],
            directory_naming_convention: default_naming_convention(),
        }
    }
}
