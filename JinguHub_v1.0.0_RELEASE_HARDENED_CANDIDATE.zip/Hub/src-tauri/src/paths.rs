/**************************************************************************/
/*  paths.rs                                                            */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use crate::models::AppSettings;
use serde::Serialize;
use std::path::{Path, PathBuf};
use tauri::{AppHandle, Manager};

pub const PORTABLE_MARKER: &str = "portable.flag";

const STORAGE_NAME: &str = "JinguHub";
const WORKSPACE_NAME: &str = "Jingu";

#[derive(Debug, Clone, Serialize)]
pub struct DirectoryLayout {
    pub workspace_root: String,
    pub projects_root: String,
    pub github_root: String,
    pub github_repositories_root: String,
    pub github_exports_root: String,
    pub stores_root: String,
    pub store_jingu_root: String,
    pub store_godot_root: String,
    pub store_shaders_root: String,
    pub store_itchio_root: String,
    pub versions_root: String,
    pub hub_versions_root: String,
    pub engine_versions_root: String,
    pub app_state_root: String,
}

/// Returns the directory containing the executable when this is an explicit
/// folder-portable build. The marker is intentionally external to the binary,
/// so signed executables do not need to be modified.
pub fn portable_root() -> Option<PathBuf> {
    if let Some(explicit_root) = std::env::var_os("JINGU_PORTABLE_ROOT") {
        let root = PathBuf::from(explicit_root);
        if root.is_dir() {
            return Some(root);
        }
    }

    let forced = std::env::var("JINGU_PORTABLE")
        .ok()
        .is_some_and(|value| matches!(value.trim(), "1" | "true" | "TRUE" | "yes" | "YES"));
    let exe = std::env::current_exe().ok()?;
    let exe_dir = exe.parent()?.to_path_buf();
    if forced {
        return Some(exe_dir);
    }

    for candidate in exe_dir.ancestors().take(4) {
        if candidate.join(PORTABLE_MARKER).is_file() {
            return Some(candidate.to_path_buf());
        }
    }
    None
}

#[cfg(target_os = "windows")]
fn fallback_data_dir() -> PathBuf {
    std::env::var_os("LOCALAPPDATA")
        .map(PathBuf::from)
        .unwrap_or_else(std::env::temp_dir)
        .join(STORAGE_NAME)
        .join("data")
}

#[cfg(target_os = "macos")]
fn fallback_data_dir() -> PathBuf {
    std::env::var_os("HOME")
        .map(PathBuf::from)
        .map(|home| home.join("Library/Application Support").join(STORAGE_NAME))
        .unwrap_or_else(|| std::env::temp_dir().join(STORAGE_NAME).join("data"))
}

#[cfg(all(unix, not(target_os = "macos")))]
fn fallback_data_dir() -> PathBuf {
    if let Some(xdg) = std::env::var_os("XDG_DATA_HOME").map(PathBuf::from) {
        return xdg.join(STORAGE_NAME);
    }
    std::env::var_os("HOME")
        .map(PathBuf::from)
        .map(|home| home.join(".local/share").join(STORAGE_NAME))
        .unwrap_or_else(|| std::env::temp_dir().join(STORAGE_NAME).join("data"))
}

#[cfg(not(any(target_os = "windows", target_os = "macos", unix)))]
fn fallback_data_dir() -> PathBuf {
    std::env::temp_dir().join(STORAGE_NAME).join("data")
}

fn fallback_documents_dir() -> PathBuf {
    if let Some(root) = portable_root() {
        return root.join("data");
    }

    #[cfg(target_os = "windows")]
    if let Some(home) = std::env::var_os("USERPROFILE").map(PathBuf::from) {
        return home.join("Documents");
    }

    #[cfg(any(target_os = "macos", unix))]
    if let Some(home) = std::env::var_os("HOME").map(PathBuf::from) {
        return home.join("Documents");
    }

    std::env::temp_dir().join(WORKSPACE_NAME)
}

fn normalize_nonempty(value: &Option<String>) -> Option<PathBuf> {
    value
        .as_ref()
        .map(|item| item.trim())
        .filter(|item| !item.is_empty())
        .map(PathBuf::from)
}

pub(crate) fn managed_documents_workspace_root(app: &AppHandle) -> PathBuf {
    app.path()
        .document_dir()
        .unwrap_or_else(|_| fallback_documents_dir())
        .join(WORKSPACE_NAME)
}

#[cfg(target_os = "windows")]
pub(crate) fn is_managed_documents_workspace(app: &AppHandle, path: &Path) -> bool {
    let candidate = managed_documents_workspace_root(app);
    let left = path.to_string_lossy().replace('/', "\\");
    let right = candidate.to_string_lossy().replace('/', "\\");
    left.trim_end_matches('\\')
        .eq_ignore_ascii_case(right.trim_end_matches('\\'))
}

#[cfg(not(target_os = "windows"))]
pub(crate) fn is_managed_documents_workspace(app: &AppHandle, path: &Path) -> bool {
    path == managed_documents_workspace_root(app)
}

pub fn default_workspace_root(app: &AppHandle) -> PathBuf {
    if let Some(root) = portable_root() {
        return root.join("data").join(WORKSPACE_NAME);
    }

    // Keep Jingu-managed mutable content outside OS-protected Documents/Desktop
    // folders by default. Windows Controlled Folder Access and macOS privacy/TCC
    // can legitimately gate those locations. A profile-level ~/Jingu workspace
    // is user-writable, predictable and avoids asking the user to weaken system
    // security. Documents/Jingu remains only a legacy migration source.
    #[cfg(target_os = "windows")]
    let profile = std::env::var_os("USERPROFILE").map(PathBuf::from);
    #[cfg(not(target_os = "windows"))]
    let profile = std::env::var_os("HOME").map(PathBuf::from);

    if let Some(profile) = profile {
        let preferred = profile.join(WORKSPACE_NAME);
        if std::fs::create_dir_all(&preferred).is_ok() {
            return preferred;
        }
    }

    let fallback = app_data_dir(app).join("Workspace");
    let _ = std::fs::create_dir_all(&fallback);
    crate::startup::log(format!(
        "WARNING: preferred workspace unavailable; using app-data workspace {}",
        fallback.display()
    ));
    fallback
}

#[cfg(target_os = "windows")]
fn installed_startup_log_dir() -> PathBuf {
    std::env::var_os("LOCALAPPDATA")
        .map(PathBuf::from)
        .unwrap_or_else(std::env::temp_dir)
        .join(STORAGE_NAME)
        .join("logs")
}

#[cfg(target_os = "macos")]
fn installed_startup_log_dir() -> PathBuf {
    std::env::var_os("HOME")
        .map(PathBuf::from)
        .map(|home| home.join("Library/Logs").join(STORAGE_NAME))
        .unwrap_or_else(|| std::env::temp_dir().join(STORAGE_NAME).join("logs"))
}

#[cfg(all(unix, not(target_os = "macos")))]
fn installed_startup_log_dir() -> PathBuf {
    if let Some(state) = std::env::var_os("XDG_STATE_HOME").map(PathBuf::from) {
        return state.join(STORAGE_NAME).join("logs");
    }
    std::env::var_os("HOME")
        .map(PathBuf::from)
        .map(|home| home.join(".local/state").join(STORAGE_NAME).join("logs"))
        .unwrap_or_else(|| std::env::temp_dir().join(STORAGE_NAME).join("logs"))
}

#[cfg(not(any(target_os = "windows", target_os = "macos", unix)))]
fn installed_startup_log_dir() -> PathBuf {
    std::env::temp_dir().join(STORAGE_NAME).join("logs")
}

pub fn startup_log_dir() -> PathBuf {
    portable_root()
        .map(|root| root.join("data").join(STORAGE_NAME).join("Logs"))
        .unwrap_or_else(installed_startup_log_dir)
}

pub fn app_data_dir(app: &AppHandle) -> PathBuf {
    if let Some(root) = portable_root() {
        let path = root.join("data").join(STORAGE_NAME).join("HubState");
        if let Err(error) = std::fs::create_dir_all(&path) {
            crate::startup::log(format!(
                "WARNING: could not create portable app-data directory {}: {error}",
                path.display()
            ));
        }
        return path;
    }

    match app.path().app_data_dir() {
        Ok(path) => {
            if let Err(error) = std::fs::create_dir_all(&path) {
                crate::startup::log(format!(
                    "WARNING: could not create Tauri app-data directory {}: {error}",
                    path.display()
                ));
            }
            path
        }
        Err(error) => {
            let fallback = fallback_data_dir();
            let _ = std::fs::create_dir_all(&fallback);
            crate::startup::log(format!(
                "WARNING: Tauri app-data directory unavailable ({error}); using {}",
                fallback.display()
            ));
            fallback
        }
    }
}

pub fn directory_layout_for_settings(app: &AppHandle, settings: &AppSettings) -> DirectoryLayout {
    let workspace_root =
        normalize_nonempty(&settings.workspace_root).unwrap_or_else(|| default_workspace_root(app));
    let projects_root = normalize_nonempty(&settings.default_project_location)
        .unwrap_or_else(|| workspace_root.join("Projects"));
    let versions_root = workspace_root.join("Versions");
    let engine_versions_root = normalize_nonempty(&settings.download_dir)
        .unwrap_or_else(|| versions_root.join("Jingu Engine"));
    let hub_versions_root = versions_root.join("Jingu Hub");
    let github_root = workspace_root.join("GitHub");
    let github_repositories_root = github_root.join("Repositories");
    let github_exports_root = github_root.join("Exports");
    let stores_root = workspace_root.join("Stores");
    let app_state_root = workspace_root.join("Hub State");

    DirectoryLayout {
        workspace_root: workspace_root.to_string_lossy().to_string(),
        projects_root: projects_root.to_string_lossy().to_string(),
        github_root: github_root.to_string_lossy().to_string(),
        github_repositories_root: github_repositories_root.to_string_lossy().to_string(),
        github_exports_root: github_exports_root.to_string_lossy().to_string(),
        stores_root: stores_root.to_string_lossy().to_string(),
        store_jingu_root: stores_root.join("Jingu").to_string_lossy().to_string(),
        store_godot_root: stores_root.join("Godot").to_string_lossy().to_string(),
        store_shaders_root: stores_root
            .join("Godot Shaders")
            .to_string_lossy()
            .to_string(),
        store_itchio_root: stores_root.join("Itch.io").to_string_lossy().to_string(),
        versions_root: versions_root.to_string_lossy().to_string(),
        hub_versions_root: hub_versions_root.to_string_lossy().to_string(),
        engine_versions_root: engine_versions_root.to_string_lossy().to_string(),
        app_state_root: app_state_root.to_string_lossy().to_string(),
    }
}

fn ensure_dir(path: &Path) -> bool {
    match std::fs::create_dir_all(path) {
        Ok(()) => true,
        Err(error) => {
            crate::startup::log(format!(
                "WARNING: could not create managed directory {}: {error}",
                path.display()
            ));
            false
        }
    }
}

pub fn ensure_directory_layout(app: &AppHandle, settings: &AppSettings) -> DirectoryLayout {
    let layout = directory_layout_for_settings(app, settings);
    if !ensure_dir(Path::new(&layout.workspace_root)) {
        return layout;
    }
    for path in [
        &layout.projects_root,
        &layout.github_root,
        &layout.github_repositories_root,
        &layout.github_exports_root,
        &layout.stores_root,
        &layout.store_jingu_root,
        &layout.store_godot_root,
        &layout.store_shaders_root,
        &layout.store_itchio_root,
        &layout.versions_root,
        &layout.hub_versions_root,
        &layout.engine_versions_root,
        &layout.app_state_root,
    ] {
        let _ = ensure_dir(Path::new(path));
    }
    layout
}

#[tauri::command]
pub fn get_directory_layout(app: AppHandle) -> DirectoryLayout {
    let settings = crate::settings::read_settings(&app);
    ensure_directory_layout(&app, &settings)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::sync::Mutex;

    static PORTABLE_ENV_LOCK: Mutex<()> = Mutex::new(());

    #[test]
    fn explicit_portable_root_is_unicode_safe_and_requires_an_existing_directory() {
        let _guard = PORTABLE_ENV_LOCK.lock().unwrap();
        let previous = std::env::var_os("JINGU_PORTABLE_ROOT");
        let root =
            std::env::temp_dir().join(format!("jingu-portable-ç-日本-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        std::env::set_var("JINGU_PORTABLE_ROOT", &root);
        assert_eq!(portable_root(), Some(root.clone()));
        assert_eq!(
            startup_log_dir(),
            root.join("data").join(STORAGE_NAME).join("Logs")
        );

        let missing = root.join("missing");
        std::env::set_var("JINGU_PORTABLE_ROOT", &missing);
        assert_ne!(portable_root(), Some(missing));
        if let Some(value) = previous {
            std::env::set_var("JINGU_PORTABLE_ROOT", value);
        } else {
            std::env::remove_var("JINGU_PORTABLE_ROOT");
        }
        let _ = fs::remove_dir_all(root);
    }
}
