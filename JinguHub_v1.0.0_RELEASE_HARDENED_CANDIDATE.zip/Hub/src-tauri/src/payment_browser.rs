/**************************************************************************/
/*  payment_browser.rs                                                  */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
//! Isolated embedded browser for the provider-hosted payment flow.
//!
//! The Hub never renders card/Pix forms itself and never injects credentials
//! into provider pages. Only a checkout URL returned by the native payment
//! command can start a session. Subsequent HTTPS navigations are allowed so
//! provider-controlled authentication/3DS can complete; every top-level URL is
//! emitted to the React shell so the current origin remains visible.

use serde::{Deserialize, Serialize};
use tauri::{
    webview::{DownloadEvent, NewWindowResponse, WebviewBuilder},
    AppHandle, Emitter, LogicalPosition, LogicalSize, Manager, WebviewUrl,
};

const PAYMENT_LABEL: &str = "payment-browser";

fn is_official_payment_checkout_host(host: Option<&str>) -> bool {
    matches!(
        host,
        Some("checkout.infinitepay.io") | Some("checkout.infinitepay.com.br")
    )
}

#[derive(Debug, Clone, Copy, Deserialize, Serialize)]
pub struct PaymentBounds {
    pub x: f64,
    pub y: f64,
    pub width: f64,
    pub height: f64,
}

#[derive(Debug, Clone, Serialize)]
struct PaymentNavigationEvent {
    url: String,
    trusted_provider: bool,
    return_to_jingu: bool,
}

fn trusted_initial_url(raw: &str) -> Result<reqwest::Url, String> {
    let url =
        reqwest::Url::parse(raw.trim()).map_err(|_| "URL de checkout inválida.".to_string())?;
    if url.scheme() != "https"
        || url.username() != ""
        || url.password().is_some()
        || !is_official_payment_checkout_host(url.host_str())
    {
        return Err("O checkout não pertence a um domínio oficial de pagamento da Jingu.".into());
    }
    Ok(url)
}

fn is_jingu_return(url: &reqwest::Url) -> bool {
    let Some(base) =
        crate::continuity::base_url().and_then(|value| reqwest::Url::parse(&value).ok())
    else {
        return false;
    };
    url.scheme() == "https"
        && url.host_str() == base.host_str()
        && url.port_or_known_default() == base.port_or_known_default()
        && url.path().starts_with("/v1/payments/return/infinitepay/")
}

fn emit_navigation(app: &AppHandle, url: &reqwest::Url) {
    let payload = PaymentNavigationEvent {
        url: url.to_string(),
        trusted_provider: is_official_payment_checkout_host(url.host_str()),
        return_to_jingu: is_jingu_return(url),
    };
    let _ = app.emit("jingu-payment-browser-navigation", &payload);
    if payload.return_to_jingu {
        let _ = app.emit("jingu-payment-browser-returned", &payload);
    }
}

fn apply_bounds(webview: &tauri::Webview, bounds: PaymentBounds) -> Result<(), String> {
    webview
        .set_position(LogicalPosition::new(bounds.x.max(0.0), bounds.y.max(0.0)))
        .map_err(|error| error.to_string())?;
    webview
        .set_size(LogicalSize::new(
            bounds.width.max(1.0),
            bounds.height.max(1.0),
        ))
        .map_err(|error| error.to_string())?;
    Ok(())
}

fn create_payment_webview(
    app: &AppHandle,
    url: reqwest::Url,
    bounds: PaymentBounds,
) -> Result<tauri::Webview, String> {
    let parent = app
        .get_window("main")
        .ok_or_else(|| "A janela principal do Jingu Hub não foi encontrada.".to_string())?;
    let app_for_nav = app.clone();
    let app_for_popup = app.clone();

    let builder = WebviewBuilder::new(PAYMENT_LABEL, WebviewUrl::External(url))
        // Keep provider cookies/local storage ephemeral. Payment data belongs to
        // the provider session and must not become durable Hub browsing state.
        .incognito(true)
        .enable_clipboard_access()
        .zoom_hotkeys_enabled(false)
        .on_navigation(move |url| {
            if !matches!(url.scheme(), "https" | "about") {
                return false;
            }
            if url.scheme() == "https" {
                emit_navigation(&app_for_nav, url);
            }
            true
        })
        .on_new_window(move |url, _features| {
            // Provider authentication may use target=_blank. Keep HTTPS flows
            // inside the isolated payment view and never spawn an uncontrolled
            // application window.
            if url.scheme() == "https" {
                if let Some(webview) = app_for_popup.get_webview(PAYMENT_LABEL) {
                    let _ = webview.navigate(url);
                }
            }
            NewWindowResponse::Deny
        })
        .on_download(|_webview, event| {
            // Payment pages must never write arbitrary files through the Hub.
            !matches!(event, DownloadEvent::Requested { .. })
        });

    let webview = parent
        .add_child(
            builder,
            LogicalPosition::new(bounds.x.max(0.0), bounds.y.max(0.0)),
            LogicalSize::new(bounds.width.max(1.0), bounds.height.max(1.0)),
        )
        .map_err(|error| {
            format!("Não foi possível abrir o checkout dentro do Jingu Hub: {error}")
        })?;
    Ok(webview)
}

#[tauri::command]
pub async fn payment_browser_show(
    app: AppHandle,
    url: String,
    bounds: PaymentBounds,
) -> Result<(), String> {
    let target = trusted_initial_url(&url)?;
    if let Some(webview) = app.get_webview(PAYMENT_LABEL) {
        apply_bounds(&webview, bounds)?;
        webview
            .navigate(target)
            .map_err(|error| error.to_string())?;
        webview.show().map_err(|error| error.to_string())?;
        let _ = webview.set_focus();
        return Ok(());
    }
    let webview = create_payment_webview(&app, target, bounds)?;
    webview.show().map_err(|error| error.to_string())?;
    let _ = webview.set_focus();
    Ok(())
}

#[tauri::command]
pub fn payment_browser_set_bounds(app: AppHandle, bounds: PaymentBounds) -> Result<(), String> {
    let webview = app
        .get_webview(PAYMENT_LABEL)
        .ok_or_else(|| "O checkout integrado ainda não foi aberto.".to_string())?;
    apply_bounds(&webview, bounds)
}

#[tauri::command]
pub fn payment_browser_hide(app: AppHandle) {
    if let Some(webview) = app.get_webview(PAYMENT_LABEL) {
        // Destroy the private provider session on close instead of retaining a
        // hidden payment webview with cookies/session state in memory.
        let _ = webview.close();
    }
}

#[tauri::command]
pub fn payment_browser_reload(app: AppHandle) -> Result<(), String> {
    let webview = app
        .get_webview(PAYMENT_LABEL)
        .ok_or_else(|| "O checkout integrado ainda não foi aberto.".to_string())?;
    webview.reload().map_err(|error| error.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn initial_payment_url_accepts_only_exact_provider_hosts() {
        assert!(trusted_initial_url("https://checkout.infinitepay.io/jingu/abc").is_ok());
        assert!(trusted_initial_url("https://checkout.infinitepay.com.br/jingu/abc").is_ok());
        for raw in [
            "http://checkout.infinitepay.io/jingu/abc",
            "https://checkout.infinitepay.io.example.com/jingu/abc",
            "https://evil.example/checkout.infinitepay.io",
            "javascript:alert(1)",
        ] {
            assert!(trusted_initial_url(raw).is_err(), "{raw}");
        }
    }
}
