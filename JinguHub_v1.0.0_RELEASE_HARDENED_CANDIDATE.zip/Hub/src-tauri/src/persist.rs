/**************************************************************************/
/*  persist.rs                                                          */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use serde::de::DeserializeOwned;
use serde::Serialize;
use std::ffi::OsString;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Mutex;

use crate::error::AppResult;

pub fn read_json<T: DeserializeOwned + Default>(path: &Path) -> T {
    if !path.exists() {
        return T::default();
    }
    let raw = match fs::read(path) {
        Ok(raw) => raw,
        Err(error) => {
            crate::startup::log(format!(
                "WARNING: could not read persisted JSON {}: {error}",
                path.display()
            ));
            return T::default();
        }
    };
    match serde_json::from_slice(&raw) {
        Ok(value) => value,
        Err(error) => {
            // Never silently overwrite a malformed user-state file with an
            // empty/default state. Preserve the original for recovery and let
            // the application continue with safe defaults.
            let timestamp = chrono::Utc::now().format("%Y%m%dT%H%M%SZ");
            let backup = path.with_extension(format!("json.corrupt-{timestamp}"));
            match fs::rename(path, &backup) {
                Ok(()) => crate::startup::log(format!(
                    "WARNING: invalid JSON {} ({error}); preserved as {}",
                    path.display(),
                    backup.display()
                )),
                Err(rename_error) => crate::startup::log(format!(
                    "WARNING: invalid JSON {} ({error}); backup failed: {rename_error}",
                    path.display()
                )),
            }
            T::default()
        }
    }
}

fn temp_path_for(path: &Path) -> io::Result<PathBuf> {
    static COUNTER: AtomicU64 = AtomicU64::new(0);
    let parent = path
        .parent()
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "path has no parent"))?;
    let file_name = path
        .file_name()
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "path has no file name"))?;
    let mut name = OsString::from(".");
    name.push(file_name);
    name.push(format!(
        ".jingu-tmp-{}-{}",
        std::process::id(),
        COUNTER.fetch_add(1, Ordering::Relaxed)
    ));
    Ok(parent.join(name))
}

#[cfg(target_os = "windows")]
fn replace_file(temp: &Path, destination: &Path) -> io::Result<()> {
    use std::os::windows::ffi::OsStrExt;

    const MOVEFILE_REPLACE_EXISTING: u32 = 0x0000_0001;
    const MOVEFILE_WRITE_THROUGH: u32 = 0x0000_0008;

    #[link(name = "Kernel32")]
    extern "system" {
        fn MoveFileExW(
            existing_file_name: *const u16,
            new_file_name: *const u16,
            flags: u32,
        ) -> i32;
    }

    let from: Vec<u16> = temp
        .as_os_str()
        .encode_wide()
        .chain(std::iter::once(0))
        .collect();
    let to: Vec<u16> = destination
        .as_os_str()
        .encode_wide()
        .chain(std::iter::once(0))
        .collect();
    let ok = unsafe {
        MoveFileExW(
            from.as_ptr(),
            to.as_ptr(),
            MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH,
        )
    };
    if ok == 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(())
    }
}

#[cfg(not(target_os = "windows"))]
fn replace_file(temp: &Path, destination: &Path) -> io::Result<()> {
    fs::rename(temp, destination)?;
    if let Some(parent) = destination.parent() {
        if let Ok(dir) = fs::File::open(parent) {
            let _ = dir.sync_all();
        }
    }
    Ok(())
}

pub fn write_atomic(path: &Path, bytes: &[u8]) -> AppResult<()> {
    static WRITE_LOCK: Mutex<()> = Mutex::new(());
    let _guard = WRITE_LOCK
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    let parent = path
        .parent()
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "path has no parent"))?;
    fs::create_dir_all(parent)?;

    let temp = temp_path_for(path)?;
    let result = (|| -> io::Result<()> {
        let mut file = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temp)?;
        file.write_all(bytes)?;
        file.sync_all()?;
        drop(file);
        replace_file(&temp, path)
    })();

    if result.is_err() {
        let _ = fs::remove_file(&temp);
    }
    result?;
    Ok(())
}

pub fn write_json<T: Serialize>(path: &Path, data: &T) -> AppResult<()> {
    let mut json = serde_json::to_vec_pretty(data)?;
    json.push(b'\n');
    write_atomic(path, &json)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde::{Deserialize, Serialize};

    #[derive(Debug, Default, Serialize, Deserialize, PartialEq)]
    struct Sample {
        value: String,
    }

    #[test]
    fn atomic_json_round_trip() {
        let root =
            std::env::temp_dir().join(format!("jingu-persist-test-{}", uuid::Uuid::new_v4()));
        let file = root.join("state.json");
        let expected = Sample { value: "ok".into() };
        write_json(&file, &expected).unwrap();
        let actual: Sample = read_json(&file);
        assert_eq!(actual, expected);
        assert!(fs::read_to_string(&file).unwrap().ends_with('\n'));
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn malformed_json_is_preserved_instead_of_overwritten() {
        let root =
            std::env::temp_dir().join(format!("jingu-corrupt-test-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let file = root.join("state.json");
        fs::write(&file, b"{broken").unwrap();
        let actual: Sample = read_json(&file);
        assert_eq!(actual, Sample::default());
        assert!(!file.exists());
        assert!(fs::read_dir(&root).unwrap().flatten().any(|entry| entry
            .file_name()
            .to_string_lossy()
            .starts_with("state.json.corrupt-")));
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn non_utf8_json_is_preserved_instead_of_overwritten() {
        let root =
            std::env::temp_dir().join(format!("jingu-non-utf8-test-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let file = root.join("estado-ç-日本.json");
        fs::write(&file, [0xff, 0xfe, b'{', b'}']).unwrap();
        let actual: Sample = read_json(&file);
        assert_eq!(actual, Sample::default());
        assert!(!file.exists());
        assert!(fs::read_dir(&root).unwrap().flatten().any(|entry| entry
            .file_name()
            .to_string_lossy()
            .starts_with("estado-ç-日本.json.corrupt-")));
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn concurrent_unicode_writers_leave_one_complete_json_and_no_temp_files() {
        let root = std::env::temp_dir().join(format!(
            "jingu-concurrent-persist-ç-日本-{}",
            uuid::Uuid::new_v4()
        ));
        let file = root.join("estado.json");
        let mut writers = Vec::new();
        for writer in 0..8 {
            let file = file.clone();
            writers.push(std::thread::spawn(move || {
                for iteration in 0..32 {
                    let sample = Sample {
                        value: format!("writer-{writer}-iteration-{iteration}-ç-日本"),
                    };
                    write_json(&file, &sample).unwrap();
                }
            }));
        }
        for writer in writers {
            writer.join().unwrap();
        }

        let raw = fs::read(&file).unwrap();
        let actual: Sample = serde_json::from_slice(&raw).unwrap();
        assert!(actual.value.starts_with("writer-"));
        assert!(raw.ends_with(b"\n"));
        assert!(!fs::read_dir(&root)
            .unwrap()
            .flatten()
            .any(|entry| entry.file_name().to_string_lossy().contains(".jingu-tmp-")));
        let _ = fs::remove_dir_all(root);
    }
}
