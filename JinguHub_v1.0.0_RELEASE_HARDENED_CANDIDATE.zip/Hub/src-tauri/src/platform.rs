/**************************************************************************/
/*  platform.rs                                                         */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
#[cfg(unix)]
use std::collections::HashSet;
#[cfg(unix)]
use std::path::PathBuf;

/// GUI applications launched from Finder/Desktop environments can inherit a
/// much smaller PATH than an interactive shell. Keep the user's existing PATH,
/// then add only conventional executable locations needed by Git/terminal
/// integration. No shell startup files are executed.
pub fn prepare_process_environment() {
    #[cfg(unix)]
    {
        let mut paths: Vec<PathBuf> = std::env::var_os("PATH")
            .map(|value| std::env::split_paths(&value).collect())
            .unwrap_or_default();

        if let Some(home) = std::env::var_os("HOME").map(PathBuf::from) {
            paths.push(home.join(".local/bin"));
            paths.push(home.join(".cargo/bin"));
        }

        #[cfg(target_os = "macos")]
        for candidate in [
            "/opt/homebrew/bin",
            "/opt/homebrew/sbin",
            "/usr/local/bin",
            "/usr/local/sbin",
            "/usr/bin",
            "/bin",
            "/usr/sbin",
            "/sbin",
        ] {
            paths.push(PathBuf::from(candidate));
        }

        #[cfg(all(unix, not(target_os = "macos")))]
        for candidate in [
            "/usr/local/bin",
            "/usr/bin",
            "/bin",
            "/usr/local/sbin",
            "/usr/sbin",
            "/sbin",
        ] {
            paths.push(PathBuf::from(candidate));
        }

        let mut seen = HashSet::new();
        paths.retain(|path| seen.insert(path.clone()));
        if let Ok(joined) = std::env::join_paths(paths) {
            std::env::set_var("PATH", joined);
        }
    }
}
