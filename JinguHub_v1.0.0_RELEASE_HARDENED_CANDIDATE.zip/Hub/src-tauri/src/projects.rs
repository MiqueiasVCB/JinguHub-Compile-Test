/**************************************************************************/
/*  projects.rs                                                         */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use crate::models::*;
use crate::persist;
use crate::settings;
use std::fs;
use std::path::{Component, Path, PathBuf};
use std::process::Child;
use tauri::{AppHandle, Emitter, Manager};
use uuid::Uuid;

use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};
use std::time::SystemTime;

pub enum TrackedHandle {
    Child(Child),
    #[cfg(unix)]
    Pid(u32),
}

pub struct TrackedProcess {
    pub handle: TrackedHandle,
}

impl TrackedProcess {
    fn is_running(&mut self) -> bool {
        match &mut self.handle {
            TrackedHandle::Child(child) => matches!(child.try_wait(), Ok(None)),
            #[cfg(unix)]
            TrackedHandle::Pid(pid) => crate::terminal::process_is_alive(*pid),
        }
    }
}

pub struct ActiveProcesses(pub Mutex<HashMap<String, TrackedProcess>>);

const DEFAULT_ICON_SVG: &[u8] = include_bytes!("../jingu_project_icon.svg");

struct CachedIcon {
    project_config_mtime: Option<SystemTime>,
    data: Option<String>,
}

/// Jingu projects use `project.jingu` as the canonical editable project file.
/// `project.godot` is accepted only as a legacy/import compatibility format.
pub(crate) fn project_config_path(project_path: &str) -> Option<PathBuf> {
    let root = PathBuf::from(project_path);
    let jingu = root.join("project.jingu");
    if jingu.is_file() {
        return Some(jingu);
    }
    let legacy = root.join("project.godot");
    legacy.is_file().then_some(legacy)
}

pub(crate) fn is_project_directory(project_path: &str) -> bool {
    project_config_path(project_path).is_some()
}

fn icon_cache() -> &'static Mutex<HashMap<String, CachedIcon>> {
    static CACHE: OnceLock<Mutex<HashMap<String, CachedIcon>>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(HashMap::new()))
}

fn projects_file(app: &AppHandle) -> PathBuf {
    crate::paths::app_data_dir(app).join("projects.json")
}

fn project_registry_lock() -> &'static Mutex<()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
}

fn update_projects_path<R>(
    path: &Path,
    update: impl FnOnce(&mut Vec<Project>) -> Result<R, String>,
) -> Result<R, String> {
    let _guard = project_registry_lock()
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    let mut projects: Vec<Project> = persist::read_json(path);
    let result = update(&mut projects)?;
    persist::write_json(path, &projects).map_err(|error| error.to_string())?;
    Ok(result)
}

pub(crate) fn update_projects<R>(
    app: &AppHandle,
    update: impl FnOnce(&mut Vec<Project>) -> Result<R, String>,
) -> Result<R, String> {
    update_projects_path(&projects_file(app), update)
}

pub(crate) fn read_projects(app: &AppHandle) -> Vec<Project> {
    persist::read_json(&projects_file(app))
}

pub(crate) fn write_projects(app: &AppHandle, projects: &Vec<Project>) -> Result<(), String> {
    persist::write_json(&projects_file(app), projects).map_err(|e| e.to_string())
}

#[cfg(target_os = "linux")]
fn case_fold(path: &str) -> String {
    path.to_string()
}

#[cfg(not(target_os = "linux"))]
fn case_fold(path: &str) -> String {
    path.to_lowercase()
}

fn normalize_path(path: &str) -> String {
    let trimmed = path.trim_end_matches(['/', '\\']);
    case_fold(if trimmed.is_empty() { path } else { trimmed })
}

pub fn same_path(a: &str, b: &str) -> bool {
    normalize_path(a) == normalize_path(b)
}

pub fn contains_path(paths: &[String], path: &str) -> bool {
    let target = normalize_path(path);
    paths.iter().any(|p| normalize_path(p) == target)
}

fn undismiss(app: &AppHandle, path: &str) {
    let mut s = settings::read_settings(app);
    let before = s.dismissed_project_paths.len();
    s.dismissed_project_paths.retain(|p| !same_path(p, path));
    if s.dismissed_project_paths.len() != before {
        let _ = settings::write_settings(app, &s);
    }
}

fn next_sort_order(projects: &[Project], category: &Option<String>) -> i64 {
    projects
        .iter()
        .filter(|p| !p.pinned && &p.category == category)
        .map(|p| p.sort_order)
        .max()
        .map(|m| m + 1)
        .unwrap_or(0)
}

fn project_version_display(
    path: &str,
    binding: &str,
    installed: &[InstalledGodotVersion],
) -> String {
    let pin = crate::godotenv::read_jingu_pin(path);
    let binding_key = pin
        .as_deref()
        .filter(|value| !value.trim().is_empty())
        .unwrap_or(binding);
    if binding_key.trim().is_empty() {
        return String::new();
    }
    let Some(version) = installed.iter().find(|version| version.tag == binding_key) else {
        // Project feature tags describe the underlying Godot-compatible runtime,
        // not a Jingu product release. Preserve the last known Jingu version in
        // projects.json instead of inventing one from `config/features`.
        return String::new();
    };
    if version.managed_install == Some(false) {
        // Externally compiled/imported Engines do not carry a trustworthy Jingu
        // release identifier. The frontend will display them as a local build
        // using `runtime_version`, rather than mislabeling Godot 4.x as Jingu 4.x.
        return String::new();
    }
    version.version.trim().trim_start_matches('v').to_string()
}

fn list_projects_blocking(app: &AppHandle) -> Vec<Project> {
    let _guard = project_registry_lock()
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    let projects = read_projects(app);
    let (mut kept, removed): (Vec<Project>, Vec<Project>) = projects
        .into_iter()
        .partition(|p| is_project_directory(&p.path));

    let mut metadata_changed = false;
    let installed = crate::godot_versions::read_registry(app);
    for p in kept.iter_mut() {
        if let Some(disk_name) = resolve_project_name(&p.path) {
            if p.name != disk_name {
                p.name = disk_name;
                metadata_changed = true;
            }
        }
        if p.tags.is_empty() {
            let disk_tags = resolve_project_tags(&p.path);
            if !disk_tags.is_empty() {
                p.tags = disk_tags;
                metadata_changed = true;
            }
        }
        if p.godot_version.is_empty() {
            let detected = crate::godotenv::read_jingu_pin(&p.path)
                .or_else(|| {
                    crate::godotenv::detect_version(&p.path).and_then(|spec| {
                        crate::godotenv::best_match(&spec, &installed).map(|v| v.tag.clone())
                    })
                })
                .or_else(|| {
                    crate::godotenv::best_project_feature_match(&p.path, &installed)
                        .map(|v| v.tag.clone())
                });
            if let Some(version) = detected {
                p.godot_version = version;
                metadata_changed = true;
            }
        }
        let version_display = project_version_display(&p.path, &p.godot_version, &installed);
        if !version_display.is_empty() && p.jingu_version != version_display {
            p.jingu_version = version_display;
            metadata_changed = true;
        }
    }

    if !removed.is_empty() || metadata_changed {
        let _ = write_projects(app, &kept);
    }
    kept
}

#[tauri::command]
pub async fn list_projects(app: AppHandle) -> Result<Vec<Project>, String> {
    tokio::task::spawn_blocking(move || list_projects_blocking(&app))
        .await
        .map_err(|error| format!("Falha aguardando leitura dos projetos: {error}"))
}

fn capitalize_word(word: &str) -> String {
    let mut chars = word.chars();
    match chars.next() {
        Some(first) => first.to_uppercase().collect::<String>() + &chars.as_str().to_lowercase(),
        None => String::new(),
    }
}

fn split_naming_words(name: &str) -> Vec<String> {
    let mut words: Vec<String> = Vec::new();
    let mut current = String::new();
    let chars: Vec<char> = name.chars().collect();
    let n = chars.len();
    for (i, &c) in chars.iter().enumerate() {
        if !c.is_ascii_alphanumeric() {
            if !current.is_empty() {
                words.push(std::mem::take(&mut current));
            }
            continue;
        }
        if !current.is_empty() {
            // `current` is known to be non-empty here. Avoid a panic anyway so
            // malformed/unexpected Unicode input can never take down the Hub.
            let Some(last) = current.chars().last() else {
                continue;
            };
            let split = (last.is_ascii_lowercase() || last.is_ascii_digit())
                && c.is_ascii_uppercase()
                || last.is_ascii_uppercase()
                    && c.is_ascii_uppercase()
                    && i + 1 < n
                    && chars[i + 1].is_ascii_lowercase();
            if split {
                words.push(std::mem::take(&mut current));
            }
        }
        current.push(c);
    }
    if !current.is_empty() {
        words.push(current);
    }
    words
}

pub(crate) fn apply_naming_convention(name: &str, convention: &str) -> String {
    let words = split_naming_words(name);
    if words.is_empty() {
        return name.trim().to_string();
    }
    match convention {
        "kebab-case" => words
            .iter()
            .map(|w| w.to_lowercase())
            .collect::<Vec<_>>()
            .join("-"),
        "snake_case" => words
            .iter()
            .map(|w| w.to_lowercase())
            .collect::<Vec<_>>()
            .join("_"),
        "camelCase" => {
            let mut out = String::new();
            for (i, w) in words.iter().enumerate() {
                if i == 0 {
                    out.push_str(&w.to_lowercase());
                } else {
                    out.push_str(&capitalize_word(w));
                }
            }
            out
        }
        "PascalCase" => words.iter().map(|w| capitalize_word(w)).collect::<String>(),
        "Title Case" => words
            .iter()
            .map(|w| capitalize_word(w))
            .collect::<Vec<_>>()
            .join(" "),
        _ => name.to_string(),
    }
}

fn validate_new_project_name(name: &str) -> Result<(), String> {
    let count = name.chars().count();
    if name.trim() != name || count == 0 || count > 120 || name.chars().any(char::is_control) {
        return Err(
            "O nome do projeto deve ter entre 1 e 120 caracteres e não pode conter espaços externos ou controles."
                .into(),
        );
    }
    Ok(())
}

fn validate_project_folder_component(folder_name: &str) -> Result<(), String> {
    if folder_name.is_empty()
        || folder_name.trim() != folder_name
        || folder_name.ends_with('.')
        || folder_name.contains(['/', '\\'])
        || folder_name
            .chars()
            .any(|ch| ch.is_control() || matches!(ch, '<' | '>' | ':' | '"' | '|' | '?' | '*'))
    {
        return Err("O nome de pasta gerado para o projeto é inválido ou inseguro.".into());
    }
    let mut components = Path::new(folder_name).components();
    if !matches!(
        (components.next(), components.next()),
        (Some(Component::Normal(_)), None)
    ) {
        return Err("O nome de pasta do projeto deve ser um único componente seguro.".into());
    }
    let stem = folder_name
        .split('.')
        .next()
        .unwrap_or("")
        .to_ascii_uppercase();
    let reserved = matches!(stem.as_str(), "CON" | "PRN" | "AUX" | "NUL")
        || stem
            .strip_prefix("COM")
            .or_else(|| stem.strip_prefix("LPT"))
            .is_some_and(|suffix| {
                matches!(suffix, "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9")
            });
    if reserved {
        return Err("O nome de pasta do projeto é reservado pelo sistema operacional.".into());
    }
    Ok(())
}

fn create_project_directory(location: &Path, folder_name: &str) -> Result<PathBuf, String> {
    fs::create_dir_all(location).map_err(|error| error.to_string())?;
    let project_dir = location.join(folder_name);
    fs::create_dir(&project_dir).map_err(|error| {
        if error.kind() == std::io::ErrorKind::AlreadyExists {
            format!("A pasta '{folder_name}' já existe neste local.")
        } else {
            error.to_string()
        }
    })?;
    Ok(project_dir)
}

#[tauri::command]
pub fn create_project(
    app: AppHandle,
    name: String,
    location: String,
    godot_version: String,
    icon_path: Option<String>,
    category: Option<String>,
) -> Result<Project, String> {
    validate_new_project_name(&name)?;
    let settings = settings::read_settings(&app);
    let folder_name = apply_naming_convention(&name, &settings.directory_naming_convention);
    validate_project_folder_component(&folder_name)?;
    let project_dir = create_project_directory(Path::new(&location), &folder_name)?;

    let installed_versions = crate::godot_versions::read_registry(&app);
    let selected_install = installed_versions
        .iter()
        .find(|version| version.tag == godot_version);
    let feature_source = selected_install
        .and_then(|version| version.runtime_version.as_deref())
        .filter(|value| !value.trim().is_empty())
        .or_else(|| {
            selected_install
                .map(|version| version.version.as_str())
                .filter(|value| !value.trim().is_empty())
        })
        .unwrap_or(&godot_version);
    let feature_tag = version_feature_tag(feature_source);
    let config_name = escape_project_setting_string(&name);
    let mut project_config = format!(
        "; Jingu Engine project configuration file.\n\n[application]\n\nconfig/name=\"{}\"\nconfig/icon=\"res://icon.svg\"\nconfig/features=PackedStringArray(\"{}\")\n",
        config_name, feature_tag
    );

    if let Some(icon) = &icon_path {
        let src = PathBuf::from(icon);
        if src.is_file() {
            let ext = src.extension().and_then(|e| e.to_str()).unwrap_or("svg");
            let icon_name = format!("icon.{ext}");
            let dest = project_dir.join(&icon_name);
            fs::copy(&src, dest).map_err(|e| e.to_string())?;
            if ext != "svg" {
                project_config =
                    project_config.replace("res://icon.svg", &format!("res://icon.{ext}"));
            }
        }
    } else {
        fs::write(project_dir.join("icon.svg"), DEFAULT_ICON_SVG).map_err(|e| e.to_string())?;
    }

    // New Jingu projects are canonical `project.jingu` projects. We do not
    // create a shadow `project.godot`, which could become a second editable
    // source of truth and is reserved for explicit Godot export/compatibility.
    fs::write(project_dir.join("project.jingu"), &project_config).map_err(|e| e.to_string())?;
    let _ = fs::create_dir(project_dir.join(".godot"));

    let effective_category = category.as_ref().and_then(|c| {
        if c.trim().is_empty() {
            None
        } else {
            Some(c.clone())
        }
    });
    let project_path = project_dir.to_string_lossy().to_string();
    let tags = resolve_project_tags(&project_path);
    let mut project = Project {
        id: Uuid::new_v4().to_string(),
        name,
        path: project_path,
        godot_version,
        jingu_version: selected_install
            .filter(|version| version.managed_install != Some(false))
            .map(|version| version.version.trim().trim_start_matches('v').to_string())
            .unwrap_or_default(),
        created_at: chrono::Utc::now().to_rfc3339(),
        last_opened: None,
        category: effective_category.clone(),
        pinned: false,
        sort_order: 0,
        launch_arguments: String::new(),
        tags,
    };

    if !project.godot_version.is_empty() {
        if let Err(e) = crate::godotenv::pin_version(&project.path, &project.godot_version) {
            let _ = fs::remove_dir_all(&project_dir);
            return Err(format!(
                "O projeto não foi criado porque não foi possível vincular a versão da Jingu Engine: {e}"
            ));
        }
    }

    let registered = update_projects(&app, |projects| {
        if projects
            .iter()
            .any(|item| same_path(&item.path, &project.path))
        {
            return Err("Este projeto já está na biblioteca do Jingu Hub.".into());
        }
        project.sort_order = next_sort_order(projects, &effective_category);
        projects.push(project.clone());
        Ok(project.clone())
    });
    let project = match registered {
        Ok(project) => project,
        Err(e) => {
            let _ = fs::remove_dir_all(&project_dir);
            return Err(e);
        }
    };
    undismiss(&app, &project.path);
    Ok(project)
}

fn escape_project_setting_string(value: &str) -> String {
    value
        .replace('\\', "\\\\")
        .replace('"', "\\\"")
        .replace('\n', "\\n")
        .replace('\r', "\\r")
        .replace('\t', "\\t")
}

fn unescape_project_setting_string(value: &str) -> Option<String> {
    let quoted = value.trim().strip_prefix('"')?.strip_suffix('"')?;
    let mut decoded = String::with_capacity(quoted.len());
    let mut chars = quoted.chars();
    while let Some(ch) = chars.next() {
        if ch != '\\' {
            decoded.push(ch);
            continue;
        }
        decoded.push(match chars.next()? {
            '\\' => '\\',
            '"' => '"',
            'n' => '\n',
            'r' => '\r',
            't' => '\t',
            _ => return None,
        });
    }
    Some(decoded)
}

fn set_project_config_name(project_path: &str, name: &str) -> Result<(), String> {
    let config = project_config_path(project_path)
        .ok_or_else(|| "A cópia não contém project.jingu/project.godot válido.".to_string())?;
    let text = fs::read_to_string(&config).map_err(|e| e.to_string())?;
    let escaped = escape_project_setting_string(name);
    let replacement = format!("config/name=\"{escaped}\"");
    let mut replaced = false;
    let mut lines: Vec<String> = text
        .lines()
        .map(|line| {
            if !replaced && line.trim_start().starts_with("config/name=") {
                replaced = true;
                replacement.clone()
            } else {
                line.to_string()
            }
        })
        .collect();
    if !replaced {
        if let Some(application) = lines.iter().position(|line| line.trim() == "[application]") {
            lines.insert(application + 1, replacement);
        } else {
            if !lines.is_empty() && !lines.last().is_some_and(|line| line.is_empty()) {
                lines.push(String::new());
            }
            lines.push("[application]".to_string());
            lines.push(replacement);
        }
    }
    let mut output = lines.join("\n");
    if text.ends_with('\n') {
        output.push('\n');
    }
    persist::write_atomic(&config, output.as_bytes()).map_err(|e| e.to_string())
}

fn version_feature_tag(tag: &str) -> String {
    let cleaned = tag.trim().trim_start_matches('v');
    let mut parts = cleaned.split(['.', '-']);
    let is_num = |s: &str| !s.is_empty() && s.bytes().all(|b| b.is_ascii_digit());
    match (parts.next(), parts.next()) {
        (Some(m), Some(n)) if is_num(m) && is_num(n) => format!("{}.{}", m, n),
        _ => "4.7".to_string(),
    }
}

pub fn rebind_projects_to_version(app: &AppHandle, version: &InstalledGodotVersion) {
    let _ = update_projects(app, |projects| {
        for project in projects.iter_mut() {
            if !project.godot_version.is_empty() {
                continue;
            }
            let exact_match = crate::godotenv::detect_version(&project.path)
                .is_some_and(|spec| crate::godotenv::matches_detected(&spec, &version.tag));
            let feature_match = crate::godotenv::project_feature_matches(&project.path, version);
            if exact_match || feature_match {
                project.godot_version = version.tag.clone();
            }
        }
        Ok(())
    });
}

pub fn register_project(
    app: AppHandle,
    path: String,
    godot_version: String,
    category: Option<String>,
) -> Result<Project, String> {
    if !is_project_directory(&path) {
        return Err("Nenhum project.jingu foi encontrado na pasta selecionada. Projetos legados com project.godot também são aceitos.".into());
    }
    let name = resolve_project_name(&path).unwrap_or_else(|| {
        PathBuf::from(&path)
            .file_name()
            .map(|n| n.to_string_lossy().to_string())
            .unwrap_or_else(|| "Untitled".into())
    });

    let mut godot_version = godot_version;
    if godot_version.is_empty() {
        if let Some(pin) = crate::godotenv::read_jingu_pin(&path) {
            godot_version = pin;
        } else {
            let installed = crate::godot_versions::read_registry(&app);
            if let Some(spec) = crate::godotenv::detect_version(&path) {
                if let Some(v) = crate::godotenv::best_match(&spec, &installed) {
                    godot_version = v.tag.clone();
                }
            }
            if godot_version.is_empty() {
                if let Some(v) = crate::godotenv::best_project_feature_match(&path, &installed) {
                    godot_version = v.tag.clone();
                }
            }
        }
    }
    let tags = resolve_project_tags(&path);
    let mut project = Project {
        id: Uuid::new_v4().to_string(),
        name,
        jingu_version: project_version_display(
            &path,
            &godot_version,
            &crate::godot_versions::read_registry(&app),
        ),
        path,
        godot_version,
        created_at: chrono::Utc::now().to_rfc3339(),
        last_opened: None,
        sort_order: 0,
        category,
        pinned: false,
        launch_arguments: String::new(),
        tags,
    };
    update_projects(&app, |projects| {
        if projects
            .iter()
            .any(|item| same_path(&item.path, &project.path))
        {
            return Err("Este projeto já está na biblioteca do Jingu Hub.".into());
        }
        project.sort_order = next_sort_order(projects, &project.category);
        projects.push(project.clone());
        Ok(project.clone())
    })
}

#[tauri::command]
pub fn import_project(
    app: AppHandle,
    path: String,
    godot_version: String,
    category: Option<String>,
) -> Result<Project, String> {
    let effective_category = category.as_ref().and_then(|c| {
        if c.trim().is_empty() {
            None
        } else {
            Some(c.clone())
        }
    });
    let project = register_project(app.clone(), path.clone(), godot_version, effective_category)?;
    undismiss(&app, &path);
    Ok(project)
}

fn validate_project_delete_confirmation(
    path: &Path,
    typed_folder_name: Option<&str>,
) -> Result<(), String> {
    let expected = path
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or("Não foi possível determinar o nome da pasta do projeto.")?;
    let typed = typed_folder_name.map(str::trim).unwrap_or("");
    if typed != expected {
        return Err(
            "O nome digitado não corresponde exatamente ao nome da pasta do projeto.".into(),
        );
    }
    Ok(())
}

fn validate_project_directory_for_delete(path: &Path) -> Result<(), String> {
    let metadata = fs::symlink_metadata(path).map_err(|error| error.to_string())?;
    if !metadata.file_type().is_dir() {
        return Err("O alvo da exclusão não é uma pasta de projeto regular.".into());
    }
    let has_regular_config = ["project.jingu", "project.godot"].iter().any(|name| {
        fs::symlink_metadata(path.join(name))
            .ok()
            .is_some_and(|metadata| metadata.file_type().is_file())
    });
    if !has_regular_config {
        return Err(
            "A pasta deixou de conter project.jingu/project.godot regular; exclusão cancelada."
                .into(),
        );
    }
    Ok(())
}

fn resolve_project_delete_target(
    path: &Path,
    typed_folder_name: Option<&str>,
) -> Result<Option<PathBuf>, String> {
    validate_project_delete_confirmation(path, typed_folder_name)?;
    if !path.is_absolute()
        || path
            .components()
            .any(|component| matches!(component, Component::CurDir | Component::ParentDir))
    {
        return Err(
            "O caminho persistido do projeto é relativo ou contém navegação insegura.".into(),
        );
    }
    match fs::symlink_metadata(path) {
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => {
            return Err(format!(
                "Não foi possível inspecionar o alvo da exclusão: {error}"
            ))
        }
        Ok(_) => {}
    }
    validate_project_directory_for_delete(path)?;
    let canonical = fs::canonicalize(path)
        .map_err(|error| format!("Não foi possível resolver a pasta do projeto: {error}"))?;
    validate_project_directory_for_delete(&canonical)?;
    Ok(Some(canonical))
}

#[tauri::command]
pub async fn remove_project(
    app: AppHandle,
    id: String,
    delete_files: bool,
    typed_folder_name: Option<String>,
) -> Result<(), String> {
    let project = {
        let _guard = project_registry_lock()
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        read_projects(&app)
            .into_iter()
            .find(|project| project.id == id)
            .ok_or("Project not found")?
    };

    let mut dismissed_before = None;
    if delete_files {
        let path = PathBuf::from(&project.path);
        let target = resolve_project_delete_target(&path, typed_folder_name.as_deref())?;
        if let Some(path) = target {
            tokio::task::spawn_blocking(move || -> Result<(), String> {
                validate_project_directory_for_delete(&path)?;
                trash::delete_all([&path])
                    .map_err(|e| format!("Não foi possível mover o projeto para a lixeira: {e}"))?;
                Ok(())
            })
            .await
            .map_err(|e| format!("Falha interna ao remover o projeto: {e}"))??;
        }
    } else {
        let mut settings = crate::settings::read_settings(&app);
        if !contains_path(&settings.dismissed_project_paths, &project.path) {
            dismissed_before = Some(settings.clone());
            settings.dismissed_project_paths.push(project.path.clone());
            crate::settings::write_settings(&app, &settings).map_err(|e| e.to_string())?;
        }
    }

    let registry_result = update_projects(&app, |projects| {
        if let Some(index) = projects.iter().position(|item| item.id == id) {
            projects.remove(index);
        }
        Ok(())
    });
    if let Err(registry_error) = registry_result {
        if let Some(previous_settings) = dismissed_before {
            let rollback = crate::settings::write_settings(&app, &previous_settings);
            return match rollback {
                Ok(()) => Err(registry_error),
                Err(rollback_error) => Err(format!(
                    "Não foi possível atualizar a biblioteca de projetos ({registry_error}) e a reversão das configurações também falhou ({rollback_error})."
                )),
            };
        }
        return Err(registry_error);
    }

    Ok(())
}

#[tauri::command]
pub fn update_project(
    app: AppHandle,
    id: String,
    updates: ProjectUpdate,
) -> Result<Project, String> {
    update_projects(&app, |projects| {
        let project = projects
            .iter_mut()
            .find(|project| project.id == id)
            .ok_or("Project not found")?;
        if let Some(name) = updates.name {
            project.name = name;
        }
        if let Some(version) = updates.godot_version {
            if project.godot_version != version {
                return Err("A versão da Jingu Engine não pode ser alterada diretamente. Use a troca segura de versão para criar uma cópia do projeto.".into());
            }
        }
        if let Some(category) = updates.category {
            project.category = if category.trim().is_empty() {
                None
            } else {
                Some(category)
            };
        }
        if let Some(pinned) = updates.pinned {
            project.pinned = pinned;
        }
        if let Some(launch_arguments) = updates.launch_arguments {
            project.launch_arguments = launch_arguments;
        }
        Ok(project.clone())
    })
}

#[tauri::command]
pub async fn open_project(
    app: AppHandle,
    id: String,
    editor: bool,
    console: Option<bool>,
) -> Result<(), String> {
    let projects = read_projects(&app);
    let project_index = projects
        .iter()
        .position(|project| project.id == id)
        .ok_or("Project not found")?;
    let project = projects[project_index].clone();
    let project_name = project.name.clone();
    let project_version = project.godot_version.clone();

    if project.godot_version.is_empty() {
        return Err("Nenhuma versão da Jingu Engine está vinculada a este projeto".into());
    }

    let versions = crate::godot_versions::list_installed_godot_versions_blocking(&app)?;
    let version = versions
        .iter()
        .find(|v| v.tag == project.godot_version)
        .cloned()
        .ok_or("A versão vinculada da Jingu Engine não está instalada")?;
    if version.restricted
        && crate::github::authorized_private_repository(
            crate::github::PrivateResource::EngineReleases,
        )
        .await?
        .is_none()
    {
        return Err(
            "A versão TEST vinculada a este projeto requer uma conta GitHub atualmente autorizada."
                .into(),
        );
    }

    let mut args = vec!["--path".to_string(), project.path.clone()];
    if editor {
        args.push("-e".to_string());
    }
    args.extend(
        project
            .launch_arguments
            .split_whitespace()
            .map(str::to_string),
    );

    let settings = settings::read_settings(&app);
    let use_console = console.unwrap_or(settings.launch_with_console);

    let launched = crate::godot_versions::spawn_editor(
        &app,
        Path::new(&version.executable_path),
        &args,
        &project_name,
        use_console,
    )?;
    #[cfg(unix)]
    let pid_file = launched.pid_file.clone();

    let opened_at = chrono::Utc::now().to_rfc3339();
    update_projects(&app, |projects| {
        if let Some(current) = projects.iter_mut().find(|current| current.id == id) {
            current.last_opened = Some(opened_at);
        }
        Ok(())
    })?;

    let _ = crate::tray::refresh_tray_menu(app.clone());

    if let Some(state) = app.try_state::<ActiveProcesses>() {
        state.0.lock().unwrap_or_else(|e| e.into_inner()).insert(
            id.clone(),
            TrackedProcess {
                handle: TrackedHandle::Child(launched.child),
            },
        );
    }

    let _ = app.emit(
        "project:launched",
        serde_json::json!({
            "id": id.clone(),
            "name": project_name,
            "version": project_version,
        }),
    );

    let mut reopen_when_closed = false;

    if settings.close_on_project_open {
        #[cfg(target_os = "macos")]
        let keep_alive = true;
        #[cfg(not(target_os = "macos"))]
        let keep_alive = settings.minimize_to_tray && crate::tray::is_available(&app);

        if keep_alive {
            if let Some(window) = app.get_webview_window("main") {
                let _ = window.hide();
            }
            reopen_when_closed = settings.reopen_after_godot_closes;
        } else {
            app.exit(0);
        }
    }

    let app_clone = app.clone();
    let watched = id.clone();
    std::thread::spawn(move || {
        #[cfg(unix)]
        if let Some(file) = pid_file {
            adopt_terminal_pid(&app_clone, &watched, &file);
        }

        wait_until_exited(&app_clone, &watched);

        if reopen_when_closed {
            if let Some(window) = app_clone.get_webview_window("main") {
                let _ = window.show();
                let _ = window.set_focus();
            }
        }
    });

    Ok(())
}

#[cfg(unix)]
fn adopt_terminal_pid(app: &AppHandle, id: &str, pid_file: &Path) {
    const ATTEMPTS: u32 = 200;

    for _ in 0..ATTEMPTS {
        if let Some(pid) = crate::terminal::read_pid_file(pid_file) {
            let _ = fs::remove_file(pid_file);

            let replaced = {
                let Some(state) = app.try_state::<ActiveProcesses>() else {
                    return;
                };
                let mut active = state.0.lock().unwrap_or_else(|e| e.into_inner());
                active
                    .get_mut(id)
                    .map(|tracked| std::mem::replace(&mut tracked.handle, TrackedHandle::Pid(pid)))
            };

            if let Some(TrackedHandle::Child(mut launcher)) = replaced {
                let _ = launcher.wait();
            }
            return;
        }
        std::thread::sleep(std::time::Duration::from_millis(50));
    }
}

fn wait_until_exited(app: &AppHandle, id: &str) {
    const POLL: std::time::Duration = std::time::Duration::from_millis(500);

    loop {
        let Some(state) = app.try_state::<ActiveProcesses>() else {
            return;
        };

        let exited = {
            let mut active = state.0.lock().unwrap_or_else(|e| e.into_inner());
            let running = match active.get_mut(id) {
                Some(tracked) => tracked.is_running(),
                None => return,
            };
            if !running {
                active.remove(id);
            }
            !running
        };

        if exited {
            let _ = app.emit("project:exited", serde_json::json!({ "id": id }));
            return;
        }

        std::thread::sleep(POLL);
    }
}

#[cfg(all(unix, not(target_os = "macos")))]
fn spawn_detached_checked(bin: &str, args: &[std::ffi::OsString]) -> Result<(), String> {
    let mut cmd = std::process::Command::new(bin);
    crate::terminal::sanitize_child_env(&mut cmd);
    cmd.args(args);
    let mut child = cmd.spawn().map_err(|e| format!("{bin}: {e}"))?;

    let deadline = std::time::Instant::now() + std::time::Duration::from_millis(1500);
    loop {
        match child.try_wait() {
            Ok(Some(status)) if status.success() => return Ok(()),
            Ok(Some(_)) => return Err(format!("{bin} exited with an error")),
            Ok(None) if std::time::Instant::now() >= deadline => return Ok(()),
            Ok(None) => std::thread::sleep(std::time::Duration::from_millis(50)),
            Err(e) => return Err(format!("{bin}: {e}")),
        }
    }
}

#[cfg(all(unix, not(target_os = "macos")))]
fn open_folder_linux(path: &str, dir: &Path) -> Result<(), String> {
    let dir_arg = dir.as_os_str().to_os_string();
    let path_arg = std::ffi::OsString::from(path);

    let mut last_err = String::from("no file manager could open the folder");

    for (bin, args) in [("xdg-open", vec![dir_arg.clone()])] {
        match spawn_detached_checked(bin, &args) {
            Ok(()) => return Ok(()),
            Err(e) => last_err = e,
        }
    }

    let file_managers: [(&str, Vec<std::ffi::OsString>); 12] = [
        (
            "gio",
            vec![std::ffi::OsString::from("open"), path_arg.clone()],
        ),
        ("nautilus", vec![path_arg.clone()]),
        ("org.gnome.Nautilus", vec![path_arg.clone()]),
        ("dolphin", vec![path_arg.clone()]),
        ("thunar", vec![path_arg.clone()]),
        ("pcmanfm", vec![path_arg.clone()]),
        ("pcmanfm-qt", vec![path_arg.clone()]),
        ("nemo", vec![path_arg.clone()]),
        ("caja", vec![path_arg.clone()]),
        ("konqueror", vec![path_arg.clone()]),
        (
            "exo-open",
            vec![
                std::ffi::OsString::from("--launch"),
                std::ffi::OsString::from("FileManager"),
                path_arg.clone(),
            ],
        ),
        ("gnome-open", vec![path_arg.clone()]),
    ];
    for (bin, args) in file_managers {
        match spawn_detached_checked(bin, &args) {
            Ok(()) => return Ok(()),
            Err(e) => last_err = e,
        }
    }

    Err(format!(
        "{last_err}.\n\nNo file manager was found. Install one (e.g. `sudo pacman -S nautilus` \
         on Arch) or register your default folder handler:\n  xdg-mime default <file-manager>.desktop \
         inode/directory"
    ))
}

#[tauri::command]
pub fn open_project_folder(path: String) -> Result<(), String> {
    let dir = PathBuf::from(&path);
    if !dir.exists() {
        return Err("Esta pasta não existe mais".into());
    }

    #[cfg(target_os = "windows")]
    let result = std::process::Command::new("explorer").arg(&dir).spawn();

    #[cfg(target_os = "macos")]
    let result = std::process::Command::new("open").arg(&dir).spawn();

    #[cfg(all(unix, not(target_os = "macos")))]
    return open_folder_linux(&path, &dir);

    #[cfg(any(target_os = "windows", target_os = "macos"))]
    result.map(|_| ()).map_err(|e| e.to_string())
}

#[tauri::command]
pub async fn pick_file(app: tauri::AppHandle) -> Option<String> {
    use tauri_plugin_dialog::DialogExt;
    let (tx, rx) = std::sync::mpsc::channel();
    app.dialog()
        .file()
        .add_filter("Images", &["png", "svg", "jpg", "jpeg", "webp"])
        .pick_file(move |file| {
            let _ = tx.send(file);
        });
    rx.recv().ok().flatten().map(|p| p.to_string())
}

fn find_resource_by_uid(
    dir: &Path,
    target_uid: &str,
    depth: usize,
    budget: &mut usize,
) -> Option<PathBuf> {
    if depth > 14 || *budget == 0 {
        return None;
    }
    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return None,
    };

    let mut subdirs: Vec<PathBuf> = Vec::new();
    for entry in entries.flatten() {
        if *budget == 0 {
            break;
        }
        *budget -= 1;
        let path = entry.path();
        if path.is_dir() {
            let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
            if name == ".git" || name == ".godot" || name == "node_modules" {
                continue;
            }
            subdirs.push(path);
        } else if path.extension().and_then(|e| e.to_str()) == Some("import") {
            if let Ok(content) = fs::read_to_string(&path) {
                let target_line = format!("uid=\"{}\"", target_uid);
                if content.lines().any(|l| l.trim() == target_line) {
                    let mut src = path.clone();
                    src.set_extension("");
                    return Some(src);
                }
            }
        }
    }

    for sub in subdirs {
        if let Some(found) = find_resource_by_uid(&sub, target_uid, depth + 1, budget) {
            return Some(found);
        }
    }
    None
}

fn resolve_project_icon(project_path: &str) -> Option<(Vec<u8>, &'static str)> {
    let dir = PathBuf::from(project_path);
    let config_file = project_config_path(project_path)?;
    let mut icon_rel: Option<String> = None;
    let mut icon_uid: Option<String> = None;

    if let Ok(content) = fs::read_to_string(&config_file) {
        for line in content.lines() {
            let line = line.trim();
            if let Some(rest) = line.strip_prefix("config/icon=") {
                let cleaned = rest.trim().trim_matches('"');
                if let Some(uid) = cleaned.strip_prefix("uid://") {
                    icon_uid = Some(format!("uid://{uid}"));
                } else {
                    icon_rel = Some(cleaned.trim_start_matches("res://").to_string());
                }
                break;
            }
        }
    }

    let mut candidates: Vec<String> = Vec::new();
    if let Some(p) = icon_rel {
        candidates.push(p);
    }
    if let Some(uid) = icon_uid {
        let mut budget = 8000usize;
        if let Some(found) = find_resource_by_uid(&dir, &uid, 0, &mut budget) {
            if let Ok(rel) = found.strip_prefix(&dir) {
                if let Some(rel_str) = rel.to_str() {
                    candidates.push(rel_str.to_string());
                }
            }
        }
    }

    for fallback in ["icon.svg", "icon.png"] {
        if !candidates.iter().any(|c| c == fallback) {
            candidates.push(fallback.to_string());
        }
    }

    for rel in candidates {
        let full = dir.join(&rel);
        if full.is_file() {
            if let Ok(bytes) = fs::read(&full) {
                let lower = rel.to_lowercase();
                let mime = if lower.ends_with(".svg") {
                    "image/svg+xml"
                } else if lower.ends_with(".png") {
                    "image/png"
                } else if lower.ends_with(".jpg") || lower.ends_with(".jpeg") {
                    "image/jpeg"
                } else {
                    continue;
                };
                return Some((bytes, mime));
            }
        }
    }
    None
}

pub(crate) fn resolve_project_tags(project_path: &str) -> Vec<String> {
    let Some(config_file) = project_config_path(project_path) else {
        return vec![];
    };
    let content = match fs::read_to_string(&config_file) {
        Ok(c) => c,
        Err(_) => return vec![],
    };
    for line in content.lines() {
        let line = line.trim();
        if let Some(rest) = line.strip_prefix("config/tags=") {
            if let Some(inner) = rest
                .strip_prefix("PackedStringArray(")
                .and_then(|s| s.strip_suffix(')'))
            {
                let tags: Vec<String> = inner
                    .split(',')
                    .filter_map(|t| {
                        let t = t.trim().trim_matches('"');
                        if t.is_empty() {
                            None
                        } else {
                            Some(t.to_string())
                        }
                    })
                    .collect();
                return tags;
            }
        }
    }
    vec![]
}

pub(crate) fn resolve_project_name(project_path: &str) -> Option<String> {
    let config_file = project_config_path(project_path)?;
    let content = fs::read_to_string(&config_file).ok()?;
    for line in content.lines() {
        let line = line.trim();
        if let Some(rest) = line.strip_prefix("config/name=") {
            if let Some(cleaned) = unescape_project_setting_string(rest) {
                if !cleaned.is_empty() {
                    return Some(cleaned);
                }
            }
            break;
        }
    }
    None
}

#[tauri::command]
pub async fn get_project_icon(path: String) -> Option<String> {
    tokio::task::spawn_blocking(move || {
        let mtime = project_config_path(&path)
            .and_then(|config| fs::metadata(config).ok())
            .and_then(|metadata| metadata.modified().ok());

        if let Some(cached) = icon_cache()
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .get(&path)
        {
            if cached.project_config_mtime == mtime {
                return cached.data.clone();
            }
        }

        let (bytes, mime) = match resolve_project_icon(&path) {
            Some(v) => v,
            None => {
                icon_cache()
                    .lock()
                    .unwrap_or_else(|e| e.into_inner())
                    .insert(
                        path.clone(),
                        CachedIcon {
                            project_config_mtime: mtime,
                            data: None,
                        },
                    );
                return None;
            }
        };
        use base64::{engine::general_purpose, Engine as _};
        let encoded = general_purpose::STANDARD.encode(bytes);
        let data_url = format!("data:{};base64,{}", mime, encoded);

        icon_cache()
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .insert(
                path.clone(),
                CachedIcon {
                    project_config_mtime: mtime,
                    data: Some(data_url.clone()),
                },
            );
        Some(data_url)
    })
    .await
    .ok()
    .flatten()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn naming_convention_kebab() {
        assert_eq!(
            apply_naming_convention("New Game", "kebab-case"),
            "new-game"
        );
        assert_eq!(
            apply_naming_convention("My Awesome Game", "kebab-case"),
            "my-awesome-game"
        );
        assert_eq!(
            apply_naming_convention("Pixels & Dreams", "kebab-case"),
            "pixels-dreams"
        );
    }

    #[test]
    fn naming_convention_snake() {
        assert_eq!(
            apply_naming_convention("New Game", "snake_case"),
            "new_game"
        );
    }

    #[test]
    fn naming_convention_camel() {
        assert_eq!(apply_naming_convention("New Game", "camelCase"), "newGame");
    }

    #[test]
    fn naming_convention_pascal() {
        assert_eq!(apply_naming_convention("New Game", "PascalCase"), "NewGame");
    }

    #[test]
    fn naming_convention_title() {
        assert_eq!(
            apply_naming_convention("new game", "Title Case"),
            "New Game"
        );
    }

    #[test]
    fn naming_convention_keep_and_unknown() {
        assert_eq!(apply_naming_convention("New Game", "keep"), "New Game");
        assert_eq!(apply_naming_convention("New Game", "bogus"), "New Game");
    }

    #[test]
    fn naming_convention_splits_camel_and_acronyms() {
        assert_eq!(apply_naming_convention("myGame", "kebab-case"), "my-game");
        assert_eq!(
            apply_naming_convention("HTTPServer", "kebab-case"),
            "http-server"
        );
        assert_eq!(
            apply_naming_convention("v0.0.1 - The Beginning", "snake_case"),
            "v0_0_1_the_beginning"
        );
    }

    #[test]
    fn naming_convention_empty_falls_back() {
        assert_eq!(apply_naming_convention("  ", "kebab-case"), "");
        assert_eq!(apply_naming_convention("!!!", "kebab-case"), "!!!");
    }

    #[test]
    fn project_config_prefers_jingu_and_accepts_legacy_godot() {
        let root =
            std::env::temp_dir().join(format!("jingu-hub-project-config-{}", Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        fs::write(
            root.join("project.godot"),
            "[application]\nconfig/name=\"Legacy\"\n",
        )
        .unwrap();
        assert_eq!(
            project_config_path(&root.to_string_lossy()),
            Some(root.join("project.godot"))
        );
        fs::write(
            root.join("project.jingu"),
            "[application]\nconfig/name=\"Jingu\"\n",
        )
        .unwrap();
        assert_eq!(
            project_config_path(&root.to_string_lossy()),
            Some(root.join("project.jingu"))
        );
        assert_eq!(
            resolve_project_name(&root.to_string_lossy()).as_deref(),
            Some("Jingu")
        );
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn project_lifecycle_fixture_preserves_original_and_excludes_generated_state() {
        let root =
            std::env::temp_dir().join(format!("jingu-project-lifecycle-ç-日本-{}", Uuid::new_v4()));
        let source = root.join("Projeto Ç 日本");
        let copied = root.join("Projeto Ç 日本-jingu-2.0.0");
        fs::create_dir_all(source.join("assets")).unwrap();
        fs::create_dir_all(source.join(".godot")).unwrap();
        fs::create_dir_all(source.join(".import")).unwrap();
        fs::create_dir_all(source.join(".jingu_engine")).unwrap();
        fs::create_dir_all(source.join(".git")).unwrap();
        fs::write(
            source.join("project.jingu"),
            "[application]\nconfig/name=\"Original\"\n",
        )
        .unwrap();
        fs::write(source.join("assets").join("árvore.txt"), b"owner-data").unwrap();
        fs::write(source.join(".godot").join("cache"), b"generated").unwrap();
        fs::write(source.join(".import").join("cache"), b"generated").unwrap();
        fs::write(source.join(".jingu_engine").join("cache"), b"generated").unwrap();
        fs::write(source.join(".git").join("HEAD"), b"ref: refs/heads/main\n").unwrap();

        assert!(is_project_directory(&source.to_string_lossy()));
        assert_eq!(
            resolve_project_name(&source.to_string_lossy()).as_deref(),
            Some("Original")
        );
        copy_project_tree(&source, &copied).unwrap();
        set_project_config_name(&copied.to_string_lossy(), "Cópia \\\"segura\\\"").unwrap();

        assert_eq!(
            fs::read(source.join("assets").join("árvore.txt")).unwrap(),
            b"owner-data"
        );
        assert_eq!(
            fs::read(copied.join("assets").join("árvore.txt")).unwrap(),
            b"owner-data"
        );
        assert!(copied.join(".git").join("HEAD").is_file());
        assert!(!copied.join(".godot").exists());
        assert!(!copied.join(".import").exists());
        assert!(!copied.join(".jingu_engine").exists());
        assert_eq!(
            resolve_project_name(&copied.to_string_lossy()).as_deref(),
            Some("Cópia \\\"segura\\\"")
        );

        let blocked = root.join("blocked-destination");
        fs::write(&blocked, b"not-a-directory").unwrap();
        assert!(copy_project_tree(&source, &blocked).is_err());
        assert_eq!(
            fs::read(source.join("assets").join("árvore.txt")).unwrap(),
            b"owner-data"
        );
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn project_delete_confirmation_and_version_slug_fail_closed() {
        let path = PathBuf::from("fixtures").join("Projeto Ç 日本");
        assert!(validate_project_delete_confirmation(&path, Some("Projeto Ç 日本")).is_ok());
        assert!(validate_project_delete_confirmation(&path, Some("projeto ç 日本")).is_err());
        assert!(validate_project_delete_confirmation(&path, Some("..")).is_err());
        assert!(validate_project_delete_confirmation(&path, None).is_err());
        assert_eq!(
            safe_version_slug("../../v2.0.0 --exec"),
            "..-..-v2.0.0---exec"
        );
        assert!(!safe_version_slug("../../v2.0.0 --exec").contains(['/', '\\']));
    }

    #[test]
    fn destructive_project_target_is_revalidated_against_corrupt_registry_paths() {
        let root = std::env::temp_dir().join(format!("jingu-delete-target-{}", Uuid::new_v4()));
        let project = root.join("Projeto ç 日本");
        fs::create_dir_all(&project).unwrap();
        fs::write(project.join("project.jingu"), b"[application]\n").unwrap();
        assert_eq!(
            resolve_project_delete_target(&project, Some("Projeto ç 日本")).unwrap(),
            Some(fs::canonicalize(&project).unwrap())
        );

        fs::remove_file(project.join("project.jingu")).unwrap();
        assert!(resolve_project_delete_target(&project, Some("Projeto ç 日本")).is_err());
        fs::create_dir_all(project.join("project.godot")).unwrap();
        assert!(resolve_project_delete_target(&project, Some("Projeto ç 日本")).is_err());
        assert!(resolve_project_delete_target(
            Path::new("relative-project"),
            Some("relative-project")
        )
        .is_err());

        fs::remove_dir_all(project.join("project.godot")).unwrap();
        fs::write(project.join("project.jingu"), b"[application]\n").unwrap();
        let navigated = root.join("child").join("..").join("Projeto ç 日本");
        assert!(resolve_project_delete_target(&navigated, Some("Projeto ç 日本")).is_err());
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn new_project_path_and_display_name_validation_blocks_escape_and_controls() {
        validate_new_project_name("Jogo ç 日本").unwrap();
        validate_project_folder_component("Jogo ç 日本").unwrap();
        for name in ["", " leading", "trailing ", "line\nbreak", "nul\0byte"] {
            assert!(
                validate_new_project_name(name).is_err(),
                "accepted {name:?}"
            );
        }
        for folder in [
            "",
            ".",
            "..",
            "../escape",
            "..\\escape",
            "C:\\absolute",
            "/absolute",
            "name.",
            "name ",
            "bad?.dir",
            "CON",
            "nul.txt",
            "COM1",
            "LPT9.log",
        ] {
            assert!(
                validate_project_folder_component(folder).is_err(),
                "accepted {folder:?}"
            );
        }
        let hostile = apply_naming_convention("..\\outside", "keep");
        assert!(validate_project_folder_component(&hostile).is_err());
    }

    #[test]
    fn concurrent_project_directory_and_registry_updates_are_lossless() {
        let root = std::env::temp_dir().join(format!("jingu-project-race-{}", Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let mut creators = Vec::new();
        for _ in 0..16 {
            let root = root.clone();
            creators.push(std::thread::spawn(move || {
                create_project_directory(&root, "same-project").is_ok()
            }));
        }
        assert_eq!(
            creators
                .into_iter()
                .map(|thread| thread.join().unwrap())
                .filter(|created| *created)
                .count(),
            1
        );

        let registry = root.join("projects.json");
        let mut writers = Vec::new();
        for index in 0..32 {
            let registry = registry.clone();
            writers.push(std::thread::spawn(move || {
                update_projects_path(&registry, |projects| {
                    projects.push(Project {
                        id: format!("project-{index}"),
                        name: format!("Projeto {index}"),
                        path: format!(r"C:\\fixture\\project-{index}"),
                        godot_version: String::new(),
                        jingu_version: String::new(),
                        created_at: "2026-08-25T00:00:00Z".into(),
                        last_opened: None,
                        category: None,
                        pinned: false,
                        sort_order: index,
                        launch_arguments: String::new(),
                        tags: Vec::new(),
                    });
                    Ok(())
                })
                .unwrap();
            }));
        }
        for writer in writers {
            writer.join().unwrap();
        }
        let projects: Vec<Project> = persist::read_json(&registry);
        assert_eq!(projects.len(), 32);
        assert_eq!(
            projects
                .iter()
                .map(|project| &project.id)
                .collect::<std::collections::HashSet<_>>()
                .len(),
            32
        );
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn project_name_setting_round_trips_escapes_and_rejects_malformed_values() {
        let name = "Linha 1\\\"citada\\\"\nLinha 2\tç-日本";
        let encoded = format!("\"{}\"", escape_project_setting_string(name));
        assert!(!encoded.contains("\nLinha 2"));
        assert_eq!(
            unescape_project_setting_string(&encoded).as_deref(),
            Some(name)
        );
        assert!(unescape_project_setting_string("unquoted").is_none());
        assert!(unescape_project_setting_string("\"dangling\\\"").is_none());
        assert!(unescape_project_setting_string("\"unknown\\xescape\"").is_none());
    }

    #[test]
    fn missing_project_is_rejected_and_truncated_config_never_yields_a_trusted_name() {
        let root = std::env::temp_dir().join(format!("jingu-project-missing-{}", Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        assert!(!is_project_directory(&root.to_string_lossy()));
        fs::write(root.join("project.jingu"), b"[application\nconfig/name=\"").unwrap();
        assert!(is_project_directory(&root.to_string_lossy()));
        assert!(resolve_project_name(&root.to_string_lossy()).is_none());
        let _ = fs::remove_dir_all(root);
    }
}

#[derive(Debug, Clone, serde::Serialize)]
pub struct ProjectVersionChangeResult {
    pub project: Project,
    pub copied: bool,
    pub original_path: String,
    pub new_path: String,
}

fn safe_version_slug(version: &str) -> String {
    version
        .trim()
        .trim_start_matches('v')
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '.' || c == '-' {
                c
            } else {
                '-'
            }
        })
        .collect::<String>()
        .trim_matches('-')
        .to_string()
}

fn copy_project_tree(source: &Path, destination: &Path) -> Result<(), String> {
    const EXCLUDED_DIRS: &[&str] = &[".godot", ".import", ".jingu_engine"];
    fs::create_dir_all(destination).map_err(|e| e.to_string())?;
    for entry in fs::read_dir(source).map_err(|e| e.to_string())? {
        let entry = entry.map_err(|e| e.to_string())?;
        let name = entry.file_name();
        let name_string = name.to_string_lossy();
        if EXCLUDED_DIRS
            .iter()
            .any(|excluded| name_string.eq_ignore_ascii_case(excluded))
        {
            continue;
        }
        let src = entry.path();
        let dst = destination.join(&name);
        let meta = fs::symlink_metadata(&src).map_err(|e| e.to_string())?;
        if meta.file_type().is_symlink() {
            // Avoid accidentally copying data from outside the project tree.
            continue;
        }
        if name_string.eq_ignore_ascii_case(".git") && !meta.is_dir() {
            // A linked worktree stores `.git` as a pointer to metadata outside
            // this project. Copying that pointer would make the new project
            // depend on the original worktree, so only self-contained `.git/`
            // directories are preserved.
            continue;
        }
        if meta.is_dir() {
            copy_project_tree(&src, &dst)?;
        } else if meta.is_file() {
            fs::copy(&src, &dst).map_err(|e| format!("Falha ao copiar {}: {e}", src.display()))?;
        }
    }
    Ok(())
}

/// Change the Jingu Engine bound to a project. If the requested version differs
/// from the original binding, create a sibling copy first so a newer/older
/// editor can never migrate the user's only copy by accident.
#[tauri::command]
pub async fn set_project_engine_version(
    app: AppHandle,
    id: String,
    version: String,
) -> Result<ProjectVersionChangeResult, String> {
    let requested = version.trim().to_string();
    if requested.is_empty() {
        return Err("Selecione uma versão instalada da Jingu Engine.".into());
    }
    let installed = crate::godot_versions::list_installed_godot_versions(app.clone()).await?;
    if !installed.iter().any(|v| v.tag == requested) {
        return Err("A versão selecionada da Jingu Engine não está instalada.".into());
    }

    let projects = read_projects(&app);
    let index = projects
        .iter()
        .position(|p| p.id == id)
        .ok_or("Projeto não encontrado")?;
    let original = projects[index].clone();
    if original.godot_version == requested {
        return Ok(ProjectVersionChangeResult {
            project: original.clone(),
            copied: false,
            original_path: original.path.clone(),
            new_path: original.path,
        });
    }

    let source = PathBuf::from(&original.path);
    let parent = source
        .parent()
        .ok_or("Não foi possível determinar a pasta pai do projeto")?;
    let base = source
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or("projeto");
    let version_slug = safe_version_slug(&requested);
    let preferred = format!("{base}-jingu-{version_slug}");
    let mut final_path = parent.join(&preferred);
    let mut suffix = 2u32;
    while final_path.exists() {
        final_path = parent.join(format!("{preferred}-{suffix}"));
        suffix += 1;
    }
    let final_name = final_path
        .file_name()
        .ok_or("Não foi possível determinar o nome da cópia do projeto")?
        .to_string_lossy();
    let staging = parent.join(format!(".{final_name}.jingu-copying-{}", Uuid::new_v4()));
    let source_for_copy = source.clone();
    let staging_for_copy = staging.clone();
    let final_for_copy = final_path.clone();
    let copy_result = match tokio::task::spawn_blocking(move || {
        copy_project_tree(&source_for_copy, &staging_for_copy)
            .and_then(|_| fs::rename(&staging_for_copy, &final_for_copy).map_err(|e| e.to_string()))
    })
    .await
    {
        Ok(result) => result,
        Err(e) => {
            let _ = fs::remove_dir_all(&staging);
            return Err(format!("Falha interna ao copiar o projeto: {e}"));
        }
    };
    if let Err(e) = copy_result {
        let _ = fs::remove_dir_all(&staging);
        return Err(format!(
            "Não foi possível criar a cópia segura do projeto: {e}"
        ));
    }

    let copied_path = final_path.to_string_lossy().to_string();
    let target = installed
        .iter()
        .find(|version| version.tag == requested)
        .ok_or("A versão selecionada deixou de estar disponível durante a cópia")?;
    let target_display = if target.managed_install == Some(false) {
        String::new()
    } else {
        target.version.trim().trim_start_matches('v').to_string()
    };
    let copied_suffix = if !target_display.is_empty() {
        format!("Jingu {target_display}")
    } else if let Some(runtime) = target
        .runtime_version
        .as_deref()
        .filter(|value| !value.trim().is_empty())
    {
        format!("Jingu local {}", runtime.trim())
    } else {
        "Jingu local".to_string()
    };
    let copied_name = format!("{} - {}", original.name, copied_suffix);
    if let Err(e) = set_project_config_name(&copied_path, &copied_name) {
        let _ = fs::remove_dir_all(&final_path);
        return Err(format!(
            "A cópia foi cancelada porque o nome do novo projeto não pôde ser salvo: {e}"
        ));
    }
    let mut copied = Project {
        id: Uuid::new_v4().to_string(),
        name: copied_name,
        path: copied_path.clone(),
        godot_version: requested.clone(),
        jingu_version: target_display,
        created_at: chrono::Utc::now().to_rfc3339(),
        last_opened: None,
        category: original.category.clone(),
        pinned: false,
        sort_order: 0,
        launch_arguments: original.launch_arguments.clone(),
        tags: original.tags.clone(),
    };
    if let Err(e) = crate::godotenv::pin_version(&copied.path, &requested) {
        let _ = fs::remove_dir_all(&final_path);
        return Err(format!(
            "A cópia foi cancelada porque não foi possível vincular a versão: {e}"
        ));
    }
    let registered = update_projects(&app, |projects| {
        if !projects.iter().any(|project| project.id == original.id) {
            return Err("O projeto original foi removido durante a cópia; nenhuma entrada nova foi registrada.".into());
        }
        if projects
            .iter()
            .any(|project| same_path(&project.path, &copied.path))
        {
            return Err("A cópia já foi registrada por outra operação concorrente.".into());
        }
        copied.sort_order = next_sort_order(projects, &original.category);
        projects.push(copied.clone());
        Ok(copied.clone())
    });
    let copied = match registered {
        Ok(copied) => copied,
        Err(error) => {
            let _ = fs::remove_dir_all(&final_path);
            return Err(error);
        }
    };
    Ok(ProjectVersionChangeResult {
        project: copied,
        copied: true,
        original_path: original.path,
        new_path: copied_path,
    })
}
