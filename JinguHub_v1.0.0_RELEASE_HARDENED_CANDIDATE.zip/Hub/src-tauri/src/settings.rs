/**************************************************************************/
/*  settings.rs                                                         */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use crate::error::AppResult;
use crate::models::AppSettings;
use crate::persist;
use std::path::PathBuf;
use tauri::AppHandle;

fn settings_file(app: &AppHandle) -> PathBuf {
    crate::paths::app_data_dir(app).join("settings.json")
}

fn persist_if_changed(app: &AppHandle, settings: &AppSettings, changed: bool) {
    if changed {
        let _ = write_settings(app, settings);
    }
}

fn old_default_projects(old_root: &std::path::Path) -> String {
    old_root.join("Projects").to_string_lossy().to_string()
}

fn old_default_engines(old_root: &std::path::Path) -> String {
    old_root
        .join("Versions")
        .join("Jingu Engine")
        .to_string_lossy()
        .to_string()
}

fn normalized_path_text(value: &str) -> String {
    let trimmed = value.trim().trim_end_matches(['\\', '/']);
    #[cfg(target_os = "windows")]
    {
        trimmed.replace('/', "\\").to_ascii_lowercase()
    }
    #[cfg(not(target_os = "windows"))]
    {
        trimmed.to_string()
    }
}

fn same_path_text(left: &str, right: &str) -> bool {
    normalized_path_text(left) == normalized_path_text(right)
}

pub fn apply_managed_defaults(
    app: &AppHandle,
    settings: &mut AppSettings,
    previous: Option<&AppSettings>,
) -> bool {
    let mut changed = false;

    // Preserve the original managed root so child defaults from an older build
    // can be migrated together with it. On Windows, legacy Documents\Jingu
    // defaults are moved to %USERPROFILE%\Jingu to avoid Controlled Folder
    // Access stalls while custom user paths remain untouched.
    let original_root = settings
        .workspace_root
        .as_ref()
        .map(|value| value.trim())
        .filter(|value| !value.is_empty())
        .map(PathBuf::from);
    let previous_root = previous
        .and_then(|item| item.workspace_root.as_ref())
        .map(|value| value.trim())
        .filter(|value| !value.is_empty())
        .map(PathBuf::from)
        .or_else(|| original_root.clone());

    match original_root.as_ref() {
        None => {
            let resolved = crate::paths::default_workspace_root(app);
            settings.workspace_root = Some(resolved.to_string_lossy().to_string());
            changed = true;
        }
        Some(root) if crate::paths::is_managed_documents_workspace(app, root) => {
            let resolved = crate::paths::default_workspace_root(app);
            if !same_path_text(&root.to_string_lossy(), &resolved.to_string_lossy()) {
                crate::startup::log(format!(
                    "Managed workspace migrated away from protected Documents {} to {}",
                    root.display(),
                    resolved.display()
                ));
                settings.workspace_root = Some(resolved.to_string_lossy().to_string());
                changed = true;
            }
        }
        Some(_) => {}
    }

    // Child managed paths must be derived from the resolved workspace root,
    // never from stale child values already stored in settings. A legacy
    // order allowed Documents\Jingu\Projects to survive after workspace_root
    // had correctly fallen back to %USERPROFILE%\Jingu.
    let resolved_workspace_root = settings
        .workspace_root
        .as_ref()
        .map(|item| item.trim())
        .filter(|item| !item.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| crate::paths::default_workspace_root(app));
    let resolved_workspace_text = resolved_workspace_root.to_string_lossy().to_string();
    let previous_root = previous_root.unwrap_or_else(|| resolved_workspace_root.clone());

    let current_root = settings
        .workspace_root
        .as_ref()
        .map(|item| item.trim())
        .filter(|item| !item.is_empty());
    if !current_root
        .map(|value| same_path_text(value, &resolved_workspace_text))
        .unwrap_or(false)
    {
        settings.workspace_root = Some(resolved_workspace_text.clone());
        changed = true;
    }

    let previous_default_projects = old_default_projects(&previous_root);
    let previous_default_engines = old_default_engines(&previous_root);
    let target_projects = old_default_projects(&resolved_workspace_root);
    let target_engines = old_default_engines(&resolved_workspace_root);

    // Also recognize the original managed Documents defaults even when an
    // earlier run already migrated only the workspace root. This repairs the
    // partial migration state observed on Windows without touching any custom path.
    let managed_documents_root = crate::paths::managed_documents_workspace_root(app);
    let managed_documents_projects = old_default_projects(&managed_documents_root);
    let managed_documents_engines = old_default_engines(&managed_documents_root);

    let replace_projects = match settings
        .default_project_location
        .as_ref()
        .map(|item| item.trim())
    {
        None => true,
        Some(value) => {
            value.is_empty()
                || same_path_text(value, &previous_default_projects)
                || same_path_text(value, &managed_documents_projects)
        }
    };
    if replace_projects
        && !settings
            .default_project_location
            .as_deref()
            .map(|value| same_path_text(value, &target_projects))
            .unwrap_or(false)
    {
        crate::startup::log(format!(
            "Managed project directory migrated to {}",
            target_projects
        ));
        settings.default_project_location = Some(target_projects);
        changed = true;
    }

    let replace_downloads = match settings.download_dir.as_ref().map(|item| item.trim()) {
        None => true,
        Some(value) => {
            value.is_empty()
                || same_path_text(value, &previous_default_engines)
                || same_path_text(value, &managed_documents_engines)
        }
    };
    if replace_downloads
        && !settings
            .download_dir
            .as_deref()
            .map(|value| same_path_text(value, &target_engines))
            .unwrap_or(false)
    {
        crate::startup::log(format!(
            "Managed Engine directory migrated to {}",
            target_engines
        ));
        settings.download_dir = Some(target_engines);
        changed = true;
    }

    crate::paths::ensure_directory_layout(app, settings);
    changed
}

pub fn read_settings(app: &AppHandle) -> AppSettings {
    let mut settings: AppSettings = persist::read_json(&settings_file(app));
    let changed = apply_managed_defaults(app, &mut settings, None);
    persist_if_changed(app, &settings, changed);
    settings
}

pub fn write_settings(app: &AppHandle, settings: &AppSettings) -> AppResult<()> {
    persist::write_json(&settings_file(app), settings)
}

#[tauri::command]
pub fn get_settings(app: AppHandle) -> AppSettings {
    read_settings(&app)
}

#[tauri::command]
pub fn update_settings(app: AppHandle, mut settings: AppSettings) -> Result<AppSettings, String> {
    let previous = read_settings(&app);
    settings.dismissed_project_paths = previous.dismissed_project_paths.clone();
    apply_managed_defaults(&app, &mut settings, Some(&previous));
    write_settings(&app, &settings).map_err(|e| e.to_string())?;
    if let Err(error) = crate::github::configure_session_persistence(settings.remember_github_login)
    {
        // Do not leave the persisted preference claiming a guarantee the secure
        // store could not honor. Restore the previous file and runtime policy.
        let _ = write_settings(&app, &previous);
        let _ = crate::github::configure_session_persistence(previous.remember_github_login);
        return Err(error);
    }
    Ok(settings)
}
