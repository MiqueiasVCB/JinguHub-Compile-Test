/**************************************************************************/
/*  startup.rs                                                          */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::PathBuf;

const MAX_LOG_BYTES: u64 = 1024 * 1024;

fn log_dir() -> PathBuf {
    crate::paths::startup_log_dir()
}

pub fn log_path() -> PathBuf {
    log_dir().join("startup.log")
}

#[cfg(unix)]
fn restrict_log_permissions(path: &std::path::Path, mode: u32) {
    use std::os::unix::fs::PermissionsExt;
    if let Ok(metadata) = fs::metadata(path) {
        let mut permissions = metadata.permissions();
        permissions.set_mode(mode);
        let _ = fs::set_permissions(path, permissions);
    }
}

#[cfg(not(unix))]
fn restrict_log_permissions(_path: &std::path::Path, _mode: u32) {}

fn rotate_if_needed(path: &PathBuf) {
    let should_rotate = fs::metadata(path)
        .map(|metadata| metadata.len() >= MAX_LOG_BYTES)
        .unwrap_or(false);
    if !should_rotate {
        return;
    }
    let previous = path.with_file_name("startup.previous.log");
    let _ = fs::remove_file(&previous);
    let _ = fs::rename(path, previous);
}

pub fn log(message: impl AsRef<str>) {
    let dir = log_dir();
    if fs::create_dir_all(&dir).is_err() {
        return;
    }
    restrict_log_permissions(&dir, 0o700);
    let path = log_path();
    rotate_if_needed(&path);
    let Ok(mut file) = OpenOptions::new().create(true).append(true).open(&path) else {
        return;
    };
    restrict_log_permissions(&path, 0o600);

    let timestamp = chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Millis, true);
    let safe_message = redact_text(message.as_ref());
    let _ = writeln!(file, "[{timestamp}] {safe_message}");
    let _ = file.flush();
}

fn redact_after_marker(out: &mut String, marker: &str, replacement: &str) {
    let marker = marker.to_ascii_lowercase();
    let mut cursor = 0usize;
    loop {
        let lower = out.to_ascii_lowercase();
        let Some(relative) = lower.get(cursor..).and_then(|tail| tail.find(&marker)) else {
            break;
        };
        let index = cursor + relative;
        let mut start = index + marker.len();
        let mut quoted = None;
        while start < out.len() && out.as_bytes()[start].is_ascii() {
            let byte = out.as_bytes()[start];
            if matches!(byte, b'"' | b'\'') {
                quoted = Some(byte);
                start += 1;
                break;
            }
            if matches!(byte, b' ' | b'\t' | b':' | b'=') {
                start += 1;
                continue;
            }
            break;
        }
        let mut end = start;
        while end < out.len() {
            let byte = out.as_bytes()[end];
            if let Some(quote) = quoted {
                if byte == quote {
                    break;
                }
            } else if byte.is_ascii_whitespace()
                || matches!(byte, b'"' | b'\'' | b',' | b';' | b'&' | b')' | b']' | b'}')
            {
                break;
            }
            end += 1;
        }
        if end <= start {
            cursor = (index + marker.len()).min(out.len());
            continue;
        }
        out.replace_range(start..end, replacement);
        cursor = start + replacement.len();
    }
}

pub(crate) fn redact_text(value: &str) -> String {
    let mut out = value.to_string();
    for marker in ["ghp_", "github_pat_", "gho_", "ghu_", "ghs_", "ghr_"] {
        let mut cursor = 0usize;
        while let Some(relative) = out.get(cursor..).and_then(|tail| tail.find(marker)) {
            let index = cursor + relative;
            let end = out[index..]
                .find(|ch: char| {
                    ch.is_whitespace()
                        || matches!(ch, '"' | '\'' | ',' | ';' | '&' | ')' | ']' | '}')
                })
                .map(|offset| index + offset)
                .unwrap_or(out.len());
            out.replace_range(index..end, "[REDACTED_GITHUB_TOKEN]");
            cursor = index + "[REDACTED_GITHUB_TOKEN]".len();
        }
    }
    // Redact credentials even when a dependency formats them as a key/value pair
    // or HTTP Authorization header. This happens before any message reaches disk
    // or the Manager event bus; consumers never receive the original secret.
    for marker in [
        "bearer ",
        "authorization=",
        "authorization:",
        "access_token=",
        "access_token:",
        "refresh_token=",
        "refresh_token:",
        "client_secret=",
        "client_secret:",
        "\"client_secret\"",
        "'client_secret'",
        "jingu_continuity_ingest_key=",
        "jingu_continuity_ingest_key:",
        "\"jingu_continuity_ingest_key\"",
        "'jingu_continuity_ingest_key'",
        "ingest_key=",
        "ingest_key:",
        "\"ingest_key\"",
        "'ingest_key'",
        "jingu_payment_signing_secret=",
        "jingu_payment_signing_secret:",
        "\"jingu_payment_signing_secret\"",
        "'jingu_payment_signing_secret'",
        "signing_secret=",
        "signing_secret:",
        "\"signing_secret\"",
        "'signing_secret'",
        "password=",
        "password:",
        "\"password\"",
        "'password'",
        "api_key=",
        "api_key:",
        "\"api_key\"",
        "'api_key'",
        "x-api-key=",
        "x-api-key:",
        "x-jingu-ingest-key=",
        "x-jingu-ingest-key:",
        "device_code=",
        "device_code:",
        "\"device_code\"",
        "'device_code'",
        "code_verifier=",
        "code_verifier:",
        "\"code_verifier\"",
        "'code_verifier'",
        "token=",
        "token:",
        "\"token\"",
        "'token'",
        "\"authorization\"",
        "'authorization'",
        "\"access_token\"",
        "'access_token'",
        "\"refresh_token\"",
        "'refresh_token'",
        "email=",
        "email:",
        "\"email\"",
        "'email'",
        "e-mail=",
        "e-mail:",
        "phone=",
        "phone:",
        "\"phone\"",
        "'phone'",
        "telephone=",
        "telephone:",
        "telefone=",
        "telefone:",
        "cpf=",
        "cpf:",
        "\"cpf\"",
        "'cpf'",
        "cnpj=",
        "cnpj:",
        "\"cnpj\"",
        "'cnpj'",
        "document=",
        "document:",
        "tax_id=",
        "tax_id:",
        "card_number=",
        "card_number:",
        "\"card_number\"",
        "'card_number'",
        "cardholder=",
        "cardholder:",
        "card_holder=",
        "card_holder:",
        "cvv=",
        "cvv:",
        "\"cvv\"",
        "'cvv'",
        "cvc=",
        "cvc:",
        "\"cvc\"",
        "'cvc'",
        "pix_key=",
        "pix_key:",
        "\"pix_key\"",
        "'pix_key'",
        "chave_pix=",
        "chave_pix:",
    ] {
        redact_after_marker(&mut out, marker, "[REDACTED]");
    }
    out
}

pub fn install_panic_hook() {
    std::panic::set_hook(Box::new(|info| {
        log(format!(
            "PANIC thread={:?}: {info}",
            std::thread::current().name().unwrap_or("unnamed")
        ));
    }));
}

/// Executes a best-effort startup maintenance step without allowing an
/// unexpected panic in migration/cache code to take down the desktop shell.
/// The panic hook still records the original panic details before this guard
/// logs that the step was isolated.
pub fn run_nonfatal_step(label: &str, step: impl FnOnce()) {
    log(format!("Startup step begin: {label}"));
    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(step)) {
        Ok(()) => log(format!("Startup step completed: {label}")),
        Err(_) => log(format!(
            "WARNING: startup step panicked and was isolated: {label}"
        )),
    }
}

#[cfg(target_os = "windows")]
pub fn show_fatal_dialog(message: &str) {
    use std::os::windows::ffi::OsStrExt;

    #[link(name = "User32")]
    extern "system" {
        fn MessageBoxW(
            hwnd: *mut core::ffi::c_void,
            text: *const u16,
            caption: *const u16,
            kind: u32,
        ) -> i32;
    }

    const MB_OK: u32 = 0x0000_0000;
    const MB_ICONERROR: u32 = 0x0000_0010;
    let text: Vec<u16> = std::ffi::OsStr::new(message)
        .encode_wide()
        .chain(std::iter::once(0))
        .collect();
    let caption: Vec<u16> = std::ffi::OsStr::new("Jingu Hub - erro de inicialização")
        .encode_wide()
        .chain(std::iter::once(0))
        .collect();
    unsafe {
        MessageBoxW(
            std::ptr::null_mut(),
            text.as_ptr(),
            caption.as_ptr(),
            MB_OK | MB_ICONERROR,
        );
    }
}

#[cfg(target_os = "macos")]
pub fn show_fatal_dialog(message: &str) {
    eprintln!("Jingu Hub startup error: {message}");
    // Pass the message as argv rather than interpolating it into AppleScript so
    // quotes/newlines in an error cannot break the script.
    let _ = std::process::Command::new("osascript")
        .args([
            "-e",
            "on run argv",
            "-e",
            "display alert \"Jingu Hub\" message (item 1 of argv) as critical buttons {\"OK\"} default button \"OK\"",
            "-e",
            "end run",
            "--",
            message,
        ])
        .status();
}

#[cfg(all(unix, not(target_os = "macos")))]
pub fn show_fatal_dialog(message: &str) {
    eprintln!("Jingu Hub startup error: {message}");
    let text_arg = format!("--text={message}");
    if std::process::Command::new("zenity")
        .args(["--error", "--title=Jingu Hub"])
        .arg(&text_arg)
        .status()
        .map(|status| status.success())
        .unwrap_or(false)
    {
        return;
    }
    let _ = std::process::Command::new("kdialog")
        .args(["--error", message, "--title", "Jingu Hub"])
        .status();
}

#[cfg(not(any(target_os = "windows", target_os = "macos", unix)))]
pub fn show_fatal_dialog(message: &str) {
    eprintln!("Jingu Hub startup error: {message}");
}

pub fn fatal(message: impl AsRef<str>) {
    let safe_message = redact_text(message.as_ref());
    log(format!("FATAL: {safe_message}"));
    show_fatal_dialog(&safe_message);
}

#[cfg(test)]
mod tests {
    use super::redact_text;

    #[test]
    fn redaction_covers_structured_and_query_secrets() {
        let input = r#"{"client_secret":"top-secret","ingest_key":"ingest-secret","authorization":"Bearer bearer-secret","email":"alice@example.com","phone":"+55 11 99999-9999","cpf":"123.456.789-00","card_number":"4111111111111111","cvv":"123","pix_key":"alice@example.com"} token=query-secret&device_code=device-secret"#;
        let redacted = redact_text(input);
        for secret in [
            "top-secret",
            "ingest-secret",
            "bearer-secret",
            "query-secret",
            "device-secret",
            "alice@example.com",
            "+55 11 99999-9999",
            "123.456.789-00",
            "4111111111111111",
            "123",
        ] {
            assert!(!redacted.contains(secret));
        }
        assert!(redacted.contains("[REDACTED]"));
    }
}
