/**************************************************************************/
/*  store_browser.rs                                                    */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, VecDeque};
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use tauri::{
    webview::{DownloadEvent, NewWindowResponse, WebviewBuilder},
    AppHandle, Emitter, LogicalPosition, LogicalSize, Manager, WebviewUrl,
};

const STORE_PREFIX: &str = "store-browser-";
const EXTERNAL_STORES: [&str; 3] = ["godot", "shaders", "itchio"];

#[derive(Debug, Clone, Copy, Deserialize, Serialize)]
pub struct StoreBounds {
    pub x: f64,
    pub y: f64,
    pub width: f64,
    pub height: f64,
}

#[derive(Debug, Clone, Serialize)]
struct StoreDownloadStatus {
    store_id: String,
    url: String,
    name: String,
    path: String,
    success: Option<bool>,
}

fn store_label(store_id: &str) -> Result<String, String> {
    if !EXTERNAL_STORES.contains(&store_id) {
        return Err(format!("Loja externa desconhecida: {store_id}"));
    }
    Ok(format!("{STORE_PREFIX}{store_id}"))
}

fn store_home_url(store_id: &str) -> Result<reqwest::Url, String> {
    let raw = match store_id {
        "godot" => "https://godotengine.org/asset-library/asset",
        "shaders" => "https://godotshaders.com",
        "itchio" => "https://itch.io/game-assets",
        _ => return Err(format!("Loja externa desconhecida: {store_id}")),
    };
    reqwest::Url::parse(raw).map_err(|e| e.to_string())
}

fn store_download_root(app: &AppHandle, store_id: &str) -> Result<PathBuf, String> {
    let settings = crate::settings::read_settings(app);
    let layout = crate::paths::ensure_directory_layout(app, &settings);
    let raw = match store_id {
        "godot" => layout.store_godot_root,
        "shaders" => layout.store_shaders_root,
        "itchio" => layout.store_itchio_root,
        _ => return Err(format!("Loja externa desconhecida: {store_id}")),
    };
    let path = PathBuf::from(raw);
    std::fs::create_dir_all(&path).map_err(|e| {
        format!(
            "Não foi possível preparar a pasta de downloads da loja {}: {e}",
            path.display()
        )
    })?;
    Ok(path)
}

fn safe_download_name(url: &reqwest::Url) -> String {
    let raw = url
        .path_segments()
        .and_then(|mut segments| segments.rfind(|part| !part.is_empty()))
        .unwrap_or("download");
    let decoded: String = raw
        .chars()
        .map(|ch| {
            if matches!(ch, '/' | '\\' | ':' | '*' | '?' | '"' | '<' | '>' | '|') {
                '_'
            } else {
                ch
            }
        })
        .collect();
    let trimmed = decoded.trim_matches(|ch| ch == '.' || ch == ' ');
    if trimmed.is_empty() {
        "download".to_string()
    } else {
        trimmed.to_string()
    }
}

fn unique_destination(root: &Path, file_name: &str) -> PathBuf {
    let initial = root.join(file_name);
    if !initial.exists() {
        return initial;
    }

    let path = Path::new(file_name);
    let stem = path
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("download");
    let extension = path.extension().and_then(|s| s.to_str());
    for index in 2..10_000 {
        let candidate_name = match extension {
            Some(ext) if !ext.is_empty() => format!("{stem} ({index}).{ext}"),
            _ => format!("{stem} ({index})"),
        };
        let candidate = root.join(candidate_name);
        if !candidate.exists() {
            return candidate;
        }
    }
    root.join(format!("{stem}-{}", chrono::Utc::now().timestamp_millis()))
}

fn hide_other_store_webviews(app: &AppHandle, keep_label: Option<&str>) {
    for (label, webview) in app.webviews() {
        if label.starts_with(STORE_PREFIX) && keep_label != Some(label.as_str()) {
            let _ = webview.hide();
        }
    }
}

fn apply_bounds(webview: &tauri::Webview, bounds: StoreBounds) -> Result<(), String> {
    let width = bounds.width.max(1.0);
    let height = bounds.height.max(1.0);
    webview
        .set_position(LogicalPosition::new(bounds.x.max(0.0), bounds.y.max(0.0)))
        .map_err(|e| e.to_string())?;
    webview
        .set_size(LogicalSize::new(width, height))
        .map_err(|e| e.to_string())?;
    Ok(())
}

fn create_store_webview(
    app: &AppHandle,
    store_id: &str,
    bounds: StoreBounds,
) -> Result<tauri::Webview, String> {
    let label = store_label(store_id)?;
    let home = store_home_url(store_id)?;
    let download_root = store_download_root(app, store_id)?;
    let parent = app
        .get_window("main")
        .ok_or_else(|| "A janela principal do Jingu Hub não foi encontrada.".to_string())?;

    let app_for_popup = app.clone();
    let label_for_popup = label.clone();
    let download_root_for_handler = download_root.clone();
    let store_id_for_download = store_id.to_string();
    // Tauri may report `Finished.path = None` (always on macOS). Remember the
    // destination chosen at request time so lifecycle events retain a stable
    // key/path across platforms. A queue also handles repeated downloads of the
    // same URL without collapsing them into a single entry.
    let pending_downloads: Arc<Mutex<HashMap<String, VecDeque<PathBuf>>>> =
        Arc::new(Mutex::new(HashMap::new()));
    let pending_downloads_for_handler = pending_downloads.clone();

    let builder = WebviewBuilder::new(label.clone(), WebviewUrl::External(home))
        .zoom_hotkeys_enabled(true)
        .on_navigation(|url| matches!(url.scheme(), "https" | "about"))
        .on_new_window(move |url, _features| {
            // Keep target=_blank/window.open navigation inside the same embedded
            // store WebView instead of spawning a second application window.
            if url.scheme() == "https" {
                if let Some(webview) = app_for_popup.get_webview(&label_for_popup) {
                    let _ = webview.navigate(url);
                }
            }
            NewWindowResponse::Deny
        })
        .on_download(move |webview, event| {
            match event {
                DownloadEvent::Requested { url, destination } => {
                    let name = safe_download_name(&url);
                    *destination = unique_destination(&download_root_for_handler, &name);
                    let destination_path = destination.clone();
                    pending_downloads_for_handler
                        .lock()
                        .unwrap_or_else(|e| e.into_inner())
                        .entry(url.to_string())
                        .or_default()
                        .push_back(destination_path.clone());
                    let payload = StoreDownloadStatus {
                        store_id: store_id_for_download.clone(),
                        url: url.to_string(),
                        name,
                        path: destination_path.to_string_lossy().into_owned(),
                        success: None,
                    };
                    let _ = webview.app_handle().emit("store-download-started", payload);
                }
                DownloadEvent::Finished { url, path, success } => {
                    let url_key = url.to_string();
                    let remembered = {
                        let mut pending = pending_downloads_for_handler
                            .lock()
                            .unwrap_or_else(|e| e.into_inner());
                        let remembered = pending.get_mut(&url_key).and_then(VecDeque::pop_front);
                        if pending.get(&url_key).is_some_and(VecDeque::is_empty) {
                            pending.remove(&url_key);
                        }
                        remembered
                    };
                    let final_path = path.or(remembered);
                    let name = final_path
                        .as_ref()
                        .and_then(|value| value.file_name())
                        .and_then(|value| value.to_str())
                        .map(str::to_string)
                        .unwrap_or_else(|| safe_download_name(&url));
                    let payload = StoreDownloadStatus {
                        store_id: store_id_for_download.clone(),
                        url: url_key,
                        name,
                        path: final_path
                            .as_ref()
                            .map(|value| value.to_string_lossy().into_owned())
                            .unwrap_or_default(),
                        success: Some(success),
                    };
                    let event_name = if success {
                        "store-download-complete"
                    } else {
                        "store-download-error"
                    };
                    let _ = webview.app_handle().emit(event_name, payload);
                }
                _ => {}
            }
            true
        });

    // WebView2/WebKitGTK support an explicit profile directory. WKWebView uses
    // its native persistent website data store, which is preferable on macOS.
    #[cfg(not(target_os = "macos"))]
    let builder = {
        let profile = crate::paths::app_data_dir(app)
            .join("browser")
            .join(store_id);
        std::fs::create_dir_all(&profile)
            .map_err(|e| format!("Não foi possível preparar o perfil do navegador da loja: {e}"))?;
        builder.data_directory(profile)
    };

    let webview = parent
        .add_child(
            builder,
            LogicalPosition::new(bounds.x.max(0.0), bounds.y.max(0.0)),
            LogicalSize::new(bounds.width.max(1.0), bounds.height.max(1.0)),
        )
        .map_err(|e| format!("Não foi possível integrar a loja ao Jingu Hub: {e}"))?;

    Ok(webview)
}

#[tauri::command]
pub async fn store_browser_show(
    app: AppHandle,
    store_id: String,
    bounds: StoreBounds,
) -> Result<(), String> {
    let label = store_label(&store_id)?;
    hide_other_store_webviews(&app, Some(&label));

    if let Some(webview) = app.get_webview(&label) {
        apply_bounds(&webview, bounds)?;
        webview.show().map_err(|e| e.to_string())?;
        let _ = webview.set_focus();
        return Ok(());
    }

    let webview = create_store_webview(&app, &store_id, bounds)?;
    webview.show().map_err(|e| e.to_string())?;
    let _ = webview.set_focus();
    Ok(())
}

#[tauri::command]
pub fn store_browser_set_bounds(
    app: AppHandle,
    store_id: String,
    bounds: StoreBounds,
) -> Result<(), String> {
    let label = store_label(&store_id)?;
    let webview = app
        .get_webview(&label)
        .ok_or_else(|| "O navegador integrado desta loja ainda não foi criado.".to_string())?;
    apply_bounds(&webview, bounds)
}

#[tauri::command]
pub fn store_browser_hide(app: AppHandle) {
    hide_other_store_webviews(&app, None);
}

#[tauri::command]
pub fn store_browser_home(app: AppHandle, store_id: String) -> Result<(), String> {
    let label = store_label(&store_id)?;
    let webview = app
        .get_webview(&label)
        .ok_or_else(|| "O navegador integrado desta loja ainda não foi criado.".to_string())?;
    webview
        .navigate(store_home_url(&store_id)?)
        .map_err(|e| e.to_string())
}

#[tauri::command]
pub fn store_browser_back(app: AppHandle, store_id: String) -> Result<(), String> {
    let label = store_label(&store_id)?;
    let webview = app
        .get_webview(&label)
        .ok_or_else(|| "O navegador integrado desta loja ainda não foi criado.".to_string())?;
    webview.eval("history.back();").map_err(|e| e.to_string())
}

#[tauri::command]
pub fn store_browser_reload(app: AppHandle, store_id: String) -> Result<(), String> {
    let label = store_label(&store_id)?;
    let webview = app
        .get_webview(&label)
        .ok_or_else(|| "O navegador integrado desta loja ainda não foi criado.".to_string())?;
    webview.reload().map_err(|e| e.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    #[test]
    fn store_ids_are_strictly_allowlisted() {
        assert_eq!(store_label("godot").unwrap(), "store-browser-godot");
        assert!(store_label("javascript:alert(1)").is_err());
        assert!(store_home_url("unknown").is_err());
    }

    #[test]
    fn download_names_strip_windows_forbidden_characters() {
        let url = reqwest::Url::parse("https://example.com/a%3Ab%3Fc.zip").unwrap();
        let name = safe_download_name(&url);
        assert!(!name.contains(':'));
        assert!(!name.contains('?'));
    }

    #[test]
    fn duplicate_downloads_get_a_unique_destination() {
        let root = std::env::temp_dir().join(format!("jingu-store-test-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let first = root.join("asset.zip");
        fs::write(&first, b"test").unwrap();
        let second = unique_destination(&root, "asset.zip");
        assert_eq!(
            second.file_name().and_then(|v| v.to_str()),
            Some("asset (2).zip")
        );
        let _ = fs::remove_dir_all(root);
    }
}
