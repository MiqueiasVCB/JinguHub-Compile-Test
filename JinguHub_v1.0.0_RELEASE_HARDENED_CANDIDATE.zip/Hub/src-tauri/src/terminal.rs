/**************************************************************************/
/*  terminal.rs                                                         */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
use std::path::Path;
use std::process::{Child, Command};

#[cfg(target_os = "windows")]
use std::os::windows::process::CommandExt;

#[cfg(target_os = "windows")]
pub const CREATE_NO_WINDOW: u32 = 0x0800_0000;

#[cfg(unix)]
use std::path::PathBuf;

#[cfg(unix)]
use tauri::{AppHandle, Manager};

#[cfg(all(unix, not(target_os = "macos")))]
const TERMINALS: [(&str, &[&str]); 23] = [
    ("xdg-terminal-exec", &[]),
    ("x-terminal-emulator", &["-e"]),
    ("gnome-terminal", &["--"]),
    ("konsole", &["-e"]),
    ("kgx", &["--"]),
    ("ptyxis", &["-x"]),
    ("xfce4-terminal", &["-x"]),
    ("tilix", &["-e"]),
    ("mate-terminal", &["-x"]),
    ("deepin-terminal", &["-e"]),
    ("cosmic-term", &["-e"]),
    ("qterminal", &["-e"]),
    ("lxterminal", &["-e"]),
    ("kitty", &[]),
    ("alacritty", &["-e"]),
    ("wezterm", &["start", "--"]),
    ("foot", &[]),
    ("ghostty", &["-e"]),
    ("terminator", &["-x"]),
    ("urxvt", &["-e"]),
    ("rxvt", &["-e"]),
    ("st", &["-e"]),
    ("xterm", &["-e"]),
];

#[cfg(unix)]
fn sh_quote(value: &str) -> String {
    format!("'{}'", value.replace('\'', "'\\''"))
}

#[cfg(unix)]
fn prune_stale_scripts(dir: &Path) {
    let Ok(entries) = std::fs::read_dir(dir) else {
        return;
    };
    let cutoff = std::time::Duration::from_secs(60 * 60 * 24);
    for entry in entries.flatten() {
        let stale = entry
            .metadata()
            .and_then(|m| m.modified())
            .map(|m| m.elapsed().map(|age| age > cutoff).unwrap_or(false))
            .unwrap_or(false);
        if stale {
            let _ = std::fs::remove_file(entry.path());
        }
    }
}

#[cfg(unix)]
fn launch_dir(app: &AppHandle) -> Result<PathBuf, String> {
    use std::os::unix::fs::{DirBuilderExt, PermissionsExt};

    let dir = app
        .path()
        .app_cache_dir()
        .map_err(|e| e.to_string())?
        .join("launch");

    if !dir.exists() {
        if let Some(parent) = dir.parent() {
            std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
        std::fs::DirBuilder::new()
            .mode(0o700)
            .create(&dir)
            .map_err(|e| e.to_string())?;
    } else {
        std::fs::set_permissions(&dir, std::fs::Permissions::from_mode(0o700))
            .map_err(|e| e.to_string())?;
    }

    Ok(dir)
}

#[cfg(unix)]
fn launch_stamp() -> u128 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0)
}

#[cfg(unix)]
fn write_launch_script(
    app: &AppHandle,
    body: &str,
    extension: &str,
    stamp: u128,
) -> Result<PathBuf, String> {
    use std::os::unix::fs::PermissionsExt;

    let dir = launch_dir(app)?;
    prune_stale_scripts(&dir);

    let script = dir.join(format!("launch-{stamp}.{extension}"));

    std::fs::write(&script, body).map_err(|e| e.to_string())?;
    std::fs::set_permissions(&script, std::fs::Permissions::from_mode(0o700))
        .map_err(|e| e.to_string())?;

    Ok(script)
}

#[cfg(unix)]
fn program_script_body(program: &Path, args: &[String], pid_file: &Path) -> String {
    let quoted_pid_file = sh_quote(&pid_file.to_string_lossy());
    let mut body = format!(
        "#!/bin/sh\necho $$ > {quoted_pid_file}.tmp && mv {quoted_pid_file}.tmp {quoted_pid_file}\nexec "
    );
    body.push_str(&sh_quote(&program.to_string_lossy()));
    for arg in args {
        body.push(' ');
        body.push_str(&sh_quote(arg));
    }
    body.push('\n');
    body
}

#[cfg(all(unix, not(target_os = "macos")))]
fn find_on_path(binary: &str) -> Option<PathBuf> {
    if binary.contains('/') {
        let direct = PathBuf::from(binary);
        return direct.is_file().then_some(direct);
    }
    std::env::split_paths(&std::env::var_os("PATH")?)
        .map(|dir| dir.join(binary))
        .find(|candidate| candidate.is_file())
}

#[cfg(all(unix, not(target_os = "macos")))]
fn flags_for(binary: &str) -> &'static [&'static str] {
    let name = Path::new(binary)
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or(binary);
    TERMINALS
        .iter()
        .find(|(known, _)| *known == name)
        .map(|(_, flags)| *flags)
        .unwrap_or(&["-e"])
}

pub fn sanitize_child_env(_cmd: &mut Command) {
    // GitHub App credentials live only in the native secure store and are never
    // exported through environment variables. Keep AppImage runtime libraries
    // from leaking into child processes on Linux.
    #[cfg(all(unix, not(target_os = "macos")))]
    if std::env::var_os("APPIMAGE").is_some() {
        _cmd.env_remove("LD_LIBRARY_PATH");
    }
}

#[cfg(all(unix, not(target_os = "macos")))]
fn spawn_script(script: &Path) -> Result<Child, String> {
    if let Some(preferred) = std::env::var("TERMINAL").ok().filter(|t| !t.is_empty()) {
        if let Some(binary) = find_on_path(&preferred) {
            let mut cmd = Command::new(binary);
            sanitize_child_env(&mut cmd);
            if let Ok(child) = cmd.args(flags_for(&preferred)).arg(script).spawn() {
                return Ok(child);
            }
        }
    }

    for (binary, flags) in TERMINALS {
        let Some(resolved) = find_on_path(binary) else {
            continue;
        };
        let mut cmd = Command::new(resolved);
        sanitize_child_env(&mut cmd);
        if let Ok(child) = cmd.args(flags).arg(script).spawn() {
            return Ok(child);
        }
    }

    Err("Could not find a terminal emulator".into())
}

#[cfg(target_os = "macos")]
fn spawn_script(script: &Path) -> Result<Child, String> {
    Command::new("open")
        .arg(script)
        .spawn()
        .or_else(|_| {
            Command::new("open")
                .args(["-a", "Terminal"])
                .arg(script)
                .spawn()
        })
        .map_err(|e| format!("Failed to open a terminal: {e}"))
}

#[cfg(unix)]
pub fn spawn_program_in_terminal(
    app: &AppHandle,
    program: &Path,
    args: &[String],
) -> Result<(Child, PathBuf), String> {
    let extension = if cfg!(target_os = "macos") {
        "command"
    } else {
        "sh"
    };
    let stamp = launch_stamp();
    let pid_file = launch_dir(app)?.join(format!("launch-{stamp}.pid"));
    let script = write_launch_script(
        app,
        &program_script_body(program, args, &pid_file),
        extension,
        stamp,
    )?;
    spawn_script(&script).map(|child| (child, pid_file))
}

#[cfg(unix)]
pub fn read_pid_file(path: &Path) -> Option<u32> {
    std::fs::read_to_string(path)
        .ok()?
        .trim()
        .parse::<u32>()
        .ok()
        .filter(|pid| *pid > 1)
}

#[cfg(unix)]
pub fn process_is_alive(pid: u32) -> bool {
    unsafe { libc::kill(pid as libc::pid_t, 0) == 0 }
}

#[cfg(target_os = "windows")]
fn console_command(program: &Path, args: &[String]) -> Command {
    const CREATE_NEW_CONSOLE: u32 = 0x0000_0010;
    let mut command = Command::new(program);
    command.args(args).creation_flags(CREATE_NEW_CONSOLE);
    command
}

#[cfg(target_os = "windows")]
pub fn spawn_program_in_console(
    program: &Path,
    args: &[String],
    _title: &str,
) -> Result<Child, String> {
    console_command(program, args)
        .spawn()
        .map_err(|e| format!("Failed to open a console window: {e}"))
}

#[cfg(all(test, target_os = "windows"))]
mod console_tests {
    use super::*;

    #[test]
    fn console_launch_preserves_literal_arguments_without_a_shell() {
        let program = Path::new(r"C:\Engine & tools\Jingu.console.exe");
        let args = vec![
            r"C:\projects\%TEMP% & literal".into(),
            "quoted\"value".into(),
            "!literal!".into(),
        ];
        let command = console_command(program, &args);
        assert_eq!(command.get_program(), program.as_os_str());
        assert_eq!(
            command.get_args().collect::<Vec<_>>(),
            args.iter().map(std::ffi::OsStr::new).collect::<Vec<_>>()
        );
    }
}
