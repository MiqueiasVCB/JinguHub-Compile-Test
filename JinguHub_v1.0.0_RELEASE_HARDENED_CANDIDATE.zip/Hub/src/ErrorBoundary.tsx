/**************************************************************************/
/*  ErrorBoundary.tsx                                                   */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { Component, type ErrorInfo, type ReactNode } from 'react'

interface Props { children: ReactNode }
interface State { failed: boolean }

export class ErrorBoundary extends Component<Props, State> {
  state: State = { failed: false }
  static getDerivedStateFromError(): State { return { failed: true } }
  componentDidCatch(_error: Error, _info: ErrorInfo) {
    // Do not expose exception text or component stacks in the renderer console.
    // Backend diagnostics are independently bounded/redacted and are not part of
    // the public Settings surface.
  }
  render() {
    if (!this.state.failed) return this.props.children
    const ptBr = navigator.language.toLowerCase().startsWith('pt')
    const title = ptBr ? 'O Jingu Hub encontrou um erro' : 'Jingu Hub encountered an error'
    const help = ptBr
      ? 'Recarregue a interface. Se o problema persistir, tente novamente mais tarde.'
      : 'Reload the interface. If the problem persists, try again later.'
    const reload = ptBr ? 'Recarregar' : 'Reload'
    return <div style={{height:'100vh',width:'100vw',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:12,padding:24,background:'#08120c',color:'#edf3ee',fontFamily:'Segoe UI, sans-serif',textAlign:'center'}}>
      <h1 style={{fontSize:18,fontWeight:600}}>{title}</h1>
      <p style={{fontSize:13,color:'#9bac9e',maxWidth:520}}>{help}</p>
      <button onClick={()=>window.location.reload()} style={{padding:'9px 18px',borderRadius:10,border:'1px solid #416f33',background:'#14241a',color:'#edf3ee',cursor:'pointer',fontSize:13}}>{reload}</button>
    </div>
  }
}
