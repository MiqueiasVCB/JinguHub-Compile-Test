/**************************************************************************/
/*  community.ts                                                        */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { invoke } from '@tauri-apps/api/core'
import type { CommunityCatalogResult, CommunityRequestInput, CommunityRequestResult, CommunityRequestRow } from '../types'

export const communityApi={
  catalog:(forceRefresh=false)=>invoke<CommunityCatalogResult>('community_catalog',{forceRefresh}),
  submitRequest:(input:CommunityRequestInput)=>invoke<CommunityRequestResult>('community_submit_request',{input}),
  myRequests:()=>invoke<CommunityRequestRow[]>('community_my_requests'),
}
