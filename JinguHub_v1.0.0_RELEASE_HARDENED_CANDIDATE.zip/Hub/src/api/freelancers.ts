/**************************************************************************/
/*  freelancers.ts                                                      */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { invoke } from '@tauri-apps/api/core'
import type { FreelancerAccountStatus, FreelancerEntitlements, FreelancerFeed, FreelancerPost, FreelancerPostInput, FreelancerReactionState, FreelancerReportInput, FreelancerReportResult, JinguMembershipProfile, PaymentCheckoutResult, PaymentConfig, PaymentPricePreview, SupporterPublicEntry } from '../types'

export const freelancersApi={
  membershipProfile:(forceRefresh=false)=>invoke<JinguMembershipProfile>('membership_profile',{forceRefresh}),
  creditsOptIn:(enabled:boolean)=>invoke<JinguMembershipProfile>('membership_credits_opt_in',{enabled}),
  paymentConfig:(forceRefresh=false)=>invoke<PaymentConfig>('payment_config',{forceRefresh}),
  paymentPricePreview:(tier:string,currency:string,planUnits=1,amountMinor:number|null=null)=>invoke<PaymentPricePreview>('payment_price_preview',{tier,currency,planUnits,amountMinor}),
  paymentCheckoutStart:(tier:string,amountMinor:number|null,currency='BRL',planUnits:number|null=null)=>invoke<PaymentCheckoutResult>('payment_checkout_start',{tier,amountMinor,currency,planUnits}),
  supporters:()=>invoke<SupporterPublicEntry[]>('supporters_list'),
  entitlements:()=>invoke<FreelancerEntitlements>('freelancers_entitlements'),
  accountStatus:(forceRefresh=false)=>invoke<FreelancerAccountStatus>('freelancers_account_status',{forceRefresh}),
  fetch:(page=1,sort:'created'|'updated'='created',creator?:string,forceRefresh=false)=>invoke<FreelancerFeed>('freelancers_fetch',{page,sort,creator:creator||null,forceRefresh}),
  create:(input:FreelancerPostInput)=>invoke<FreelancerPost>('freelancers_create',{input,channel:'public'}),
  close:(number:number,channel:string)=>invoke<void>('freelancers_close',{number,channel}),
  reactionState:(number:number,channel:string)=>invoke<FreelancerReactionState>('freelancers_reaction_state',{number,channel}),
  reactionStates:(lookups:{number:number;channel:string}[])=>invoke<Record<string,FreelancerReactionState>>('freelancers_reaction_states',{lookups}),
  toggleLike:(number:number,channel:string)=>invoke<FreelancerReactionState>('freelancers_toggle_like',{number,channel}),
  report:(input:FreelancerReportInput)=>invoke<FreelancerReportResult>('freelancers_report',{input}),
  openContact:(kind:string,value:string)=>invoke<void>('freelancers_open_contact',{kind,value}),
}
