/**************************************************************************/
/*  git.ts                                                              */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { invoke } from '@tauri-apps/api/core'
import type { GitBranchInfo, GitChangedFile, GitStatus } from '../types'

export const gitApi = {
  status: (path:string) => invoke<GitStatus>('get_git_status',{path}),
  clone: (url:string,dest:string) => invoke<string>('clone_repo',{url,dest}),
  pull: (path:string) => invoke<string>('git_pull',{path}),
  fetch: (path:string) => invoke<string>('git_fetch',{path}),
  push: (path:string) => invoke<string>('git_push',{path,force:false}),
  remoteUrl: (path:string) => invoke<string>('git_remote_url',{path}),
  listBranches: (path:string) => invoke<GitBranchInfo[]>('git_list_branches',{path}),
  switchBranch: (path:string,name:string) => invoke<void>('git_switch_branch',{path,name}),
  createBranch: (path:string,name:string) => invoke<void>('git_create_branch',{path,name}),
  changedFiles: (path:string) => invoke<GitChangedFile[]>('git_changed_files',{path}),
  init: (path:string) => invoke<string>('git_init',{path}),
  stageAll: (path:string) => invoke<void>('git_stage_all',{path}),
  unstageAll: (path:string) => invoke<void>('git_unstage_all',{path}),
  stageFile: (path:string,filePath:string) => invoke<void>('git_stage_file',{path,filePath}),
  unstageFile: (path:string,filePath:string) => invoke<void>('git_unstage_file',{path,filePath}),
  commit: (path:string,message:string) => invoke<string>('git_commit',{path,message,amend:false}),
  setRemote: (path:string,url:string) => invoke<void>('git_set_remote',{path,url}),
  removeRemote: (path:string) => invoke<void>('git_remove_remote',{path}),
}
