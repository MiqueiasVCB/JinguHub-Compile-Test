/**************************************************************************/
/*  github.ts                                                           */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { invoke } from '@tauri-apps/api/core'
import type { DeviceFlowStart, DevicePollResult, GitHubInstallationStatus, GitHubPrivateAccess, GitHubRemoteStatus, GitHubRepository, GitHubUser } from '../types'

export const githubApi = {
  session: () => invoke<GitHubUser | null>('github_session'),
  beginDeviceFlow: () => invoke<DeviceFlowStart>('github_begin_device_flow'),
  pollDeviceFlow: (deviceCode: string) => invoke<DevicePollResult>('github_poll_device_flow', { deviceCode }),
  signOut: () => invoke<void>('github_sign_out'),
  installationStatus: (forceRefresh = false) => invoke<GitHubInstallationStatus>('github_installation_status', { forceRefresh }),
  privateAccess: () => invoke<GitHubPrivateAccess>('github_private_access'),
  createRepository: (name: string, description: string | null, isPrivate: boolean) =>
    invoke<GitHubRepository>('github_create_repository', { name, description, private: isPrivate }),
  listRepositories: () => invoke<GitHubRepository[]>('github_list_accessible_repositories'),
  remoteStatus: (remote: string) => invoke<GitHubRemoteStatus>('github_remote_status', { remote }),
}
