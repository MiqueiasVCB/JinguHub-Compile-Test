/**************************************************************************/
/*  projects.ts                                                         */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { invoke } from '@tauri-apps/api/core'
import type { Project, ProjectUpdate, ProjectVersionChangeResult } from '../types'

const iconCache=new Map<string,string|null>()
const ICON_CACHE_MAX=256
function clearIconCache(){iconCache.clear()}
function cacheIcon(path:string,value:string|null){
  if(iconCache.size>=ICON_CACHE_MAX&&!iconCache.has(path)){const oldest=iconCache.keys().next().value;if(oldest!==undefined)iconCache.delete(oldest)}
  iconCache.set(path,value)
  return value
}
export const projectsApi={
  list:()=>invoke<Project[]>('list_projects'),
  create:(name:string,location:string,godotVersion:string,iconPath?:string|null)=>invoke<Project>('create_project',{name,location,godotVersion,iconPath:iconPath??null,category:null}).then(project=>{clearIconCache();return project}),
  import:(path:string,godotVersion:string)=>invoke<Project>('import_project',{path,godotVersion,category:null}).then(project=>{clearIconCache();return project}),
  remove:(id:string,deleteFiles:boolean,typedFolderName:string|null=null)=>invoke<void>('remove_project',{id,deleteFiles,typedFolderName}).then(result=>{clearIconCache();return result}),
  update:(id:string,updates:ProjectUpdate)=>invoke<Project>('update_project',{id,updates}).then(project=>{clearIconCache();return project}),
  open:(id:string,editor:boolean,withConsole?:boolean)=>invoke<void>('open_project',{id,editor,console:withConsole??null}),
  openFolder:(path:string)=>invoke<void>('open_project_folder',{path}),
  pickFolder:()=>invoke<string|null>('pick_folder'),
  pickFile:()=>invoke<string|null>('pick_file'),
  getIcon:(path:string)=>{const cached=iconCache.get(path);if(cached!==undefined)return Promise.resolve(cached);return invoke<string|null>('get_project_icon',{path}).then(value=>cacheIcon(path,value))},
  setEngineVersion:(id:string,version:string)=>invoke<ProjectVersionChangeResult>('set_project_engine_version',{id,version}),
}
