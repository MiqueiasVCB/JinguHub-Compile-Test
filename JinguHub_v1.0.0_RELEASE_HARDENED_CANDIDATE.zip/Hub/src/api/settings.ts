/**************************************************************************/
/*  settings.ts                                                         */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { invoke } from '@tauri-apps/api/core'
import type { AppSettings, CredentialStoreStatus } from '../types'
export const settingsApi={
  get:()=>invoke<AppSettings>('get_settings'),
  update:(settings:AppSettings)=>invoke<AppSettings>('update_settings',{settings}),
  credentialStoreStatus:()=>invoke<CredentialStoreStatus>('credential_store_status'),
}
