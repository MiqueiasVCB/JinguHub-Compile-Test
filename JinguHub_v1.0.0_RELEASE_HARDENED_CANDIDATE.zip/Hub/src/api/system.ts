/**************************************************************************/
/*  system.ts                                                           */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { invoke } from '@tauri-apps/api/core'
import type { DirectoryLayout } from '../types'

export type EmbeddedBrowserBounds={x:number;y:number;width:number;height:number}
export type StoreBounds=EmbeddedBrowserBounds

export const systemApi={
  getDirectoryLayout:()=>invoke<DirectoryLayout>('get_directory_layout'),
  openHttpsUrl:(url:string)=>invoke<void>('open_https_url',{url}),
  storeBrowserShow:(storeId:string,bounds:StoreBounds)=>invoke<void>('store_browser_show',{storeId,bounds}),
  storeBrowserSetBounds:(storeId:string,bounds:StoreBounds)=>invoke<void>('store_browser_set_bounds',{storeId,bounds}),
  storeBrowserHide:()=>invoke<void>('store_browser_hide'),
  storeBrowserHome:(storeId:string)=>invoke<void>('store_browser_home',{storeId}),
  storeBrowserBack:(storeId:string)=>invoke<void>('store_browser_back',{storeId}),
  storeBrowserReload:(storeId:string)=>invoke<void>('store_browser_reload',{storeId}),
  paymentBrowserShow:(url:string,bounds:EmbeddedBrowserBounds)=>invoke<void>('payment_browser_show',{url,bounds}),
  paymentBrowserSetBounds:(bounds:EmbeddedBrowserBounds)=>invoke<void>('payment_browser_set_bounds',{bounds}),
  paymentBrowserHide:()=>invoke<void>('payment_browser_hide'),
  paymentBrowserReload:()=>invoke<void>('payment_browser_reload'),
}
