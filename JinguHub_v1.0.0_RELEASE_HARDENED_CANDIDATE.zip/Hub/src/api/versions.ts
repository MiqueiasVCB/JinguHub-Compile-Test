/**************************************************************************/
/*  versions.ts                                                         */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { invoke } from '@tauri-apps/api/core'
import type { GodotRelease, HubBuildProfile, HubReleaseCheck, HubRuntimeInfo, InstalledGodotVersion } from '../types'
export type DownloadSnapshot={tag:string;state:'downloading'|'queued'|'paused'}
export const versionsApi={
  hubBuildProfile:()=>invoke<HubBuildProfile>('hub_build_profile'),
  hubRuntimeInfo:()=>invoke<HubRuntimeInfo>('hub_runtime_info'),
  checkHubRelease:()=>invoke<HubReleaseCheck>('check_hub_release'),
  fetchAvailable:(forceRefresh=false)=>invoke<GodotRelease[]>('fetch_available_godot_versions',{forceRefresh}),
  checkLatestEngineRelease:()=>invoke<string|null>('check_latest_engine_release'),
  download:(tag:string,assetName:string,downloadUrl:string,expectedSha256:string,expectedSize:number,entrypoint:string,restricted:boolean)=>invoke<void>('download_godot_version',{request:{tag,assetName,downloadUrl,expectedSha256,expectedSize,entrypoint,restricted}}),
  listDownloads:()=>invoke<DownloadSnapshot[]>('list_downloads'),
  pauseDownload:(key:string)=>invoke<void>('pause_download',{key}),
  resumeDownload:(key:string)=>invoke<void>('resume_download',{key}),
  cancelDownload:(key:string)=>invoke<void>('cancel_download',{key}),
  listInstalled:()=>invoke<InstalledGodotVersion[]>('list_installed_godot_versions'),
  delete:(tag:string)=>invoke<void>('delete_godot_version',{tag}),
  open:(tag:string)=>invoke<void>('open_godot_version',{tag,console:null}),
  importZip:(zipPath:string)=>invoke<InstalledGodotVersion>('import_version_zip',{zipPath}),
  importPath:(targetPath:string)=>invoke<InstalledGodotVersion>('import_version_path',{targetPath}),
  pickArchiveFile:()=>invoke<string|null>('pick_engine_archive_file'),
  pickExecutableFile:()=>invoke<string|null>('pick_engine_executable_file'),
}
