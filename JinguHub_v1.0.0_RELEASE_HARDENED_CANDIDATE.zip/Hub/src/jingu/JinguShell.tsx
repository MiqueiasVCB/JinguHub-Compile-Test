/**************************************************************************/
/*  JinguShell.tsx                                                      */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { lazy, startTransition, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { getCurrentWindow } from '@tauri-apps/api/window'
import { listen, type UnlistenFn } from '@tauri-apps/api/event'
import { openUrl } from '@tauri-apps/plugin-opener'
import type { AppSettings, GitHubUser, JinguMembershipProfile, GodotRelease, HubReleaseCheck, HubRuntimeInfo, InstalledGodotVersion, Project } from '../types'
import { api } from '../lib/api'
import { copyFor, languageOptionValue, localeDirection } from './copy'
import { localizeNotification } from './notifications'
import { Icon, type IconName } from './components/Icon'
import { IconButton, Toast } from './components/UI'
import { NotificationCenter, type SessionNotification, type SessionNotificationKind } from './components/NotificationCenter'
import { DownloadHistoryCenter, type SessionDownload, type SessionDownloadState } from './components/DownloadHistoryCenter'
import { ProjectsView } from './views/ProjectsView'
import releaseProfile from '../../release-profile.json'

type Tab='projects'|'versions'|'stores'|'community'|'freelancers'|'github'|'plans'|'settings'|'about'

const loadVersionsView=()=>import('./views/VersionsView')
const loadGitHubView=()=>import('./views/GitHubView')
const loadSettingsView=()=>import('./views/SettingsView')
const loadStoreView=()=>import('./views/StoreView')
const loadAboutView=()=>import('./views/AboutView')
const loadPlansView=()=>import('./views/PlansView')
const loadCommunityView=()=>import('./views/CommunityView')
const loadFreelancersView=()=>import('./views/FreelancersView')
const VersionsView=lazy(()=>loadVersionsView().then(module=>({default:module.VersionsView})))
const GitHubView=lazy(()=>loadGitHubView().then(module=>({default:module.GitHubView})))
const SettingsView=lazy(()=>loadSettingsView().then(module=>({default:module.SettingsView})))
const StoreView=lazy(()=>loadStoreView().then(module=>({default:module.StoreView})))
const AboutView=lazy(()=>loadAboutView().then(module=>({default:module.AboutView})))
const PlansView=lazy(()=>loadPlansView().then(module=>({default:module.PlansView})))
const CommunityView=lazy(()=>loadCommunityView().then(module=>({default:module.CommunityView})))
const FreelancersView=lazy(()=>loadFreelancersView().then(module=>({default:module.FreelancersView})))
const VIEW_PRELOADERS:Partial<Record<Tab,()=>Promise<unknown>>>= {
  versions:loadVersionsView,stores:loadStoreView,community:loadCommunityView,freelancers:loadFreelancersView,
  github:loadGitHubView,plans:loadPlansView,settings:loadSettingsView,about:loadAboutView,
}
function preloadView(tab:Tab){void VIEW_PRELOADERS[tab]?.().catch(()=>{})}
function scheduleIdle(task:()=>void){
  const host=window as Window&{requestIdleCallback?:(callback:()=>void,options?:{timeout:number})=>number;cancelIdleCallback?:(handle:number)=>void}
  if(host.requestIdleCallback){
    const handle=host.requestIdleCallback(task,{timeout:1800})
    return ()=>host.cancelIdleCallback?.(handle)
  }
  const handle=window.setTimeout(task,300)
  return ()=>window.clearTimeout(handle)
}
type EngineDownloadProgress={tag:string;downloaded:number;total:number}
type StoreDownloadPayload={store_id:string;url:string;name:string;path:string;success:boolean|null}
type HubUpdateState='idle'|'checking'|'synced'|'available'|'error'
type EngineCatalogState='idle'|'refreshing'

function normalizedVersion(value:string){return value.trim().replace(/^v/i,'').split('-')[0]}
function versionTuple(value:string):[number,number,number]|null{
  const parts=normalizedVersion(value).split('.')
  if(parts.length<1||parts.length>3)return null
  const numbers=parts.map(part=>/^\d+$/.test(part)?Number(part):Number.NaN)
  if(numbers.some(Number.isNaN))return null
  return [numbers[0]??0,numbers[1]??0,numbers[2]??0]
}
function compareVersions(left:string,right:string){
  const a=versionTuple(left),b=versionTuple(right)
  if(!a&&!b)return left.localeCompare(right,undefined,{numeric:true,sensitivity:'base'})
  if(!a)return -1
  if(!b)return 1
  return a[0]-b[0]||a[1]-b[1]||a[2]-b[2]
}
function sortReleases(rows:GodotRelease[]){return [...rows].sort((a,b)=>compareVersions(b.tag,a.tag))}
function isTerminalDownload(state:SessionDownloadState){return state==='complete'||state==='error'||state==='canceled'}

export function JinguShell(){
  const [settings,setSettings]=useState<AppSettings|null>(null)
  const [projects,setProjects]=useState<Project[]>([])
  const [versions,setVersions]=useState<InstalledGodotVersion[]>([])
  const [available,setAvailable]=useState<GodotRelease[]>([])
  const [tab,setTab]=useState<Tab>('projects')
  const [selectedId,setSelectedId]=useState<string|null>(null)
  const [loading,setLoading]=useState(true)
  const [fatal,setFatal]=useState<string|null>(null)
  const [toast,setToast]=useState<{message:string;error:boolean}|null>(null)
  const [downloadHistory,setDownloadHistory]=useState<SessionDownload[]>([])
  const [alertsOpen,setAlertsOpen]=useState(false)
  const [downloadsOpen,setDownloadsOpen]=useState(false)
  const [notifications,setNotifications]=useState<SessionNotification[]>([])
  const [hubRuntime,setHubRuntime]=useState<HubRuntimeInfo|null>(null)
  const [githubUser,setGithubUser]=useState<GitHubUser|null>(null)
  const [membershipProfile,setMembershipProfile]=useState<JinguMembershipProfile|null>(null)
  const [hubState,setHubState]=useState<HubUpdateState>('idle')
  const [hubRelease,setHubRelease]=useState<HubReleaseCheck|null>(null)
  const [engineCatalogState,setEngineCatalogState]=useState<EngineCatalogState>('idle')
  const [projectsRefreshing,setProjectsRefreshing]=useState(false)
  const notificationSequence=useRef(0)
  const downloadSequence=useRef(0)
  const releaseCheckDone=useRef(false)
  const engineStartupCheckDone=useRef(false)
  const engineHeadLastCheck=useRef(0)
  const downloadsOpenRef=useRef(false)
  const projectsRefreshInFlight=useRef<Promise<void>|null>(null)
  const versionsRefreshInFlight=useRef<Promise<void>|null>(null)
  const privateCapabilitySignature=useRef<string|null>(null)
  const paymentRefreshUntil=useRef(0)
  const paymentRefreshTimers=useRef<number[]>([])
  const notificationCooldown=useRef(new Map<string,number>())
  const toastTimer=useRef<number|null>(null)
  const membershipRefreshInFlight=useRef<Promise<JinguMembershipProfile|null>|null>(null)
  const privateRevalidationInFlight=useRef<Promise<void>|null>(null)
  const privateCapabilityLastCheck=useRef(0)

  const c=useMemo(()=>copyFor(settings?.language),[settings?.language])
  useEffect(()=>{downloadsOpenRef.current=downloadsOpen},[downloadsOpen])
  const animations=!(settings?.reduce_motion??false)
  useEffect(()=>()=>{if(toastTimer.current!==null)window.clearTimeout(toastTimer.current)},[])

  const applyUiPreferences=useCallback((next:AppSettings)=>{
    document.documentElement.classList.toggle('reduce-motion',next.reduce_motion)
    document.documentElement.lang=languageOptionValue(next.language)
    document.documentElement.dir=localeDirection(next.language)
  },[])

  const addNotification=useCallback((entry:{kind:SessionNotificationKind;title:string;description:string;dedupeKey?:string})=>{
    setNotifications(current=>{
      if(entry.dedupeKey&&current.some(item=>item.dedupeKey===entry.dedupeKey))return current
      const id=`alert-${Date.now()}-${++notificationSequence.current}`
      return [{...entry,id,createdAt:Date.now(),unread:!alertsOpen},...current].slice(0,100)
    })
  },[alertsOpen])

  const notify=useCallback((description:string,error=false,title?:string)=>{
    const localized=localizeNotification(description,error,c,settings?.language)
    void error; void localized; void description
    const resolvedTitle=title??(error?c.error:c.success)
    const cooldownKey=`${error?'error':'ok'}:${resolvedTitle}:${localized}`
    const now=Date.now();const previous=notificationCooldown.current.get(cooldownKey)??0
    if(now-previous>12_000){
      notificationCooldown.current.set(cooldownKey,now)
      if(notificationCooldown.current.size>128){
        for(const [key,createdAt] of notificationCooldown.current){if(now-createdAt>60_000)notificationCooldown.current.delete(key)}
      }
      addNotification({kind:error?'error':'success',title:resolvedTitle,description:localized})
    }
    setToast({message:localized,error})
    if(toastTimer.current!==null)window.clearTimeout(toastTimer.current)
    toastTimer.current=window.setTimeout(()=>{setToast(null);toastTimer.current=null},5000)
  },[addNotification,c,settings?.language])

  const announceEngineUpdate=useCallback((releaseRows:GodotRelease[],installedRows:InstalledGodotVersion[])=>{
    const latest=sortReleases(releaseRows)[0]
    if(!latest)return
    const latestInstalled=installedRows.reduce<string|null>((best,item)=>{
      const candidate=item.version||item.tag
      if(!versionTuple(candidate))return best
      return best===null||compareVersions(candidate,best)>0?candidate:best
    },null)
    const exactInstalled=installedRows.some(item=>normalizedVersion(item.tag)===normalizedVersion(latest.tag)||normalizedVersion(item.version)===normalizedVersion(latest.tag))
    if(exactInstalled||(latestInstalled&&compareVersions(latest.tag,latestInstalled)<=0))return
    addNotification({
      kind:'update',
      title:c.engineUpdateAlertTitle,
      description:c.engineUpdateAlertDescription.replace('{version}',normalizedVersion(latest.tag)),
      dedupeKey:`engine-update:${latest.tag}`,
    })
  },[addNotification,c.engineUpdateAlertDescription,c.engineUpdateAlertTitle])

  const checkHubUpdate=useCallback(async(manual=true)=>{
    setHubState('checking')
    try{
      const release=await api.checkHubRelease()
      setHubRelease(release)
      if(!release.latest_version){setHubState('synced');if(manual)notify(c.hubNoPublishedRelease);return}
      if(!release.update_available){setHubState('synced');if(manual)notify(c.hubUpToDate);return}
      setHubState('available')
      addNotification({kind:'update',title:c.hubUpdateAlertTitle,description:`${c.hubUpdateAvailable} ${c.stable} · v${release.latest_version}. ${c.hubUpdateChannel}`,dedupeKey:`hub-update:${release.latest_version}`})
    }catch(e){
      setHubState('error')
      const message=`${c.hubUpdateError}: ${String(e)}`
      if(manual)notify(message,true,c.hubUpdateAlertTitle)
      else addNotification({kind:'error',title:c.hubUpdateAlertTitle,description:localizeNotification(message,true,c,settings?.language),dedupeKey:'hub-update-check-error'})
    }
  },[addNotification,c,notify,settings?.language])

  const openHubUpdate=useCallback(async()=>{
    const releaseUrl=hubRelease?.release_url
    if(!releaseUrl)return
    try{await openUrl(releaseUrl)}
    catch(e){notify(`${c.hubUpdateError}: ${String(e)}`,true,c.hubUpdateAlertTitle)}
  },[c.hubUpdateAlertTitle,c.hubUpdateError,hubRelease?.release_url,notify])

  const refreshProjects=useCallback(()=>{
    if(projectsRefreshInFlight.current)return projectsRefreshInFlight.current
    setProjectsRefreshing(true)
    const task=(async()=>{
      const rows=await api.listProjects()
      startTransition(()=>{
        setProjects(rows)
        setSelectedId(current=>current===null?null:(rows.some(p=>p.id===current)?current:null))
      })
    })().finally(()=>{setProjectsRefreshing(false);projectsRefreshInFlight.current=null})
    projectsRefreshInFlight.current=task
    return task
  },[])

  const refreshVersions=useCallback((forceRefresh=true,announce=true)=>{
    if(versionsRefreshInFlight.current)return versionsRefreshInFlight.current
    setEngineCatalogState('refreshing')
    const task=(async()=>{
      const [installedRows,availableRows]=await Promise.all([
        api.listInstalledGodotVersions(),
        api.fetchAvailableGodotVersions(forceRefresh),
      ])
      const sorted=sortReleases(availableRows)
      startTransition(()=>{setVersions(installedRows);setAvailable(sorted)})
      if(announce)announceEngineUpdate(sorted,installedRows)
    })().finally(()=>{setEngineCatalogState('idle');versionsRefreshInFlight.current=null})
    versionsRefreshInFlight.current=task
    return task
  },[announceEngineUpdate])

  useEffect(()=>{
    Promise.all([api.getSettings(),api.listProjects(),api.listInstalledGodotVersions()]).then(([s,p,v])=>{
      setSettings(s);applyUiPreferences(s);startTransition(()=>{setProjects(p);setVersions(v);setSelectedId(p[0]?.id??null)})
    }).catch(e=>setFatal(String(e))).finally(()=>setLoading(false))
  },[applyUiPreferences])


  useEffect(()=>{
    if(!settings)return
    // Warm secondary chunks one idle slice at a time. This keeps navigation warm
    // without creating a single parse/IO burst immediately after startup.
    const queue:Tab[]=['versions','plans','community','freelancers','github','settings','about','stores']
    let index=0
    let canceled=false
    let cancelScheduled=()=>{}
    const next=()=>{
      if(canceled||index>=queue.length)return
      preloadView(queue[index++])
      cancelScheduled=scheduleIdle(next)
    }
    cancelScheduled=scheduleIdle(next)
    return ()=>{canceled=true;cancelScheduled()}
  },[settings])

  useEffect(()=>{
    if(!settings||engineStartupCheckDone.current)return
    engineStartupCheckDone.current=true
    engineHeadLastCheck.current=Date.now()
    void refreshVersions(false,true).catch(error=>{
      void error
      addNotification({kind:'error',title:c.engine,description:localizeNotification(String(error),true,c,settings.language),dedupeKey:'engine-catalog-refresh-error'})
    })
  },[addNotification,c,refreshVersions,settings])

  useEffect(()=>{
    let disposed=false
    let unlisten:UnlistenFn|undefined
    void listen<GodotRelease[]>('jingu-engine-catalog-refreshed',({payload})=>{
      if(disposed)return
      const sorted=sortReleases(payload)
      startTransition(()=>setAvailable(sorted))
      announceEngineUpdate(sorted,versions)
    }).then(fn=>{if(disposed)void fn();else unlisten=fn})
    return()=>{disposed=true;if(unlisten)void unlisten()}
  },[announceEngineUpdate,versions])

  useEffect(()=>{
    let unlisten:UnlistenFn|undefined
    void listen<JinguMembershipProfile>('jingu-membership-refreshed',({payload})=>{
      setMembershipProfile(payload)
      window.dispatchEvent(new CustomEvent('jingu-membership-changed',{detail:payload}))
    }).then(fn=>{unlisten=fn})
    return()=>{unlisten?.()}
  },[])

  useEffect(()=>{
    let disposed=false
    void api.hubRuntimeInfo().then(runtime=>{if(!disposed)setHubRuntime(runtime)}).catch(()=>{})
    return()=>{disposed=true}
  },[])

  useEffect(()=>{
    if(!settings||releaseCheckDone.current)return
    releaseCheckDone.current=true
    void checkHubUpdate(false)
  },[checkHubUpdate,settings])

  useEffect(()=>{
    const onAuthChanged=()=>{
      // GitHub authorization is a runtime capability. Refresh immediately so
      // TEST rows appear only after an authorized login and disappear on sign-out.
      void refreshVersions(true,false).catch(()=>{})
      void checkHubUpdate(false)
    }
    window.addEventListener('jingu-github-auth-changed',onAuthChanged)
    window.addEventListener('jingu-private-capabilities-changed',onAuthChanged)
    return()=>{window.removeEventListener('jingu-github-auth-changed',onAuthChanged);window.removeEventListener('jingu-private-capabilities-changed',onAuthChanged)}
  },[checkHubUpdate,refreshVersions])

  const refreshMembershipProfile=useCallback((force=false)=>{
    if(membershipRefreshInFlight.current)return membershipRefreshInFlight.current
    const task=api.membershipProfile(force).then(profile=>{setMembershipProfile(profile);window.dispatchEvent(new CustomEvent('jingu-membership-changed',{detail:profile}));return profile}).catch(error=>{
      void error
      return null
    }).finally(()=>{membershipRefreshInFlight.current=null})
    membershipRefreshInFlight.current=task
    return task
  },[])

  const refreshMembershipOnly=useCallback(async()=>{void await refreshMembershipProfile(true)},[refreshMembershipProfile])

  useEffect(()=>{
    const clearTimers=()=>{for(const timer of paymentRefreshTimers.current)window.clearTimeout(timer);paymentRefreshTimers.current=[]}
    const schedule=()=>{
      if(Date.now()>paymentRefreshUntil.current)return
      clearTimers()
      // A payment provider can confirm the transaction shortly after the browser returns.
      // Poll only the lightweight membership endpoint for a short bounded window;
      // normal private GitHub capability revalidation remains on its own cadence.
      paymentRefreshTimers.current=[0,1500,4000,8000,15000].map(delay=>window.setTimeout(()=>{
        if(Date.now()<=paymentRefreshUntil.current)void refreshMembershipOnly()
      },delay))
    }
    const onCheckoutStarted=()=>{paymentRefreshUntil.current=Date.now()+3*60_000;schedule()}
    const onFocus=()=>schedule()
    const onVisibility=()=>{if(document.visibilityState==='visible')schedule()}
    let unlistenPaymentReturn:UnlistenFn|undefined
    void listen('jingu-payment-browser-returned',()=>{paymentRefreshUntil.current=Math.max(paymentRefreshUntil.current,Date.now()+3*60_000);schedule()}).then(fn=>{unlistenPaymentReturn=fn})
    window.addEventListener('jingu-payment-checkout-started',onCheckoutStarted)
    window.addEventListener('focus',onFocus)
    document.addEventListener('visibilitychange',onVisibility)
    return()=>{clearTimers();unlistenPaymentReturn?.();window.removeEventListener('jingu-payment-checkout-started',onCheckoutStarted);window.removeEventListener('focus',onFocus);document.removeEventListener('visibilitychange',onVisibility)}
  },[refreshMembershipOnly])

  const revalidatePrivateCapabilities=useCallback((forceMembership=false,force=false)=>{
    if(privateRevalidationInFlight.current)return privateRevalidationInFlight.current
    if(!force&&Date.now()-privateCapabilityLastCheck.current<90_000)return Promise.resolve()
    privateCapabilityLastCheck.current=Date.now()
    const task=(async()=>{
      let signature='anonymous'
      try{
        const session=await api.githubSession()
        setGithubUser(session)
        if(session){
          // Start both calls together. Membership display and private GitHub capability
          // checks are independent; coalescing prevents focus + visibility from causing
          // duplicate server round-trips.
          const membershipPromise=refreshMembershipProfile(forceMembership)
          const accessPromise=api.githubPrivateAccess().then(value=>({ok:true as const,value})).catch(error=>({ok:false as const,error}))
          await membershipPromise
          const accessResult=await accessPromise
          if(accessResult.ok){
            const access=accessResult.value
            signature=`${access.engine_test_releases?'1':'0'}${access.hub_test_releases?'1':'0'}`
          }else{
            signature='unverified'
            void accessResult.error
          }
        }else{setMembershipProfile(null)}
      }catch(error){
        // A remembered local user must never remain visible when the session can
        // no longer be validated remotely. Credentials are preserved on transient
        // failures by Rust, but UI identity is fail-closed until validation works.
        setGithubUser(null)
        setMembershipProfile(null)
        signature='anonymous'
        void error
      }
      const previous=privateCapabilitySignature.current
      privateCapabilitySignature.current=signature
      if(previous!==null&&previous!==signature)window.dispatchEvent(new CustomEvent('jingu-private-capabilities-changed'))
    })().finally(()=>{privateRevalidationInFlight.current=null})
    privateRevalidationInFlight.current=task
    return task
  },[refreshMembershipProfile])

  useEffect(()=>{
    void revalidatePrivateCapabilities()
    const timer=window.setInterval(()=>void revalidatePrivateCapabilities(),5*60_000)
    const onFocus=()=>void revalidatePrivateCapabilities(false)
    const onVisibility=()=>{if(document.visibilityState==='visible')void revalidatePrivateCapabilities(false)}
    const onAuth=()=>void revalidatePrivateCapabilities(true,true)
    window.addEventListener('focus',onFocus)
    window.addEventListener('jingu-github-auth-changed',onAuth)
    document.addEventListener('visibilitychange',onVisibility)
    return()=>{window.clearInterval(timer);window.removeEventListener('focus',onFocus);window.removeEventListener('jingu-github-auth-changed',onAuth);document.removeEventListener('visibilitychange',onVisibility)}
  },[revalidatePrivateCapabilities])

  const checkEngineHead=useCallback(async()=>{
    if(!settings)return
    const now=Date.now()
    if(now-engineHeadLastCheck.current<15*60_000)return
    engineHeadLastCheck.current=now
    try{
      const latest=await api.checkLatestEngineRelease()
      if(latest&&!available.some(row=>normalizedVersion(row.tag)===normalizedVersion(latest)))await refreshVersions(true,true)
    }catch(error){
      void error
      addNotification({kind:'error',title:c.engine,description:localizeNotification(String(error),true,c,settings.language),dedupeKey:'engine-catalog-background-error'})
    }
  },[addNotification,available,c,refreshVersions,settings])

  useEffect(()=>{
    if(!settings)return
    const timer=window.setInterval(()=>void checkEngineHead(),15*60_000)
    const onFocus=()=>void checkEngineHead()
    const onVisibility=()=>{if(document.visibilityState==='visible')void checkEngineHead()}
    window.addEventListener('focus',onFocus)
    document.addEventListener('visibilitychange',onVisibility)
    return()=>{window.clearInterval(timer);window.removeEventListener('focus',onFocus);document.removeEventListener('visibilitychange',onVisibility)}
  },[checkEngineHead,settings])

  useEffect(()=>{if(tab!=='stores')void api.storeBrowserHide().catch(()=>{})},[tab])

  const downloadDescription=useCallback((state:SessionDownloadState,detail?:string)=>{
    if(detail?.trim())return detail.trim()
    if(state==='queued')return c.downloadQueuedDescription
    if(state==='downloading')return c.downloadActiveDescription
    if(state==='paused')return c.downloadPausedDescription
    if(state==='complete')return c.downloadCompleteDescription
    if(state==='canceled')return c.downloadCanceledDescription
    return c.downloadErrorDescription
  },[c.downloadActiveDescription,c.downloadCanceledDescription,c.downloadCompleteDescription,c.downloadErrorDescription,c.downloadPausedDescription,c.downloadQueuedDescription])

  const upsertDownload=useCallback((jobKey:string,data:{label:string;source:'engine'|'store';state:SessionDownloadState;progress:number|null;detail?:string})=>{
    const now=Date.now()
    setDownloadHistory(current=>{
      const index=current.findIndex(item=>item.jobKey===jobKey&&!isTerminalDownload(item.state))
      const description=downloadDescription(data.state,data.detail)
      const nextData={label:data.label,source:data.source,state:data.state,progress:data.progress}
      if(index>=0){
        const next=[...current]
        const previous=next[index]
        const progress=data.progress===null&&(data.state==='paused'||data.state==='canceled')?previous.progress:data.progress
        next[index]={...previous,...nextData,progress,description,updatedAt:now,unread:previous.unread||(!downloadsOpenRef.current&&isTerminalDownload(data.state))}
        return next
      }
      const record:SessionDownload={id:`download-${now}-${++downloadSequence.current}`,jobKey,...nextData,description,createdAt:now,updatedAt:now,unread:!downloadsOpenRef.current}
      return [record,...current].slice(0,100)
    })
  },[downloadDescription])

  useEffect(()=>{
    let disposed=false
    const unlisteners:UnlistenFn[]=[]
    const engineLabel=(tag:string)=>`Jingu Engine ${tag.replace(/^v/,'')}`
    const subscribe=async()=>{
      const handlers=await Promise.all([
        listen<string>('godot-download-started',({payload})=>upsertDownload(`engine:${payload}`,{label:engineLabel(payload),source:'engine',state:'downloading',progress:null})),
        listen<string>('godot-download-queued',({payload})=>upsertDownload(`engine:${payload}`,{label:engineLabel(payload),source:'engine',state:'queued',progress:null})),
        listen<string>('godot-download-paused',({payload})=>upsertDownload(`engine:${payload}`,{label:engineLabel(payload),source:'engine',state:'paused',progress:null})),
        listen<EngineDownloadProgress>('godot-download-progress',({payload})=>{const progress=payload.total>0?Math.min(100,Math.round(payload.downloaded/payload.total*100)):null;upsertDownload(`engine:${payload.tag}`,{label:engineLabel(payload.tag),source:'engine',state:'downloading',progress})}),
        listen<string>('godot-download-complete',({payload})=>{const label=engineLabel(payload);upsertDownload(`engine:${payload}`,{label,source:'engine',state:'complete',progress:100});addNotification({kind:'success',title:c.downloadComplete,description:`${label}. ${c.downloadCompleteDescription}`})}),
        listen<string>('godot-download-canceled',({payload})=>upsertDownload(`engine:${payload}`,{label:engineLabel(payload),source:'engine',state:'canceled',progress:null})),
        listen<{tag:string;message:string}>('godot-download-error',({payload})=>{const label=engineLabel(payload.tag);upsertDownload(`engine:${payload.tag}`,{label,source:'engine',state:'error',progress:null,detail:payload.message});addNotification({kind:'error',title:c.error,description:`${label}: ${localizeNotification(payload.message,true,c,settings?.language)}`})}),
        listen<StoreDownloadPayload>('store-download-started',({payload})=>upsertDownload(`store:${payload.path||payload.url}`,{label:payload.name||c.downloads,source:'store',state:'downloading',progress:null})),
        listen<StoreDownloadPayload>('store-download-complete',({payload})=>{const label=payload.name||c.downloads;upsertDownload(`store:${payload.path||payload.url}`,{label,source:'store',state:'complete',progress:100});addNotification({kind:'success',title:c.downloadComplete,description:`${label}. ${c.downloadCompleteDescription}`})}),
        listen<StoreDownloadPayload>('store-download-error',({payload})=>{const label=payload.name||c.downloads;upsertDownload(`store:${payload.path||payload.url}`,{label,source:'store',state:'error',progress:null});addNotification({kind:'error',title:c.error,description:`${label}. ${c.downloadErrorDescription}`})}),
      ])
      if(disposed){handlers.forEach(unlisten=>unlisten());return}
      unlisteners.push(...handlers)
      const active=await api.listGodotDownloads().catch(()=>[])
      if(disposed)return
      for(const item of active)upsertDownload(`engine:${item.tag}`,{label:engineLabel(item.tag),source:'engine',state:item.state,progress:null})
    }
    void subscribe().catch(()=>{})
    return()=>{disposed=true;unlisteners.splice(0).forEach(unlisten=>unlisten())}
  },[addNotification,c,settings?.language,upsertDownload])

  const unreadAlerts=notifications.reduce((count,item)=>count+(item.unread?1:0),0)
  const unreadDownloads=downloadHistory.reduce((count,item)=>count+(item.unread?1:0),0)
  const activeDownloads=downloadHistory.filter(item=>!isTerminalDownload(item.state))
  const toggleAlerts=()=>{setDownloadsOpen(false);setAlertsOpen(current=>{const next=!current;if(next)setNotifications(items=>items.map(item=>item.unread?{...item,unread:false}:item));return next})}
  const toggleDownloads=()=>{setAlertsOpen(false);setDownloadsOpen(current=>{const next=!current;if(next)setDownloadHistory(items=>items.map(item=>item.unread?{...item,unread:false}:item));return next})}
  const closePanels=()=>{setAlertsOpen(false);setDownloadsOpen(false)}


  const nav:Array<{id:Tab;label:string;icon:IconName}>=[
    {id:'projects',label:c.projects,icon:'projects'},
    {id:'versions',label:c.versions,icon:'versions'},
    {id:'stores',label:c.stores,icon:'store'},
    {id:'community',label:c.community,icon:'users'},
    {id:'freelancers',label:c.freelancers,icon:'briefcase'},
    {id:'github',label:c.github,icon:'github'},
  ]

  if(loading)return <div className="flex h-screen items-center justify-center bg-base px-6 text-ink"><div className="w-full max-w-sm rounded-xl border border-line bg-surface p-6 text-center shadow-2xl"><div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-line border-t-accent"/><div className="mt-4 text-sm font-semibold">{c.loadingHub}</div><div className="mt-1 text-xs leading-5 text-muted">{c.loadingHubDetail}</div></div></div>
  if(fatal||!settings)return <div className="flex h-screen items-center justify-center bg-base p-8 text-center text-danger">{fatal||c.error}</div>

  return <div className="flex h-screen w-screen flex-col overflow-hidden bg-base text-ink">
    <TitleBar stableLabel={c.stable} minimizeLabel={c.minimize} maximizeLabel={c.maximize} closeLabel={c.close} user={githubUser} membership={membershipProfile}/>
    <div className="flex min-h-0 flex-1">
      <aside className="flex w-[230px] shrink-0 flex-col border-e border-line bg-surface px-3 pb-3">
        <div className="flex h-[118px] items-center justify-center"><img src="/jingu-engine-logo.png" alt="Jingu Engine" className="max-h-[82px] max-w-[185px] object-contain"/></div>
        <nav className="grid gap-1">{nav.map(item=><NavButton key={item.id} active={tab===item.id} icon={item.icon} label={item.label} onPreload={()=>preloadView(item.id)} onClick={()=>{closePanels();setTab(item.id)}}/>)}</nav>
        <div className="mt-auto"><div className="mb-1 grid grid-cols-3 gap-1"><UtilityNavButton active={tab==='plans'} icon="heart" label={c.plans} onPreload={()=>preloadView('plans')} onClick={()=>{closePanels();setTab('plans')}}/><UtilityNavButton active={alertsOpen} icon="bell" label={c.alerts} badge={unreadAlerts} onClick={toggleAlerts}/><UtilityNavButton active={downloadsOpen} icon="download" label={c.downloads} badge={unreadDownloads} onClick={toggleDownloads}/></div><div className="mt-2 border-t border-line pt-3"><NavButton active={tab==='settings'} icon="settings" label={c.settings} onPreload={()=>preloadView('settings')} onClick={()=>{closePanels();setTab('settings')}}/><NavButton active={tab==='about'} icon="info" label={c.about} onPreload={()=>preloadView('about')} onClick={()=>{closePanels();setTab('about')}}/></div></div>
      </aside>
      <main className="relative min-w-0 flex-1 overflow-hidden bg-[radial-gradient(circle_at_top_left,rgba(105,173,75,.035),transparent_34%)]">
        <BackgroundActivity labels={[projectsRefreshing?c.refreshingProjects:null,engineCatalogState==='refreshing'?c.refreshingVersions:null,hubState==='checking'?c.syncingGitHubReleases:null].filter((label):label is string=>Boolean(label))}/>
        <AnimatePresence mode="wait" initial={false}>
          <motion.div key={tab} className="absolute inset-0" initial={animations?{opacity:0,y:4}:{opacity:1}} animate={{opacity:1,y:0}} exit={animations?{opacity:0,y:-3}:{opacity:1}} transition={{duration: animations ? 0.14 : 0}}>
            <Suspense fallback={<ViewLoading label={c.loadingHub}/>}>
              {tab==='projects'&&<ProjectsView c={c} projects={projects} versions={versions} selectedId={selectedId} animations={animations} onSelect={setSelectedId} onDeselect={()=>setSelectedId(null)} onRefresh={refreshProjects} refreshing={projectsRefreshing} notify={notify} settings={settings}/>} 
              {tab==='versions'&&<VersionsView c={c} installed={versions} available={available} onRefresh={()=>refreshVersions(true,true)} catalogRefreshing={engineCatalogState==='refreshing'} notify={notify} hubRuntime={hubRuntime} hubRelease={hubRelease} hubState={hubState} onCheckHubUpdate={()=>checkHubUpdate(true)} onOpenHubUpdate={openHubUpdate}/>} 
              {tab==='community'&&<CommunityView c={c} notify={notify} onRequireGitHubLogin={()=>{closePanels();setTab('github')}}/>}
              {tab==='freelancers'&&<FreelancersView c={c} language={settings.language} membership={membershipProfile} notify={notify} onRequireGitHubLogin={()=>{closePanels();setTab('github')}}/>}
              {tab==='github'&&<GitHubView c={c} projects={projects} selectedId={selectedId} onSelect={setSelectedId} notify={notify} membership={membershipProfile}/>} 
              {tab==='settings'&&<SettingsView c={c} settings={settings} membership={membershipProfile} onChange={async(next)=>{const saved=await api.updateSettings(next);setSettings(saved);applyUiPreferences(saved)}} notify={notify}/>} 
              {tab==='stores'&&<StoreView c={c} notify={notify}/>} 
              {tab==='plans'&&<PlansView c={c} language={settings.language} membership={membershipProfile} notify={notify} onRequireGitHubLogin={()=>{closePanels();setTab('github')}}/>} 
              {tab==='about'&&<AboutView c={c}/>} 
            </Suspense>
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
    <NotificationCenter c={c} language={settings.language} animations={animations} open={alertsOpen} items={notifications} onClose={()=>setAlertsOpen(false)} onClear={id=>setNotifications(items=>items.filter(item=>item.id!==id))} onClearAll={()=>setNotifications([])}/>
    <DownloadHistoryCenter c={c} language={settings.language} animations={animations} open={downloadsOpen} items={downloadHistory} onClose={()=>setDownloadsOpen(false)} onClear={id=>setDownloadHistory(items=>items.filter(item=>item.id!==id))} onClearCompleted={()=>setDownloadHistory(items=>items.filter(item=>!isTerminalDownload(item.state)))}/>
    <ActiveDownloadOverlay c={c} items={activeDownloads}/>
    <Toast message={toast?.message??null} kind={toast?.error?'error':'success'}/>
  </div>
}

function ViewLoading({label}:{label:string}){return <div className="grid h-full place-items-center"><div className="flex items-center gap-2 text-sm text-muted"><span className="h-4 w-4 animate-spin rounded-full border-2 border-line border-t-accent"/>{label}</div></div>}

function BackgroundActivity({labels}:{labels:string[]}){
  if(!labels.length)return null
  return <div className="pointer-events-none absolute right-5 top-4 z-[80] grid max-w-[360px] gap-2">{labels.map(label=><div key={label} className="flex items-center gap-2 rounded-lg border border-accent/25 bg-surface/95 px-3 py-2 text-xs font-medium text-muted shadow-lg backdrop-blur"><span className="h-3.5 w-3.5 shrink-0 animate-spin rounded-full border-2 border-line border-t-accent"/><span className="truncate">{label}</span></div>)}</div>
}

function ActiveDownloadOverlay({c,items}:{c:ReturnType<typeof copyFor>;items:SessionDownload[]}){
  if(!items.length)return null
  const visible=items.slice(0,3)
  const status=(item:SessionDownload)=>item.state==='queued'?c.queued:item.state==='paused'?c.paused:c.downloading
  return <div className="fixed bottom-5 left-[250px] z-[110] w-[360px] max-w-[calc(100vw-280px)] overflow-hidden rounded-lg border border-line bg-surface/95 shadow-2xl backdrop-blur">
    <div className="flex items-center gap-2 border-b border-line px-3.5 py-2.5 text-xs font-semibold uppercase tracking-wide text-muted"><span className="h-3 w-3 animate-spin rounded-full border-2 border-line border-t-accent"/>{c.downloads}</div>
    <div className="grid max-h-56 overflow-y-auto">{visible.map(item=><div key={item.id} className="border-b border-line/60 px-3.5 py-2.5 last:border-0"><div className="flex min-w-0 items-center gap-3"><div className="min-w-0 flex-1"><div className="truncate text-sm font-medium">{item.label}</div><div className="mt-0.5 text-xs text-muted">{status(item)}{item.progress!==null?` · ${item.progress}%`:''}</div></div><Icon name={item.state==='paused'?'pause':'download'} className="h-4 w-4 shrink-0 text-muted"/></div><div className="mt-2 h-1 overflow-hidden rounded-full bg-base"><div className={`h-full bg-accent transition-[width] ${item.progress===null?'animate-pulse':''}`} style={{width:item.progress===null?'28%':`${Math.max(item.progress,2)}%`}}/></div></div>)}</div>
    {items.length>visible.length&&<div className="border-t border-line px-3.5 py-2 text-xs text-muted">+{items.length-visible.length}</div>}
  </div>
}

function UtilityNavButton({active,icon,label,onClick,onPreload,badge=0}:{active:boolean;icon:IconName;label:string;onClick:()=>void;onPreload?:()=>void;badge?:number}){
  return <button type="button" title={label} aria-label={label} onClick={onClick} onPointerEnter={onPreload} onFocus={onPreload} className={`focus-ring grid h-11 w-full place-items-center rounded-md border transition-all ${active?'border-accent/45 bg-accent/15 text-accent-bright':'border-transparent text-muted hover:border-line hover:bg-raised hover:text-ink'}`}><div className="relative"><Icon name={icon} className="h-5 w-5"/>{badge>0&&<span className="absolute -right-2.5 -top-2.5 grid min-h-4 min-w-4 place-items-center rounded-full bg-accent px-1 text-[10px] font-bold leading-4 text-white">{badge>99?'99+':badge}</span>}</div></button>
}

function NavButton({active,icon,label,onClick,onPreload,badge=0,tone='default'}:{active:boolean;icon:IconName;label:string;onClick:()=>void;onPreload?:()=>void;badge?:number;tone?:'default'|'support'}){
  const idle=tone==='support'?'border-transparent text-muted hover:border-accent/40 hover:bg-accent/10 hover:text-accent-bright':'border-transparent text-muted hover:bg-raised hover:text-ink'
  return <button onClick={onClick} onPointerEnter={onPreload} onFocus={onPreload} className={`focus-ring flex h-11 w-full items-center gap-3 rounded-md border-s-2 px-3 text-start text-sm transition-all ${active?'border-accent bg-accent/15 text-ink':idle}`}><div className="relative shrink-0"><Icon name={icon} className={`h-5 w-5 ${active?'text-accent-bright':tone==='support'?'text-accent-bright/80':''}`}/>{badge>0&&<span className="absolute -right-2 -top-2 grid min-h-4 min-w-4 place-items-center rounded-full bg-accent px-1 text-[10px] font-bold leading-4 text-white">{badge>99?'99+':badge}</span>}</div><span className="min-w-0 flex-1 truncate">{label}</span></button>
}

function membershipTone(tier:string|undefined|null){
  switch((tier??'').toLowerCase()){
    case 'gold': return {text:'text-amber-200', border:'border-amber-300/35', bg:'bg-amber-300/10'}
    case 'silver': return {text:'text-slate-100', border:'border-slate-300/35', bg:'bg-slate-300/10'}
    case 'bronze': return {text:'text-orange-200', border:'border-orange-300/35', bg:'bg-orange-300/10'}
    default: return {text:'text-accent-bright', border:'border-accent/25', bg:'bg-base/60'}
  }
}

function releaseChannelLabel(channel:string,stableLabel:string){
  switch(channel){case 'stable':return stableLabel;case 'beta':return 'Beta';case 'experimental':return 'Experimental';case 'dev':return 'Dev';default:return channel}
}

function TitleBar({stableLabel,minimizeLabel,maximizeLabel,closeLabel,user,membership}:{stableLabel:string;minimizeLabel:string;maximizeLabel:string;closeLabel:string;user:GitHubUser|null;membership:JinguMembershipProfile|null}){
  const win=getCurrentWindow()
  const tone=membershipTone(membership?.tier)
  return <header dir="ltr" className="flex h-9 shrink-0 items-center border-b border-black/30 bg-[#202020] text-[#d7d7d7]">
    <div data-tauri-drag-region className="flex h-full min-w-0 flex-1 items-center gap-2 px-2 text-xs"><img src="/jingu-hub-icon.png" alt="" className="h-5 w-5 rounded"/><span data-tauri-drag-region className="font-medium">Jingu Hub</span><span data-tauri-drag-region className="rounded-full border border-accent/30 bg-accent/10 px-2 py-0.5 text-[10px] font-semibold text-accent-bright">{releaseChannelLabel(releaseProfile.channel,stableLabel)} - v{releaseProfile.version}</span></div>
    {user&&<div className={`mr-2 flex h-7 items-center gap-2 rounded-md border px-2 text-[11px] ${tone.border} ${tone.bg}`}><img src={user.avatar_url} alt="" className="h-4 w-4 rounded-full"/><span className={`max-w-40 truncate ${tone.text}`}>@{user.login}</span>{membership?.badge_label&&<span className={`rounded-full border px-1.5 py-0.5 text-[9px] font-bold uppercase ${tone.border} ${tone.bg} ${tone.text}`}>{membership.badge_label}</span>}</div>}
    <div className="flex h-full items-center"><IconButton icon="minimize" label={minimizeLabel} className="h-9 w-12 rounded-none border-0 hover:bg-white/10" onClick={()=>win.minimize()}/><IconButton icon="maximize" label={maximizeLabel} className="h-9 w-12 rounded-none border-0 hover:bg-white/10" onClick={()=>win.toggleMaximize()}/><IconButton icon="close" label={closeLabel} className="h-9 w-12 rounded-none border-0 hover:bg-danger hover:text-white" onClick={()=>win.close()}/></div>
  </header>
}
