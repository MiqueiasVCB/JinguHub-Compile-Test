/**************************************************************************/
/*  CurrencySelect.tsx                                                  */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { useEffect, useMemo, useRef, useState } from 'react'
import type { PaymentCurrencyOption } from '../../types'
import type { JinguCopy } from '../copy'
import { currencyPresentation } from '../currencyPresentation'
import { Icon } from './Icon'

export function CurrencySelect({
  options,value,locale,c,onChange,
}:{
  options:PaymentCurrencyOption[]
  value:string
  locale:string
  c:JinguCopy
  onChange:(code:string)=>void
}){
  const rootRef=useRef<HTMLDivElement|null>(null)
  const [open,setOpen]=useState(false)
  const selectedIndex=Math.max(0,options.findIndex(option=>option.code===value))
  const [activeIndex,setActiveIndex]=useState(selectedIndex)
  const selected=options[selectedIndex]??options[0]
  const selectedPresentation=selected?currencyPresentation(selected,locale):null
  const listId='jingu-payment-currency-options'

  useEffect(()=>{setActiveIndex(selectedIndex)},[selectedIndex])
  useEffect(()=>{
    if(!open)return
    const onPointer=(event:MouseEvent)=>{
      if(rootRef.current&&!rootRef.current.contains(event.target as Node))setOpen(false)
    }
    document.addEventListener('mousedown',onPointer)
    return()=>document.removeEventListener('mousedown',onPointer)
  },[open])

  const enabledIndexes=useMemo(()=>options.map((option,index)=>option.available?index:-1).filter(index=>index>=0),[options])
  const move=(direction:1|-1)=>{
    if(enabledIndexes.length===0)return
    const currentPosition=Math.max(0,enabledIndexes.indexOf(activeIndex))
    const nextPosition=(currentPosition+direction+enabledIndexes.length)%enabledIndexes.length
    setActiveIndex(enabledIndexes[nextPosition])
  }
  const choose=(index:number)=>{
    const option=options[index]
    if(!option?.available)return
    onChange(option.code)
    setActiveIndex(index)
    setOpen(false)
  }

  return <div ref={rootRef} className="relative">
    <button
      type="button"
      role="combobox"
      aria-controls={listId}
      aria-expanded={open}
      aria-haspopup="listbox"
      aria-label={c.paymentCurrency}
      className="focus-ring flex h-11 w-full items-center gap-2.5 rounded-md border border-line bg-base px-3 text-left text-sm text-ink transition hover:border-accent-dim focus:border-accent"
      onClick={()=>setOpen(current=>!current)}
      onKeyDown={event=>{
        if(event.key==='Escape'){setOpen(false);return}
        if(event.key==='ArrowDown'){event.preventDefault();setOpen(true);move(1);return}
        if(event.key==='ArrowUp'){event.preventDefault();setOpen(true);move(-1);return}
        if(event.key==='Enter'&&open){event.preventDefault();choose(activeIndex)}
      }}
    >
      {selectedPresentation&&<img src={selectedPresentation.flagAsset} alt="" aria-hidden className="h-[18px] w-6 shrink-0 rounded-[2px] object-contain"/>}
      <span className="min-w-0 flex-1 truncate font-medium">{selected?`${selected.code.toUpperCase()} - ${selectedPresentation?.origin??selected.code}`:'—'}</span>
      <Icon name="chevronRight" className={`h-4 w-4 shrink-0 text-muted transition-transform ${open?'-rotate-90':'rotate-90'}`}/>
    </button>
    {open&&<div id={listId} role="listbox" aria-label={c.paymentCurrency} className="absolute right-0 z-[70] mt-2 max-h-[360px] w-full min-w-[360px] overflow-y-auto rounded-md border border-line bg-surface p-1.5 shadow-2xl">
      {options.map((option,index)=>{
        const presentation=currencyPresentation(option,locale)
        const active=index===activeIndex
        const selectedOption=option.code===value
        return <button
          key={option.code}
          type="button"
          role="option"
          aria-selected={selectedOption}
          disabled={!option.available}
          className={`focus-ring flex w-full items-center gap-2.5 rounded px-3 py-2.5 text-left text-sm transition disabled:cursor-not-allowed disabled:opacity-45 ${active?'bg-raised':''} ${selectedOption?'text-accent-bright':'text-ink'} hover:bg-raised`}
          onMouseEnter={()=>option.available&&setActiveIndex(index)}
          onClick={()=>choose(index)}
        >
          <img src={presentation.flagAsset} alt="" aria-hidden className="h-[18px] w-6 shrink-0 rounded-[2px] object-contain"/>
          <span className="font-mono font-semibold">{option.code.toUpperCase()}</span>
          <span className="text-muted">-</span>
          <span className="min-w-0 flex-1 truncate">{presentation.origin}</span>
          {!option.available&&<span className="ml-auto text-[10px] uppercase tracking-wide text-muted">{c.comingSoon}</span>}
        </button>
      })}
    </div>}
  </div>
}
