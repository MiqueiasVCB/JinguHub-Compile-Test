/**************************************************************************/
/*  Icon.tsx                                                            */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import type { ReactNode, SVGProps } from 'react'

export type IconName =
  | 'projects' | 'versions' | 'store' | 'github' | 'settings' | 'info' | 'bell' | 'heart'
  | 'plus' | 'folder' | 'search' | 'refresh' | 'clean' | 'star' | 'crown' | 'more'
  | 'play' | 'pause' | 'download' | 'trash' | 'external' | 'link' | 'logout'
  | 'pull' | 'push' | 'fetch' | 'branch' | 'check' | 'copy' | 'x'
  | 'minimize' | 'maximize' | 'close' | 'lock' | 'globe' | 'git' | 'arrowLeft' | 'browser' | 'home' | 'chevronRight' | 'users' | 'briefcase' | 'warning'
  | 'whatsapp' | 'discord' | 'instagram' | 'mail' | 'telegram' | 'linkedin'

const paths: Record<IconName, ReactNode> = {
  projects: <><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M8 4v16M4 9h3M4 14h3M11 8h7M11 12h7M11 16h5"/></>,
  versions: <><path d="M4 12a8 8 0 1 0 2.3-5.65L4 8"/><path d="M4 4v4h4M12 8v4l3 2"/></>,
  store: <><path d="M4 10h16l-1 10H5L4 10Z"/><path d="M7 10V8a5 5 0 0 1 10 0v2"/></>,
  github: <><circle cx="7" cy="7" r="3"/><circle cx="17" cy="6" r="3"/><circle cx="17" cy="18" r="3"/><path d="M9.5 8.5l5 6.5M9.7 6.7l4.3-.5"/></>,
  settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21h-4v-.1a1.7 1.7 0 0 0-1.4-1.5 1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 3.8 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H2v-4h.1A1.7 1.7 0 0 0 3.6 8.2a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 8 3.8a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V2h4v.1A1.7 1.7 0 0 0 14.8 3.6a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 20.2 8c.2.38.3.8.3 1.2V9h1v4h-1v-.1a1.7 1.7 0 0 0-1.1 2.1Z"/></>,
  info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
  heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"/>,
  plus: <path d="M12 5v14M5 12h14"/>,
  folder: <path d="M3 7h7l2 2h9v10H3V7Z"/>,
  search: <><circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5"/></>,
  refresh: <><path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 8A7 7 0 0 1 18 7l2 5M18 16a7 7 0 0 1-12 1l-2-5"/></>,
  clean: <><path d="m4 15 5-9 6 3-5 10H5l-1-4Z"/><path d="M10 19h10M14 12l5 2"/></>,
  star: <path d="m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9L12 3Z"/>,
  crown: <><path d="M4 18h16l-1.2-9-4.3 3.5L12 6l-2.5 6.5L5.2 9 4 18Z"/><path d="M5 21h14M4.8 9 3 6m16.2 3L21 6M12 6V3"/></>,
  more: <><circle cx="12" cy="5" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="12" cy="19" r="1" fill="currentColor"/></>,
  play: <path d="m9 6 9 6-9 6V6Z"/>,
  pause: <><path d="M9 6v12"/><path d="M15 6v12"/></>,
  download: <><path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 20h14"/></>,
  trash: <><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 11v5M14 11v5"/></>,
  external: <><path d="M14 4h6v6M20 4l-9 9"/><path d="M19 14v5H5V5h5"/></>,
  link: <><path d="m10 13 4-4"/><path d="M8 16H7a4 4 0 0 1 0-8h4M16 8h1a4 4 0 1 1 0 8h-4"/></>,
  logout: <><path d="M10 5H5v14h5M14 8l4 4-4 4M18 12H9"/></>,
  pull: <><path d="M12 4v14M7 13l5 5 5-5"/><path d="M5 4h14"/></>,
  push: <><path d="M12 20V6M7 11l5-5 5 5"/><path d="M5 20h14"/></>,
  fetch: <><path d="M5 7a8 8 0 0 1 14 2M19 5v4h-4M19 17a8 8 0 0 1-14-2M5 19v-4h4"/></>,
  branch: <><circle cx="7" cy="5" r="2"/><circle cx="7" cy="19" r="2"/><circle cx="17" cy="8" r="2"/><path d="M7 7v10M9 10c5 0 6-2 6-2"/></>,
  check: <path d="m5 12 4 4L19 6"/>,
  copy: <><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5H5v11h3"/></>,
  x: <path d="m6 6 12 12M18 6 6 18"/>,
  minimize: <path d="M5 12h14"/>,
  maximize: <rect x="5" y="5" width="14" height="14" rx="1"/>,
  close: <path d="m6 6 12 12M18 6 6 18"/>,
  lock: <><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
  globe: <><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></>,
  git: <><circle cx="6" cy="6" r="2"/><circle cx="18" cy="18" r="2"/><circle cx="18" cy="6" r="2"/><path d="M8 6h8M8 7.5l8.5 8.5"/></>,
  arrowLeft: <path d="M15 18l-6-6 6-6M9 12h10"/>,
  browser: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 9h18"/><path d="M7 7h.01M10 7h.01"/></>,
  home: <><path d="m4 11 8-7 8 7"/><path d="M6 10v10h12V10M10 20v-6h4v6"/></>,
  chevronRight: <path d="m9 18 6-6-6-6"/>,
  users: <><circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3.5 20a5.5 5.5 0 0 1 11 0M14 15.5a4.5 4.5 0 0 1 6.5 4"/></>,
  briefcase: <><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5h8v2M3 12h18M10 12v2h4v-2"/></>,
  warning: <><path d="M12 3 2.8 20h18.4L12 3Z"/><path d="M12 9v5M12 17h.01"/></>,
  whatsapp: <><path d="M20 11.5a8 8 0 0 1-11.7 7L4 20l1.4-4A8 8 0 1 1 20 11.5Z"/><path d="M8.2 7.8c.5 3.3 2.7 5.5 6 6l1.2-1.5 2 .9"/></>,
  discord: <><path d="M7 7.5A13 13 0 0 1 17 7.5c1.5 2.2 2.2 4.8 2.3 7.5-2 1.5-4 2.2-5.7 2.5l-.8-1.2M17 7l-1-2M7 7 8 5"/><path d="M10 12h.01M14 12h.01M8.5 15c2.2 1 4.8 1 7 0"/></>,
  instagram: <><rect x="4" y="4" width="16" height="16" rx="5"/><circle cx="12" cy="12" r="3.5"/><path d="M17.5 6.5h.01"/></>,
  mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></>,
  telegram: <><path d="m3 11 18-7-5 16-5-5-4 3 1-5 9-6-11 5-3-1Z"/></>,
  linkedin: <><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 10v6M8 7.5h.01M12 16v-6M12 12.5a3 3 0 0 1 6 0V16"/></>,
}

export function Icon({ name, ...props }: SVGProps<SVGSVGElement> & { name: IconName }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
      {paths[name]}
    </svg>
  )
}
