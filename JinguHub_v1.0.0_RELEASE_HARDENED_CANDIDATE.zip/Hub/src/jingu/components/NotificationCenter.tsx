/**************************************************************************/
/*  NotificationCenter.tsx                                              */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { AnimatePresence, motion } from 'framer-motion'
import type { JinguCopy } from '../copy'
import { languageOptionValue } from '../copy'
import { Button, IconButton } from './UI'
import { Icon } from './Icon'

export type SessionNotificationKind = 'info' | 'success' | 'error' | 'update'

export type SessionNotification = {
  id: string
  kind: SessionNotificationKind
  title: string
  description: string
  createdAt: number
  unread: boolean
  dedupeKey?: string
}

type Props = {
  c: JinguCopy
  language?: string | null
  animations: boolean
  open: boolean
  items: SessionNotification[]
  onClose: () => void
  onClear: (id: string) => void
  onClearAll: () => void
}

function kindIcon(kind: SessionNotificationKind){
  if(kind==='success')return 'check' as const
  if(kind==='error')return 'x' as const
  if(kind==='update')return 'download' as const
  return 'info' as const
}

function kindClass(kind: SessionNotificationKind){
  if(kind==='error')return 'border-danger/35 bg-danger/8 text-danger'
  if(kind==='success'||kind==='update')return 'border-accent/35 bg-accent/8 text-accent-bright'
  return 'border-line bg-base text-muted'
}

export function NotificationCenter({c,language,animations,open,items,onClose,onClear,onClearAll}:Props){
  const formatter=new Intl.DateTimeFormat(languageOptionValue(language),{hour:'2-digit',minute:'2-digit'})
  return <AnimatePresence>{open&&<motion.section
    role="dialog"
    aria-label={c.alerts}
    className="fixed bottom-3 left-[242px] z-[115] flex max-h-[min(620px,calc(100vh-56px))] w-[430px] max-w-[calc(100vw-260px)] flex-col overflow-hidden rounded-xl border border-accent-dim bg-surface/98 shadow-2xl backdrop-blur"
    initial={animations?{opacity:0,x:-8,y:6,scale:.985}:{opacity:1,x:0,y:0,scale:1}}
    animate={{opacity:1,x:0,y:0,scale:1}}
    exit={animations?{opacity:0,x:-6,y:4,scale:.99}:{opacity:1,x:0,y:0,scale:1}}
    transition={{duration:animations?.15:0}}
  >
    <header className="flex items-center gap-3 border-b border-line px-4 py-3">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-accent/30 bg-accent/10 text-accent-bright"><Icon name="bell" className="h-5 w-5"/></div>
      <div className="min-w-0 flex-1"><div className="font-semibold text-ink">{c.alerts}</div><div className="mt-0.5 text-xs text-muted">{c.alertsSessionHelp}</div></div>
      <IconButton icon="x" label={c.close} onClick={onClose}/>
    </header>
    {items.length===0?<div className="grid min-h-40 place-items-center px-6 py-10 text-center"><div><Icon name="bell" className="mx-auto h-7 w-7 text-muted/70"/><p className="mt-3 text-sm text-muted">{c.noAlerts}</p></div></div>:
      <div className="min-h-0 flex-1 overflow-y-auto p-2">{items.map(item=><article key={item.id} className={`mb-2 rounded-lg border p-3 last:mb-0 ${item.unread?'border-accent/25 bg-raised/70':'border-line bg-base/55'}`}>
        <div className="flex items-start gap-3">
          <div className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-md border ${kindClass(item.kind)}`}><Icon name={kindIcon(item.kind)} className="h-4 w-4"/></div>
          <div className="min-w-0 flex-1"><div className="flex min-w-0 items-baseline gap-2"><h3 className="min-w-0 flex-1 truncate text-sm font-semibold text-ink">{item.title}</h3><time className="shrink-0 text-[11px] text-muted">{formatter.format(item.createdAt)}</time></div><p className="mt-1 whitespace-pre-wrap break-words text-sm leading-5 text-muted">{item.description}</p></div>
          <IconButton icon="x" label={c.clearAlert} className="h-8 w-8 shrink-0" onClick={()=>onClear(item.id)}/>
        </div>
      </article>)}</div>}
    {items.length>0&&<footer className="flex items-center justify-between gap-3 border-t border-line px-4 py-3"><div className="text-xs text-muted">{c.alertsCurrentSession}</div><Button variant="ghost" icon="clean" onClick={onClearAll}>{c.clearAllAlerts}</Button></footer>}
  </motion.section>}</AnimatePresence>
}
