/**************************************************************************/
/*  UI.tsx                                                              */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { AnimatePresence, motion } from 'framer-motion'
import { useEffect } from 'react'
import type { ButtonHTMLAttributes, PropsWithChildren, ReactNode } from 'react'
import { Icon, type IconName } from './Icon'

export function Button({ icon, children, variant='secondary', className='', ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { icon?: IconName; variant?: 'primary'|'secondary'|'ghost'|'danger' }) {
  const styles = variant === 'primary'
    ? 'bg-accent text-white border-accent hover:bg-accent-bright hover:text-white'
    : variant === 'danger'
      ? 'bg-danger/12 text-danger border-danger/30 hover:bg-danger/20'
      : variant === 'ghost'
        ? 'bg-transparent text-muted border-transparent hover:bg-raised hover:text-ink'
        : 'bg-surface text-ink border-line hover:border-accent-dim hover:bg-raised'
  return <button className={`focus-ring inline-flex h-10 items-center justify-center gap-2 rounded-md border px-3.5 text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-55 active:scale-[.98] ${styles} ${className}`} {...props}>
    {icon && <Icon name={icon} className="h-[18px] w-[18px] shrink-0"/>}{children}
  </button>
}

export function IconButton({ icon, label, active=false, className='', ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { icon: IconName; label: string; active?: boolean }) {
  return <button title={label} aria-label={label} className={`focus-ring icon-wiggle inline-flex h-9 w-9 items-center justify-center rounded-md border transition-colors ${active ? 'border-accent/50 bg-accent/15 text-accent-bright' : 'border-transparent text-muted hover:border-line hover:bg-raised hover:text-ink'} ${className}`} {...props}>
    <Icon name={icon} className="h-5 w-5"/>
  </button>
}

export function SectionCard({ children, className='' }: PropsWithChildren<{className?: string}>) {
  return <div className={`rounded-lg border border-line bg-surface ${className}`}>{children}</div>
}

export function Modal({ open, title, onClose, children, footer, width='max-w-xl', closeLabel }: { open:boolean; title:string; onClose:()=>void; children:ReactNode; footer?:ReactNode; width?:string; closeLabel:string }) {
  useEffect(()=>{
    if(!open)return
    const onKeyDown=(event:KeyboardEvent)=>{if(event.key==='Escape')onClose()}
    window.addEventListener('keydown',onKeyDown)
    return()=>window.removeEventListener('keydown',onKeyDown)
  },[open,onClose])
  return <AnimatePresence>{open && <motion.div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/55 p-5" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onMouseDown={(e)=>{if(e.currentTarget===e.target) onClose()}}>
    <motion.div role="dialog" aria-modal="true" aria-label={title} className={`w-full ${width} max-h-[calc(100vh-48px)] overflow-hidden rounded-lg border border-accent-dim bg-surface shadow-2xl`} initial={{opacity:0,scale:.97,y:8}} animate={{opacity:1,scale:1,y:0}} exit={{opacity:0,scale:.98,y:4}} transition={{duration:.16}}>
      <div className="flex h-12 items-center justify-between border-b border-line px-5"><h2 className="font-semibold">{title}</h2><IconButton icon="x" label={closeLabel} onClick={onClose}/></div>
      <div className="max-h-[calc(100vh-170px)] overflow-y-auto p-5">{children}</div>
      {footer && <div className="flex flex-wrap items-center justify-end gap-2 border-t border-line px-5 py-3.5">{footer}</div>}
    </motion.div>
  </motion.div>}</AnimatePresence>
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`focus-ring h-10 min-w-0 rounded-md border border-line bg-base px-3 text-sm text-ink placeholder:text-muted/55 focus:border-accent ${props.className ?? ''}`}/>
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={`focus-ring h-10 min-w-0 rounded-md border border-line bg-base px-3 text-sm text-ink focus:border-accent ${props.className ?? ''}`}/>
}

export function BusyNotice({ label, progress=null }: {label:string; progress?:number|null}) {
  return <div role="status" aria-live="polite" className="rounded-lg border border-accent/30 bg-accent/8 px-4 py-3">
    <div className="flex items-center justify-between gap-3">
      <div className="text-sm font-medium text-ink">{label}</div>
      {progress!==null && <div className="text-xs font-medium text-accent-bright">{progress}%</div>}
    </div>
    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-base">
      {progress===null
        ? <div className="task-progress-indeterminate h-full w-1/3 rounded-full bg-accent"/>
        : <div className="h-full rounded-full bg-accent transition-[width]" style={{width:`${Math.max(0, Math.min(100, progress))}%`}}/>}
    </div>
  </div>
}

export function Toast({ message, kind='success' }: {message:string|null; kind?:'success'|'error'}) {
  return <AnimatePresence>{message && <motion.div role={kind==='error'?'alert':'status'} aria-live={kind==='error'?'assertive':'polite'} className={`fixed bottom-6 right-6 z-[120] max-w-md rounded-md border px-4 py-3 text-sm shadow-xl ${kind==='error' ? 'border-danger/40 bg-[#231416] text-[#ffb6b8]' : 'border-accent/40 bg-raised text-ink'}`} initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} exit={{opacity:0,y:8}}>{message}</motion.div>}</AnimatePresence>
}

export function Toggle({ checked, onChange, label='Toggle' }: {checked:boolean; onChange:(v:boolean)=>void; label?:string}) {
  return <button
    role="switch"
    aria-checked={checked}
    aria-label={label}
    onClick={()=>onChange(!checked)}
    className={`focus-ring relative inline-flex h-7 w-14 shrink-0 items-center rounded-full border transition-colors ${checked?'border-accent bg-accent':'border-line bg-base'}`}
  >
    <span className={`absolute left-1 top-1/2 h-5 w-5 -translate-y-1/2 rounded-full bg-white shadow-sm transition-transform ${checked?'translate-x-7':'translate-x-0'}`}/>
  </button>
}
