/**************************************************************************/
/*  currencyPresentation.ts                                             */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import type { PaymentCurrencyOption } from '../types'

const REGION_BY_CURRENCY:Record<string,string>={
  AED:'AE',ALL:'AL',AMD:'AM',AUD:'AU',AWG:'AW',AZN:'AZ',BAM:'BA',BDT:'BD',BMD:'BM',BND:'BN',BOB:'BO',
  BRL:'BR',BSD:'BS',BWP:'BW',BZD:'BZ',CAD:'CA',CHF:'CH',CLP:'CL',CNY:'CN',CRC:'CR',CZK:'CZ',DKK:'DK',
  DOP:'DO',EGP:'EG',ETB:'ET',EUR:'EU',FJD:'FJ',GBP:'GB',GEL:'GE',GMD:'GM',GTQ:'GT',GYD:'GY',HKD:'HK',
  HNL:'HN',HUF:'HU',IDR:'ID',ILS:'IL',INR:'IN',JPY:'JP',KRW:'KR',KZT:'KZ',LKR:'LK',LRD:'LR',LSL:'LS',
  MAD:'MA',MKD:'MK',MOP:'MO',MUR:'MU',MVR:'MV',MWK:'MW',MXN:'MX',MYR:'MY',NGN:'NG',NOK:'NO',NPR:'NP',
  NZD:'NZ',PEN:'PE',PGK:'PG',PHP:'PH',PLN:'PL',PYG:'PY',QAR:'QA',RON:'RO',RSD:'RS',SAR:'SA',SBD:'SB',
  SCR:'SC',SEK:'SE',SGD:'SG',SZL:'SZ',THB:'TH',TOP:'TO',TRY:'TR',TWD:'TW',TZS:'TZ',USD:'US',UYU:'UY',
  VND:'VN',WST:'WS',ZAR:'ZA',ZMW:'ZM',
}
const SHARED_REGION:Record<string,string>={XAF:'CEMAC',XOF:'UEMOA'}

// The language selector expresses a user locale, not a billing guarantee.
// We derive the locale's usual currency and then accept it only when the
// Worker exposes that route as available + checkout-enabled. Unsupported or
// disabled routes fall back to USD as requested by the product UX.
const DEFAULT_CURRENCY_BY_LANGUAGE:Record<string,string>={
  'pt-br':'BRL','pt':'EUR','pt-pt':'EUR',
  'en':'USD','en-us':'USD',
  'es':'EUR','es-es':'EUR','es-ar':'ARS',
  'fr':'EUR','fr-fr':'EUR','de':'EUR','de-de':'EUR','it':'EUR','it-it':'EUR','nl':'EUR','nl-nl':'EUR',
  'pl':'PLN','pl-pl':'PLN','ru':'RUB','ru-ru':'RUB','uk':'UAH','uk-ua':'UAH','tr':'TRY','tr-tr':'TRY',
  'cs':'CZK','cs-cz':'CZK','sk':'EUR','sk-sk':'EUR','hu':'HUF','hu-hu':'HUF','ro':'RON','ro-ro':'RON',
  'sv':'SEK','sv-se':'SEK','fi':'EUR','fi-fi':'EUR','id':'IDR','id-id':'IDR','vi':'VND','vi-vn':'VND',
  'ja':'JPY','ja-jp':'JPY','ko':'KRW','ko-kr':'KRW','zh-hans':'CNY','zh-hant':'TWD',
  'ar':'EGP','he':'ILS','fa':'IRR','bg':'BGN','bg-bg':'BGN','el':'EUR','el-gr':'EUR',
  'ca':'EUR','ca-es':'EUR','gl':'EUR','gl-es':'EUR','et':'EUR','et-ee':'EUR','eo':'USD',
  'ga':'EUR','ga-ie':'EUR','ka':'GEL','ka-ge':'GEL','bn':'BDT','bn-bd':'BDT',
  'ta':'INR','ta-in':'INR','th':'THB','th-th':'THB','tok':'USD',
}

function displayName(locale:string,type:'region',code:string){
  try{return new Intl.DisplayNames([locale],{type}).of(code)??code}catch{return code}
}
function normalizedLanguage(language:string){
  return language.trim().replace(/_/g,'-').toLowerCase()
}
function enabledOption(options:PaymentCurrencyOption[],code:string){
  return options.find(option=>option.code.toUpperCase()===code&&option.available&&option.checkout_enabled)
}

export function currencyPresentation(option:PaymentCurrencyOption,locale:string){
  const code=option.code.toUpperCase()
  const region=REGION_BY_CURRENCY[code]??''
  const origin=SHARED_REGION[code]??(region?displayName(locale,'region',region):code)
  const flagKey=SHARED_REGION[code]?'world':region.toLowerCase()
  const flagAsset=flagKey?`/currency-flags/${flagKey}.png`:'/currency-flags/world.png'
  const label=`${code} - ${origin}`
  return{label,origin,flagAsset,region}
}

export function compareCurrencyOptions(a:PaymentCurrencyOption,b:PaymentCurrencyOption,_locale:string){
  return a.code.toUpperCase().localeCompare(b.code.toUpperCase(),'en',{sensitivity:'base'})
}

export function preferredCurrencyForLanguage(language:string,options:PaymentCurrencyOption[]){
  const normalized=normalizedLanguage(language)
  const requested=DEFAULT_CURRENCY_BY_LANGUAGE[normalized]??DEFAULT_CURRENCY_BY_LANGUAGE[normalized.split('-')[0]]??'USD'
  return enabledOption(options,requested)?.code
    ??enabledOption(options,'USD')?.code
    ??options.find(option=>option.available&&option.checkout_enabled)?.code
    ??options.find(option=>option.code.toUpperCase()==='USD'&&option.available)?.code
    ??options.find(option=>option.available)?.code
    ??'USD'
}
