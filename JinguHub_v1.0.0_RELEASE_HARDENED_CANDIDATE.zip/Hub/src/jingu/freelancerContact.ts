/**************************************************************************/
/*  freelancerContact.ts                                                */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import type { FreelancerLinkKind } from '../types'
import type { IconName } from './components/Icon'

export type ContactKind=Extract<FreelancerLinkKind,'email'|'discord'|'whatsapp'|'telegram'|'github'|'linkedin'|'instagram'|'website'>

export const CONTACT_KINDS:ContactKind[]=['email','discord','whatsapp','telegram','github','linkedin','instagram','website']

export function contactLabel(kind:ContactKind){return kind==='email'?'E-mail':kind==='discord'?'Discord':kind==='whatsapp'?'WhatsApp':kind==='telegram'?'Telegram':kind==='github'?'GitHub':kind==='linkedin'?'LinkedIn':kind==='instagram'?'Instagram':'Site'}
export function contactIcon(kind:ContactKind):IconName{return kind==='email'?'mail':kind==='website'?'globe':kind}
export function contactPlaceholder(kind:ContactKind){return kind==='email'?'nome@provedor.com':kind==='whatsapp'?'https://wa.me/5511999999999':kind==='discord'?'https://discord.com/users/123456789012345678':kind==='telegram'?'https://t.me/usuario':kind==='github'?'https://github.com/usuario':kind==='linkedin'?'https://www.linkedin.com/in/perfil':kind==='instagram'?'https://www.instagram.com/usuario':'https://seusite.com'}

function exactHttps(value:string){try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password?url:null}catch{return null}}
function segments(url:URL){return url.pathname.split('/').filter(Boolean)}
function emailValid(value:string){return value.length<=254&&!/\s/.test(value)&&/^[^\s@]{1,64}@[^\s@]+\.[^\s@]+$/.test(value)}

export function normalizeContactValue(kind:ContactKind,value:string){const raw=value.trim();if(kind==='email'){const email=raw.replace(/^mailto:/i,'').trim().toLowerCase();return email?`mailto:${email}`:''}return raw}
export function contactValueValid(kind:ContactKind,value:string){
  const raw=normalizeContactValue(kind,value)
  if(!raw||raw.length>2048)return false
  if(kind==='email')return raw.startsWith('mailto:')&&emailValid(raw.slice(7))
  const url=exactHttps(raw);if(!url)return false
  const host=url.hostname.toLowerCase(),parts=segments(url)
  if(kind==='whatsapp')return host==='wa.me'&&!url.search&&!url.hash&&parts.length===1&&/^[1-9]\d{7,14}$/.test(parts[0])
  if(kind==='discord')return (host==='discord.com'||host==='www.discord.com')&&!url.search&&!url.hash&&parts.length===2&&parts[0]==='users'&&/^\d{15,22}$/.test(parts[1])
  if(kind==='telegram')return (host==='t.me'||host==='www.t.me')&&!url.search&&!url.hash&&parts.length===1&&/^[A-Za-z0-9_]{5,32}$/.test(parts[0])
  if(kind==='github')return host==='github.com'&&parts.length===1&&/^[A-Za-z0-9-]{1,39}$/.test(parts[0])
  if(kind==='linkedin')return (host==='linkedin.com'||host==='www.linkedin.com')&&parts.length===2&&parts[0]==='in'&&parts[1].length>0
  if(kind==='instagram')return (host==='instagram.com'||host==='www.instagram.com')&&parts.length===1&&/^[A-Za-z0-9_.]{1,30}$/.test(parts[0])
  return kind==='website'
}
