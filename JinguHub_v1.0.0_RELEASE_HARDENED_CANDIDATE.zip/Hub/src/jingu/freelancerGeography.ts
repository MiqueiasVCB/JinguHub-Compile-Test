/**************************************************************************/
/*  freelancerGeography.ts                                              */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import data from './freelancer-geography.generated.json'

export type GeographySubdivision={code:string;name:string;type:string}
export type GeographyCountry={code:string;name:string;subdivisions:GeographySubdivision[]}
type GeographyPayload={schema:number;source:string;countries:GeographyCountry[]}

const payload=data as GeographyPayload
const byCountry=new Map(payload.countries.map(country=>[country.code,country]))

export function geographyCountries(locale:string){
  let displayNames:Intl.DisplayNames|null=null
  try{displayNames=new Intl.DisplayNames([locale],{type:'region'})}catch{}
  return payload.countries.map(country=>({
    ...country,
    label:displayNames?.of(country.code)??country.name,
  })).sort((a,b)=>a.label.localeCompare(b.label,locale,{sensitivity:'base'}))
}

export function geographyCountry(code:string){return byCountry.get(code.trim().toUpperCase())??null}
export function geographySubdivisions(countryCode:string){return geographyCountry(countryCode)?.subdivisions??[]}
export function geographyCountryLabel(code:string,locale:string){
  const country=geographyCountry(code)
  if(!country)return ''
  try{return new Intl.DisplayNames([locale],{type:'region'}).of(country.code)??country.name}catch{return country.name}
}
export function geographyRegionLabel(countryCode:string,regionCode:string){
  const code=regionCode.trim().toUpperCase()
  return geographySubdivisions(countryCode).find(region=>region.code===code)?.name??''
}
export function geographySelectionValid(countryCode:string,regionCode:string){
  const country=geographyCountry(countryCode)
  if(!country)return false
  if(country.subdivisions.length===0)return regionCode.trim()===''
  return country.subdivisions.some(region=>region.code===regionCode.trim().toUpperCase())
}
