/**************************************************************************/
/*  notifications.ts                                                    */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import type { JinguCopy } from './copy'
import { normalizeLocale } from './copy'

function clean(raw: string) {
  return raw
    .trim()
    .replace(/^Error:\s*/i, '')
    .replace(/^Invoke failed:\s*/i, '')
}


function looksPortuguese(raw: string) {
  return /[ãõáéíóúç]|\b(?:não|nenhum|nenhuma|falha|erro|sucesso|concluíd[oa]|atualizad[oa]|removid[oa]|criad[oa]|projeto|pasta|versão|repositório|arquivo|conta|sessão|instalação|alteração|download|enviado|aberto|fechado)\b/i.test(raw)
}

const EXACT_EN = new Map<string, string>([
  ['A sessão do GitHub expirou. Entre novamente.', 'Your GitHub session expired. Sign in again.'],
  ['O GitHub não retornou um access token.', 'GitHub did not return an access token. Sign in again.'],
  ['Código de dispositivo ausente.', 'The GitHub device code is missing. Start sign-in again.'],
  ['O GitHub não retornou um código de dispositivo válido.', 'GitHub did not return a valid device code. Start sign-in again.'],
  ['Informe um nome de repositório válido.', 'Enter a valid repository name.'],
  ['O nome do repositório contém caracteres não suportados.', 'The repository name contains unsupported characters.'],
  ['A GitHub App Jingu Engine ainda não está instalada nesta conta. Abra “Acesso aos repositórios” e instale a App.', 'The Jingu Engine GitHub App is not installed on this account yet. Open Repository access and install the App.'],
  ['A instalação da Jingu Engine ainda não possui Administração: leitura e gravação. Aprove as permissões atualizadas no GitHub e entre novamente.', 'The Jingu Engine installation still needs Administration: Read and write. Approve the updated permissions on GitHub and sign in again.'],
  ['A instalação da Jingu Engine ainda não possui Contents: leitura e gravação. Aprove as permissões atualizadas no GitHub e entre novamente.', 'The Jingu Engine installation still needs Contents: Read and write. Approve the updated permissions on GitHub and sign in again.'],
  ['Este projeto não é um repositório Git.', 'This project is not a Git repository.'],
  ['Este projeto ainda não possui um repositório Git.', 'This project does not have a Git repository yet.'],
  ["Nenhum remote 'origin' está configurado.", 'No origin remote is configured.'],
  ['Não há uma ramificação ativa para enviar ao GitHub.', 'There is no active branch to push to GitHub.'],
  ['Informe uma mensagem para o commit.', 'Enter a commit message.'],
  ['Nenhuma alteração está preparada para commit. Selecione arquivos ou use “Preparar tudo” primeiro.', 'No changes are staged for commit. Select files or use Stage all first.'],
  ['O caminho informado não existe.', 'The selected path does not exist.'],
  ['Este projeto já possui um repositório Git.', 'This project already has a Git repository.'],
  ['Informe uma URL Git válida.', 'Enter a valid Git URL.'],
  ['O executável selecionado não foi encontrado.', 'The selected executable was not found.'],
  ['Já existe uma versão apontando para este executável.', 'A version already points to this executable.'],
  ['Esta versão da Jingu Engine já está instalada', 'This Jingu Engine version is already installed.'],
  ['Esta versão já está sendo baixada ou está na fila.', 'This version is already downloading or queued.'],
  ['Esta versão não está sendo baixada.', 'This version is not currently downloading.'],
  ['O download não está pausado.', 'The download is not paused.'],
  ['O executável não existe mais nesse caminho.', 'The executable no longer exists at this path.'],
  ['Arquivo não encontrado.', 'File not found.'],
  ['O arquivo precisa ser um pacote .zip.', 'The file must be a .zip package.'],
  ['Já existe uma versão com este nome.', 'A version with this name already exists.'],
  ['Arquivo ou pasta não encontrado.', 'File or folder not found.'],
  ['Este projeto já está na biblioteca do Jingu Hub.', 'This project is already in the Jingu Hub library.'],
  ['Selecione uma versão instalada da Jingu Engine.', 'Select an installed Jingu Engine version.'],
  ['A versão selecionada da Jingu Engine não está instalada.', 'The selected Jingu Engine version is not installed.'],
  ['Esta pasta não existe mais', 'This folder no longer exists.'],
  ['A pasta do projeto não existe ou não está acessível.', 'The project folder does not exist or is not accessible.'],
  ['A versão da Jingu Engine não pode ser vazia.', 'The Jingu Engine version cannot be empty.'],
])

const PREFIX_EN: Array<[string, string]> = [
  ['Falha de rede ao consultar a conta do GitHub:', 'Network error while checking the GitHub account:'],
  ['Falha de rede ao renovar a sessão do GitHub:', 'Network error while refreshing the GitHub session:'],
  ['Falha de rede durante o login do GitHub:', 'Network error during GitHub sign-in:'],
  ['Falha ao consultar a instalação da GitHub App:', 'Could not check the GitHub App installation:'],
  ['Falha de rede ao criar o repositório:', 'Network error while creating the repository:'],
  ['Não foi possível validar o repositório remoto no GitHub:', 'Could not validate the remote repository on GitHub:'],
  ['Não foi possível inicializar o Git:', 'Could not initialize Git:'],
  ['Falha ao inicializar o Git:', 'Git initialization failed:'],
  ['Não foi possível executar o Git:', 'Could not run Git:'],
  ['Não foi possível abrir a Jingu Engine:', 'Could not open Jingu Engine:'],
  ['Não foi possível mover o projeto para a lixeira:', 'Could not move the project to the Trash:'],
  ['Falha interna ao remover o projeto:', 'Internal error while removing the project:'],
  ['Falha interna ao copiar o projeto:', 'Internal error while copying the project:'],
  ['Não foi possível gravar .jingu-version:', 'Could not write .jingu-version:'],
  ['Não foi possível preparar o perfil do navegador da loja:', 'Could not prepare the store browser profile:'],
  ['Não foi possível integrar a loja ao Jingu Hub:', 'Could not integrate the store into Jingu Hub:'],
]

function englishMessage(raw: string) {
  if (/incorrect_client_credentials|client_id.*client_secret|client credentials/i.test(raw)) return 'The saved GitHub authorization is no longer compatible with this Jingu App configuration. Sign in again.'
  if (/rate limit exceeded|api rate limit/i.test(raw)) return 'GitHub API rate limit reached. Signed-in requests use the authenticated limit; refresh your session or try again later.'
  if (/infinitepay checkout could not be created|payments are not configured yet|payment provider is unavailable/i.test(raw)) return 'The payment provider could not start the checkout. No charge was created. Try again shortly.'
  if (/github.*(?:temporarily unavailable|service unavailable|http\s*(?:500|502|503|504)|\b(?:500|502|503|504)\b)|(?:http\s*(?:500|502|503|504)).*github/i.test(raw)) return 'GitHub is temporarily unavailable. Jingu preserved your session and will keep using local/cached data where possible. Try again shortly.'
  const exact = EXACT_EN.get(raw)
  if (exact) return exact
  for (const [prefix, translated] of PREFIX_EN) {
    if (raw.startsWith(prefix)) return `${translated}${raw.slice(prefix.length)}`
  }
  if (/metadados de integridade válidos|manifesto oficial/i.test(raw)) return 'This Jingu Engine release does not have valid official integrity metadata.'
  if (/verificação SHA-256/i.test(raw)) return 'The Jingu Engine package failed SHA-256 verification and was discarded.'
  if (/verificação de tamanho/i.test(raw)) return 'The Jingu Engine package size does not match the official release manifest.'
  if (/entrypoint declarado/i.test(raw)) return 'The executable declared by the Jingu Engine release manifest was not found after extraction.'
  if (/repository not found/i.test(raw)) return 'Repository not found or not accessible with the current GitHub App installation.'
  if (/authentication failed|permission denied|access denied|http 403|\b403\b/i.test(raw)) return 'GitHub denied access. Review the Jingu Engine App permissions and repository access.'
  if (/timed? out|timeout/i.test(raw)) return 'The operation timed out. Check your connection and try again.'
  if (/network|connection|dns|tcp|tls|certificate/i.test(raw)) return 'A network error interrupted the operation. Check your connection and try again.'
  return null
}


function portugueseMessage(raw: string, c: JinguCopy) {
  if (/incorrect_client_credentials|client_id.*client_secret|client credentials/i.test(raw)) return 'A autorização salva do GitHub não é mais compatível com a configuração atual da App Jingu. Saia e entre novamente.'
  if (/rate limit exceeded|api rate limit/i.test(raw)) return 'O limite temporário da API do GitHub foi atingido. Requisições autenticadas possuem limite maior; atualize a sessão ou tente novamente mais tarde.'
  if (/infinitepay checkout could not be created|payments are not configured yet|payment provider is unavailable/i.test(raw)) return 'O provedor de pagamento não conseguiu iniciar o checkout. Nenhuma cobrança foi criada. Tente novamente em instantes.'
  if (/github.*(?:temporarily unavailable|temporariamente indisponível|service unavailable|http\s*(?:500|502|503|504)|\b(?:500|502|503|504)\b)|(?:http\s*(?:500|502|503|504)).*github/i.test(raw)) return 'O GitHub está temporariamente indisponível. A Jingu preservou sua sessão e continuará usando dados locais/cache quando possível. Tente novamente em instantes.'
  if (/repository not found/i.test(raw)) return 'Repositório não encontrado ou sem acesso pela instalação atual da GitHub App.'
  if (/authentication failed|permission denied|access denied|http 403|\b403\b/i.test(raw)) return 'O GitHub negou o acesso. Revise as permissões e os repositórios liberados para a App Jingu Engine.'
  if (/timed? out|timeout/i.test(raw)) return 'A operação excedeu o tempo limite. Verifique sua conexão e tente novamente.'
  if (/network|connection|dns|tcp|tls|certificate|error sending request|request failed/i.test(raw)) return 'Uma falha de rede interrompeu a operação. Verifique sua conexão e tente novamente.'
  if (/no such file|file not found/i.test(raw)) return 'Arquivo ou pasta não encontrado.'

  // Rust, Git, reqwest and the OS can append English diagnostics to an otherwise
  // Portuguese message. Do not expose that mixed-language implementation detail
  // in the user-facing toast. The raw detail is still written to the console.
  if (/\b(failed|failure|invalid|not found|unable to|could not|access denied|permission denied)\b/i.test(raw)) {
    return genericLocalizedError(raw, c)
  }
  return raw
}

function genericLocalizedError(raw: string, c: JinguCopy) {
  const lower = raw.toLowerCase()
  const area = lower.includes('github') || lower.includes('git') || lower.includes('reposit') || lower.includes('origin')
    ? c.github
    : lower.includes('engine') || lower.includes('vers') || lower.includes('download') || lower.includes('.zip')
      ? c.versions
      : lower.includes('projeto') || lower.includes('project') || lower.includes('pasta')
        ? c.projects
        : lower.includes('loja') || lower.includes('store')
          ? c.stores
          : null
  return area ? `${c.error}: ${area}. ${c.retry}.` : `${c.error}. ${c.retry}.`
}

export function localizeNotification(message: string, error: boolean, c: JinguCopy, language?: string | null) {
  const raw = clean(message)
  if (!raw) return error ? c.error : c.success

  const locale = normalizeLocale(language)

  // Common Git output should not leak a fixed English success sentence into a localized UI.
  if (!error && /^(already up[ -]?to[ -]?date\.?|everything up[ -]?to[ -]?date\.?)$/i.test(raw)) return c.success
  // Rust/backend success strings can still be Portuguese because PT-BR is the
  // canonical internal message language. For every non-Portuguese UI, never
  // surface that implementation detail; use the localized success label.
  if (!error) return (locale === 'pt_BR' || locale === 'pt' || !looksPortuguese(raw)) ? raw : c.success

  if (locale === 'pt_BR' || locale === 'pt') return portugueseMessage(raw, c)
  if (locale === 'en') return englishMessage(raw) ?? genericLocalizedError(raw, c)

  // For locales without a dedicated backend-error dictionary, never surface a
  // Portuguese Rust sentence in the toast. The technical detail remains in the
  // application log/console, while the user gets a message from the active pack.
  return genericLocalizedError(raw, c)
}
