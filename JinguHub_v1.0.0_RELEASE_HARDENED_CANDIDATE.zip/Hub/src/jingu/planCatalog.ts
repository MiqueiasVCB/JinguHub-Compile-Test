/**************************************************************************/
/*  planCatalog.ts                                                      */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import type { JinguCopy } from './copy'

export type JinguPlanTier='free'|'bronze'|'silver'|'gold'

export type JinguPlanDefinition={
  tier:JinguPlanTier
  name:string
  price:string
  durationLabel:string
  borderColor:string
  background:string
  dotColor:string
  activePosts:number
  summaryMax:number
  descriptionMax:number
  benefits:string[]
}

// Structural/visual plan catalog. Prices and limits remain authoritative on the
// Worker; user-facing labels are localized at render time by localizedPlanCatalog().
export const PLAN_CATALOG:JinguPlanDefinition[]=[
  {
    tier:'free',name:'Gratuito',price:'R$ 0',durationLabel:'Sempre disponível',
    borderColor:'rgba(89,151,86,.42)',background:'rgba(42,88,49,.10)',dotColor:'#75c65f',
    activePosts:1,summaryMax:180,descriptionMax:3000,
    benefits:['1 anúncio ativo','Resumo de até 180 caracteres','Descrição de até 3.000 caracteres','Acesso completo aos recursos gratuitos da Jingu'],
  },
  {
    tier:'bronze',name:'Bronze',price:'R$ 5',durationLabel:'31 dias por unidade',
    borderColor:'rgba(251,146,60,.58)',background:'rgba(251,146,60,.055)',dotColor:'#fb923c',
    activePosts:2,summaryMax:220,descriptionMax:4000,
    benefits:['2 anúncios ativos','Resumo de até 220 caracteres','Descrição de até 4.000 caracteres','Selo Bronze no perfil','Nome na aba Assinantes (opcional)'],
  },
  {
    tier:'silver',name:'Prata',price:'R$ 7',durationLabel:'31 dias por unidade',
    borderColor:'rgba(203,213,225,.58)',background:'rgba(203,213,225,.045)',dotColor:'#cbd5e1',
    activePosts:3,summaryMax:260,descriptionMax:5000,
    benefits:['3 anúncios ativos','Resumo de até 260 caracteres','Descrição de até 5.000 caracteres','Selo Prata no perfil','Nome na aba Assinantes (opcional)'],
  },
  {
    tier:'gold',name:'Ouro',price:'R$ 10',durationLabel:'31 dias por unidade',
    borderColor:'rgba(250,204,21,.72)',background:'rgba(250,204,21,.055)',dotColor:'#facc15',
    activePosts:4,summaryMax:320,descriptionMax:6500,
    benefits:['4 anúncios ativos','Resumo de até 320 caracteres','Descrição de até 6.500 caracteres','Selo Ouro no perfil','Nome na aba Assinantes (opcional)'],
  },
]

function fill(template:string,values:Record<string,string|number>){
  return Object.entries(values).reduce((text,[key,value])=>text.split(`{${key}}`).join(String(value)),template)
}

function localizedName(tier:JinguPlanTier,c:JinguCopy){
  return tier==='free'?c.freeTier:tier==='bronze'?c.bronzeTier:tier==='silver'?c.silverTier:c.goldTier
}

export function localizedPlanCatalog(c:JinguCopy,locale='pt-BR'):JinguPlanDefinition[]{
  return PLAN_CATALOG.map(plan=>{
    const name=localizedName(plan.tier,c)
    const benefits=[
      fill(c.benefitActiveListings,{count:plan.activePosts}),
      fill(c.benefitSummaryMax,{count:plan.summaryMax.toLocaleString(locale)}),
      fill(c.benefitDescriptionMax,{count:plan.descriptionMax.toLocaleString(locale)}),
      ...(plan.tier==='free'?[c.benefitFreeAccess]:[fill(c.benefitProfileBadge,{tier:name}),c.benefitSubscribers]),
    ]
    return {...plan,name,durationLabel:plan.tier==='free'?c.alwaysAvailable:c.daysPerUnit,benefits}
  })
}

export function planByTier(tier:string|undefined|null,c?:JinguCopy,locale='pt-BR'){
  const catalog=c?localizedPlanCatalog(c,locale):PLAN_CATALOG
  return catalog.find(plan=>plan.tier===(tier??'free').toLowerCase())??catalog[0]
}
