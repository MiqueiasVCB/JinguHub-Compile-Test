/**************************************************************************/
/*  planDomain.ts                                                       */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import type { JinguMembershipProfile, PaymentConfig } from '../types'
import type { JinguPlanTier } from './planCatalog'

export type PaidTier=Exclude<JinguPlanTier,'free'>
export type CheckoutDestination=PaidTier|'donation'
export type CheckoutPreference=CheckoutDestination|'auto'
export type Allocation={tier:PaidTier;units:number;unitPrice:number;base:number;support:number}
export type TransitionPreview={kind:'new'|'extend'|'upgrade'|'downgrade';carryMs:number;totalMs:number;projected:string|null}

export const DAY_MS=24*60*60*1000
export const UNIT_DAYS=31
export const MAX_PREVIEW_DATE_MS=Date.parse('9998-12-31T23:59:59.999Z')
export const PAID_TIERS:readonly PaidTier[]=['bronze','silver','gold']

export function tierRank(tier:string){return tier==='gold'?3:tier==='silver'?2:tier==='bronze'?1:0}

export function currencyFractionDigits(currency='BRL',locale='en-US'){
  try{
    const digits=new Intl.NumberFormat(locale,{style:'currency',currency}).resolvedOptions().maximumFractionDigits??2
    return Number.isInteger(digits)&&digits>=0&&digits<=6?digits:2
  }catch{return 2}
}

export function moneyMinor(minor:number,currency='BRL',fixed=true,locale='pt-BR'){
  const digits=currencyFractionDigits(currency,locale)
  const divisor=10**digits
  try{return new Intl.NumberFormat(locale,{style:'currency',currency,minimumFractionDigits:fixed?digits:0,maximumFractionDigits:digits}).format(minor/divisor)}
  catch{return `${currency} ${(minor/divisor).toFixed(fixed?digits:0)}`}
}

export function parseAmountMinor(raw:string,currency='BRL',locale='en-US'){
  const digits=currencyFractionDigits(currency,locale)
  const value=raw.trim().replace(/^R\$\s*/i,'').replace(/\s/g,'').replace(',','.')
  const pattern=digits===0?/^\d+$/:new RegExp(`^\\d+(?:\\.\\d{0,${digits}})?$`)
  if(!pattern.test(value))return null
  const number=Number(value)
  if(!Number.isFinite(number))return null
  const minor=Math.round(number*(10**digits))
  return Number.isSafeInteger(minor)?minor:null
}

export function unitPrice(tier:PaidTier,config:PaymentConfig|null){
  const configured=config?.prices_minor?.[tier]
  return typeof configured==='number'&&Number.isFinite(configured)&&configured>0?Math.trunc(configured):(tier==='bronze'?500:tier==='silver'?700:1000)
}
export function transitionValuePrice(tier:PaidTier,config:PaymentConfig|null){
  const configured=config?.transition_value_prices_minor?.[tier]
  return typeof configured==='number'&&Number.isFinite(configured)&&configured>0?Math.trunc(configured):unitPrice(tier,config)
}

export function allocationsFor(amountMinor:number|null,config:PaymentConfig|null):Allocation[]{
  if(amountMinor===null||!Number.isSafeInteger(amountMinor)||amountMinor<0)return[]
  return PAID_TIERS.flatMap(tier=>{
    const price=unitPrice(tier,config)
    const units=Math.floor(amountMinor/price)
    if(units<1)return[]
    const base=units*price
    return[{tier,units,unitPrice:price,base,support:amountMinor-base}]
  })
}

export function resolveCheckoutDestination(amountMinor:number|null,preference:CheckoutPreference|undefined|null,config:PaymentConfig|null){
  const allocations=allocationsFor(amountMinor,config)
  const affordable=allocations.map(item=>item.tier)
  const recommended=allocations.length>0?allocations[allocations.length-1].tier:null
  const bronzePrice=unitPrice('bronze',config)
  const destination:CheckoutDestination = amountMinor!==null&&amountMinor>=bronzePrice
    ? (preference==='donation'?'donation':preference&&preference!=='auto'&&affordable.includes(preference)?preference:(recommended??'bronze'))
    : 'donation'
  return {destination,recommended,allocations,selected:destination==='donation'?null:(allocations.find(item=>item.tier===destination)??null)}
}

export function projectedIso(now:number,durationMs:number){
  const projected=now+durationMs
  return Number.isFinite(projected)&&projected<=MAX_PREVIEW_DATE_MS?new Date(projected).toISOString():null
}

export function transitionPreview(membership:JinguMembershipProfile|null,allocation:Allocation,config:PaymentConfig|null,now=Date.now()):TransitionPreview{
  const currentTier=String(membership?.tier??'free').toLowerCase()
  const end=membership?.cycle_ends_at?Date.parse(membership.cycle_ends_at):NaN
  const active=currentTier!=='free'&&Number.isFinite(end)&&end>now&&!membership?.lifetime
  const purchasedMs=allocation.units*UNIT_DAYS*DAY_MS
  if(!active)return{kind:'new',carryMs:0,totalMs:purchasedMs,projected:projectedIso(now,purchasedMs)}
  const remaining=Math.max(0,end-now)
  if(currentTier===allocation.tier)return{kind:'extend',carryMs:remaining,totalMs:remaining+purchasedMs,projected:projectedIso(now,remaining+purchasedMs)}
  const currentPrice=currentTier==='bronze'?transitionValuePrice('bronze',config):currentTier==='silver'?transitionValuePrice('silver',config):transitionValuePrice('gold',config)
  const targetPrice=transitionValuePrice(allocation.tier,config)
  const carry=Math.floor(remaining*currentPrice/targetPrice)
  const kind=tierRank(allocation.tier)>tierRank(currentTier)?'upgrade':'downgrade'
  return{kind,carryMs:carry,totalMs:carry+purchasedMs,projected:projectedIso(now,carry+purchasedMs)}
}
