/**************************************************************************/
/*  remoteRefresh.ts                                                    */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/

// Manual refreshes and post-mutation canonical reconciliations intentionally
// wait for the backend projection window before issuing the authoritative request.
// This avoids racing a just-confirmed GitHub mutation against its mirror. The UI
// may still apply an optimistic local state while the canonical fetch settles.
export const REMOTE_REFRESH_SETTLE_MS=2_000

export function waitForRemoteRefreshSettle(){
  return new Promise<void>(resolve=>window.setTimeout(resolve,REMOTE_REFRESH_SETTLE_MS))
}
