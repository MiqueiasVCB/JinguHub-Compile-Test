/**************************************************************************/
/*  AboutView.tsx                                                       */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { useCallback, useEffect, useMemo, useState } from 'react'
import { openUrl } from '@tauri-apps/plugin-opener'
import type { SupporterPublicEntry } from '../../types'
import type { JinguCopy } from '../copy'
import { Button, SectionCard } from '../components/UI'
import packageJson from '../../../package.json'
import { api } from '../../lib/api'

const JINGU_ENGINE_VERSION='1.0.0'
const SUPPORTERS=[{name:'PiauIndie',url:'https://linktr.ee/piauindie'}]
const SPONSORS:Array<{name:string;description:string;url:string}>=[]

function tierOrder(tier:string){return ({gold:0,silver:1,bronze:2} as Record<string,number>)[tier] ?? 99}
function tierBadge(tier:string){return tier==='gold'?'border-amber-300/40 bg-amber-300/10 text-amber-100':tier==='silver'?'border-slate-300/40 bg-slate-300/10 text-slate-100':'border-orange-400/40 bg-orange-400/10 text-orange-100'}
function tierLabel(tier:string,c:JinguCopy){return tier==='gold'?c.goldTier:tier==='silver'?c.silverTier:c.bronzeTier}
function monthLabel(value:number,c:JinguCopy){const months=Math.min(1200,Math.max(1,Math.trunc(Number(value)||1)));return `${months} ${months===1?c.monthSingular:c.monthPlural}`}

export function AboutView({c}:{c:JinguCopy}){
  const [supportTab,setSupportTab]=useState<'supporters'|'sponsors'|'subscribers'>('supporters')
  const [subscriberScope,setSubscriberScope]=useState<'active'|'history'>('active')
  const [subscribers,setSubscribers]=useState<SupporterPublicEntry[]>([])
  const [subscribersLoading,setSubscribersLoading]=useState(false)
  const [subscribersError,setSubscribersError]=useState(false)
  const [subscriberReload,setSubscriberReload]=useState(0)

  const reloadSubscribers=useCallback(()=>setSubscriberReload(value=>value+1),[])
  useEffect(()=>{
    if(supportTab!=='subscribers') return
    let cancelled=false
    setSubscribersLoading(true)
    setSubscribersError(false)
    void api.supportersList().then(rows=>{
      if(!cancelled)setSubscribers(rows)
    }).catch(()=>{
      if(!cancelled){setSubscribers([]);setSubscribersError(true)}
    }).finally(()=>{
      if(!cancelled)setSubscribersLoading(false)
    })
    return()=>{cancelled=true}
  },[supportTab,subscriberReload])

  const orderedSubscribers=useMemo(()=>[...subscribers]
    .filter(entry=>subscriberScope==='history'||entry.active)
    .sort((a,b)=>tierOrder(a.tier)-tierOrder(b.tier)||b.months-a.months||a.github_login.localeCompare(b.github_login)),[subscribers,subscriberScope])

  return <div className="mx-auto h-full w-full max-w-[1500px] overflow-y-auto px-7 py-6">
    <h1 className="text-2xl font-semibold tracking-tight">{c.aboutTitle}</h1>
    <div className="mt-5 grid gap-4">
      <SectionCard className="p-7">
        <div className="flex flex-col items-center gap-8 lg:flex-row lg:items-stretch">
          <div className="flex w-full shrink-0 items-center justify-center lg:w-[250px]"><img src="/jingu-mascot-wukong.png" alt="" className="max-h-[330px] w-auto max-w-full object-contain"/></div>
          <div className="flex min-w-0 flex-1 flex-col justify-center py-2"><div className="text-3xl font-semibold">Jingu</div><div className="mt-2 text-sm text-muted">{c.ownerLabel} · {c.ownerName}</div><p className="mt-5 max-w-5xl leading-7 text-muted">{c.aboutText}</p><div className="mt-6 grid gap-3 md:grid-cols-3"><InfoLine label="Jingu Hub" value={`${c.versionLabel} ${packageJson.version}`}/><InfoLine label="Jingu Engine" value={`${c.versionLabel} ${JINGU_ENGINE_VERSION}`}/><InfoLine label={c.contact} value="jinguengine@gmail.com"/></div></div>
        </div>
      </SectionCard>

      <div className="grid gap-4 xl:grid-cols-[1.1fr_.9fr]">
        <SectionCard className="p-6"><div className="text-lg font-semibold">{c.hubCredits}</div><p className="mt-3 leading-7 text-muted">{c.hubCreditsText}</p><ul className="mt-4 grid gap-3 text-sm leading-6 text-muted"><li>• {c.jinguRights}</li><li>• {c.basedOn}</li><li>• {c.hubArchitectureText}</li><li>• {c.hubGitHubIntegrationText}</li></ul><div className="mt-5 flex flex-wrap gap-2"><Button icon="external" onClick={()=>openUrl('https://github.com/RykoTheDev/GodotHub')}>{c.viewGodotHub}</Button><Button icon="external" onClick={()=>openUrl('https://github.com/apps/jingu-engine')}>{c.viewGitHubApp}</Button></div></SectionCard>
        <SectionCard className="p-6"><div className="text-lg font-semibold">{c.engineCredits}</div><p className="mt-3 leading-7 text-muted">{c.engineCreditsText}</p><ul className="mt-4 grid gap-3 text-sm leading-6 text-muted"><li>• {c.godotRights}</li><li>• {c.engineLegalFilesText}</li><li>• {c.separatedCreditsText}</li></ul><div className="mt-5 flex flex-wrap gap-2"><Button icon="external" onClick={()=>openUrl('https://godotengine.org')}>{c.viewGodot}</Button></div></SectionCard>
      </div>

      <SectionCard className="p-6"><div className="text-lg font-semibold">{c.legalCredits}</div><div className="mt-4 grid gap-4 md:grid-cols-3"><LegalCard title={c.authorCardTitle} body={c.jinguRights}/><LegalCard title="Godot Engine" body={c.godotRights}/><LegalCard title="GodotHub" body={c.godotHubRights}/></div><div className="mt-5 flex flex-wrap gap-2"><Button icon="external" onClick={()=>openUrl('https://github.com/godotengine/godot/blob/master/COPYRIGHT.txt')}>{c.viewLicenses}</Button></div></SectionCard>

      <SectionCard className="p-6">
        <div className="text-lg font-semibold">{c.privacyTitle}</div>
        <p className="mt-3 leading-7 text-muted">{c.privacySummary}</p>
        <p className="mt-2 text-sm leading-6 text-muted">{c.privacyResponsibility}</p>
        <div className="mt-3 text-sm text-muted">{c.privacyContact}</div>
        <div className="mt-5 flex flex-wrap gap-2">
          <Button icon="external" onClick={()=>openUrl('https://docs.github.com/pt/site-policy/privacy-policies/github-general-privacy-statement')}>{c.githubPrivacy}</Button>
          <Button icon="external" onClick={()=>openUrl('https://www.cloudflare.com/pt-br/privacypolicy/')}>{c.cloudflarePrivacy}</Button>
          <Button icon="external" onClick={()=>openUrl('https://www.infinitepay.io/legal/aviso-de-privacidade')}>{c.infinitePayPrivacy}</Button>
          
        </div>
      </SectionCard>

      <SectionCard className="p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-4">
          <div className="flex flex-wrap gap-2"><Button variant={supportTab==='supporters'?'primary':'secondary'} onClick={()=>setSupportTab('supporters')}>{c.supporters}</Button><Button variant={supportTab==='sponsors'?'primary':'secondary'} onClick={()=>setSupportTab('sponsors')}>{c.sponsors}</Button><Button variant={supportTab==='subscribers'?'primary':'secondary'} onClick={()=>setSupportTab('subscribers')}>{c.subscribers}</Button></div>
          {supportTab==='subscribers'&&<div className="flex gap-2" role="group" aria-label={c.subscriberFilterLabel}><Button variant={subscriberScope==='active'?'primary':'secondary'} onClick={()=>setSubscriberScope('active')}>{c.activeOnly}</Button><Button variant={subscriberScope==='history'?'primary':'secondary'} onClick={()=>setSubscriberScope('history')}>{c.history}</Button></div>}
        </div>
        <p className="mt-4 text-sm leading-6 text-muted">{supportTab==='supporters'?c.supportersText:supportTab==='sponsors'?c.sponsorsText:subscriberScope==='active'?c.activeSubscriptionsHelp:c.subscriptionHistoryHelp}</p>
        {supportTab==='subscribers' ? (
          subscribersLoading ? <div className="mt-5 rounded-lg border border-line bg-base/60 p-5 text-sm text-muted">{c.loadingSubscribers}</div>
          : subscribersError ? <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-danger/35 bg-danger/5 p-5 text-sm text-red-200"><span>{c.subscribersLoadError}</span><Button variant="secondary" onClick={reloadSubscribers}>{c.retry}</Button></div>
          : orderedSubscribers.length===0 ? <div className="mt-5 rounded-lg border border-line bg-base/60 p-5 text-sm text-muted">{subscriberScope==='active'?c.noActiveSubscribers:c.noSubscriberHistory}</div>
          : <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">{orderedSubscribers.map(entry=><div key={`${entry.github_login}:${entry.tier}`} className="rounded-lg border border-line bg-base/60 p-4 text-left"><div className="flex items-center justify-between gap-3"><div className="flex min-w-0 items-center gap-3"><img src={entry.avatar_url} alt="" className="h-10 w-10 rounded-full border border-line bg-base"/><div className="min-w-0"><div className="truncate font-semibold">@{entry.github_login}</div></div></div><div className="flex shrink-0 items-center gap-2"><span className="text-xs font-medium text-muted">{monthLabel(entry.months,c)}</span><span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${tierBadge(entry.tier)}`}>{tierLabel(entry.tier,c)}</span></div></div></div>)}</div>
        ) : supportTab==='supporters' ? (
          <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">{SUPPORTERS.map(entry=><button key={entry.name} className="focus-ring rounded-lg border border-line bg-base/60 p-4 text-left transition hover:border-accent-dim hover:bg-raised" onClick={()=>void api.openHttpsUrl(entry.url)}><div className="font-semibold">{entry.name}</div><p className="mt-2 text-sm leading-6 text-muted">{c.piauIndieDescription}</p><div className="mt-3 text-xs font-medium text-accent-bright">{c.open} ↗</div></button>)}</div>
        ) : SPONSORS.length===0 ? <div className="mt-5 rounded-lg border border-line bg-base/60 p-5 text-sm text-muted">{c.noSponsors}</div>
        : <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">{SPONSORS.map(entry=><button key={entry.name} className="focus-ring rounded-lg border border-line bg-base/60 p-4 text-left transition hover:border-accent-dim hover:bg-raised" onClick={()=>void api.openHttpsUrl(entry.url)}><div className="font-semibold">{entry.name}</div><p className="mt-2 text-sm leading-6 text-muted">{entry.description}</p><div className="mt-3 text-xs font-medium text-accent-bright">{c.open} ↗</div></button>)}</div>}
      </SectionCard>
    </div>
  </div>
}
function InfoLine({label,value}:{label:string;value:string}){return <div className="rounded-lg border border-line bg-base/60 px-4 py-3"><div className="text-xs font-semibold uppercase tracking-wide text-muted">{label}</div><div className="mt-1 text-sm text-ink">{value}</div></div>}
function LegalCard({title,body}:{title:string;body:string}){return <div className="rounded-lg border border-line bg-base/60 p-4"><div className="font-medium">{title}</div><p className="mt-2 text-sm leading-6 text-muted">{body}</p></div>}
