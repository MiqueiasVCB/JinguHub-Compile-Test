/**************************************************************************/
/*  CommunityView.tsx                                                   */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { useEffect, useMemo, useState } from 'react'
import { listen } from '@tauri-apps/api/event'
import type { CommunityCatalogResult, CommunityLink, CommunityRequestInput, CommunityRequestRow } from '../../types'
import type { JinguCopy } from '../copy'
import { api } from '../../lib/api'
import { Button, BusyNotice, Input, Modal, SectionCard, Select } from '../components/UI'
import { Icon, type IconName } from '../components/Icon'
import { waitForRemoteRefreshSettle } from '../remoteRefresh'

type RequestDraft={name:string;country:string;region:string;description:string;tags:string;site:string;whatsapp:string;discord:string;github:string;instagram:string}
const EMPTY:RequestDraft={name:'',country:'Brasil',region:'',description:'',tags:'',site:'',whatsapp:'',discord:'',github:'',instagram:''}

function linkIcon(kind:string):IconName {
  const key=kind.trim().toLowerCase()
  if(key==='whatsapp')return 'whatsapp'
  if(key==='discord')return 'discord'
  if(key==='instagram')return 'instagram'
  if(key==='github')return 'git'
  if(key==='email'||key==='mail')return 'mail'
  if(key==='telegram')return 'telegram'
  if(key==='linkedin')return 'linkedin'
  return 'globe'
}
function location(region:string,country:string){return [region,country].filter(Boolean).join(' - ')}
function requestLinkLabel(c:JinguCopy,kind:'site'|'whatsapp'|'discord'|'github'|'instagram'){return kind==='site'?c.website:kind==='whatsapp'?'WhatsApp':kind==='discord'?'Discord':kind==='github'?'GitHub':'Instagram'}

const FEATURED_COMMUNITY_TAGS=['Patrocinador','Recomendado','Apoiador'] as const
function featuredCommunityTag(tag:string){return FEATURED_COMMUNITY_TAGS.find(value=>value.toLocaleLowerCase()===tag.trim().toLocaleLowerCase())}
function featuredCommunityTagLabel(c:JinguCopy,tag:string){
  const key=featuredCommunityTag(tag)
  return key==='Patrocinador'?c.communitySponsorTag:key==='Recomendado'?c.communityRecommendedTag:key==='Apoiador'?c.communitySupporterTag:tag
}
function featuredCommunityTagClass(tag:string){
  const key=featuredCommunityTag(tag)
  return key==='Patrocinador'?'border-amber-400/45 bg-amber-400/12 text-amber-100 shadow-[0_0_14px_rgba(251,191,36,.06)]':key==='Recomendado'?'border-sky-400/40 bg-sky-400/10 text-sky-100 shadow-[0_0_14px_rgba(56,189,248,.055)]':'border-fuchsia-400/35 bg-fuchsia-400/10 text-fuchsia-100 shadow-[0_0_14px_rgba(232,121,249,.05)]'
}

export function CommunityView({c,onRequireGitHubLogin,notify}:{c:JinguCopy;onRequireGitHubLogin:()=>void;notify:(message:string,error?:boolean,title?:string)=>void}){
  const [catalog,setCatalog]=useState<CommunityCatalogResult|null>(null)
  const [loading,setLoading]=useState(true)
  const [query,setQuery]=useState('')
  const [country,setCountry]=useState('all')
  const [region,setRegion]=useState('all')
  const [topic,setTopic]=useState('all')
  const [error,setError]=useState<string|null>(null)
  const [request,setRequest]=useState<RequestDraft|null>(null)
  const [sending,setSending]=useState(false)
  const [myRequests,setMyRequests]=useState<CommunityRequestRow[]>([])
  const [myRequestsOpen,setMyRequestsOpen]=useState(false)
  const [myRequestsLoading,setMyRequestsLoading]=useState(false)
  const [manualRefreshPending,setManualRefreshPending]=useState(false)

  const load=async(force=false)=>{setLoading(true);setError(null);try{setCatalog(await api.communityCatalog(force))}catch(e){setError(String(e))}finally{setLoading(false)}}
  useEffect(()=>{void load(false)},[])
  useEffect(()=>{
    let unlisten:(()=>void)|undefined
    void listen<CommunityCatalogResult>('jingu-community-refreshed',event=>{setCatalog(event.payload)}).then(fn=>{unlisten=fn})
    return()=>{unlisten?.()}
  },[])
  const countries=useMemo(()=>[...new Set<string>((catalog?.communities??[]).map(item=>item.country).filter((value):value is string=>Boolean(value)))].sort((a,b)=>a.localeCompare(b)),[catalog])
  const regions=useMemo(()=>[...new Set<string>((catalog?.communities??[]).filter(item=>country==='all'||item.country===country).map(item=>item.region).filter((value):value is string=>Boolean(value)))].sort((a,b)=>a.localeCompare(b)),[catalog,country])
  const topics=useMemo(()=>[...new Set<string>((catalog?.communities??[]).flatMap(item=>item.tags))].sort((a,b)=>a.localeCompare(b)),[catalog])
  useEffect(()=>{if(region!=='all'&&!regions.includes(region))setRegion('all')},[region,regions])
  const filtered=useMemo(()=>{
    const needle=query.trim().toLocaleLowerCase()
    return (catalog?.communities??[]).filter(item=>
      (country==='all'||item.country===country)&&
      (region==='all'||item.region===region)&&
      (topic==='all'||item.tags.includes(topic))&&
      (!needle||[item.name,item.country,item.region,item.description,...item.tags].join(' ').toLocaleLowerCase().includes(needle)))
      .sort((a,b)=>(b.created_at??'').localeCompare(a.created_at??'')||a.name.localeCompare(b.name))
  },[catalog,country,query,region,topic])

  const manualRefresh=async()=>{
    if(manualRefreshPending||loading)return
    setManualRefreshPending(true)
    try{
      await waitForRemoteRefreshSettle()
      await load(true)
    }finally{setManualRefreshPending(false)}
  }

  const openRequest=async()=>{const user=await api.githubSession().catch(()=>null);if(!user){notify(c.communityRequestLogin,true,c.community);onRequireGitHubLogin();return}setRequest({...EMPTY})}
  const openMyRequests=async()=>{const user=await api.githubSession().catch(()=>null);if(!user){notify(c.communityRequestLogin,true,c.community);onRequireGitHubLogin();return}setMyRequestsOpen(true);setMyRequestsLoading(true);try{setMyRequests(await api.communityMyRequests())}catch(e){notify(String(e),true,c.community);setMyRequestsOpen(false)}finally{setMyRequestsLoading(false)}}
  const submit=async()=>{
    if(!request)return
    const links:CommunityLink[]=(['site','whatsapp','discord','github','instagram'] as const).flatMap(kind=>{const url=request[kind].trim();return url?[{kind,label:requestLinkLabel(c,kind),url}]:[]})
    const input:CommunityRequestInput={name:request.name.trim(),country:request.country.trim(),region:request.region.trim(),description:request.description.trim(),tags:request.tags.split(',').map(v=>v.trim()).filter(Boolean),links}
    setSending(true);try{await api.communitySubmitRequest(input);setRequest(null);notify(c.communityRequestSent,false,c.community);if(myRequestsOpen){setMyRequests(await api.communityMyRequests())}}catch(e){notify(String(e),true,c.community)}finally{setSending(false)}
  }

  return <div className="mx-auto h-full w-full max-w-[1500px] overflow-y-auto px-7 py-6">
    <div className="flex flex-wrap items-center justify-between gap-4"><div><h1 className="text-2xl font-semibold tracking-tight text-ink">{c.communityTitle}</h1></div><div className="flex flex-wrap gap-2"><Button icon="refresh" onClick={()=>void manualRefresh()} disabled={loading||manualRefreshPending}>{manualRefreshPending?c.syncing:c.refresh}</Button><Button variant="secondary" onClick={()=>void openMyRequests()}>{c.myCommunityRequests}</Button><Button icon="plus" variant="primary" onClick={()=>void openRequest()}>{c.communityRequest}</Button></div></div>
    <SectionCard className="mt-5 p-4"><div className="grid gap-3 lg:grid-cols-[minmax(260px,1fr)_190px_190px_210px]">
      <Input placeholder={c.communitySearch} value={query} onChange={e=>setQuery(e.target.value)}/>
      <Select value={country} onChange={e=>setCountry(e.target.value)}><option value="all">{c.allCountries}</option>{countries.map(value=><option key={value} value={value}>{value}</option>)}</Select>
      <Select value={region} onChange={e=>setRegion(e.target.value)}><option value="all">{c.allRegions}</option>{regions.map(value=><option key={value} value={value}>{value}</option>)}</Select>
      <Select value={topic} onChange={e=>setTopic(e.target.value)}><option value="all">{c.allTopics}</option>{topics.map(value=><option key={value} value={value}>{value}</option>)}</Select>
    </div></SectionCard>
    {loading&&!catalog&&<div className="mt-4"><BusyNotice label={c.communityLoading}/></div>}{loading&&catalog&&<div className="mt-3 flex items-center justify-end gap-2 text-xs text-muted"><span className="h-2 w-2 animate-pulse rounded-full bg-accent"/>{c.communityLoading}</div>}
    {error&&<SectionCard className="mt-4 border-danger/40 p-5 text-danger">{error}</SectionCard>}
    {!loading&&filtered.length===0&&<SectionCard className="mt-5 p-8 text-center text-muted">{c.communityEmpty}</SectionCard>}
    {filtered.length>0&&<div className="mt-5 w-full"><div className="mb-2 text-right text-xs text-muted">{filtered.length} {c.community}</div><SectionCard className="overflow-hidden p-0">{filtered.map((item,index)=><div key={item.id} className={`px-5 py-4 ${index>0?'border-t border-line':''}`}><div className="flex min-w-0 flex-col gap-3 lg:flex-row lg:items-center"><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><div className="text-base font-semibold text-ink">{item.name}</div>{location(item.region,item.country)&&<span className="inline-flex rounded bg-accent/10 px-2 py-1 text-xs font-semibold text-accent-bright">{location(item.region,item.country)}</span>}{item.tags.filter(featuredCommunityTag).map(tag=><span key={`featured-${tag}`} className={`inline-flex items-center rounded-lg border px-2.5 py-1 text-[13px] font-bold uppercase tracking-[0.05em] ${featuredCommunityTagClass(tag)}`}>{featuredCommunityTagLabel(c,tag)}</span>)}</div><p className="mt-1.5 line-clamp-2 max-w-5xl text-sm leading-6 text-muted">{item.description}</p>{item.tags.some(tag=>!featuredCommunityTag(tag))&&<div className="mt-2 flex flex-wrap gap-1.5">{item.tags.filter(tag=>!featuredCommunityTag(tag)).map(tag=><span key={tag} className="rounded border border-line bg-base px-2 py-1 text-[11px] text-muted">{tag}</span>)}</div>}</div><div className="flex shrink-0 flex-wrap gap-2 lg:justify-end">{item.links.map(link=><button key={`${item.id}-${link.kind}-${link.url}`} className="focus-ring grid h-10 w-10 place-items-center rounded-lg border border-line bg-base text-muted transition hover:border-accent-dim hover:text-accent-bright" title={link.label} aria-label={link.label} onClick={()=>void api.openHttpsUrl(link.url)}><Icon name={linkIcon(link.kind)} className="h-5 w-5"/></button>)}</div></div></div>)}</SectionCard></div>}
    <Modal closeLabel={c.close} open={myRequestsOpen} title={c.myCommunityRequests} onClose={()=>!myRequestsLoading&&setMyRequestsOpen(false)} width="max-w-2xl" footer={<Button variant="secondary" onClick={()=>setMyRequestsOpen(false)} disabled={myRequestsLoading}>{c.close}</Button>}>
      {myRequestsLoading?<BusyNotice label={c.loading}/>:myRequests.length===0?<div className="py-5 text-sm text-muted">{c.noMyCommunityRequests}</div>:<div className="grid gap-3">{myRequests.map(item=><div key={item.display_id} className="rounded-lg border border-line bg-base p-4"><div className="flex flex-wrap items-center justify-between gap-2"><div className="font-semibold text-ink">{item.name}</div><span className="rounded-full border border-line px-2 py-1 text-[11px] font-semibold text-muted">{item.status==='approved'?c.requestApproved:item.status==='rejected'?c.requestRejected:c.requestPending}</span></div><div className="mt-1 text-xs text-muted">{item.display_id??''} · {location(item.region,item.country)} · {new Date(item.created_at).toLocaleDateString()}</div><p className="mt-2 line-clamp-3 text-sm text-muted">{item.description}</p></div>)}</div>}
    </Modal>
    <Modal closeLabel={c.close} open={Boolean(request)} title={c.communityRequestTitle} onClose={()=>!sending&&setRequest(null)} width="max-w-2xl" footer={<><Button variant="secondary" onClick={()=>setRequest(null)} disabled={sending}>{c.cancel}</Button><Button variant="primary" onClick={()=>void submit()} disabled={sending||!request?.name.trim()||!request?.description.trim()}>{sending?c.working:c.communityRequest}</Button></>}>
      {request&&<div className="grid gap-4"><p className="text-sm text-muted">{c.communityRequestHelp}</p><Input placeholder={c.communityName} value={request.name} onChange={e=>setRequest(v=>v&&({...v,name:e.target.value}))}/><div className="grid gap-3 sm:grid-cols-2"><Input placeholder={c.communityRegion} value={request.region} onChange={e=>setRequest(v=>v&&({...v,region:e.target.value}))}/><Input placeholder={c.country} value={request.country} onChange={e=>setRequest(v=>v&&({...v,country:e.target.value}))}/></div><textarea className="input min-h-28 w-full resize-y" placeholder={c.communityDescription} value={request.description} onChange={e=>setRequest(v=>v&&({...v,description:e.target.value}))}/><Input placeholder={`${c.communityTags} — ${c.communityTagsExample}`} value={request.tags} onChange={e=>setRequest(v=>v&&({...v,tags:e.target.value}))}/><div className="grid gap-3 sm:grid-cols-2">{(['site','whatsapp','discord','github','instagram'] as const).map(kind=><Input key={kind} placeholder={`${requestLinkLabel(c,kind)} https://…`} value={request[kind]} onChange={e=>setRequest(v=>v&&({...v,[kind]:e.target.value}))}/>)}</div></div>}
    </Modal>
  </div>
}
