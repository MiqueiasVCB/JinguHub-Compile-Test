/**************************************************************************/
/*  GitHubView.tsx                                                      */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { openUrl } from '@tauri-apps/plugin-opener'
import type {
  DeviceFlowStart,
  DirectoryLayout,
  GitBranchInfo,
  GitChangedFile,
  GitHubInstallationStatus,
  GitHubRemoteStatus,
  GitHubRepository,
  GitHubUser,
  GitStatus,
  JinguMembershipProfile,
  Project,
} from '../../types'
import { api } from '../../lib/api'
import type { JinguCopy } from '../copy'
import { BusyNotice, Button, IconButton, Input, Modal, SectionCard, Select } from '../components/UI'
import { Icon } from '../components/Icon'

type Props = {
  c: JinguCopy
  projects: Project[]
  selectedId: string | null
  onSelect: (id: string | null) => void
  notify: (m: string, e?: boolean) => void
  membership: JinguMembershipProfile | null
}

function safeRepoName(name: string) {
  return name
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^A-Za-z0-9._-]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 100) || 'jingu-project'
}

function githubWebUrl(remote: string | null) {
  if (!remote) return null
  try {
    if (remote.startsWith('git@github.com:')) {
      const repo = remote.slice('git@github.com:'.length).replace(/\.git$/, '').replace(/^\/+|\/+$/g, '')
      return repo.includes('/') ? `https://github.com/${repo}` : null
    }
    const url = new URL(remote)
    if (url.protocol !== 'https:' || url.hostname !== 'github.com') return null
    const repo = url.pathname.replace(/\.git$/, '').replace(/^\/+|\/+$/g, '')
    return repo.split('/').length >= 2 ? `https://github.com/${repo}` : null
  } catch {
    return null
  }
}

function MembershipBadge({membership}:{membership:JinguMembershipProfile|null}) {
  const tier=String(membership?.tier??'free').toLowerCase()
  if(!membership?.badge_label||tier==='free')return null
  const classes=tier==='gold'?'border-amber-300/40 bg-amber-300/10 text-amber-100':tier==='silver'?'border-slate-300/40 bg-slate-300/10 text-slate-100':'border-orange-400/40 bg-orange-400/10 text-orange-100'
  return <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${classes}`}>{membership.badge_label}</span>
}

export function GitHubView({ c, projects, selectedId, onSelect, notify, membership }: Props) {
  const project = projects.find((p) => p.id === selectedId) ?? null
  const [user, setUser] = useState<GitHubUser | null>(null)
  const [install, setInstall] = useState<GitHubInstallationStatus | null>(null)
  const [gitStatus, setGitStatus] = useState<GitStatus | null>(null)
  const [remote, setRemote] = useState<string | null>(null)
  const [remoteStatus, setRemoteStatus] = useState<GitHubRemoteStatus | null>(null)
  const [remoteChecking, setRemoteChecking] = useState(false)
  const [remoteValidationError, setRemoteValidationError] = useState<string | null>(null)
  const [unlinkModal, setUnlinkModal] = useState(false)
  const [changes, setChanges] = useState<GitChangedFile[]>([])
  const [commitMessage, setCommitMessage] = useState('')
  const [busy, setBusy] = useState<string | null>(null)
  const [device, setDevice] = useState<DeviceFlowStart | null>(null)
  const [deviceWaiting, setDeviceWaiting] = useState(false)
  const loginGeneration = useRef(0)
  const accountRefreshAt = useRef(0)
  const accountRefreshInFlight = useRef<Promise<void> | null>(null)
  const installFlowPending = useRef(false)
  const [accountStatusUnavailable,setAccountStatusUnavailable] = useState(false)
  const [repoModal, setRepoModal] = useState(false)
  const [repoName, setRepoName] = useState('')
  const [repoDesc, setRepoDesc] = useState('')
  const [repoPrivate, setRepoPrivate] = useState(true)
  const [branchModal, setBranchModal] = useState(false)
  const [branches, setBranches] = useState<GitBranchInfo[]>([])
  const [newBranch, setNewBranch] = useState('')
  const [cloneModal, setCloneModal] = useState(false)
  const [cloneUrl, setCloneUrl] = useState('')
  const [cloneDest, setCloneDest] = useState('')
  const [repositories, setRepositories] = useState<GitHubRepository[]>([])
  const [repoQuery, setRepoQuery] = useState('')
  const [repoLoading, setRepoLoading] = useState(false)
  const [layout, setLayout] = useState<DirectoryLayout | null>(null)

  const remoteWebUrl = githubWebUrl(remote)
  const filteredRepositories = useMemo(() => {
    const q = repoQuery.trim().toLowerCase()
    if (!q) return repositories
    return repositories.filter((repo) => `${repo.full_name} ${repo.private ? 'private' : 'public'}`.toLowerCase().includes(q))
  }, [repositories, repoQuery])

  const refreshAccount = useCallback(async (force = false) => {
    if (!force && Date.now() - accountRefreshAt.current < 5_000) return
    if (accountRefreshInFlight.current) return accountRefreshInFlight.current
    const task = (async () => {
      try {
        const u = await api.githubSession()
        setUser(u)
        if (!u) {
          setInstall(null)
          setAccountStatusUnavailable(false)
          return
        }
        try {
          setInstall(await api.githubInstallationStatus(force))
          setAccountStatusUnavailable(false)
        } catch (e) {
          // A temporary GitHub outage must not visually sign the user out. The
          // local OAuth session is still authoritative; only installation status
          // becomes unavailable until a later refresh succeeds.
          setInstall(null)
          setAccountStatusUnavailable(true)
          if (force) notify(String(e), true)
        }
      } catch (e) {
        // Session refresh can itself touch GitHub near token expiry. Preserve the
        // last known identity on transient failures; explicit sign-out/session-null
        // paths still clear it deterministically.
        setAccountStatusUnavailable(true)
        if (force) notify(String(e), true)
      } finally {
        accountRefreshAt.current = Date.now()
      }
    })().finally(() => { accountRefreshInFlight.current = null })
    accountRefreshInFlight.current = task
    return task
  }, [notify])

  const refreshGit = useCallback(async () => {
    if (!project) {
      setGitStatus(null)
      setRemote(null)
      setRemoteStatus(null)
      setRemoteValidationError(null)
      setChanges([])
      return
    }
    try {
      const st = await api.getGitStatus(project.path)
      setGitStatus(st)
      if (st.is_repo) {
        const [r, ch] = await Promise.all([
          api.gitRemoteUrl(project.path).catch(() => null),
          api.gitChangedFiles(project.path).catch(() => []),
        ])
        setRemote(r)
        setChanges(ch)
      } else {
        setRemote(null)
        setRemoteStatus(null)
        setRemoteValidationError(null)
        setChanges([])
      }
    } catch (e) {
      notify(String(e), true)
    }
  }, [project, notify])

  const validateRemote = useCallback(async () => {
    if (!remote || !user) {
      setRemoteStatus(null)
      setRemoteValidationError(null)
      setRemoteChecking(false)
      return
    }
    setRemoteChecking(true)
    setRemoteValidationError(null)
    try {
      setRemoteStatus(await api.githubRemoteStatus(remote))
    } catch (e) {
      setRemoteStatus(null)
      setRemoteValidationError(String(e))
    } finally {
      setRemoteChecking(false)
    }
  }, [remote, user])

  useEffect(() => {
    void refreshAccount(true)
  }, [refreshAccount])
  useEffect(() => {
    const refresh = () => {
      const force = installFlowPending.current
      installFlowPending.current = false
      void refreshAccount(force)
    }
    const onVisibility = () => { if (document.visibilityState === 'visible') refresh() }
    const timer = window.setInterval(() => void refreshAccount(), 60_000)
    window.addEventListener('focus', refresh)
    document.addEventListener('visibilitychange', onVisibility)
    return () => { window.clearInterval(timer); window.removeEventListener('focus', refresh); document.removeEventListener('visibilitychange', onVisibility) }
  }, [refreshAccount])
  useEffect(() => {
    void api.getDirectoryLayout().then(setLayout).catch(() => setLayout(null))
  }, [])
  useEffect(() => {
    void refreshGit()
  }, [refreshGit])
  useEffect(() => {
    void validateRemote()
  }, [validateRemote])

  async function beginLogin() {
    const generation = ++loginGeneration.current
    setBusy('login')
    try {
      const start = await api.githubBeginDeviceFlow()
      if (generation !== loginGeneration.current) return
      setDevice(start)
      setDeviceWaiting(true)
      navigator.clipboard?.writeText(start.user_code).catch(() => {})
      const verification = (() => {
        try {
          const u = new URL(start.verification_uri)
          return u.protocol === 'https:' && u.hostname === 'github.com' ? u.toString() : 'https://github.com/login/device'
        } catch {
          return 'https://github.com/login/device'
        }
      })()
      openUrl(verification).catch(() => {})
      let interval = Math.max(5, start.interval) * 1000
      const deadline = Date.now() + start.expires_in * 1000
      while (generation === loginGeneration.current && Date.now() < deadline) {
        await new Promise((resolve) => setTimeout(resolve, interval))
        if (generation !== loginGeneration.current) return
        const result = await api.githubPollDeviceFlow(start.device_code)
        if (result.status === 'authorized') {
          setDeviceWaiting(false)
          setDevice(null)
          setUser(result.user)
          await refreshAccount(true)
          window.dispatchEvent(new CustomEvent('jingu-github-auth-changed'))
          notify(c.success)
          return
        }
        if (result.status === 'slow_down') {
          interval += 5000
          continue
        }
        if (result.status === 'pending') continue
        throw new Error(result.message || result.status)
      }
      throw new Error(c.githubLoginCodeExpired)
    } catch (e) {
      if (generation === loginGeneration.current) {
        setDeviceWaiting(false)
        notify(String(e), true)
      }
    } finally {
      if (generation === loginGeneration.current) setBusy(null)
    }
  }

  async function signOut() {
    loginGeneration.current++
    try {
      await api.githubSignOut()
      setUser(null)
      setInstall(null)
      setAccountStatusUnavailable(false)
      setRepositories([])
      setRemoteStatus(null)
      setRemoteValidationError(null)
      setDevice(null)
      setDeviceWaiting(false)
      window.dispatchEvent(new CustomEvent('jingu-github-auth-changed'))
    } catch (e) {
      notify(String(e), true)
    }
  }

  async function createRepository() {
    if (!project || !user) return
    setBusy('repo')
    try {
      // Prepare the local repository first. If GitHub rejects creation, no
      // remote repository is left orphaned and the local project is intact.
      let st = await api.getGitStatus(project.path)
      if (!st.is_repo) {
        await api.gitInit(project.path)
        st = await api.getGitStatus(project.path)
      }
      const repo = await api.githubCreateRepository(repoName.trim(), repoDesc.trim() || null, repoPrivate)
      await api.gitSetRemote(project.path, repo.clone_url)
      setRepoModal(false)
      await refreshGit()
      notify(c.repoCreated)
    } catch (e) {
      notify(String(e), true)
    } finally {
      setBusy(null)
    }
  }

  async function removeOrigin() {
    if (!project) return
    setBusy('unlink')
    try {
      await api.gitRemoveRemote(project.path)
      setUnlinkModal(false)
      await refreshGit()
      notify(c.remoteRemoved)
    } catch (e) {
      notify(String(e), true)
    } finally {
      setBusy(null)
    }
  }

  async function sync(action: 'pull' | 'push' | 'fetch') {
    if (!project) return
    setBusy(action)
    try {
      if (action === 'pull') await api.gitPull(project.path)
      else if (action === 'push') await api.gitPush(project.path)
      else await api.gitFetch(project.path)
      await refreshGit()
      notify(c.success)
    } catch (e) {
      notify(String(e), true)
    } finally {
      setBusy(null)
    }
  }

  async function stage(file: GitChangedFile) {
    if (!project) return
    try {
      if (file.staged) await api.gitUnstageFile(project.path, file.path)
      else await api.gitStageFile(project.path, file.path)
      await refreshGit()
    } catch (e) {
      notify(String(e), true)
    }
  }

  async function commit() {
    if (!project || !commitMessage.trim()) return
    setBusy('commit')
    try {
      await api.gitCommit(project.path, commitMessage.trim())
      setCommitMessage('')
      await refreshGit()
      notify(c.localCommitDone)
    } catch (e) {
      notify(String(e), true)
    } finally {
      setBusy(null)
    }
  }

  async function openBranches() {
    if (!project) return
    try {
      setBranches(await api.gitListBranches(project.path))
      setBranchModal(true)
    } catch (e) {
      notify(String(e), true)
    }
  }

  async function switchBranch(name: string) {
    if (!project) return
    setBusy('branch')
    try {
      await api.gitSwitchBranch(project.path, name)
      setBranchModal(false)
      await refreshGit()
      notify(c.success)
    } catch (e) {
      notify(String(e), true)
    } finally {
      setBusy(null)
    }
  }

  async function createBranch() {
    if (!project || !newBranch.trim()) return
    setBusy('branch')
    try {
      await api.gitCreateBranch(project.path, newBranch.trim())
      setNewBranch('')
      setBranches(await api.gitListBranches(project.path))
      await refreshGit()
      notify(c.success)
    } catch (e) {
      notify(String(e), true)
    } finally {
      setBusy(null)
    }
  }

  async function openClone() {
    setCloneDest(layout?.github_repositories_root ?? '')
    setCloneUrl('')
    setRepoQuery('')
    setCloneModal(true)
    if (!user) {
      setRepositories([])
      return
    }
    setRepoLoading(true)
    try {
      setRepositories(await api.githubListRepositories())
    } catch (e) {
      setRepositories([])
      notify(String(e), true)
    } finally {
      setRepoLoading(false)
    }
  }

  function openRepositoryAccess() {
    installFlowPending.current = true
    void openUrl(install?.install_url || 'https://github.com/apps/jingu-engine/installations/new')
  }

  async function clone() {
    if (!cloneUrl.trim() || !cloneDest.trim()) return
    setBusy('clone')
    try {
      const path = await api.cloneRepo(cloneUrl.trim(), cloneDest.trim())
      setCloneModal(false)
      notify(`${c.success}: ${path}`)
    } catch (e) {
      notify(String(e), true)
    } finally {
      setBusy(null)
    }
  }

  const staged = changes.filter((f) => f.staged).length
  const canRepo = Boolean(user && install?.can_create_repositories && install.can_use_git)
  const installationHealthy = Boolean(install?.can_use_git)
  const installationMissing = Boolean(install && !install.installed)
  const personalSelection = install?.personal_installed ? (install.personal_repository_selection === 'all' ? c.allRepositories : c.selectedRepositories) : null
  const organizationSelection = install?.organization_installed ? (install.organization_repository_selection === 'all' ? c.allRepositories : c.selectedRepositories) : null
  const remoteState = remoteStatus?.state
  const remoteMissing = remoteState === 'missing'
  const remoteAccessProblem = remoteState === 'inaccessible' || remoteState === 'missing_or_inaccessible'
  const remoteReadOnly = remoteState === 'read_only'
  const remoteUsable = !remoteStatus || remoteState === 'reachable' || remoteReadOnly || remoteState === 'external'
  const busyLabel = busy === 'repo' ? c.workingCreateRepo
    : busy === 'unlink' ? c.workingRemoveOrigin
    : busy === 'pull' ? c.workingPull
    : busy === 'push' ? c.workingPush
    : busy === 'fetch' ? c.workingFetch
    : busy === 'commit' ? c.workingCommit
    : busy === 'branch' ? c.workingBranch
    : busy === 'clone' ? c.workingClone
    : busy === 'login' ? c.waiting
    : null

  return <div className="mx-auto flex h-full w-full max-w-[1500px] flex-col gap-3 overflow-hidden px-7 py-6">
    <div className="shrink-0"><h1 className="text-2xl font-semibold tracking-tight">{c.github}</h1></div>
    <div className="flex min-w-0 shrink-0 items-center gap-2">
      <span className="shrink-0 text-sm text-muted">{c.gitProject}</span>
      <Select className="min-w-0 flex-1" value={selectedId ?? ''} onChange={(e) => onSelect(e.target.value || null)}>
        <option value="">—</option>
        {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
      </Select>
      <Button icon="download" onClick={openClone}>{c.cloneRepo}</Button>
      <IconButton icon="refresh" label={c.refresh} onClick={() => void Promise.all([refreshAccount(true), refreshGit()]).then(() => validateRemote())}/>
    </div>
    {project && <div className="shrink-0 truncate text-xs text-muted">{project.path}</div>}
    {busyLabel && <BusyNotice label={busyLabel}/>}

    <div className="min-h-0 flex-1 overflow-y-auto pr-1"><div className="grid gap-3 pb-5">
      <SectionCard className="p-5">
        {!user ? <div className="flex items-center justify-between gap-4">
          <div><div className="font-semibold">{c.account}</div><div className="mt-1 text-sm text-muted">GitHub App: Jingu Engine</div></div>
          <Button icon="link" variant="primary" onClick={beginLogin} disabled={busy === 'login'}>{c.signIn}</Button>
        </div> : <div className="flex items-center justify-between gap-4">
          <div className="flex min-w-0 items-center gap-3">
            {user.avatar_url && <img src={user.avatar_url} className="h-11 w-11 rounded-full" alt=""/>}
            <div className="min-w-0">
              <div className="flex min-w-0 items-center gap-2"><div className="truncate font-semibold">{user.name || user.login}</div><MembershipBadge membership={membership}/></div>
              <div className="mt-1 text-sm text-muted">@{user.login} · {c.linked}</div>
              {accountStatusUnavailable?<div className="mt-1 text-xs text-amber">{c.githubStatusUnavailable}</div>:installationMissing?<div className="mt-1 text-xs text-amber">{c.githubAppNotInstalled}</div>:install && !installationHealthy?<div className="mt-1 grid gap-0.5 text-xs text-amber"><div>{c.permissionsMissing}</div>{organizationSelection&&<div className="text-muted">JinguEngine · {organizationSelection}</div>}{personalSelection&&<div className="text-muted">@{user.login} · {personalSelection}</div>}</div>:null}
            </div>
          </div>
          <div className="flex shrink-0 gap-2">
            <Button icon="external" onClick={openRepositoryAccess}>{installationMissing ? c.installGithubApp : c.repoAccess}</Button>
            <Button icon="logout" variant="primary" onClick={signOut}>{c.signOut}</Button>
          </div>
        </div>}
      </SectionCard>

      {!project ? <SectionCard className="p-8 text-center text-muted">{c.noProject}</SectionCard> : <>
        <SectionCard className="p-5">
          <div className="flex min-w-0 items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="text-lg font-semibold">{project.name}</div>
              <div className="mt-2 truncate text-sm text-muted">{remote ? `${c.remote}: ${remote}` : gitStatus?.is_repo ? c.noRemote : c.noRepo}</div>
            </div>
            <div className="flex shrink-0 flex-wrap justify-end gap-2">
              {remoteWebUrl && !remoteMissing && <Button icon="external" onClick={() => openUrl(remoteWebUrl)}>{c.openOnGitHub}</Button>}
              {gitStatus?.is_repo && <Button icon="branch" onClick={openBranches}>{gitStatus.branch || c.branch}</Button>}
              {(!gitStatus?.is_repo || !remote) && <Button icon="plus" disabled={!canRepo} onClick={() => { setRepoName(safeRepoName(project.name)); setRepoDesc(''); setRepoPrivate(true); setRepoModal(true) }}>{c.createRepo}</Button>}
            </div>
          </div>
          {remoteChecking && remote && <div className="mt-4 rounded-md border border-line bg-base/55 p-3 text-sm text-muted">{c.remoteChecking}</div>}
          {remoteMissing && <div className="mt-4 rounded-md border border-danger/35 bg-danger/8 p-4">
            <div className="font-semibold text-[#ffd7d8]">{c.remoteMissingTitle}</div>
            <div className="mt-1 text-sm leading-6 text-[#f7c1c2]">{c.remoteMissingHelp}</div>
            <div className="mt-3 flex flex-wrap gap-2"><Button icon="plus" variant="primary" disabled={!canRepo || Boolean(busy)} onClick={() => { setRepoName(safeRepoName(project.name)); setRepoDesc(''); setRepoPrivate(true); setRepoModal(true) }}>{c.createNewRepo}</Button><Button icon="x" disabled={Boolean(busy)} onClick={() => setUnlinkModal(true)}>{c.removeOrigin}</Button></div>
          </div>}
          {remoteAccessProblem && <div className="mt-4 rounded-md border border-amber/35 bg-amber/8 p-4">
            <div className="font-semibold text-[#ffe1a3]">{remoteState === 'inaccessible' ? c.remoteAccessTitle : c.remoteAmbiguousTitle}</div>
            <div className="mt-1 text-sm leading-6 text-[#f8d99a]">{remoteStatus?.message || c.remoteAccessHelp}</div>
            <div className="mt-3 flex flex-wrap gap-2"><Button icon="external" onClick={openRepositoryAccess}>{installationMissing ? c.installGithubApp : c.repoAccess}</Button><Button icon="x" disabled={Boolean(busy)} onClick={() => setUnlinkModal(true)}>{c.removeOrigin}</Button></div>
          </div>}
          {remoteReadOnly && <div className="mt-4 rounded-md border border-amber/30 bg-amber/5 p-3 text-sm leading-6 text-[#ffe1a3]">{c.remoteReadOnly}</div>}
          {remoteValidationError && <div className="mt-4 rounded-md border border-amber/30 bg-amber/5 p-3 text-sm leading-6 text-[#ffe1a3]">{c.remoteValidationUnavailable}: {remoteValidationError}</div>}
          {user && install && !install.can_use_git && <div className="mt-4 rounded-md border border-amber/30 bg-amber/5 p-3 text-sm leading-6 text-[#ffe1a3]">{installationMissing ? c.githubAppNotInstalledHelp : c.repoInstallHelp}</div>}
          {gitStatus?.is_repo && remote && remoteUsable && <div className="mt-5 flex items-center justify-end gap-2">
            <IconButton icon="pull" label={c.pull} disabled={Boolean(busy)} onClick={() => sync('pull')}/>
            <IconButton icon="push" label={c.push} disabled={Boolean(busy) || remoteReadOnly} onClick={() => sync('push')}/>
            <IconButton icon="fetch" label={c.fetch} disabled={Boolean(busy)} onClick={() => sync('fetch')}/>
          </div>}
        </SectionCard>

        <SectionCard className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <div className="font-semibold">{c.changes} <span className="ml-1 rounded bg-accent/12 px-2 py-0.5 text-xs text-accent-bright">{changes.length}</span></div>
            <div className="flex gap-2">
              <Button className="h-8" icon="plus" disabled={!changes.length} onClick={async () => { if (!project) return; try { await api.gitStageAll(project.path); await refreshGit() } catch (e) { notify(String(e), true) } }}>{c.stageAll}</Button>
              <Button className="h-8" disabled={!staged} onClick={async () => { if (!project) return; try { await api.gitUnstageAll(project.path); await refreshGit() } catch (e) { notify(String(e), true) } }}>{c.unstageAll}</Button>
            </div>
          </div>
          <div className="max-h-[300px] overflow-y-auto bg-base/50">
            {changes.length ? changes.map((f) => <button key={f.path} onClick={() => stage(f)} className="flex w-full items-center gap-3 border-b border-line/60 px-4 py-2.5 text-left text-sm hover:bg-raised">
              <span className={`flex h-4 w-4 items-center justify-center rounded border ${f.staged ? 'border-accent bg-accent text-white' : 'border-line bg-base'}`}>{f.staged && <Icon name="check" className="h-3 w-3"/>}</span>
              <span className={`w-7 font-mono text-xs ${f.status.includes('D') ? 'text-danger' : 'text-amber'}`}>{f.status.trim() || 'M'}</span>
              <span className="min-w-0 flex-1 truncate font-mono text-xs">{f.path}</span>
            </button>) : <div className="p-8 text-center text-sm text-muted">{c.noChanges}</div>}
          </div>
          <div className="flex min-w-0 gap-2 p-3">
            <Input value={commitMessage} onChange={(e) => setCommitMessage(e.target.value)} placeholder={c.commitPlaceholder} className="flex-1" onKeyDown={(e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) void commit() }}/>
            <Button variant="primary" icon="git" disabled={!commitMessage.trim() || !staged || busy === 'commit'} onClick={commit}>{c.commit}</Button>
          </div>
        </SectionCard>
      </>}
    </div></div>

    <Modal closeLabel={c.close} open={Boolean(device)} title={c.deviceTitle} onClose={() => { loginGeneration.current++; setDevice(null); setDeviceWaiting(false); setBusy(null) }} width="max-w-[640px]" footer={<Button onClick={() => { loginGeneration.current++; setDevice(null); setDeviceWaiting(false); setBusy(null) }}>{c.cancel}</Button>}>
      <div className="grid gap-5">
        <p className="leading-7 text-muted">{c.deviceText}</p>
        <div className="rounded-md border border-line bg-base p-4 text-center"><div className="text-xs uppercase tracking-wide text-muted">{c.deviceCode}</div><div className="mt-2 font-mono text-2xl font-semibold tracking-[.14em]">{device?.user_code}</div></div>
        <div className="flex justify-center gap-2"><Button icon="copy" onClick={() => device && navigator.clipboard?.writeText(device.user_code)}>{c.copyCode}</Button><Button variant="primary" icon="external" onClick={() => openUrl('https://github.com/login/device')}>{c.openGitHub}</Button></div>
        {deviceWaiting && <div className="text-center text-sm text-muted">{c.waiting}</div>}
      </div>
    </Modal>

    <Modal closeLabel={c.close} open={repoModal} title={c.createRepoTitle} onClose={() => !busy && setRepoModal(false)} footer={<><Button onClick={() => setRepoModal(false)} disabled={Boolean(busy)}>{c.cancel}</Button><Button variant="primary" icon="plus" onClick={createRepository} disabled={!repoName.trim() || busy === 'repo'}>{c.create}</Button></>}>
      <div className="grid gap-4">
        <label className="grid gap-1.5 text-sm"><span className="text-muted">{c.repoName}</span><Input value={repoName} onChange={(e) => setRepoName(safeRepoName(e.target.value))} autoFocus/></label>
        <label className="grid gap-1.5 text-sm"><span className="text-muted">{c.description}</span><Input value={repoDesc} onChange={(e) => setRepoDesc(e.target.value)}/></label>
        <div className="flex gap-2">
          <button className={`flex-1 rounded-md border p-3 text-left text-ink ${repoPrivate ? 'border-accent bg-accent/10' : 'border-line'}`} onClick={() => setRepoPrivate(true)}><Icon name="lock" className="mb-2 h-5 w-5"/><div className="text-sm font-medium">{c.privateRepo}</div></button>
          <button className={`flex-1 rounded-md border p-3 text-left text-ink ${!repoPrivate ? 'border-accent bg-accent/10' : 'border-line'}`} onClick={() => setRepoPrivate(false)}><Icon name="globe" className="mb-2 h-5 w-5"/><div className="text-sm font-medium">{c.publicRepo}</div></button>
        </div>
      </div>
    </Modal>

    <Modal closeLabel={c.close} open={unlinkModal} title={c.removeOriginTitle} onClose={() => !busy && setUnlinkModal(false)} footer={<><Button onClick={() => setUnlinkModal(false)} disabled={busy === 'unlink'}>{c.cancel}</Button><Button variant="danger" icon="x" onClick={removeOrigin} disabled={busy === 'unlink'}>{c.removeOrigin}</Button></>}>
      <p className="leading-7 text-muted">{c.removeOriginHelp}</p>
      {remote && <div className="mt-3 break-all rounded-md border border-line bg-base px-3 py-2 font-mono text-xs text-ink">{remote}</div>}
    </Modal>

    <Modal closeLabel={c.close} open={branchModal} title={c.branchTitle} onClose={() => setBranchModal(false)} footer={<Button onClick={() => setBranchModal(false)}>{c.close}</Button>}>
      <div className="grid gap-4">
        <div className="flex gap-2"><Input value={newBranch} onChange={(e) => setNewBranch(e.target.value.replace(/\s+/g, '-'))} placeholder={c.newBranch} className="flex-1"/><Button icon="plus" onClick={createBranch} disabled={!newBranch.trim() || busy === 'branch'}>{c.createBranch}</Button></div>
        <div className="grid gap-2">{branches.map((b) => <button key={b.name} className={`flex items-center justify-between rounded-md border px-3 py-2.5 text-left text-sm text-ink ${b.is_current ? 'border-accent bg-accent/10' : 'border-line hover:bg-raised'}`} onClick={() => !b.is_current && switchBranch(b.name)}><span className="flex items-center gap-2"><Icon name="branch" className="h-4 w-4"/>{b.name}</span>{b.is_current && <span className="text-xs text-accent-bright">{c.current}</span>}</button>)}</div>
      </div>
    </Modal>

    <Modal closeLabel={c.close} open={cloneModal} title={c.cloneRepo} onClose={() => !busy && setCloneModal(false)} footer={<><Button onClick={() => setCloneModal(false)} disabled={busy === 'clone'}>{c.cancel}</Button><Button variant="primary" onClick={clone} disabled={!cloneUrl.trim() || !cloneDest.trim() || busy === 'clone'}>{c.cloneRepo}</Button></>} width="max-w-2xl">
      <div className="grid gap-4">
        {user && <div className="grid gap-2">
          <div className="text-sm font-medium">{c.browseRepositories}</div>
          <div className="relative"><Icon name="search" className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted"/><Input value={repoQuery} onChange={(e) => setRepoQuery(e.target.value)} placeholder={c.searchRepositories} className="w-full pl-9"/></div>
          <div className="max-h-52 overflow-y-auto rounded-md border border-line bg-base">
            {repoLoading ? <div className="p-5 text-center text-sm text-muted">{c.loading}</div> : filteredRepositories.length ? filteredRepositories.map((repo) => <button key={repo.id} onClick={() => setCloneUrl(repo.clone_url)} className={`flex w-full items-center gap-3 border-b border-line/60 px-3 py-2.5 text-left text-ink last:border-0 hover:bg-raised ${cloneUrl === repo.clone_url ? 'bg-accent/10' : ''}`}>
              <Icon name={repo.private ? 'lock' : 'globe'} className="h-4 w-4 shrink-0 text-muted"/>
              <span className="min-w-0 flex-1 truncate text-sm">{repo.full_name}</span>
              {cloneUrl === repo.clone_url && <Icon name="check" className="h-4 w-4 shrink-0 text-accent-bright"/>}
            </button>) : <div className="p-5 text-center text-sm text-muted">{c.noRepositories}</div>}
          </div>
        </div>}
        <label className="grid gap-1.5 text-sm"><span className="text-muted">{c.manualGitUrl}</span><Input value={cloneUrl} onChange={(e) => setCloneUrl(e.target.value)} placeholder="https://github.com/usuario/repositorio.git"/></label>
        <label className="grid gap-1.5 text-sm"><span className="text-muted">{c.location}</span><div className="flex gap-2"><Input className="flex-1" value={cloneDest} onChange={(e) => setCloneDest(e.target.value)}/><Button icon="folder" onClick={async () => { const path = await api.pickFolder(); if (path) setCloneDest(path) }}>{c.choose}</Button></div></label>
      </div>
    </Modal>
  </div>
}
