/**************************************************************************/
/*  PlansView.tsx                                                       */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { listen } from '@tauri-apps/api/event'
import type { JinguMembershipProfile, PaymentCheckoutResult, PaymentConfig, PaymentCurrencyOption } from '../../types'
import { api } from '../../lib/api'
import { localizedPlanCatalog, type JinguPlanTier, planByTier } from '../planCatalog'
import { languageOptionValue, type JinguCopy } from '../copy'
import { currencyFractionDigits, moneyMinor, parseAmountMinor, resolveCheckoutDestination, tierRank as rank, transitionPreview, unitPrice, type PaidTier } from '../planDomain'
import { compareCurrencyOptions, preferredCurrencyForLanguage } from '../currencyPresentation'
import { Button, SectionCard } from '../components/UI'
import { CurrencySelect } from '../components/CurrencySelect'
import { Icon } from '../components/Icon'

type CheckoutChoice=
  | {kind:'amount';amount:string;preferredTier:PaidTier|'donation'|'auto'}
  | {kind:'units';tier:PaidTier;units:string}
type PaymentNavigationEvent={url:string;trusted_provider:boolean;return_to_jingu:boolean}

const DAY_MS=24*60*60*1000
const FALLBACK_CURRENCIES:PaymentCurrencyOption[]=[
  {code:'BRL',market:'BR',provider:'infinitepay',available:true,checkout_enabled:false,label:'BRL',prices_minor:{bronze:500,silver:700,gold:1000},donation_enabled:true,donation_min_minor:100,amount_mode:'arbitrary',adaptive_currency:false,canonical_currency:'BRL',price_source:'static'},
]

function publicBrlCurrencies(options:PaymentCurrencyOption[]){
  const safe=options.filter(option=>option.code==='BRL'&&option.market==='BR'&&option.provider==='infinitepay')
  return safe.length?safe:FALLBACK_CURRENCIES
}

function fill(template:string,values:Record<string,string|number>){
  return Object.entries(values).reduce((text,[key,value])=>text.split(`{${key}}`).join(String(value)),template)
}
function paymentPrice(planTier:JinguPlanTier,fallback:string,config:PaymentConfig|null,currency:string,locale:string,billingMinor?:number,requiresPreview=false){
  if(planTier==='free')return fallback
  if(requiresPreview){
    if(typeof billingMinor!=='number'||!Number.isFinite(billingMinor)||billingMinor<=0)return '—'
    return moneyMinor(billingMinor,currency,false,locale)
  }
  const minor=config?.prices_minor?.[planTier]
  if(typeof minor!=='number'||!Number.isFinite(minor)||minor<=0)return fallback
  return moneyMinor(minor,currency,false,locale)
}
function fmtDate(value:string|null|undefined,locale:string){
  if(!value)return '—'
  try{return new Intl.DateTimeFormat(locale,{dateStyle:'medium'}).format(new Date(value))}catch{return value}
}
function fmtDays(ms:number,c:JinguCopy,locale:string){
  const days=Math.max(0,ms/DAY_MS)
  if(!Number.isFinite(days))return c.periodVeryLong
  if(days<1)return fill(c.hoursCount,{hours:Math.max(1,Math.round(days*24))})
  if(days>365000)return c.periodOverThousandYears
  const rounded=Math.round(days*10)/10
  const value=new Intl.NumberFormat(locale,{maximumFractionDigits:1}).format(rounded)
  return fill(c.daysCount,{days:value})
}
function currencySymbol(currency:string,locale:string){
  try{
    const parts=new Intl.NumberFormat(locale,{style:'currency',currency,currencyDisplay:'narrowSymbol'}).formatToParts(0)
    return parts.find(part=>part.type==='currency')?.value??currency
  }catch{return currency}
}

export function PlansView({c,language,membership,onRequireGitHubLogin,notify}:{c:JinguCopy;language:string;membership:JinguMembershipProfile|null;onRequireGitHubLogin:()=>void;notify:(message:string,error?:boolean,title?:string)=>void}){
  const locale=languageOptionValue(language)
  const currentTier=(membership?.tier??'free').toLowerCase()
  const [paymentConfig,setPaymentConfig]=useState<PaymentConfig|null>(null)
  const [paymentCurrency,setPaymentCurrency]=useState('BRL')
  const [workingTier,setWorkingTier]=useState<string|null>(null)
  const checkoutInFlight=useRef(false)
  const [checkoutChoice,setCheckoutChoice]=useState<CheckoutChoice|null>(null)
  const [checkoutBrowser,setCheckoutBrowser]=useState<{url:string;intentId:string;provider:string}|null>(null)
  const [creditsOptIn,setCreditsOptIn]=useState(Boolean(membership?.credits_opt_in))
  const [creditsWorking,setCreditsWorking]=useState(false)

  useEffect(()=>{
    let cancelled=false
    const install=(config:PaymentConfig,choosePreferred:boolean)=>{
      if(cancelled)return
      setPaymentConfig(config)
      const options=publicBrlCurrencies(config.currencies??[])
      setPaymentCurrency(current=>{
        if(!choosePreferred&&options.some(option=>option.code===current))return current
        const preferredCode=preferredCurrencyForLanguage(language,options)
        const preferred=options.find(option=>option.code===preferredCode)
        return preferred?.code??'BRL'
      })
    }
    const refresh=(choosePreferred=false)=>{
      void api.paymentConfig(true).then(config=>install(config,choosePreferred)).catch(()=>{
        // Keep the last known configuration during a transient focus refresh.
        // Initial failure remains fail-closed because paymentConfig starts null.
      })
    }
    refresh(true)
    const onFocus=()=>refresh(false)
    const onVisibility=()=>{if(document.visibilityState==='visible')refresh(false)}
    window.addEventListener('focus',onFocus)
    document.addEventListener('visibilitychange',onVisibility)
    return()=>{cancelled=true;window.removeEventListener('focus',onFocus);document.removeEventListener('visibilitychange',onVisibility)}
  },[language])
  useEffect(()=>{setCreditsOptIn(Boolean(membership?.credits_opt_in))},[membership?.credits_opt_in,membership?.tier])
  useEffect(()=>{
    if(!checkoutChoice)return
    const onKeyDown=(event:KeyboardEvent)=>{
      if(event.key==='Escape'&&!workingTier)setCheckoutChoice(null)
    }
    window.addEventListener('keydown',onKeyDown)
    return()=>window.removeEventListener('keydown',onKeyDown)
  },[checkoutChoice,workingTier])

  const plans=useMemo(()=>localizedPlanCatalog(c,locale),[c,locale])
  const currentPlan=useMemo(()=>planByTier(currentTier,c,locale),[currentTier,c,locale])
  const currencies=[...publicBrlCurrencies(paymentConfig?.currencies??[])].sort((a,b)=>compareCurrencyOptions(a,b,locale))
  const selectedCurrency=currencies.find(option=>option.code===paymentCurrency)??currencies[0]
  const routePaymentConfig=useMemo<PaymentConfig|null>(()=>{
    if(!paymentConfig)return null
    const routePrices=selectedCurrency?.prices_minor
    return routePrices&&Object.keys(routePrices).length?{...paymentConfig,prices_minor:routePrices}:paymentConfig
  },[paymentConfig,selectedCurrency])
  const checkoutEnabled=Boolean(selectedCurrency?.available&&selectedCurrency?.checkout_enabled)
  const amountMode=selectedCurrency?.amount_mode??'arbitrary'
  const donationEnabled=Boolean(selectedCurrency?.donation_enabled??paymentConfig?.donation?.enabled)
  const paidActive=currentTier!=='free'
  const lifetime=Boolean(membership?.lifetime)
  const inputCurrency=paymentCurrency
  const donationMin=selectedCurrency?.donation_min_minor??paymentConfig?.donation?.min_minor??100

  const setCredits=async(enabled:boolean)=>{
    if(!paidActive)return
    const previous=creditsOptIn
    setCreditsOptIn(enabled);setCreditsWorking(true)
    try{const profile=await api.membershipCreditsOptIn(enabled);setCreditsOptIn(Boolean(profile.credits_opt_in))}
    catch(error){setCreditsOptIn(previous);notify(String(error),true,c.plans)}
    finally{setCreditsWorking(false)}
  }
  const openPlanCheckout=(tier:PaidTier)=>{
    if(amountMode==='product_quantity'){
      setCheckoutChoice({kind:'units',tier,units:'1'})
      return
    }
    const base=unitPrice(tier,routePaymentConfig)
    const divisor=10**currencyFractionDigits(inputCurrency,locale)
    setCheckoutChoice({kind:'amount',preferredTier:tier,amount:String(base/divisor).replace('.',',')})
  }
  const openContribution=(preferredTier:'auto'|'donation'='auto')=>{
    if(!donationEnabled||!checkoutEnabled)return
    const divisor=10**currencyFractionDigits(inputCurrency,locale)
    const suggested=preferredTier==='donation'?donationMin:Math.max(donationMin,unitPrice('bronze',routePaymentConfig))
    setCheckoutChoice({kind:'amount',preferredTier,amount:String(suggested/divisor).replace('.',',')})
  }

  const amountChoice=checkoutChoice?.kind==='amount'?checkoutChoice:null
  const unitsChoice=checkoutChoice?.kind==='units'?checkoutChoice:null
  const choiceMinor=amountChoice?parseAmountMinor(amountChoice.amount,inputCurrency,locale):null
  const selection=resolveCheckoutDestination(choiceMinor,amountChoice?.preferredTier,routePaymentConfig)
  const unitCount=unitsChoice&&/^\d{1,4}$/.test(unitsChoice.units)?Number(unitsChoice.units):null
  const unitAmount=unitsChoice&&unitCount!==null&&unitCount>=1&&unitCount<=1200?unitPrice(unitsChoice.tier,routePaymentConfig)*unitCount:null
  const unitAllocation=unitsChoice&&unitAmount!==null?{tier:unitsChoice.tier,units:unitCount as number,unitPrice:unitPrice(unitsChoice.tier,routePaymentConfig),base:unitAmount,support:0}:null
  const displayedUnitAmount=unitAmount
  const allocations=amountChoice?selection.allocations:[]
  const recommendedTier=amountChoice?selection.recommended:null
  const effectiveTier:PaidTier|'donation'=unitsChoice?unitsChoice.tier:selection.destination
  const selectedAllocation=unitsChoice?unitAllocation:selection.selected
  const preview=selectedAllocation?transitionPreview(membership,selectedAllocation,routePaymentConfig):null

  const startCheckout=async()=>{
    if(!checkoutChoice||checkoutInFlight.current)return
    checkoutInFlight.current=true
    setWorkingTier(effectiveTier)
    try{
    // Re-read the public payment matrix without either local or edge cache at
    // the exact side-effect boundary. The Worker still performs the definitive
    // fail-closed validation and prevents stale UI after payment configuration changes.
    let liveConfig:PaymentConfig
    try{liveConfig=await api.paymentConfig(true);setPaymentConfig(liveConfig)}
    catch(error){notify(String(error),true,c.plans);return}
    const liveCurrencies=publicBrlCurrencies(liveConfig.currencies??[])
    const liveCurrency=liveCurrencies.find(option=>option.code===paymentCurrency)
    if(!liveCurrency?.available){notify(c.paymentUnavailableCurrency,true,c.plans);return}
    if(!liveCurrency.checkout_enabled){notify(c.paymentConfiguringCurrency,true,c.plans);return}
    let amountMinor:number|null=null
    if(checkoutChoice.kind==='units'){
      if(unitAmount===null||!selectedAllocation){notify(c.paymentInsufficientTier,true,c.plans);return}
      amountMinor=unitAmount
    }else{
      amountMinor=parseAmountMinor(checkoutChoice.amount,inputCurrency,locale)
      if(amountMinor===null||amountMinor<donationMin){notify(`${c.chooseAmount}: ${moneyMinor(donationMin,inputCurrency,true,locale)}.`,true,c.plans);return}
      if(effectiveTier==='donation'&&!donationEnabled){notify(c.paymentInsufficientTier,true,c.plans);return}
      if(effectiveTier!=='donation'&&!selectedAllocation){notify(c.paymentInsufficientTier,true,c.plans);return}
    }
    try{
      const result:PaymentCheckoutResult=await api.paymentCheckoutStart(effectiveTier,amountMinor,paymentCurrency,checkoutChoice.kind==='units'?unitCount:null)
      setCheckoutBrowser({url:result.checkout_url,intentId:result.intent_id,provider:String(result.provider??selectedCurrency?.provider??'')})
      window.dispatchEvent(new CustomEvent('jingu-payment-checkout-started',{detail:{tier:effectiveTier,currency:paymentCurrency,intentId:result.intent_id}}))
      notify(effectiveTier==='donation'?c.checkoutSupportOpened:c.checkoutOpened,false,c.plans)
      setCheckoutChoice(null)
    }catch(error){
      const message=String(error)
      if(/GitHub|authentication|required|login/i.test(message))onRequireGitHubLogin()
      notify(message,true,c.plans)
    }
    }finally{checkoutInFlight.current=false;setWorkingTier(null)}
  }

  const previewText=selectedAllocation&&preview?(()=>{
    const planName=planByTier(selectedAllocation.tier,c,locale).name
    const days=selectedAllocation.units*31
    if(preview.kind==='new')return fill(c.previewNewPlan,{plan:planName,days})
    if(preview.kind==='extend')return fill(c.previewExtendPlan,{plan:planName,days})
    const carry=fill(c.approxCarry,{value:fmtDays(preview.carryMs,c,locale)})
    return fill(preview.kind==='upgrade'?c.previewUpgradePlan:c.previewChangePlan,{plan:planName,carry,days})
  })():null

  return <div className="mx-auto h-full w-full max-w-[1500px] overflow-y-auto px-7 py-6">
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div><h1 className="text-2xl font-semibold tracking-tight">{c.plansTitle}</h1><div className="mt-2 text-xs text-muted">{c.plansSubtitle}</div></div>
      <div className="min-w-[380px]"><div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted">{c.paymentCurrency}</div><CurrencySelect options={currencies} value={paymentCurrency} locale={locale} c={c} onChange={setPaymentCurrency}/></div>
    </div>

    <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4">{plans.map(plan=>{
      const active=plan.tier===currentTier
      const canBuy=plan.tier!=='free'&&checkoutEnabled&&!lifetime
      const relation=plan.tier==='free'||currentTier==='free'||active?'':rank(plan.tier)>rank(currentTier)?'upgrade':'downgrade'
      const buttonLabel=active&&plan.tier==='free'?c.currentPlanLabel:lifetime?c.lifetimeActive:workingTier===plan.tier?c.openingCheckout:canBuy?(active?c.addDays:relation==='upgrade'?c.upgradePlan:c.changePlan):c.inConfiguration
      return <div key={plan.tier} className={`flex flex-col rounded-lg border p-5 ${active?'ring-1 ring-accent/35':''}`} style={{borderColor:plan.borderColor,background:plan.background}}>
          <div className="flex items-start justify-between gap-3"><div><div className="text-xs uppercase tracking-wide text-muted">{c.plan}</div><div className="mt-1 text-xl font-semibold">{plan.name}</div></div>{active&&<span className="rounded-full border border-accent/30 bg-accent/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-accent-bright">{c.currentPlan}</span>}</div>
          <div className="mt-4 text-2xl font-bold text-ink">{paymentPrice(plan.tier,plan.price,routePaymentConfig,paymentCurrency,locale)}</div><div className="mt-1 text-xs text-muted">{plan.durationLabel}</div>
          <div className="mt-4 min-h-[172px] space-y-2.5">{plan.benefits.map(item=><div key={item} className="flex items-start gap-2 text-sm text-muted"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full" style={{backgroundColor:plan.dotColor}}/>{item}</div>)}</div>
          <div className="mt-5"><Button variant={active?'secondary':'primary'} disabled={plan.tier==='free'||!canBuy||Boolean(workingTier)} onClick={()=>plan.tier!=='free'&&openPlanCheckout(plan.tier)}>{buttonLabel}</Button></div>
      </div>
    })}</div>

    <div className="mt-6 grid items-stretch gap-4 xl:grid-cols-4">
      {donationEnabled&&<SectionCard className="relative flex min-h-[220px] flex-col overflow-hidden p-0 xl:col-span-1">
        <div aria-hidden className="h-1 w-full bg-gradient-to-r from-accent via-accent-bright/70 to-transparent"/>
        <div className="flex flex-1 flex-col p-5">
          <div className="flex items-start justify-between gap-3"><div className="text-lg font-semibold">{c.chooseAmount}</div><span className="rounded-full border border-line bg-base/70 px-2.5 py-1 font-mono text-[10px] font-semibold tracking-wide text-muted">{paymentCurrency}</span></div>
          <div className="mt-5 rounded-lg border border-accent/20 bg-accent/5 px-4 py-3.5"><div className="text-[10px] font-semibold uppercase tracking-[0.14em] text-muted">{c.totalAmount}</div><div className="mt-1.5 flex items-baseline gap-1.5"><span className="text-2xl font-semibold tracking-tight text-ink">{moneyMinor(donationMin,inputCurrency,false,locale)}</span><span className="text-sm font-semibold text-accent-bright">+</span></div><div className="mt-3 border-t border-accent/15 pt-3 text-xs leading-5 text-muted">{c.customAmountThanks}</div></div>
          <div className="mt-3 text-xs leading-5 text-muted">{c.customAmountPreviewHelp}</div>
          <div className="mt-auto grid gap-2 sm:grid-cols-2 xl:grid-cols-1">
            <Button className="w-full" icon="plus" variant="secondary" disabled={!checkoutEnabled||Boolean(workingTier)} onClick={()=>openContribution('auto')}>{c.informAmount}</Button>
            <Button className="w-full" variant="secondary" disabled={!checkoutEnabled||Boolean(workingTier)} onClick={()=>openContribution('donation')}>{c.supportOnly}</Button>
          </div>
        </div>
      </SectionCard>}
      <SectionCard className={`p-6 ${donationEnabled?'xl:col-span-3':'xl:col-span-4'}`}>
        <div className="flex flex-wrap items-start justify-between gap-4"><div><div className="text-lg font-semibold">{c.planSummary}</div><p className="mt-1 text-sm text-muted">{c.planSummaryHelp}</p></div><div className="text-right"><div className="text-xs uppercase tracking-wide text-muted">{c.statusLabel}</div><div className="mt-1 font-semibold text-ink">{lifetime?c.lifetimePlan:paidActive?c.paidPlanActive:c.freePlanStatus}</div></div></div>
        <div className="mt-4 grid gap-4 md:grid-cols-4"><Info label={c.plan} value={currentPlan.name}/><Info label={c.activeListings} value={String(currentPlan.activePosts)}/><Info label={c.validity} value={lifetime?c.lifetimeActive:paidActive?fmtDate(membership?.cycle_ends_at,locale):'—'}/><Info label={c.renewal} value={lifetime?c.renewalNotNeeded:c.manualRenewal}/></div>
        {paidActive&&<label className="mt-4 flex cursor-pointer items-center justify-between gap-4 rounded-lg border border-line bg-base/45 px-4 py-3"><div><div className="text-sm font-medium text-ink">{c.showInSubscribers}</div><div className="mt-1 text-xs text-muted">{c.showInSubscribersHelp}</div></div><input type="checkbox" checked={creditsOptIn} disabled={creditsWorking} onChange={event=>void setCredits(event.target.checked)}/></label>}
        {checkoutEnabled?<div className="mt-4 rounded-lg border border-accent/25 bg-accent/5 px-4 py-3 text-xs text-muted">{c.brlProviderNotice}</div>:<div className="mt-4 rounded-lg border border-amber-400/25 bg-amber-400/5 px-4 py-3 text-xs text-amber-100">{c.checkoutDisabled}</div>}
      </SectionCard>
    </div>

    {unitsChoice&&<div className="fixed inset-0 z-[80] grid place-items-center bg-black/70 p-6" onMouseDown={event=>{if(event.currentTarget===event.target&&!workingTier)setCheckoutChoice(null)}}><SectionCard className="max-h-[88vh] w-[min(620px,94vw)] overflow-y-auto p-6"><div role="dialog" aria-modal="true" aria-labelledby="jingu-units-checkout-title"><div id="jingu-units-checkout-title" className="text-xl font-semibold">{planByTier(unitsChoice.tier,c,locale).name}</div><p className="mt-2 text-sm leading-6 text-muted">{c.planSettingsHelp}</p><label className="mt-5 block"><div className="mb-2 text-sm font-semibold text-ink">{c.unitsLabel}</div><input autoFocus inputMode="numeric" className="focus-ring w-full rounded-lg border border-line bg-base/65 px-4 py-3 text-base font-semibold text-ink" autoComplete="off" spellCheck={false} value={unitsChoice.units} onChange={event=>setCheckoutChoice({...unitsChoice,units:event.target.value.replace(/\D/g,'').slice(0,4)})}/></label>{unitAmount!==null&&<div className="mt-4 rounded-lg border border-line bg-base/55 px-4 py-3"><div className="text-xs uppercase tracking-wide text-muted">{c.totalAmount} · {paymentCurrency}</div><div className="mt-1 text-xl font-semibold">{displayedUnitAmount===null?'—':moneyMinor(displayedUnitAmount,paymentCurrency,true,locale)}</div><div className="mt-1 text-xs text-muted">{fill(c.unitsThirtyDays,{units:unitCount??0})}</div></div>}{selectedAllocation&&preview&&previewText&&<div className="mt-4 rounded-lg border border-accent/25 bg-accent/5 px-4 py-3 text-sm text-muted"><div className="font-semibold text-ink">{c.afterConfirmation}</div><div className="mt-1">{previewText}</div><div className="mt-1 text-xs">{preview.projected?fill(c.projectedValidityValue,{date:fmtDate(preview.projected,locale)}):c.periodTooLongPreview} {c.serverFinalCalculation}</div></div>}<div className="mt-6 flex justify-end gap-3"><Button variant="secondary" disabled={Boolean(workingTier)} onClick={()=>setCheckoutChoice(null)}>{c.cancelAction}</Button><Button disabled={Boolean(workingTier)||unitAmount===null||!selectedAllocation} onClick={()=>void startCheckout()}>{workingTier?c.openingCheckout:c.continuePayment}</Button></div></div></SectionCard></div>}

    {amountChoice&&<div className="fixed inset-0 z-[80] grid place-items-center bg-black/70 p-6" onMouseDown={event=>{if(event.currentTarget===event.target&&!workingTier)setCheckoutChoice(null)}}><SectionCard className="max-h-[88vh] w-[min(680px,94vw)] overflow-y-auto p-6"><div role="dialog" aria-modal="true" aria-labelledby="jingu-custom-checkout-title"><div id="jingu-custom-checkout-title" className="text-xl font-semibold">{c.supportChooseTitle}</div><p className="mt-2 text-sm leading-6 text-muted">{c.supportChooseHelp}</p><label className="mt-5 block"><div className="mb-2 text-sm font-semibold text-ink">{c.totalAmount} · {inputCurrency}</div><div className="flex items-center rounded-lg border border-line bg-base/65 px-3"><span className="text-sm text-muted">{currencySymbol(inputCurrency,locale)}</span><input autoFocus inputMode="decimal" className="w-full bg-transparent px-3 py-3 text-base font-semibold text-ink caret-accent-bright outline-none selection:bg-accent/30 selection:text-ink placeholder:text-muted/60" autoComplete="off" spellCheck={false} aria-label={`${c.totalAmount} · ${inputCurrency}`} value={amountChoice.amount} onChange={event=>setCheckoutChoice({...amountChoice,amount:event.target.value})}/></div></label><div className="mt-2 text-xs text-muted">{c.supportNoMaximum}</div>
      {choiceMinor!==null&&choiceMinor>=donationMin&&<div className="mt-5"><div className="mb-2 text-sm font-semibold">{c.valueDestination}</div><div className="grid gap-2">{choiceMinor>=unitPrice('bronze',routePaymentConfig)&&allocations.map(option=>{const selected=effectiveTier===option.tier;return <button type="button" key={option.tier} className={`focus-ring rounded-lg border px-4 py-3 text-left transition ${selected?'border-accent bg-accent/10':'border-line bg-base/55 hover:border-accent/40'}`} onClick={()=>setCheckoutChoice({...amountChoice,preferredTier:option.tier})}><div className="flex flex-wrap items-center justify-between gap-2"><div className="font-semibold">{planByTier(option.tier,c,locale).name} · {fill(c.unitsThirtyDays,{units:option.units})}</div>{option.tier===recommendedTier&&<span className="rounded-full border border-accent/25 bg-accent/8 px-2 py-0.5 text-[10px] font-bold uppercase text-accent-bright">{c.recommended}</span>}</div><div className="mt-1 text-xs text-muted">{fill(c.valueInPlan,{amount:moneyMinor(option.base,inputCurrency,true,locale)})}{option.support>0?` · ${fill(c.extraSupportInline,{amount:moneyMinor(option.support,inputCurrency,true,locale)})}`:''}</div></button>})}{donationEnabled&&<button type="button" className={`focus-ring rounded-lg border px-4 py-3 text-left transition ${effectiveTier==='donation'?'border-accent bg-accent/10':'border-line bg-base/55 hover:border-accent/40'}`} onClick={()=>setCheckoutChoice({...amountChoice,preferredTier:'donation'})}><div className="font-semibold">{c.supportOnly}</div><div className="mt-1 text-xs text-muted">{moneyMinor(choiceMinor,inputCurrency,true,locale)} {c.supportOnlyHelp}</div></button>}</div></div>}
      {selectedAllocation&&preview&&previewText&&<div className="mt-4 rounded-lg border border-accent/25 bg-accent/5 px-4 py-3 text-sm text-muted"><div className="font-semibold text-ink">{c.afterConfirmation}</div><div className="mt-1">{previewText}</div><div className="mt-1 text-xs">{preview.projected?fill(c.projectedValidityValue,{date:fmtDate(preview.projected,locale)}):c.periodTooLongPreview} {c.serverFinalCalculation}</div></div>}
      <div className="mt-6 flex justify-end gap-3"><Button variant="secondary" disabled={Boolean(workingTier)} onClick={()=>setCheckoutChoice(null)}>{c.cancelAction}</Button><Button disabled={Boolean(workingTier)||choiceMinor===null||choiceMinor<donationMin||(effectiveTier==='donation'&&!donationEnabled)||(effectiveTier!=='donation'&&!selectedAllocation)} onClick={()=>void startCheckout()}>{workingTier?c.openingCheckout:effectiveTier==='donation'?c.continueSupport:c.continuePayment}</Button></div></div></SectionCard></div>}
    {checkoutBrowser&&<EmbeddedPaymentCheckout c={c} checkout={checkoutBrowser} onClose={()=>setCheckoutBrowser(null)}/>} 
  </div>
}
function Info({label,value}:{label:string;value:string}){return <div className="rounded-lg border border-line bg-base/60 p-4"><div className="text-xs uppercase tracking-wide text-muted">{label}</div><div className="mt-2 text-sm font-medium text-ink">{value}</div></div>}


function EmbeddedPaymentCheckout({c,checkout,onClose}:{c:JinguCopy;checkout:{url:string;intentId:string;provider:string};onClose:()=>void}){
  const hostRef=useRef<HTMLDivElement|null>(null)
  const [currentUrl,setCurrentUrl]=useState(checkout.url)
  const [trusted,setTrusted]=useState(true)
  const [browserError,setBrowserError]=useState(false)

  useLayoutEffect(()=>{
    const host=hostRef.current
    if(!host)return
    let cancelled=false
    let cleanupNavigation:(()=>void)|undefined
    let cleanupReturn:(()=>void)|undefined
    let raf=0
    let lastBounds=''

    const sync=()=>{
      if(cancelled)return
      cancelAnimationFrame(raf)
      raf=requestAnimationFrame(()=>{
        const rect=host.getBoundingClientRect()
        if(rect.width<=2||rect.height<=2)return
        const signature=`${Math.round(rect.left)}:${Math.round(rect.top)}:${Math.round(rect.width)}:${Math.round(rect.height)}`
        if(signature===lastBounds)return
        lastBounds=signature
        void api.paymentBrowserSetBounds({x:rect.left,y:rect.top,width:rect.width,height:rect.height}).catch(()=>{})
      })
    }

    const rect=host.getBoundingClientRect()
    void api.paymentBrowserShow(checkout.url,{x:rect.left,y:rect.top,width:rect.width,height:rect.height})
      .then(()=>{if(!cancelled)setBrowserError(false)})
      .catch(()=>{if(!cancelled)setBrowserError(true)})

    const observer=new ResizeObserver(sync)
    observer.observe(host)
    window.addEventListener('resize',sync)
    window.addEventListener('scroll',sync,true)

    void listen<PaymentNavigationEvent>('jingu-payment-browser-navigation',event=>{
      if(cancelled)return
      setCurrentUrl(event.payload.url)
      setTrusted(event.payload.trusted_provider||event.payload.return_to_jingu)
    }).then(unlisten=>{if(cancelled)unlisten();else cleanupNavigation=unlisten})

    void listen<PaymentNavigationEvent>('jingu-payment-browser-returned',event=>{
      if(cancelled)return
      setCurrentUrl(event.payload.url)
      setTrusted(true)
    }).then(unlisten=>{if(cancelled)unlisten();else cleanupReturn=unlisten})

    return()=>{
      cancelled=true
      cancelAnimationFrame(raf)
      cleanupNavigation?.()
      cleanupReturn?.()
      observer.disconnect()
      window.removeEventListener('resize',sync)
      window.removeEventListener('scroll',sync,true)
      void api.paymentBrowserHide()
    }
  },[checkout.url])

  useEffect(()=>{
    const onKeyDown=(event:KeyboardEvent)=>{if(event.key==='Escape')onClose()}
    window.addEventListener('keydown',onKeyDown)
    return()=>window.removeEventListener('keydown',onKeyDown)
  },[onClose])

  const origin=(()=>{try{return new URL(currentUrl).hostname}catch{return ''}})()
  return <div className="fixed inset-0 z-[90] grid place-items-center bg-black/70 p-4 sm:p-6" onMouseDown={event=>{if(event.currentTarget===event.target)onClose()}}>
    <SectionCard className="flex h-[min(820px,92vh)] w-[min(1040px,96vw)] min-h-[520px] flex-col overflow-hidden shadow-2xl">
      <div role="dialog" aria-modal="true" aria-label={c.checkoutInsideHub} className="flex min-h-0 flex-1 flex-col">
        <div className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-b border-line bg-surface px-4 py-3">
          <div className="min-w-0">
            <div className="text-sm font-semibold">{c.checkoutInsideHub}</div>
            <div className={`mt-0.5 truncate text-[11px] ${trusted?'text-muted':'text-amber-300'}`}>{c.checkoutOrigin}: {origin||'—'}</div>
          </div>
          <div className="flex shrink-0 gap-2">
            <Button icon="refresh" variant="secondary" onClick={()=>void api.paymentBrowserReload().catch(()=>setBrowserError(true))}>{c.checkoutReload}</Button>
            <button type="button" className="focus-ring grid h-10 w-10 place-items-center rounded-lg border border-line text-muted hover:text-ink" aria-label={c.checkoutClose} title={c.checkoutClose} onClick={onClose}><Icon name="close" className="h-5 w-5"/></button>
          </div>
        </div>
        <div className="shrink-0 border-b border-accent/20 bg-accent/5 px-4 py-2.5 text-xs leading-5 text-muted">{c.pixCheckoutNotice}</div>
        {browserError&&<div role="alert" className="shrink-0 border-b border-red-400/25 bg-red-400/10 px-4 py-2 text-xs text-red-200">{c.checkoutBrowserError}</div>}
        <div ref={hostRef} className="relative min-h-[360px] flex-1 bg-white">
          <div className="absolute inset-0 flex items-center justify-center text-sm text-neutral-500">{c.loading}</div>
        </div>
      </div>
    </SectionCard>
  </div>
}
