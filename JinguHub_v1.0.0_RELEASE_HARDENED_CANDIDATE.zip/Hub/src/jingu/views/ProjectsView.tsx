/**************************************************************************/
/*  ProjectsView.tsx                                                    */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import type { AppSettings, InstalledGodotVersion, Project } from '../../types'
import { api } from '../../lib/api'
import type { JinguCopy } from '../copy'
import { Button, IconButton, Input, Modal, SectionCard, Select } from '../components/UI'
import { Icon } from '../components/Icon'

type Props = {
  c: JinguCopy
  projects: Project[]
  versions: InstalledGodotVersion[]
  selectedId: string | null
  animations: boolean
  onSelect: (id: string) => void
  onDeselect: () => void
  onRefresh: () => Promise<void>
  refreshing: boolean
  notify: (message: string, error?: boolean) => void
  settings: AppSettings
}

type RemovalChoice = { project: Project; action: 'remove' | 'delete' } | null

function cleanVersion(value: string) {
  return value.trim().replace(/^v/i, '').replace(/-mono$/i, '')
}

function isUsefulVersion(value?: string | null) {
  return !!value && /^v?\d+(?:\.\d+){1,2}(?:[-.][a-z]+\d*)?/i.test(value.trim())
}

function installedLabel(version: InstalledGodotVersion, c: JinguCopy) {
  if (version.managed_install === false) {
    const runtime = version.runtime_version && isUsefulVersion(version.runtime_version) ? cleanVersion(version.runtime_version) : null
    return runtime ? `${c.localBuild} · ${c.runtime} ${runtime}` : c.localBuild
  }
  if (isUsefulVersion(version.version)) return `Jingu ${cleanVersion(version.version)}`
  if (isUsefulVersion(version.tag)) return `Jingu ${cleanVersion(version.tag)}`
  if (version.custom_name && !/jingu[_ .-]?engine.*(?:windows|linux|macos|editor|x86|arm)/i.test(version.custom_name)) {
    return `Jingu ${version.custom_name}`
  }
  return 'Jingu Engine'
}

function versionLabel(project: Project, versions: InstalledGodotVersion[], c: JinguCopy) {
  const installed = project.godot_version ? versions.find(version => version.tag === project.godot_version) : undefined
  if (project.jingu_version) {
    const label = `Jingu ${cleanVersion(project.jingu_version)}`
    return installed ? label : `${label} · ${c.versionNotInstalled}`
  }
  if (!project.godot_version) return c.noEngine
  if (installed) return installedLabel(installed, c)
  return `Jingu ${cleanVersion(project.godot_version)} · ${c.versionNotInstalled}`
}

function folderName(path: string) {
  return path.replace(/[\\/]+$/, '').split(/[\\/]/).pop() || path
}

function ProjectIcon({ project, animations }: { project: Project; animations: boolean }) {
  const [icon, setIcon] = useState<string | null>(null)
  useEffect(() => {
    let live = true
    setIcon(null)
    api.getProjectIcon(project.path).then(value => { if (live) setIcon(value) }).catch(() => {})
    return () => { live = false }
  }, [project.path])

  return <div className="flex h-[104px] w-[104px] shrink-0 items-center justify-center overflow-hidden rounded-xl border border-line/80 bg-base/75 shadow-inner">
    {icon
      ? <img src={icon} alt="" className={`h-[82px] w-[82px] object-contain opacity-90 drop-shadow-sm transition-transform duration-200 ${animations ? 'group-hover:scale-[1.04]' : ''}`}/>
      : <Icon name="projects" className={`h-11 w-11 text-accent/45 transition-transform duration-200 ${animations ? 'group-hover:scale-[1.04]' : ''}`}/>} 
  </div>
}

export function ProjectsView({ c, projects, versions, selectedId, animations, onSelect, onDeselect, onRefresh, refreshing, notify, settings }: Props) {
  const [query, setQuery] = useState('')
  const [sort, setSort] = useState<'recent'|'name'>('recent')
  const [menuId, setMenuId] = useState<string | null>(null)
  const [versionMenuId, setVersionMenuId] = useState<string | null>(null)
  const [versionChange, setVersionChange] = useState<{project:Project; version:string}|null>(null)
  const [removePicker, setRemovePicker] = useState<Project | null>(null)
  const [removalChoice, setRemovalChoice] = useState<RemovalChoice>(null)
  const [typedFolder, setTypedFolder] = useState('')
  const [newOpen, setNewOpen] = useState(false)
  const [newName, setNewName] = useState('')
  const [newLocation, setNewLocation] = useState('')
  const [newVersion, setNewVersion] = useState('')
  const [busy, setBusy] = useState(false)

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase()
    const rows = projects.filter(project => !q || project.name.toLowerCase().includes(q) || project.path.toLowerCase().includes(q))
    rows.sort((a,b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1
      if (sort === 'name') return a.name.localeCompare(b.name)
      return (b.last_opened ?? b.created_at).localeCompare(a.last_opened ?? a.created_at)
    })
    return rows
  }, [projects, query, sort])

  useEffect(() => {
    setMenuId(null)
    setVersionMenuId(null)
  }, [selectedId])

  async function toggleFavorite(project: Project) {
    await api.updateProject(project.id, { pinned: !project.pinned })
    await onRefresh()
  }

  function chooseVersion(project: Project, version: string) {
    setVersionMenuId(null)
    if (!version || version === project.godot_version) return
    setVersionChange({ project, version })
  }

  async function confirmVersionCopy() {
    if (!versionChange) return
    setBusy(true)
    try {
      const result = await api.setProjectEngineVersion(versionChange.project.id, versionChange.version)
      setVersionChange(null)
      await onRefresh()
      onSelect(result.project.id)
      notify(result.copied ? `${c.copied}: ${result.new_path}` : c.success)
    } catch (error) {
      notify(String(error), true)
    } finally {
      setBusy(false)
    }
  }

  async function confirmRemoval() {
    if (!removalChoice) return
    setBusy(true)
    try {
      const project = removalChoice.project
      const deleting = removalChoice.action === 'delete'
      await api.removeProject(project.id, deleting, deleting ? typedFolder : null)
      setRemovalChoice(null)
      setTypedFolder('')
      await onRefresh()
      onDeselect()
      notify(c.success)
    } catch (error) {
      notify(String(error), true)
    } finally {
      setBusy(false)
    }
  }

  function openSecondRemoval(project: Project, action: 'remove' | 'delete') {
    setRemovePicker(null)
    setTypedFolder('')
    // Queueing the second dialog avoids two modal backdrops existing in the same frame.
    window.setTimeout(() => setRemovalChoice({ project, action }), 0)
  }

  async function createProject() {
    if (!newName.trim() || !newLocation.trim() || !newVersion) return
    setBusy(true)
    try {
      const project = await api.createProject(newName.trim(), newLocation.trim(), newVersion)
      setNewOpen(false)
      setNewName('')
      setNewLocation(settings.default_project_location ?? '')
      await onRefresh()
      onSelect(project.id)
      notify(c.success)
    } catch (error) {
      notify(String(error), true)
    } finally {
      setBusy(false)
    }
  }

  async function importProject() {
    const path = await api.pickFolder()
    if (!path) return
    try {
      // The backend resolves .jingu-version / project metadata. Import must not
      // silently bind the first Engine installed on the machine.
      const project = await api.importProject(path, '')
      await onRefresh()
      onSelect(project.id)
      notify(c.success)
    } catch (error) {
      notify(String(error), true)
    }
  }

  return <div className="mx-auto flex h-full w-full max-w-[1500px] flex-col gap-4 overflow-hidden px-7 py-6">
    <div className="flex shrink-0 items-end justify-between gap-4">
      <div><h1 className="text-2xl font-semibold tracking-tight">{c.projects}</h1><p className="mt-1 text-sm text-muted">{projects.length} · {c.projects}</p></div>
      <div className="flex items-center gap-2"><Button icon="plus" variant="primary" onClick={()=>{setNewVersion(versions[0]?.tag ?? '');setNewLocation(settings.default_project_location ?? '');setNewOpen(true)}} disabled={!versions.length}>{c.newProject}</Button><Button icon="folder" onClick={importProject}>{c.import}</Button></div>
    </div>

    <SectionCard className="shrink-0 p-3">
      <div className="flex min-w-0 items-center gap-2">
        <div className="relative min-w-[180px] flex-1"><Icon name="search" className="absolute left-3 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-muted"/><Input value={query} onChange={event=>setQuery(event.target.value)} placeholder={c.searchProjects} className="w-full pl-10"/></div>
        <Select value={sort} onChange={event=>setSort(event.target.value as 'recent'|'name')} className="w-[180px] shrink-0"><option value="recent">{c.sortRecent}</option><option value="name">{c.sortName}</option></Select>
        <IconButton icon="refresh" label={refreshing?c.refreshingProjects:c.refresh} disabled={refreshing} className={refreshing?'animate-pulse':''} onClick={()=>onRefresh().catch(error=>notify(String(error),true))}/>
        <IconButton icon="clean" label={c.clean} disabled={refreshing} onClick={()=>onRefresh().then(()=>notify(c.success)).catch(error=>notify(String(error),true))}/>
      </div>
    </SectionCard>

    <div className="min-h-0 flex-1 overflow-y-auto pr-1" onMouseDown={event=>{if(event.currentTarget===event.target){setMenuId(null);setVersionMenuId(null);onDeselect()}}}>
      <div className="flex min-h-full flex-col gap-3 pb-6" onMouseDown={event=>{if(event.currentTarget===event.target){setMenuId(null);setVersionMenuId(null);onDeselect()}}}>
        {visible.map(project => {
          const selected = selectedId === project.id
          const currentInstalled = versions.find(version => version.tag === project.godot_version)
          return <motion.div key={project.id} layout={animations} whileHover={animations ? {y:-1} : undefined} className="relative z-0 focus-within:z-20 hover:z-10">
            <div className={`group relative rounded-xl border transition-[border-color,background-color,box-shadow] ${selected ? 'border-accent bg-accent/[0.11] shadow-[0_0_0_1px_rgba(105,173,75,.18),inset_3px_0_0_var(--color-accent)]' : 'border-line bg-surface hover:border-accent-dim hover:bg-raised/55'}`} onClick={()=>onSelect(project.id)}>
              <div className="flex min-h-[142px] items-center gap-5 rounded-[inherit] px-5 py-4">
                <ProjectIcon project={project} animations={animations}/>
                <div className="min-w-0 flex-1 self-stretch py-1">
                  <div className="flex min-w-0 items-center gap-2"><div className="truncate text-[17px] font-semibold tracking-[-.01em] text-ink">{project.name}</div>{project.pinned&&<Icon name="star" className="h-4 w-4 shrink-0 text-accent-bright"/>}</div>
                  <div className="mt-2 truncate text-[13px] text-muted" title={project.path}>{project.path}</div>
                  <div className="relative mt-4 inline-block" onClick={event=>event.stopPropagation()}>
                    <button type="button" className={`focus-ring inline-flex h-9 max-w-[310px] items-center gap-2 rounded-md border px-3 text-xs font-medium transition-colors ${versionMenuId===project.id?'border-accent bg-raised text-ink':'border-line bg-base text-muted hover:border-accent-dim hover:text-ink'}`} onClick={()=>{setMenuId(null);setVersionMenuId(versionMenuId===project.id?null:project.id)}} disabled={!versions.length} aria-haspopup="listbox" aria-expanded={versionMenuId===project.id}>
                      <Icon name="versions" className="h-4 w-4 shrink-0 text-accent-bright"/><span className="truncate">{versionLabel(project,versions,c)}</span>
                    </button>
                    {versionMenuId===project.id&&<div role="listbox" className="absolute left-0 top-11 z-50 max-h-64 w-[310px] overflow-y-auto rounded-lg border border-line bg-overlay p-1.5 shadow-2xl">
                      {versions.map(version=>{
                        const active=version.tag===project.godot_version
                        return <button key={version.tag} role="option" aria-selected={active} className={`flex w-full items-center gap-2 rounded-md px-3 py-2.5 text-left text-sm ${active?'bg-accent/15 text-ink':'text-muted hover:bg-raised hover:text-ink'}`} onClick={()=>chooseVersion(project,version.tag)}><Icon name={active?'check':'versions'} className={`h-4 w-4 shrink-0 ${active?'text-accent-bright':''}`}/><span className="truncate">{installedLabel(version,c)}</span></button>
                      })}
                    </div>}
                  </div>
                </div>
                <div className="flex w-[218px] shrink-0 flex-col items-center gap-2.5" onClick={event=>event.stopPropagation()}>
                  <Button variant="primary" icon="play" className="w-full" disabled={!project.godot_version||!currentInstalled} onClick={()=>api.openProject(project.id,true).catch(error=>notify(String(error),true))}>{c.openProject}</Button>
                  <div className="relative flex w-full items-center justify-center gap-3">
                    <IconButton icon="star" label={project.pinned?c.unfavorite:c.favorite} active={project.pinned} onClick={()=>toggleFavorite(project).catch(error=>notify(String(error),true))}/>
                    <IconButton icon="folder" label={c.openFolder} onClick={()=>api.openProjectFolder(project.path).catch(error=>notify(String(error),true))}/>
                    <IconButton icon="more" label={c.options} active={menuId===project.id} onClick={()=>{setVersionMenuId(null);setMenuId(menuId===project.id?null:project.id)}}/>
                    {menuId===project.id&&<div className="absolute right-0 top-10 z-50 w-52 rounded-lg border border-line bg-overlay p-1.5 shadow-2xl"><button className="flex w-full items-center gap-2 rounded-md px-3 py-2.5 text-left text-sm text-danger hover:bg-danger/10" onClick={()=>{setMenuId(null);setRemovePicker(project)}}><Icon name="trash" className="h-4 w-4"/>{c.removeProjectTitle}</button></div>}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        })}
      </div>
    </div>

    <Modal closeLabel={c.close} open={!!versionChange} title={c.safeCopyTitle} onClose={()=>!busy&&setVersionChange(null)} footer={<><Button onClick={()=>setVersionChange(null)} disabled={busy}>{c.cancel}</Button><Button variant="primary" onClick={confirmVersionCopy} disabled={busy}>{c.copyContinue}</Button></>}>
      <p className="leading-7 text-muted">{c.safeCopyText}</p><div className="mt-4 rounded-lg border border-line bg-base p-3 text-sm"><div className="font-medium">{versionChange?.project.name}</div><div className="mt-1 text-muted">{versionChange?versionLabel(versionChange.project,versions,c):''} → {versionChange?versionLabel({...versionChange.project,godot_version:versionChange.version},versions,c):''}</div></div>
    </Modal>

    <Modal closeLabel={c.close} open={!!removePicker} title={c.removeProjectTitle} onClose={()=>setRemovePicker(null)} footer={<Button onClick={()=>setRemovePicker(null)}>{c.cancel}</Button>}>
      <p className="text-sm leading-6 text-muted">{c.removeProjectPrompt}</p>
      {removePicker&&<div className="mt-4 rounded-lg border border-line bg-base p-3"><div className="font-medium">{removePicker.name}</div><div className="mt-1 truncate text-xs text-muted">{removePicker.path}</div></div>}
      <div className="mt-4 grid gap-2">
        <button className="focus-ring rounded-lg border border-line bg-base p-4 text-left transition-colors hover:border-accent-dim hover:bg-raised" onClick={()=>removePicker&&openSecondRemoval(removePicker,'remove')}><div className="flex items-center gap-2 font-medium"><Icon name="x" className="h-4 w-4"/>{c.removeOnlyLibrary}</div><div className="mt-1 text-xs text-muted">{c.confirmRemoveText}</div></button>
        <button className="focus-ring rounded-lg border border-danger/30 bg-danger/5 p-4 text-left transition-colors hover:bg-danger/10" onClick={()=>removePicker&&openSecondRemoval(removePicker,'delete')}><div className="flex items-center gap-2 font-medium text-danger"><Icon name="trash" className="h-4 w-4"/>{c.deleteLocalProject}</div><div className="mt-1 text-xs text-muted">{c.confirmDeleteText}</div></button>
      </div>
    </Modal>

    <Modal closeLabel={c.close} open={!!removalChoice} title={removalChoice?.action==='delete'?c.confirmDeleteTitle:c.confirmRemoveTitle} onClose={()=>!busy&&setRemovalChoice(null)} footer={<><Button onClick={()=>setRemovalChoice(null)} disabled={busy}>{c.cancel}</Button><Button variant={removalChoice?.action==='delete'?'danger':'primary'} onClick={confirmRemoval} disabled={busy||(removalChoice?.action==='delete'&&typedFolder!==folderName(removalChoice.project.path))}>{removalChoice?.action==='delete'?c.confirmDeleteProject:c.removeOnlyLibrary}</Button></>}>
      {removalChoice?.action==='remove'
        ? <p className="leading-7 text-muted">{c.confirmRemoveText}</p>
        : <div><p className="leading-7 text-muted">{c.confirmDeleteText}</p><div className="mt-3 rounded-md border border-danger/25 bg-danger/5 px-3 py-2 font-mono text-sm text-danger">{folderName(removalChoice?.project.path ?? '')}</div><label className="mt-4 grid gap-1.5 text-sm"><span className="text-muted">{c.folderNameConfirmation}</span><Input value={typedFolder} onChange={event=>setTypedFolder(event.target.value)} autoFocus autoComplete="off" spellCheck={false}/></label></div>}
    </Modal>

    <Modal closeLabel={c.close} open={newOpen} title={c.newProjectTitle} onClose={()=>!busy&&setNewOpen(false)} footer={<><Button onClick={()=>setNewOpen(false)} disabled={busy}>{c.cancel}</Button><Button variant="primary" onClick={createProject} disabled={busy||!newName.trim()||!newLocation||!newVersion}>{c.createProject}</Button></>}>
      <div className="grid gap-4"><label className="grid gap-1.5 text-sm"><span className="text-muted">{c.projectName}</span><Input value={newName} onChange={event=>setNewName(event.target.value)} autoFocus/></label><label className="grid gap-1.5 text-sm"><span className="text-muted">{c.location}</span><div className="flex gap-2"><Input value={newLocation} onChange={event=>setNewLocation(event.target.value)} className="flex-1"/><Button icon="folder" onClick={async()=>{const path=await api.pickFolder();if(path)setNewLocation(path)}}>{c.choose}</Button></div></label><label className="grid gap-1.5 text-sm"><span className="text-muted">{c.engineVersion}</span><Select value={newVersion} onChange={event=>setNewVersion(event.target.value)}>{versions.map(version=><option key={version.tag} value={version.tag}>{installedLabel(version,c)}</option>)}</Select></label></div>
    </Modal>
  </div>
}
