/**************************************************************************/
/*  SettingsView.tsx                                                    */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import type { AppSettings, CredentialStoreStatus, DirectoryLayout, JinguMembershipProfile } from '../../types'
import { api } from '../../lib/api'
import type { JinguCopy } from '../copy'
import { LANGUAGE_OPTIONS, languageOptionValue } from '../copy'
import { Button, SectionCard, Select, Toggle } from '../components/UI'

export function SettingsView({ c, settings, membership, onChange, notify }: { c: JinguCopy; settings: AppSettings; membership: JinguMembershipProfile | null; onChange: (next: AppSettings) => Promise<void>; notify: (message: string, error?: boolean) => void }) {
  const [credential, setCredential] = useState<CredentialStoreStatus | null>(null)
  const [layout, setLayout] = useState<DirectoryLayout | null>(null)
  useEffect(() => {
    api.credentialStoreStatus().then(setCredential).catch(() => setCredential(null))
    api.getDirectoryLayout().then(setLayout).catch(() => setLayout(null))
  }, [])

  const languages = useMemo(() => LANGUAGE_OPTIONS, [])

  async function chooseAndUpdate(field: 'workspace_root' | 'default_project_location' | 'download_dir') {
    const path = await api.pickFolder()
    if (!path) return
    try {
      await onChange({ ...settings, [field]: path })
      setLayout(await api.getDirectoryLayout())
    } catch (e) { notify(String(e), true) }
  }

  const membershipTier=String(membership?.tier??'free').toLowerCase()
  const planName = membershipTier==='gold'?c.goldTier:membershipTier==='silver'?c.silverTier:membershipTier==='bronze'?c.bronzeTier:c.freeTier
  const paidPlan = membershipTier !== 'free'
  const lifetimePlan = Boolean(membership?.lifetime)
  const locale=languageOptionValue(settings.language)
  const planExpiry = lifetimePlan ? c.lifetimeActive : paidPlan && membership?.cycle_ends_at ? (()=>{try{return new Intl.DateTimeFormat(locale,{dateStyle:'medium'}).format(new Date(membership.cycle_ends_at))}catch{return membership.cycle_ends_at}})() : '—'

  return <div className="mx-auto h-full w-full max-w-[1500px] overflow-y-auto px-7 py-6">
    <h1 className="text-2xl font-semibold tracking-tight">{c.settings}</h1>
    <div className="mt-5 grid gap-4 xl:grid-cols-[1.1fr_.9fr]">
      <SectionCard className="p-6">
        <div className="text-lg font-semibold">{c.appearance}</div>
        <div className="mt-5 grid gap-4">
          <Row label={c.language}>
            <Select value={languageOptionValue(settings.language)} onChange={e => onChange({ ...settings, language: e.target.value }).catch(err => notify(String(err), true))}>
              {languages.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}
            </Select>
          </Row>
          <Row label={c.animations} hint={c.animationsHelp}><Toggle checked={!settings.reduce_motion} onChange={checked => onChange({ ...settings, reduce_motion: !checked }).catch(err => notify(String(err), true))} /></Row>
        </div>
      </SectionCard>

      <SectionCard className="p-6">
        <div className="text-lg font-semibold">{c.behavior}</div>
        <div className="mt-5 grid gap-4">
          <Row label={c.minimizeTray}><Toggle checked={settings.minimize_to_tray} onChange={checked => onChange({ ...settings, minimize_to_tray: checked }).catch(err => notify(String(err), true))} /></Row>
          <Row label={c.rememberGithubLogin} hint={c.rememberGithubLoginHelp}><Toggle checked={settings.remember_github_login} onChange={checked => onChange({ ...settings, remember_github_login: checked }).catch(err => notify(String(err), true))} /></Row>
          <Row label={c.closeAfterOpen}><Toggle checked={settings.close_on_project_open} onChange={checked => onChange({ ...settings, close_on_project_open: checked }).catch(err => notify(String(err), true))} /></Row>
          <div className="rounded-lg border border-line bg-base/60 p-4">
            <div className="text-sm font-semibold">{c.nativeSecureStorage}</div>
            <div className="mt-2 text-sm text-muted">{credential?.available ? `${c.secureBySystem}: ${credential.backend}` : c.secureStorageUnavailable}</div>
            {credential?.detail && <div className="mt-1 text-xs text-muted">{credential.detail}</div>}
          </div>
        </div>
      </SectionCard>

      <SectionCard className="p-6 xl:col-span-2">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="text-lg font-semibold">{c.plansTitle}</div>
            <p className="mt-2 text-sm text-muted">{c.planSettingsHelp}</p>
          </div>
          <div className="rounded-lg border border-accent/25 bg-accent/8 px-4 py-3 text-right">
            <div className="text-xs uppercase tracking-wide text-muted">{c.currentPlanLabel}</div>
            <div className="mt-1 text-lg font-semibold text-accent-bright">{planName}</div>
          </div>
        </div>
        <div className="mt-5 grid gap-4 md:grid-cols-3">
          <MiniPath title={c.plan} value={planName} />
          <MiniPath title={c.validity} value={planExpiry} />
          <MiniPath title={c.nextPeriod} value={lifetimePlan ? c.notNecessary : c.nextPeriodManual} />
        </div>
      </SectionCard>

      <SectionCard className="p-6 xl:col-span-2">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-lg font-semibold">{c.workspaceRoot}</div>
            <p className="mt-2 max-w-4xl text-sm leading-6 text-muted">{c.workspaceRootHelp}</p>
          </div>
          <Button icon="folder" onClick={() => chooseAndUpdate('workspace_root')}>{c.choose}</Button>
        </div>
        <div className="mt-4 rounded-lg border border-line bg-base/60 p-4">
          <div className="text-sm font-medium text-ink">{settings.workspace_root ?? layout?.workspace_root ?? '—'}</div>
          <div className="mt-2 text-xs leading-5 text-muted">{c.managedStorageSummary}</div>
        </div>
        <div className="mt-5 grid gap-4 lg:grid-cols-2">
          <PathCard label={c.defaultProjectFolder} value={layout?.projects_root ?? settings.default_project_location} onChoose={() => chooseAndUpdate('default_project_location')} chooseLabel={c.choose} />
          <PathCard label={c.engineVersionFolder} value={layout?.engine_versions_root ?? settings.download_dir} onChoose={() => chooseAndUpdate('download_dir')} chooseLabel={c.choose} />
        </div>
        {layout && <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          <MiniPath title="GitHub" value={layout.github_repositories_root} />
          <MiniPath title={c.stores} value={layout.stores_root} />
          <MiniPath title={c.versions} value={layout.versions_root} />
          <MiniPath title={c.hubStatePath} value={layout.app_state_root} />
          <MiniPath title={c.exportsPath} value={layout.github_exports_root} />
        </div>}
      </SectionCard>
    </div>
  </div>
}

function Row({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return <div className="flex items-center justify-between gap-4 rounded-lg border border-line bg-base/60 px-4 py-3">
    <div className="min-w-0">
      <div className="font-medium">{label}</div>
      {hint && <div className="mt-1 text-sm text-muted">{hint}</div>}
    </div>
    <div className="shrink-0">{children}</div>
  </div>
}

function PathCard({ label, value, onChoose, chooseLabel }: { label: string; value?: string | null; onChoose: () => void; chooseLabel: string }) {
  return <div className="rounded-lg border border-line bg-base/60 p-4">
    <div className="flex items-start justify-between gap-3">
      <div className="min-w-0">
        <div className="text-sm font-semibold">{label}</div>
        <div className="mt-2 break-all text-sm text-muted">{value || '—'}</div>
      </div>
      <Button icon="folder" onClick={onChoose}>{chooseLabel}</Button>
    </div>
  </div>
}

function MiniPath({ title, value }: { title: string; value: string }) {
  return <div className="rounded-lg border border-line bg-base/60 p-4">
    <div className="text-xs font-semibold uppercase tracking-wide text-muted">{title}</div>
    <div className="mt-2 break-all text-sm text-ink">{value}</div>
  </div>
}
