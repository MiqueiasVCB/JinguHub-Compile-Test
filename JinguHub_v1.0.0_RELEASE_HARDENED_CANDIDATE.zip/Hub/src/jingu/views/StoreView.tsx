/**************************************************************************/
/*  StoreView.tsx                                                       */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { useLayoutEffect, useMemo, useRef, useState } from 'react'
import { openUrl } from '@tauri-apps/plugin-opener'
import { api } from '../../lib/api'
import type { JinguCopy } from '../copy'
import { Button, IconButton, SectionCard } from '../components/UI'
import { Icon } from '../components/Icon'

type StoreId='jingu'|'godot'|'shaders'|'itchio'
type ExternalStoreId=Exclude<StoreId,'jingu'>
type Props={c:JinguCopy;notify:(message:string,error?:boolean)=>void}
type StoreDescriptor={id:StoreId;title:string;subtitle:string;description:string;url:string|null;ready:boolean}

export function StoreView({c,notify}:Props){
  const stores=useMemo<StoreDescriptor[]>(()=>[
    {id:'jingu',title:c.storeJingu,subtitle:c.storeJinguSubtitle,description:c.storeJinguDescription,url:null,ready:false},
    {id:'godot',title:c.storeGodot,subtitle:c.storeGodotSubtitle,description:c.storeGodotDescription,url:'https://godotengine.org/asset-library/asset',ready:true},
    {id:'shaders',title:c.storeShaders,subtitle:c.storeShadersSubtitle,description:c.storeShadersDescription,url:'https://godotshaders.com',ready:true},
    {id:'itchio',title:c.storeItch,subtitle:c.storeItchSubtitle,description:c.storeItchDescription,url:'https://itch.io/game-assets',ready:true},
  ],[c])
  const [selectedId,setSelectedId]=useState<StoreId|null>(null)
  const selected=stores.find(store=>store.id===selectedId)??null

  if(!selected){
    return <div className="mx-auto h-full w-full max-w-[1500px] overflow-y-auto px-7 py-6">
      <div><h1 className="text-2xl font-semibold tracking-tight">{c.storesTitle}</h1></div>
      <div className="mt-5 grid gap-3">{stores.map(store=><StoreCard key={store.id} store={store} c={c} onOpen={()=>setSelectedId(store.id)}/>)}</div>
    </div>
  }

  if(selected.id==='jingu'){
    return <div className="mx-auto h-full w-full max-w-[1500px] overflow-y-auto px-7 py-6">
      <div className="mb-4"><Button icon="arrowLeft" onClick={()=>setSelectedId(null)}>{c.backToStores}</Button></div>
      <SectionCard className="flex min-h-[560px] flex-col items-center justify-center p-10 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-accent/12 text-accent-bright"><Icon name="store" className="h-10 w-10"/></div>
        <div className="mt-5 text-2xl font-semibold">{selected.title}</div>
        <p className="mt-3 max-w-2xl leading-7 text-muted">{selected.description}</p>
        <div className="mt-5 rounded-full border border-amber-400/30 bg-amber-400/10 px-4 py-2 text-sm font-semibold text-amber-300">{c.storeSoon}</div>
      </SectionCard>
    </div>
  }

  return <IntegratedStoreBrowser store={selected as StoreDescriptor & {id:ExternalStoreId;url:string}} c={c} notify={notify} onBack={()=>setSelectedId(null)}/>
}

function IntegratedStoreBrowser({store,c,notify,onBack}:{store:StoreDescriptor & {id:ExternalStoreId;url:string};c:JinguCopy;notify:(message:string,error?:boolean)=>void;onBack:()=>void}){
  const hostRef=useRef<HTMLDivElement|null>(null)

  useLayoutEffect(()=>{
    const host=hostRef.current
    if(!host)return
    let disposed=false
    let last=''
    let raf=0

    const bounds=()=>{
      const rect=host.getBoundingClientRect()
      return {x:rect.left,y:rect.top,width:Math.max(1,rect.width),height:Math.max(1,rect.height)}
    }
    const sync=()=>{
      if(disposed)return
      cancelAnimationFrame(raf)
      raf=requestAnimationFrame(()=>{
        const next=bounds()
        const signature=`${Math.round(next.x)}:${Math.round(next.y)}:${Math.round(next.width)}:${Math.round(next.height)}`
        if(signature===last)return
        last=signature
        void api.storeBrowserSetBounds(store.id,next).catch(()=>{})
      })
    }

    const initial=bounds()
    api.storeBrowserShow(store.id,initial).catch(error=>{if(!disposed)notify(String(error),true)})
    const observer=new ResizeObserver(sync)
    observer.observe(host)
    window.addEventListener('resize',sync)
    window.addEventListener('scroll',sync,true)

    return()=>{
      disposed=true
      cancelAnimationFrame(raf)
      observer.disconnect()
      window.removeEventListener('resize',sync)
      window.removeEventListener('scroll',sync,true)
      void api.storeBrowserHide().catch(()=>{})
    }
  },[notify,store.id])

  return <div className="mx-auto flex h-full w-full max-w-[1500px] flex-col px-7 py-6">
    <SectionCard className="flex min-h-0 flex-1 flex-col overflow-hidden">
      <div className="flex min-h-[68px] shrink-0 flex-wrap items-center justify-between gap-3 border-b border-line px-4 py-3">
        <div className="flex min-w-0 items-center gap-3">
          <Button icon="arrowLeft" onClick={onBack}>{c.backToStores}</Button>
          <div className="hidden h-8 w-px bg-line sm:block"/>
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent/12 text-accent-bright"><Icon name={store.id==='itchio'?'globe':'store'} className="h-5 w-5"/></div>
            <div className="min-w-0"><div className="truncate font-semibold">{store.title}</div><div className="hidden truncate text-xs text-muted md:block">{store.subtitle}</div></div>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <IconButton icon="arrowLeft" label={c.browserBack} onClick={()=>api.storeBrowserBack(store.id).catch(e=>notify(String(e),true))}/>
          <IconButton icon="home" label={c.browserHome} onClick={()=>api.storeBrowserHome(store.id).catch(e=>notify(String(e),true))}/>
          <IconButton icon="refresh" label={c.refresh} onClick={()=>api.storeBrowserReload(store.id).catch(e=>notify(String(e),true))}/>
          <IconButton icon="external" label={c.openExternal} onClick={()=>openUrl(store.url)}/>
        </div>
      </div>
      <div ref={hostRef} className="relative min-h-[420px] flex-1 bg-white">
        <div className="absolute inset-0 flex items-center justify-center text-sm text-neutral-500">{c.loading}</div>
      </div>
    </SectionCard>
  </div>
}

function StoreCard({store,c,onOpen}:{store:StoreDescriptor;c:JinguCopy;onOpen:()=>void}){
  const future=!store.ready
  return <button onClick={onOpen} className={`focus-ring w-full rounded-xl border bg-surface p-5 text-start transition-all hover:-translate-y-px hover:bg-raised/50 ${future?'border-amber-400/25 hover:border-amber-300/45':'border-line hover:border-accent/35'}`}>
    <div className="flex items-center justify-between gap-5">
      <div className="flex min-w-0 items-start gap-4">
        <div className={`mt-0.5 flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${future?'bg-amber-400/10 text-amber-300':'bg-accent/12 text-accent-bright'}`}><Icon name={store.id==='itchio'?'globe':'store'} className="h-6 w-6"/></div>
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2"><div className="font-semibold">{store.title}</div><span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${future?'bg-amber-400/10 text-amber-300':'bg-accent/12 text-accent-bright'}`}>{future?c.storeSoon:c.storeReady}</span></div>
          <div className="mt-1 text-sm text-muted">{store.subtitle}</div>
          <p className="mt-3 max-w-4xl text-sm leading-6 text-muted">{store.description}</p>
        </div>
      </div>
      <Icon name="chevronRight" className="h-5 w-5 shrink-0 text-muted"/>
    </div>
  </button>
}
