/**************************************************************************/
/*  VersionsView.tsx                                                    */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { useEffect, useMemo, useState } from 'react'
import { listen, type UnlistenFn } from '@tauri-apps/api/event'
import type { GodotRelease, HubReleaseCheck, HubRuntimeInfo, InstalledGodotVersion } from '../../types'
import { api } from '../../lib/api'
import type { JinguCopy } from '../copy'
import { BusyNotice, Button, IconButton, Input, Modal, SectionCard } from '../components/UI'
import { Icon } from '../components/Icon'

type HubUpdateState = 'idle'|'checking'|'synced'|'available'|'error'
type Props = { c:JinguCopy; installed:InstalledGodotVersion[]; available:GodotRelease[]; onRefresh:()=>Promise<void>; catalogRefreshing:boolean; notify:(m:string,e?:boolean,title?:string)=>void; hubRuntime:HubRuntimeInfo|null; hubRelease:HubReleaseCheck|null; hubState:HubUpdateState; onCheckHubUpdate:()=>Promise<void>; onOpenHubUpdate:()=>Promise<void> }
type EngineDownload = { state:'queued'|'downloading'|'paused'; progress:number|null }
type DownloadProgressPayload = { tag:string; downloaded:number; total:number }
type DownloadErrorPayload = { tag:string; message:string }
type VersionDisplayRow = {kind:'installed';tag:string;installed:InstalledGodotVersion}|{kind:'available';tag:string;release:GodotRelease}

function compareVersionTagsNewestFirst(left:string,right:string){
  const parse=(value:string)=>{const match=value.replace(/^v/i,'').match(/^(\d+)\.(\d+)\.(\d+)/);return match?[Number(match[1]),Number(match[2]),Number(match[3])]:null}
  const a=parse(left),b=parse(right)
  if(a&&b){for(let index=0;index<3;index+=1){if(a[index]!==b[index])return b[index]-a[index]}}
  return right.localeCompare(left,undefined,{numeric:true,sensitivity:'base'})
}

function formatBytes(bytes:number){
  if(!Number.isFinite(bytes)||bytes<=0)return '—'
  const units=['B','KB','MB','GB']
  let value=bytes,index=0
  while(value>=1024&&index<units.length-1){value/=1024;index+=1}
  return `${value>=10||index===0?value.toFixed(0):value.toFixed(1)} ${units[index]}`
}

export function VersionsView({c, installed, available, onRefresh, catalogRefreshing, notify, hubRuntime, hubRelease, hubState, onCheckHubUpdate, onOpenHubUpdate}:Props){
  const [query,setQuery]=useState('')
  const [downloads,setDownloads]=useState<Record<string,EngineDownload>>({})
  const [importOpen,setImportOpen]=useState(false)
  const [pendingAction,setPendingAction]=useState<string|null>(null)
  const versionRows=useMemo<VersionDisplayRow[]>(()=>{
    const installedByTag=new Map(installed.map(version=>[version.tag,version]))
    const seen=new Set<string>()
    const merged:VersionDisplayRow[]=[]
    for(const release of available){
      seen.add(release.tag)
      const local=installedByTag.get(release.tag)
      merged.push(local?{kind:'installed',tag:release.tag,installed:local}:{kind:'available',tag:release.tag,release})
    }
    for(const local of installed){if(!seen.has(local.tag))merged.push({kind:'installed',tag:local.tag,installed:local})}
    const needle=query.trim().toLowerCase()
    return merged
      .filter(row=>{
        if(!needle)return true
        if(row.tag.toLowerCase().includes(needle))return true
        return row.kind==='installed'&&(row.installed.custom_name??row.installed.version??'').toLowerCase().includes(needle)
      })
      .sort((a,b)=>compareVersionTagsNewestFirst(a.tag,b.tag))
  },[available,installed,query])

  useEffect(()=>{
    let disposed=false
    const unlisteners:UnlistenFn[]=[]
    const terminal=new Set<string>()
    const removeDownload=(tag:string)=>setDownloads(current=>{
      if(!(tag in current))return current
      const next={...current};delete next[tag];return next
    })
    const subscribe=async()=>{
      const handlers=await Promise.all([
        listen<DownloadProgressPayload>('godot-download-progress',({payload})=>{
          const progress=payload.total>0?Math.min(100,Math.round(payload.downloaded/payload.total*100)):null
          setDownloads(current=>({...current,[payload.tag]:{state:'downloading',progress}}))
        }),
        listen<string>('godot-download-started',({payload})=>setDownloads(current=>({...current,[payload]:{state:'downloading',progress:current[payload]?.progress??null}}))),
        listen<string>('godot-download-queued',({payload})=>setDownloads(current=>({...current,[payload]:{state:'queued',progress:current[payload]?.progress??null}}))),
        listen<string>('godot-download-paused',({payload})=>setDownloads(current=>({...current,[payload]:{state:'paused',progress:current[payload]?.progress??null}}))),
        listen<string>('godot-download-canceled',({payload})=>{terminal.add(payload);removeDownload(payload)}),
        listen<string>('godot-download-complete',({payload})=>{
          terminal.add(payload)
          removeDownload(payload)
          void onRefresh().catch(e=>notify(String(e),true))
        }),
        listen<DownloadErrorPayload>('godot-download-error',({payload})=>{
          terminal.add(payload.tag)
          removeDownload(payload.tag)
          void payload
        }),
      ])
      if(disposed){handlers.forEach(unlisten=>unlisten());return}
      unlisteners.push(...handlers)
      const active=await api.listGodotDownloads()
      if(disposed)return
      setDownloads(current=>{
        const next={...current}
        for(const item of active){
          if(!terminal.has(item.tag)&&!(item.tag in next))next[item.tag]={state:item.state,progress:null}
        }
        return next
      })
    }
    void subscribe().catch(e=>notify(`${c.error}: ${String(e)}`,true))
    return()=>{disposed=true;unlisteners.splice(0).forEach(unlisten=>unlisten())}
  },[c.error,c.success,notify,onRefresh])

  function preferredAsset(release:GodotRelease){
    return release.assets.find(a=>!a.is_mono) ?? release.assets[0]
  }

  function releaseDownloadKey(release:GodotRelease){
    const asset=preferredAsset(release)
    return asset?.is_mono?`${release.tag}-mono`:release.tag
  }

  async function installRelease(release:GodotRelease){
    const asset=preferredAsset(release)
    if(!asset){notify(c.noCompatiblePackage,true);return}
    const key=releaseDownloadKey(release)
    setDownloads(current=>({...current,[key]:{state:'queued',progress:null}}))
    try{ await api.downloadGodotVersion(release.tag,asset.name,asset.download_url,asset.expected_sha256,asset.size,asset.entrypoint,release.restricted) }
    catch(e){
      setDownloads(current=>{const next={...current};delete next[key];return next})
      notify(String(e),true)
    }
  }

  async function pauseEngineDownload(tag:string){
    try{await api.pauseGodotDownload(tag)}catch(e){notify(String(e),true)}
  }

  async function resumeEngineDownload(tag:string){
    try{await api.resumeGodotDownload(tag)}catch(e){notify(String(e),true)}
  }

  async function cancelEngineDownload(tag:string){
    try{await api.cancelGodotDownload(tag)}catch(e){notify(String(e),true)}
  }

  async function importBy(kind:'zip'|'folder'|'executable'){
    setPendingAction(c.workingImportVersion)
    try{
      let target:string | null=null
      if(kind==='zip') target=await api.pickEngineArchiveFile()
      else if(kind==='folder') target=await api.pickFolder()
      else target=await api.pickEngineExecutableFile()
      if(!target)return
      await api.importVersionPath(target)
      setImportOpen(false)
      await onRefresh()
      notify(c.importVersionSuccess)
    }catch(e){notify(String(e),true)}
    finally{setPendingAction(null)}
  }

  const installedHubVersion=hubRuntime?.version??'—'
  const hubUpdateVersion=hubRelease?.latest_version??null

  return <div className="mx-auto h-full w-full max-w-[1500px] overflow-y-auto px-7 py-6">
    <div><h1 className="text-2xl font-semibold tracking-tight">{c.versions}</h1></div>
    <div className="mt-5 grid gap-5">
      {pendingAction && <BusyNotice label={pendingAction}/>}
      <SectionCard className="p-5">
        <div className="flex min-w-0 items-center gap-4">
          <div className="min-w-0 flex-1"><div className="text-xs font-semibold uppercase tracking-wide text-muted">{c.hub}</div><div className="mt-2 flex flex-wrap items-center gap-2"><span className="text-base font-semibold text-ink">Jingu Hub</span><span className="inline-flex rounded bg-accent/12 px-2 py-1 text-xs font-semibold text-accent-bright">{c.stable} · v{installedHubVersion}</span></div>
            {hubState==='available'&&hubUpdateVersion&&<div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-accent-bright"><span>{c.hubUpdateAvailable}</span>{hubRelease?.restricted?<><span className="inline-flex rounded border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-bold text-amber-200">PRIVATE</span><span className="inline-flex rounded border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-bold text-amber-200">TEST</span><span>v{hubUpdateVersion}</span></>:<span>{c.stable} · v{hubUpdateVersion}</span>}</div>}
            {hubState==='synced'&&<div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-muted"><span>{c.hubUpdateChannel}</span>{hubUpdateVersion&&((hubRelease?.restricted)?<><span className="inline-flex rounded border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-bold text-amber-200">PRIVATE</span><span className="inline-flex rounded border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-bold text-amber-200">TEST</span><span>v{hubUpdateVersion}</span></>:<span>{c.stable} · v{hubUpdateVersion}</span>)}</div>}
            {hubState==='idle'&&<p className="mt-1 text-sm text-muted">{c.hubUpdateWaiting}</p>}
            {hubState==='error'&&<p className="mt-1 text-sm text-red-300">{c.hubUpdateError}</p>}
          </div>
          <div className="flex shrink-0 items-center gap-2">
            {hubState==='available'&&<Button icon="download" variant="primary" onClick={()=>void onOpenHubUpdate()}>{c.installUpdate}</Button>}
            {hubState!=='available'&&<Button icon="refresh" disabled={hubState==='checking'} onClick={()=>void onCheckHubUpdate()}>{hubState==='checking'?c.checking:c.checkUpdates}</Button>}
          </div>
        </div>
      </SectionCard>


      <div className="text-xs font-semibold uppercase tracking-wide text-muted">{c.engine}</div>
      <SectionCard className="p-3">
        <div className="flex min-w-0 flex-wrap items-center gap-2"><div className="relative min-w-0 flex-1"><Icon name="search" className="absolute left-3 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-muted"/><Input value={query} onChange={e=>setQuery(e.target.value)} placeholder={c.searchVersions} className="w-full pl-10"/></div><Button className="shrink-0" icon="folder" onClick={()=>setImportOpen(true)}>{c.import}</Button><Button className="shrink-0" icon="refresh" disabled={catalogRefreshing} onClick={()=>onRefresh().catch(e=>notify(String(e),true))}>{catalogRefreshing?c.refreshingVersions:c.refresh}</Button></div>
        <div className="mt-3 text-xs text-muted">{c.importVersionSupported}</div>
      </SectionCard>
      {versionRows.length>0&&<div className="mx-auto w-full max-w-[1040px]">
        <SectionCard className="overflow-hidden p-0">
          {versionRows.map((row,index)=>{
            const divider=index>0?' border-t border-line':''
            if(row.kind==='installed'){
              const v=row.installed
              return <div key={`i-${row.tag}`} className={`flex min-w-0 flex-col gap-3 px-4 py-3.5 sm:flex-row sm:items-center${divider}`}><div className="flex min-w-0 flex-1 items-center gap-3"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-accent/20 bg-accent/10 text-accent-bright"><Icon name="check" className="h-[18px] w-[18px]"/></div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><div className="font-semibold">Jingu {v.custom_name || v.version || row.tag.replace(/^v/,'')}</div><span className="inline-flex rounded bg-accent/12 px-2 py-1 text-xs text-accent-bright">{c.installed}</span>{v.restricted&&<><span className="inline-flex rounded border border-amber-500/30 bg-amber-500/10 px-2 py-1 text-[10px] font-bold text-amber-200">PRIVATE</span><span className="inline-flex rounded border border-amber-500/30 bg-amber-500/10 px-2 py-1 text-[10px] font-bold text-amber-200">TEST</span></>}</div><div className="mt-1 truncate text-xs text-muted">{v.executable_path}</div></div></div><div className="flex shrink-0 items-center gap-2 self-end sm:self-auto"><IconButton icon="play" label={c.open} onClick={()=>api.openGodotVersion(v.tag).catch(e=>notify(String(e),true))}/><IconButton icon="trash" label={v.managed_install===false?c.removeList:c.delete} onClick={async()=>{setPendingAction(c.workingDeleteVersion);try{await api.deleteGodotVersion(v.tag);await onRefresh();notify(c.success)}catch(e){notify(String(e),true)}finally{setPendingAction(null)}}}/></div></div>
            }
            const r=row.release
            const asset=preferredAsset(r)
            const downloadKey=releaseDownloadKey(r)
            const download=downloads[downloadKey]
            return <div key={row.tag} className={`flex min-w-0 flex-col gap-3 px-4 py-3.5 sm:flex-row sm:items-center${divider}`}><div className="flex min-w-0 flex-1 items-center gap-3"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-line bg-base text-muted"><Icon name="download" className="h-[18px] w-[18px]"/></div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><div className="font-semibold">Jingu {r.tag.replace(/^v/,'')}</div><span className="inline-flex rounded bg-base px-2 py-1 text-xs text-muted">{c.available}</span>{r.restricted&&<><span className="inline-flex rounded border border-amber-500/30 bg-amber-500/10 px-2 py-1 text-[10px] font-bold text-amber-200">PRIVATE</span><span className="inline-flex rounded border border-amber-500/30 bg-amber-500/10 px-2 py-1 text-[10px] font-bold text-amber-200">TEST</span></>}</div>{download?<div className="mt-2 max-w-[430px]"><div className="flex items-center gap-2 text-xs text-muted"><span>{download.state==='queued'?c.queued:download.state==='paused'?c.paused:c.downloading}</span>{download.progress!==null&&<span>{download.progress}%</span>}</div><div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-base"><div className="h-full bg-accent transition-[width]" style={{width:`${download.progress??0}%`}}/></div></div>:<div className="mt-1 truncate text-xs text-muted">{asset?`${asset.name} · ${formatBytes(asset.size)}`:c.available}</div>}</div></div>{download?<div className="flex shrink-0 items-center gap-2 self-end sm:self-auto">{download.state==='downloading'?<IconButton icon="pause" label={c.pauseDownload} onClick={()=>pauseEngineDownload(downloadKey)}/>:download.state==='paused'?<IconButton icon="play" label={c.resumeDownload} onClick={()=>resumeEngineDownload(downloadKey)}/>:null}<IconButton icon="x" label={c.cancelDownload} onClick={()=>cancelEngineDownload(downloadKey)}/></div>:<Button className="shrink-0 self-end sm:self-auto" icon="download" variant="primary" onClick={()=>installRelease(r)}>{c.install}</Button>}</div>
          })}
        </SectionCard>
      </div>}
      {!versionRows.length && <div className="mx-auto max-w-[1040px] py-12 text-center text-muted">{c.noInstalledEngines}</div>}
    </div>

    <Modal closeLabel={c.close} open={importOpen} title={c.importVersionTitle} onClose={()=>setImportOpen(false)} footer={<><Button onClick={()=>setImportOpen(false)}>{c.cancel}</Button></>} width="max-w-2xl">
      <p className="text-sm leading-6 text-muted">{c.importVersionHelp}</p>
      <div className="mt-5 grid gap-3">
        <ImportCard title={c.importVersionZip} description={c.importZipDescription} action={()=>importBy('zip')}/>
        <ImportCard title={c.importVersionFolder} description={c.importFolderDescription} action={()=>importBy('folder')}/>
        <ImportCard title={c.importVersionExecutable} description={c.importExecutableDescription} action={()=>importBy('executable')}/>
      </div>
      <div className="mt-4 text-xs text-muted">{c.importVersionSupported}</div>
    </Modal>
  </div>
}

function ImportCard({title,description,action}:{title:string;description:string;action:()=>void}){
  return <button onClick={action} className="focus-ring rounded-lg border border-line bg-base px-4 py-4 text-left transition-colors hover:border-accent/35 hover:bg-raised/40">
    <div className="font-medium">{title}</div>
    <div className="mt-1 text-sm leading-6 text-muted">{description}</div>
  </button>
}
