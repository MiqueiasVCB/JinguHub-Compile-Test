/**************************************************************************/
/*  api.ts                                                              */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import { projectsApi } from '../api/projects'
import { versionsApi } from '../api/versions'
import { gitApi } from '../api/git'
import { settingsApi } from '../api/settings'
import { githubApi } from '../api/github'
import { systemApi } from '../api/system'
import { communityApi } from '../api/community'
import { freelancersApi } from '../api/freelancers'

export const api={
  listProjects:projectsApi.list,createProject:projectsApi.create,importProject:projectsApi.import,removeProject:projectsApi.remove,updateProject:projectsApi.update,openProject:projectsApi.open,openProjectFolder:projectsApi.openFolder,getProjectIcon:projectsApi.getIcon,pickFolder:projectsApi.pickFolder,pickFile:projectsApi.pickFile,setProjectEngineVersion:projectsApi.setEngineVersion,
  hubBuildProfile:versionsApi.hubBuildProfile,hubRuntimeInfo:versionsApi.hubRuntimeInfo,checkHubRelease:versionsApi.checkHubRelease,fetchAvailableGodotVersions:versionsApi.fetchAvailable,checkLatestEngineRelease:versionsApi.checkLatestEngineRelease,downloadGodotVersion:versionsApi.download,listGodotDownloads:versionsApi.listDownloads,pauseGodotDownload:versionsApi.pauseDownload,resumeGodotDownload:versionsApi.resumeDownload,cancelGodotDownload:versionsApi.cancelDownload,listInstalledGodotVersions:versionsApi.listInstalled,deleteGodotVersion:versionsApi.delete,openGodotVersion:versionsApi.open,importVersionZip:versionsApi.importZip,importVersionPath:versionsApi.importPath,pickEngineArchiveFile:versionsApi.pickArchiveFile,pickEngineExecutableFile:versionsApi.pickExecutableFile,
  cloneRepo:gitApi.clone,getGitStatus:gitApi.status,gitPull:gitApi.pull,gitFetch:gitApi.fetch,gitPush:gitApi.push,gitRemoteUrl:gitApi.remoteUrl,gitListBranches:gitApi.listBranches,gitSwitchBranch:gitApi.switchBranch,gitCreateBranch:gitApi.createBranch,gitChangedFiles:gitApi.changedFiles,gitInit:gitApi.init,gitStageAll:gitApi.stageAll,gitUnstageAll:gitApi.unstageAll,gitStageFile:gitApi.stageFile,gitUnstageFile:gitApi.unstageFile,gitCommit:gitApi.commit,gitSetRemote:gitApi.setRemote,gitRemoveRemote:gitApi.removeRemote,
  githubSession:githubApi.session,githubBeginDeviceFlow:githubApi.beginDeviceFlow,githubPollDeviceFlow:githubApi.pollDeviceFlow,githubSignOut:githubApi.signOut,githubInstallationStatus:githubApi.installationStatus,githubPrivateAccess:githubApi.privateAccess,githubCreateRepository:githubApi.createRepository,githubListRepositories:githubApi.listRepositories,githubRemoteStatus:githubApi.remoteStatus,
  communityCatalog:communityApi.catalog,communitySubmitRequest:communityApi.submitRequest,communityMyRequests:communityApi.myRequests,
  membershipProfile:freelancersApi.membershipProfile,membershipCreditsOptIn:freelancersApi.creditsOptIn,paymentConfig:freelancersApi.paymentConfig,paymentPricePreview:freelancersApi.paymentPricePreview,paymentCheckoutStart:freelancersApi.paymentCheckoutStart,supportersList:freelancersApi.supporters,freelancersEntitlements:freelancersApi.entitlements,freelancersAccountStatus:freelancersApi.accountStatus,freelancersFetch:freelancersApi.fetch,freelancersCreate:freelancersApi.create,freelancersClose:freelancersApi.close,freelancersReactionState:freelancersApi.reactionState,freelancersReactionStates:freelancersApi.reactionStates,freelancersToggleLike:freelancersApi.toggleLike,freelancersReport:freelancersApi.report,freelancersOpenContact:freelancersApi.openContact,
  getSettings:settingsApi.get,updateSettings:settingsApi.update,credentialStoreStatus:settingsApi.credentialStoreStatus,
  getDirectoryLayout:systemApi.getDirectoryLayout,openHttpsUrl:systemApi.openHttpsUrl,storeBrowserShow:systemApi.storeBrowserShow,storeBrowserSetBounds:systemApi.storeBrowserSetBounds,storeBrowserHide:systemApi.storeBrowserHide,storeBrowserHome:systemApi.storeBrowserHome,storeBrowserBack:systemApi.storeBrowserBack,storeBrowserReload:systemApi.storeBrowserReload,paymentBrowserShow:systemApi.paymentBrowserShow,paymentBrowserSetBounds:systemApi.paymentBrowserSetBounds,paymentBrowserHide:systemApi.paymentBrowserHide,paymentBrowserReload:systemApi.paymentBrowserReload,
}
