/**************************************************************************/
/*  types.ts                                                            */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Portions derived from GodotHub, Copyright (c) 2026 Rayyan Aziz.         */
/* See THIRD_PARTY_NOTICES.md for upstream attribution.                   */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
export interface HubBuildProfile {
  version: string
  channel: 'stable' | 'beta' | 'experimental' | 'dev' | string
  flavor: 'unified' | string
  product_name: string
  adaptive_private_access: boolean
}

export interface GitHubPrivateAccess {
  engine_test_releases: boolean
  hub_test_releases: boolean
  any: boolean
}



export interface CredentialStoreStatus {
  backend: string
  available: boolean
  detail: string | null
}

export interface HubReleaseCheck {
  current_version: string
  latest_version: string | null
  update_available: boolean
  release_url: string | null
  source: string
  test_channel: boolean
  restricted: boolean
  uses_user_github_session: boolean
}

export interface HubRuntimeInfo {
  version: string
  channel: 'stable' | string
  portable: boolean
}

export interface InstalledGodotVersion {
  tag: string
  version: string
  /** Underlying Godot-compatible runtime version; separate from the Jingu release version. */
  runtime_version?: string | null
  executable_path: string
  is_mono: boolean
  installed_at: string
  custom_name?: string | null
  install_root?: string | null
  supports_console?: boolean
  /** true when Hub owns the installation files; false for externally registered builds. */
  managed_install?: boolean | null
  /** Installed from an authorized private TEST channel. Hidden when capability is absent. */
  restricted?: boolean
}

export interface GodotReleaseAsset {
  name: string
  download_url: string
  size: number
  is_mono: boolean
  expected_sha256: string
  entrypoint: string
}

export interface GodotRelease {
  tag: string
  assets: GodotReleaseAsset[]
  channel: 'stable' | 'test' | string
  restricted: boolean
}

export interface Project {
  id: string
  name: string
  path: string
  godot_version: string
  jingu_version: string
  created_at: string
  last_opened: string | null
  category: string | null
  pinned: boolean
  sort_order: number
  launch_arguments: string
  tags: string[]
}

export interface ProjectUpdate {
  name?: string
  godot_version?: string
  category?: string
  pinned?: boolean
  launch_arguments?: string
  tags?: string[]
}

export interface ProjectVersionChangeResult {
  project: Project
  copied: boolean
  original_path: string
  new_path: string
}

export interface GitStatus {
  branch: string | null
  has_uncommitted: boolean
  is_repo: boolean
}

export interface GitBranchInfo {
  name: string
  is_current: boolean
}

export interface GitChangedFile {
  path: string
  /** Two-character porcelain status (index + worktree). */
  status: string
  staged: boolean
  unstaged: boolean
}

/** Full IPC settings contract. Some fields are intentionally not surfaced by
 * the current Settings screen yet, but they are active runtime behavior and
 * therefore remain strongly typed instead of becoming invisible state. */
export interface AppSettings {
  workspace_root: string | null
  download_dir: string | null
  default_project_location: string | null
  download_concurrency: number
  reduce_motion: boolean
  launch_with_console: boolean
  close_on_project_open: boolean
  minimize_to_tray: boolean
  remember_github_login: boolean
  reopen_after_godot_closes: boolean
  tray_recent_projects_count: number
  language: string
  use_os_decorations: boolean
  dismissed_project_paths: string[]
  directory_naming_convention: string
}

export interface GitHubUser {
  id: number
  login: string
  name: string | null
  avatar_url: string
  html_url: string
}

export interface DeviceFlowStart {
  device_code: string
  user_code: string
  verification_uri: string
  expires_in: number
  interval: number
}

export interface DevicePollResult {
  status: 'pending' | 'slow_down' | 'expired' | 'denied' | 'error' | 'authorized'
  message: string | null
  user: GitHubUser | null
  interval: number | null
}

export interface GitHubInstallationStatus {
  installed: boolean
  installation_id: number | null
  account_login: string | null
  repository_selection: string | null
  administration: string | null
  contents: string | null
  can_create_repositories: boolean
  can_use_git: boolean
  install_url: string
  personal_installed: boolean
  personal_repository_selection: string | null
  organization_installed: boolean
  organization_repository_selection: string | null
  organization_account_login: string | null
}

export interface GitHubRepository {
  id: number
  name: string
  full_name: string
  private: boolean
  html_url: string
  clone_url: string
  default_branch: string
}

export type GitHubRemoteState = 'reachable' | 'read_only' | 'missing' | 'inaccessible' | 'missing_or_inaccessible' | 'external'

export interface GitHubRemoteStatus {
  state: GitHubRemoteState
  owner: string | null
  repository: string | null
  html_url: string | null
  can_push: boolean
  message: string | null
}


export interface DirectoryLayout {
  workspace_root: string
  projects_root: string
  github_root: string
  github_repositories_root: string
  github_exports_root: string
  stores_root: string
  store_jingu_root: string
  store_godot_root: string
  store_shaders_root: string
  store_itchio_root: string
  versions_root: string
  hub_versions_root: string
  engine_versions_root: string
  app_state_root: string
}

export interface CommunityLink {
  label: string
  kind: string
  url: string
}

export interface CommunityEntry {
  id: string
  created_at?: string
  name: string
  country: string
  region: string
  description: string
  tags: string[]
  links: CommunityLink[]
}

export interface CommunityRequestInput {
  name: string
  country: string
  region: string
  description: string
  tags: string[]
  links: CommunityLink[]
}

export interface CommunityRequestResult { display_id: string }

export interface CommunityRequestRow {
  display_id: string
  author: string
  avatar_url: string
  created_at: string
  html_url: string
  proposed_id: string
  name: string
  region: string
  country: string
  description: string
  tags: string[]
  links: CommunityLink[]
  status: 'pending'|'approved'|'rejected'|string
}

export interface CommunityCatalogResult {
  source: 'github'|'cache'|'bundled'|string
  stale: boolean
  updated_at: string
  communities: CommunityEntry[]
}

export type FreelancerKind='recruiting'|'seeking'
export type FreelancerCompensation='paid'|'volunteer'|'negotiable'
export type FreelancerArea='programming'|'art-2d'|'art-3d'|'game-design'|'ui-ux'|'animation'|'music'|'sound'|'qa'|'writing'|'production'|'marketing'|'community'|'other'

export interface FreelancerAuthor {
  id: number
  login: string
  avatar_url: string
  html_url: string
}

export type FreelancerLinkKind='website'|'portfolio'|'artstation'|'behance'|'itchio'|'github'|'linkedin'|'email'|'discord'|'whatsapp'|'telegram'|'instagram'|'other'

export interface FreelancerLink {
  kind: FreelancerLinkKind|string
  label: string
  value: string
}

export interface FreelancerPost {
  number: number
  display_id: string
  channel: 'public'|'test'|string
  title: string
  summary: string
  description: string
  kind: FreelancerKind
  compensation: FreelancerCompensation
  areas: FreelancerArea[]
  country_code: string
  country: string
  region_code: string
  region: string
  portfolio_links: FreelancerLink[]
  contact_links: FreelancerLink[]
  image_url: string|null
  author: FreelancerAuthor
  created_at: string
  updated_at: string
  html_url: string
  likes: number
  state: string
  membership_tier: string
  membership_badge: string|null
  sponsored: boolean
  sponsored_until: string|null
}

export interface FreelancerPostInput {
  title: string
  summary: string
  description: string
  kind: FreelancerKind
  compensation: FreelancerCompensation
  areas: FreelancerArea[]
  country_code: string
  region_code: string
  portfolio_links: FreelancerLink[]
  contact_links: FreelancerLink[]
  image_url: string|null
}

export interface FreelancerFeed {
  state: 'online'|'offline'|'unavailable'|'rate_limited'|'error'|string
  message: string|null
  repository_url: string
  page: number
  has_more: boolean
  posts: FreelancerPost[]
}


export interface SupporterPublicEntry {
  github_login: string
  avatar_url: string
  tier: 'bronze'|'silver'|'gold'|string
  badge_label: string|null
  months: number
  active: boolean
}

export interface PaymentCurrencyOption {
  code: string
  market: string
  provider: string|null
  available: boolean
  checkout_enabled: boolean
  label: string
  prices_minor?: Record<string,number>
  donation_enabled?: boolean
  donation_min_minor?: number
  amount_mode?: 'arbitrary'|'product_quantity'|'unavailable'|string
  adaptive_currency?: boolean
  canonical_currency?: string
  price_source?: 'static'|string
}

export interface FreelancerReactionState {
  liked: boolean
  likes: number
}

export interface JinguMembershipProfile {
  tier: 'free'|'bronze'|'silver'|'gold'|string
  label: string
  badge_label: string|null
  active_post_limit: number
  summary_max_chars: number
  description_max_chars: number
  boost_credits_per_cycle: number
  boost_duration_days: number
  boosts_remaining: number
  sponsored_available: boolean
  credits_eligible: boolean
  credits_rank: number
  status?: string
  cycle_started_at?: string|null
  cycle_ends_at?: string|null
  lifetime?: boolean
  credits_opt_in?: boolean
  source: string
}

export interface PaymentConfig {
  enabled: boolean
  provider: 'infinitepay'|string
  market: string
  currency: string
  environment?: string
  duration_days: number
  manual_renewal: boolean
  pricing_version?: number
  allocation_mode?: string
  prices_minor: Record<string,number>
  transition_value_prices_minor?: Record<string,number>
  donation?: { enabled:boolean; min_minor:number; max_minor?:number|null }
  contribution?: { min_minor:number; max_minor?:number|null; plan_threshold_minor:number }
  tier_transition?: { mode:string; rounding:string; requires_new_purchase:boolean }
  support_max_minor?: number|null
  currencies?: PaymentCurrencyOption[]
}
export interface PaymentPricePreview {
  schema: number
  provider: string
  market: string
  tier: string
  plan_units: number
  billing_currency: string
  billing_amount_minor: number
  canonical_currency: string
  canonical_amount_minor: number
}

export interface PaymentCheckoutResult {
  checkout_url: string
  intent_id: string
  intent_expires_at: string
  provider?: string
  market?: string
  currency?: string
  billing_currency?: string
  billing_amount_minor?: number
  canonical_currency?: string
  canonical_amount_minor?: number
  purpose?: 'membership'|'donation'|string
  tier?: string
  amount_minor?: number
  base_amount_minor?: number
  support_amount_minor?: number
  pricing_version?: number
  plan_units?: number
  unit_price_minor?: number
  transition_kind?: string
  carryover_ms?: number
  projected_expires_at?: string|null
}

export interface FreelancerEntitlements extends JinguMembershipProfile {}
export interface FreelancerAccountStatus { active_posts:number; active_post_limit:number; can_create:boolean; tier:string; boosts_remaining:number }


export interface FreelancerReportInput { number: number; channel: string; reason: string; detail: string }
export interface FreelancerReportResult { issue_number: number; html_url: string }
