/// <reference types="vite/client" />

/** Build-time flavor gate. False in every public frontend bundle. */
