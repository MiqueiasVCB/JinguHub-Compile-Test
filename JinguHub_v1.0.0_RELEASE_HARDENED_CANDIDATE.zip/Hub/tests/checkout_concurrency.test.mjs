/**************************************************************************/
/*  checkout_concurrency.test.mjs                                            */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import vm from 'node:vm'
import ts from 'typescript'
const source=fs.readFileSync(new URL('../src/jingu/views/PlansView.tsx',import.meta.url),'utf8')
const code=source.slice(source.indexOf('const startCheckout=async()=>{'),source.indexOf('  const previewText='))
test('checkout coalesces clicks before config resolves and releases its guard', async()=>{
let releaseConfig
const deferred=new Promise(resolve=>releaseConfig=resolve)
let requests=0
const ctx={ checkoutChoice:{kind:'units'}, checkoutInFlight:{current:false},
 api:{paymentConfig:()=>deferred,paymentCheckoutStart:async()=>{requests++;return {checkout_url:'https://checkout.infinitepay.io/fixture',intent_id:'fixture'}}},
 setPaymentConfig(){},publicBrlCurrencies:x=>x,paymentCurrency:'BRL',unitAmount:500,selectedAllocation:{},unitCount:1,
 effectiveTier:'bronze',setWorkingTier(){},setCheckoutBrowser(){},window:{dispatchEvent(){}},CustomEvent:class {},
 notify(){},c:{},setCheckoutChoice(){},setCreditsWorking(){},onRequireGitHubLogin(){},selectedCurrency:{provider:'infinitepay'},
}
vm.createContext(ctx)
vm.runInContext(ts.transpile(code+';globalThis.startCheckout=startCheckout;', {target:ts.ScriptTarget.ES2020}),ctx)
const first=ctx.startCheckout(),second=ctx.startCheckout()
releaseConfig({currencies:[{code:'BRL',available:true,checkout_enabled:true}]})
await Promise.all([first,second])
assert.equal(requests,1)
assert.equal(ctx.checkoutInFlight.current,false)
ctx.api.paymentConfig=async()=>{throw new Error('fixture offline')}
await ctx.startCheckout()
assert.equal(ctx.checkoutInFlight.current,false)
assert.equal(requests,1)
ctx.api.paymentConfig=async()=>({currencies:[{code:'BRL',available:true,checkout_enabled:true}]})
await ctx.startCheckout()
assert.equal(requests,2)
})
