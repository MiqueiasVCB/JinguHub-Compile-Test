/**************************************************************************/
/*  frontend_domain.test.mjs                                            */
/**************************************************************************/
/*                         This file is part of:                          */
/*                              JINGU HUB                                 */
/*                        https://github.com/JinguEngine                 */
/**************************************************************************/
/* Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors. */
/* Licensed under the MIT License. See LICENSE.                            */
/**************************************************************************/
import test from 'node:test'
import assert from 'node:assert/strict'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

const root=process.cwd()
const domain=await import(`${pathToFileURL(path.join(root,'.jingu-test-out','frontend-domain','jingu','planDomain.js')).href}?v=${Date.now()}`)
const {DAY_MS,allocationsFor,currencyFractionDigits,moneyMinor,parseAmountMinor,resolveCheckoutDestination,transitionPreview,unitPrice}=domain
const currencyModule=await import(`${pathToFileURL(path.join(root,'.jingu-test-out','frontend-domain','jingu','currencyPresentation.js')).href}?v=${Date.now()}`)
const {compareCurrencyOptions,currencyPresentation,preferredCurrencyForLanguage}=currencyModule
const config={prices_minor:{bronze:500,silver:700,gold:1000},currency:'BRL'}
const now=Date.parse('2026-08-21T12:00:00Z')
const membership=(tier,days,lifetime=false)=>({tier,status:'active',cycle_started_at:new Date(now-DAY_MS).toISOString(),cycle_ends_at:new Date(now+days*DAY_MS).toISOString(),lifetime,credits_opt_in:false})

test('amount parser accepts BR formats and rejects ambiguous/unsafe values',()=>{
  assert.equal(parseAmountMinor('R$ 5,00'),500)
  assert.equal(parseAmountMinor('7'),700)
  assert.equal(parseAmountMinor('10.5'),1050)
  assert.equal(parseAmountMinor('0,01'),1)
  for(const value of ['', ' ', '-1', '+5', '1,234', '1.234,56', '1e3', 'NaN', 'Infinity']) assert.equal(parseAmountMinor(value),null,value)
  assert.equal(parseAmountMinor(String(Number.MAX_SAFE_INTEGER)),null)
})

test('money helpers respect ISO currencies with zero, two and three fraction digits',()=>{
  assert.equal(currencyFractionDigits('JPY','en-US'),0)
  assert.equal(currencyFractionDigits('USD','en-US'),2)
  assert.equal(currencyFractionDigits('KWD','en-US'),3)
  assert.equal(parseAmountMinor('443','JPY','en-US'),443)
  assert.equal(parseAmountMinor('443.1','JPY','en-US'),null)
  assert.equal(parseAmountMinor('3.00','USD','en-US'),300)
  assert.equal(parseAmountMinor('1.234','KWD','en-US'),1234)
  assert.match(moneyMinor(443,'JPY',true,'en-US'),/443/)
  assert.match(moneyMinor(1234,'KWD',true,'en-US'),/1\.234/)
})

test('allocation derives whole units and support remainder from authoritative prices',()=>{
  assert.deepEqual(allocationsFor(300,config),[])
  assert.deepEqual(allocationsFor(500,config),[{tier:'bronze',units:1,unitPrice:500,base:500,support:0}])
  assert.deepEqual(allocationsFor(1500,config),[
    {tier:'bronze',units:3,unitPrice:500,base:1500,support:0},
    {tier:'silver',units:2,unitPrice:700,base:1400,support:100},
    {tier:'gold',units:1,unitPrice:1000,base:1000,support:500},
  ])
  assert.equal(unitPrice('bronze',null),500)
  assert.equal(unitPrice('silver',null),700)
  assert.equal(unitPrice('gold',null),1000)
})

test('checkout recommendation follows amount while preserving explicit eligible choice',()=>{
  assert.equal(resolveCheckoutDestination(300,'auto',config).destination,'donation')
  assert.equal(resolveCheckoutDestination(500,'auto',config).destination,'bronze')
  assert.equal(resolveCheckoutDestination(700,'auto',config).destination,'silver')
  assert.equal(resolveCheckoutDestination(1000,'auto',config).destination,'gold')
  assert.equal(resolveCheckoutDestination(1000,'bronze',config).destination,'bronze')
  assert.equal(resolveCheckoutDestination(700,'gold',config).destination,'silver')
  assert.equal(resolveCheckoutDestination(100000,'donation',config).destination,'donation')
})

test('transition preview mirrors server value-proration semantics',()=>{
  let allocation=resolveCheckoutDestination(500,'bronze',config).selected
  assert.ok(allocation)
  let preview=transitionPreview(membership('gold',10),allocation,config,now)
  assert.equal(preview.kind,'downgrade')
  assert.equal(preview.carryMs,20*DAY_MS)
  assert.equal(preview.totalMs,51*DAY_MS)

  allocation=resolveCheckoutDestination(1000,'gold',config).selected
  assert.ok(allocation)
  preview=transitionPreview(membership('silver',90),allocation,config,now)
  assert.equal(preview.kind,'upgrade')
  assert.equal(preview.carryMs,63*DAY_MS)
  assert.equal(preview.totalMs,94*DAY_MS)

  allocation=resolveCheckoutDestination(1400,'silver',config).selected
  assert.ok(allocation)
  preview=transitionPreview(membership('silver',90),allocation,config,now)
  assert.equal(preview.kind,'extend')
  assert.equal(preview.totalMs,152*DAY_MS)
})

test('expired/free memberships start fresh and preview date remains bounded',()=>{
  const allocation=resolveCheckoutDestination(500,'bronze',config).selected
  assert.ok(allocation)
  const expired={...membership('gold',-1),cycle_ends_at:new Date(now-DAY_MS).toISOString()}
  assert.equal(transitionPreview(expired,allocation,config,now).kind,'new')
  assert.equal(transitionPreview(null,allocation,config,now).kind,'new')
})


test('public v1 currency presentation is BRL-only and uses bundled Brazil flag',()=>{
  const options=[{code:'BRL',market:'BR',provider:'infinitepay',available:true,checkout_enabled:true,label:'BRL'}]
  assert.equal(currencyPresentation(options[0],'pt-BR').origin,'Brasil')
  assert.equal(currencyPresentation(options[0],'pt-BR').flagAsset,'/currency-flags/br.png')
  assert.equal(preferredCurrencyForLanguage('pt-BR',options),'BRL')
  assert.equal(preferredCurrencyForLanguage('ja-JP',options),'BRL')
  assert.equal(compareCurrencyOptions(options[0],options[0],'pt-BR'),0)
})
