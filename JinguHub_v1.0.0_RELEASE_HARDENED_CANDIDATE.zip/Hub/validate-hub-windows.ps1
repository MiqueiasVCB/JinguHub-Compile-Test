<#
************************************************************************
validate-hub-windows.ps1
************************************************************************
This file is part of:
JINGU HUB
https://github.com/JinguEngine
************************************************************************
Copyright (c) 2026-present Miquéias Veloso and Jingu Engine contributors.
Licensed under the MIT License. See LICENSE.
************************************************************************
#>
param(
    [switch]$SkipClean,
    [switch]$SkipSmokeTest,
    [ValidateRange(0,64)][int]$CargoJobs = 0
)
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$ReleaseProfile = Get-Content -LiteralPath (Join-Path $Root 'release-profile.json') -Raw | ConvertFrom-Json
$ReleaseVersion = [string]$ReleaseProfile.version
$ReleaseChannel = [string]$ReleaseProfile.channel
if($ReleaseVersion -notmatch '^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$'){throw "release-profile.json: versao invalida: $ReleaseVersion"}
if($ReleaseChannel -notin @('stable','beta','experimental','dev')){throw "release-profile.json: canal invalido: $ReleaseChannel"}
$ReleaseLabel = "v$ReleaseVersion-$ReleaseChannel"
$Parent=Split-Path -Parent $Root
$CanonicalWorkspace=((Split-Path -Leaf $Root) -eq 'Hub') -and (Test-Path -LiteralPath (Join-Path $Parent 'Manager') -PathType Container)
$Diagnostics=if($CanonicalWorkspace){Join-Path $Parent 'Diagnostics'}else{Join-Path $Root 'Diagnostics'}
$RuntimeDiagnostics=Join-Path $Root ('.jingu-build\hub-' + $ReleaseLabel + '-runtime-diagnostics')
New-Item -ItemType Directory -Force -Path $Diagnostics,$RuntimeDiagnostics | Out-Null
$Log=Join-Path $RuntimeDiagnostics 'jingu-hub-validation.log'
$BuildLog=Join-Path $RuntimeDiagnostics 'build-hub.log'
$BundleZip=Join-Path $Diagnostics 'Hub.zip'
$Work=Join-Path $Root ('.jingu-build\hub-' + $ReleaseLabel + '-diagnostics-bundle')
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$env:CARGO_TERM_COLOR='never';$env:NO_COLOR='1';$env:FORCE_COLOR='0'

$oldJobs=$env:CARGO_BUILD_JOBS
$oldIncremental=$env:CARGO_INCREMENTAL
$oldDevDebug=$env:CARGO_PROFILE_DEV_DEBUG
$oldTestDebug=$env:CARGO_PROFILE_TEST_DEBUG
$oldDevUnits=$env:CARGO_PROFILE_DEV_CODEGEN_UNITS
$oldTestUnits=$env:CARGO_PROFILE_TEST_CODEGEN_UNITS

# Perfil de QA de baixo consumo quanto a debuginfo/incremental.
# CargoJobs=0 preserva o paralelismo nativo do Cargo (comportamento antigo).
if($CargoJobs -gt 0){$env:CARGO_BUILD_JOBS=[string]$CargoJobs}else{Remove-Item Env:CARGO_BUILD_JOBS -ErrorAction SilentlyContinue}
$env:CARGO_INCREMENTAL='0'
$env:CARGO_PROFILE_DEV_DEBUG='0'
$env:CARGO_PROFILE_TEST_DEBUG='0'
$env:CARGO_PROFILE_DEV_CODEGEN_UNITS='1'
$env:CARGO_PROFILE_TEST_CODEGEN_UNITS='1'

function Require([string]$Name){$c=Get-Command $Name -ErrorAction SilentlyContinue|Select-Object -First 1;if($null -eq $c){throw "Comando obrigatorio ausente: $Name"};if($c.Source){return $c.Source};return $Name}
function MemorySnapshot {
    try{$os=Get-CimInstance Win32_OperatingSystem -ErrorAction Stop;return ("RAM livre/total: {0}/{1} MB | Memoria virtual livre/total: {2}/{3} MB" -f [math]::Round($os.FreePhysicalMemory/1024,0),[math]::Round($os.TotalVisibleMemorySize/1024,0),[math]::Round($os.FreeVirtualMemory/1024,0),[math]::Round($os.TotalVirtualMemorySize/1024,0))}catch{return "Memoria: telemetria indisponivel"}
}
function Wait-Memory([int]$MinimumFreeVirtualMB=4096,[int]$TimeoutSeconds=90){
    $deadline=(Get-Date).AddSeconds($TimeoutSeconds)
    do{
        try{$os=Get-CimInstance Win32_OperatingSystem -ErrorAction Stop;$free=[math]::Round($os.FreeVirtualMemory/1024,0);if($free -ge $MinimumFreeVirtualMB){return};Write-Host ("[MEM] Virtual livre {0} MB; aguardando recuperacao..." -f $free) -ForegroundColor Yellow}catch{return}
        [GC]::Collect();[GC]::WaitForPendingFinalizers();Start-Sleep -Seconds 5
    }while((Get-Date) -lt $deadline)
    Add-Content $Log -Encoding UTF8 -Value ("WARN: memoria virtual abaixo de {0} MB apos espera; mantendo perfil Rust de baixo consumo." -f $MinimumFreeVirtualMB)
}
function Run([string]$Title,[string]$Exe,[string[]]$CommandArgs){
    Write-Host "`n===== $Title =====" -ForegroundColor Cyan; Add-Content $Log -Encoding UTF8 -Value "`n===== $Title =====`n> $Exe $($CommandArgs -join ' ')"
    $old=$ErrorActionPreference;$ErrorActionPreference='Continue';try{& $Exe @CommandArgs 2>&1|ForEach-Object{$line=[string]$_;Add-Content $Log -Encoding UTF8 -Value $line;if($line -match '(?i)error|fatal|failed|out of memory|STATUS_'){Write-Host $line -ForegroundColor Red}elseif($line -match '(?i)warning'){Write-Host $line -ForegroundColor Yellow}else{Write-Host $line}};$rc=$LASTEXITCODE}finally{$ErrorActionPreference=$old};Add-Content $Log -Encoding UTF8 -Value ("Exit code: {0}" -f $rc);if($rc -ne 0){throw "$Title falhou (exit $rc)."}
}
function StepSegment([string]$Title){
    if(-not(Test-Path $Log)){return ''};$lines=@(Get-Content $Log);$marker="===== $Title =====";$start=0;for($i=$lines.Count-1;$i-ge 0;$i--){if([string]$lines[$i] -eq $marker){$start=$i;break}};if($lines.Count -eq 0){return ''};return ($lines[$start..($lines.Count-1)] -join "`n")
}
function Is-MemoryFailure([string]$Title){
    $s=StepSegment $Title
    return ($s -match '(?i)rustc-LLVM ERROR:\s*out of memory|Allocation failed|0xC000012D|STATUS_COMMITMENT_LIMIT|0xC0000409|STATUS_STACK_BUFFER_OVERRUN|pagefile|paging file|not enough memory|STATUS_NO_MEMORY')
}
function Add-CargoJobsArgument([string[]]$CommandArgs,[int]$Jobs){
    if($Jobs -le 0){return @($CommandArgs)}
    $separatorIndex=[Array]::IndexOf($CommandArgs,'--')
    if($separatorIndex -ge 0){
        $before=@();if($separatorIndex -gt 0){$before=@($CommandArgs[0..($separatorIndex-1)])}
        $after=@($CommandArgs[$separatorIndex..($CommandArgs.Count-1)])
        return @($before + @('--jobs',[string]$Jobs) + $after)
    }
    return @($CommandArgs + @('--jobs',[string]$Jobs))
}
function Run-CargoSafe([string]$Title,[string[]]$CommandArgs){
    Wait-Memory
    $effectiveArgs=Add-CargoJobsArgument $CommandArgs $CargoJobs
    try{Run $Title $script:Cargo $effectiveArgs}
    catch{
        if(-not(Is-MemoryFailure $Title)){throw}
        Write-Host '[MEM] Falha de memoria/commit detectada. Limpando artefatos e repetindo uma vez em perfil serial de baixo consumo...' -ForegroundColor Yellow
        Add-Content $Log -Encoding UTF8 -Value ("Memory fallback ativado em {0}. {1}" -f $Title,(MemorySnapshot))
        Run 'Cargo clean apos falha de memoria' $script:Cargo @('clean','--manifest-path','src-tauri/Cargo.toml')
        [GC]::Collect();[GC]::WaitForPendingFinalizers();Start-Sleep -Seconds 10;Wait-Memory -MinimumFreeVirtualMB 3072 -TimeoutSeconds 120
        $env:CARGO_BUILD_JOBS='1'
        $retryArgs=Add-CargoJobsArgument $CommandArgs 1
        Run "$Title (retry low-memory)" $script:Cargo $retryArgs
    }
}
function Bundle([bool]$Ok){
    try{if(Test-Path $Work){Remove-Item $Work -Recurse -Force};New-Item -ItemType Directory -Force -Path $Work|Out-Null
        @($Log,$BuildLog,(Join-Path $RuntimeDiagnostics 'runtime-diagnostic.log'),(Join-Path $Root 'release-profile.json'),(Join-Path $Root 'SOURCE_MANIFEST.sha256'),(Join-Path $Root 'src-tauri\Cargo.lock'),(Join-Path $Root 'package-lock.json'),(Join-Path $Root 'validate-hub-windows.ps1'))|ForEach-Object{if(Test-Path $_ -PathType Leaf){Copy-Item $_ $Work -Force}}
        $summary=@(("Jingu Hub v{0} [{1}]" -f $ReleaseVersion,$ReleaseChannel),("Result="+$(if($Ok){'SUCCESS'}else{'FAILURE'})),("Generated="+(Get-Date -Format o)),"Architecture=single public binary + GitHub user-token adaptive private capabilities",(MemorySnapshot))
        Set-Content (Join-Path $Work 'SUMMARY.txt') -Encoding UTF8 -Value $summary
        $dest=$BundleZip;if(Test-Path $dest){Remove-Item $dest -Force -Confirm:$false};Compress-Archive -Path (Join-Path $Work '*') -DestinationPath $dest -CompressionLevel Optimal -Force
        Write-Host "Bundle centralizado: $dest" -ForegroundColor Yellow
    }catch{Write-Host "Falha ao criar bundle: $($_.Exception.Message)" -ForegroundColor Yellow}
}
Set-Content $Log -Encoding UTF8 -Value @(("Jingu Hub v{0} [{1}] Windows QA" -f $ReleaseVersion,$ReleaseChannel),"Root=$Root",(MemorySnapshot),("Perfil Rust QA: jobs=" + $(if($CargoJobs -gt 0){[string]$CargoJobs}else{"AUTO/native"}) + ", dev/test debug=0, codegen-units=1"),'')
$ok=$false
try{
    $python=Require 'python.exe'; if([string]::IsNullOrWhiteSpace($python)){$python=Require 'python'}
    $node=Require 'node.exe'; if([string]::IsNullOrWhiteSpace($node)){$node=Require 'node'}
    $npm=Require 'npm.cmd'; if([string]::IsNullOrWhiteSpace($npm)){$npm=Require 'npm'}
    $script:Cargo=Require 'cargo.exe'; if([string]::IsNullOrWhiteSpace($script:Cargo)){$script:Cargo=Require 'cargo'}; $cargo=$script:Cargo
    $msvcHelper=Join-Path $Root 'scripts\windows-msvc-toolchain.ps1'
    if(-not(Test-Path -LiteralPath $msvcHelper -PathType Leaf)){throw "Helper MSVC obrigatorio ausente: $msvcHelper"}
    . $msvcHelper
    $msvcInfo=Initialize-JinguWindowsMsvcToolchain
    Add-Content $Log -Encoding UTF8 -Value ("MSVC toolchain: source={0}; installation={1}" -f $msvcInfo.Source,$msvcInfo.InstallationPath)
    Push-Location $Root
    try{
        # The shipped manifest is evidence, not an output of validation. Verify it
        # before npm/Cargo can touch build outputs and never regenerate it here.
        Run '0/13 source manifest integrity' $python @('scripts/validate-source-manifest.py')
        if(-not $SkipClean){@('node_modules','dist','src-tauri\target','Exports\Unified\Windows')|ForEach-Object{$p=Join-Path $Root $_;if(Test-Path $p){Remove-Item $p -Recurse -Force}}}
        Run '1/13 npm ci' $npm @('ci','--no-audit','--no-fund')
        Run '2/13 npm audit' $npm @('audit','--audit-level=high')
        Run '3/13 i18n' $npm @('run','validate:i18n')
        Run '4/13 unified contracts' $node @('--test','tests/unified_access_contract.test.mjs')
        Run '5/13 frontend domain behavior' $npm @('run','test:frontend-domain')
        Run '6/13 frontend typecheck' $npm @('run','typecheck')
        Run '7/13 source manifest recheck' $python @('scripts/validate-source-manifest.py')
        Run '8/13 static QA' $python @('scripts/qa.py','--static')
        Run '8b/13 rustfmt check (non-mutating)' $cargo @('fmt','--all','--manifest-path','src-tauri/Cargo.toml','--','--check')
        Run-CargoSafe '9/13 cargo check' @('check','--locked','--lib','--bins','--tests','--manifest-path','src-tauri/Cargo.toml')
        Run-CargoSafe '10/13 cargo clippy' @('clippy','--locked','--lib','--bins','--tests','--manifest-path','src-tauri/Cargo.toml','--','-D','warnings')
        Run-CargoSafe '11/13 cargo test' @('test','--locked','--lib','--bins','--tests','--manifest-path','src-tauri/Cargo.toml')
        Wait-Memory -MinimumFreeVirtualMB 4096 -TimeoutSeconds 120
        $buildCargoJobs=$CargoJobs
        if($env:CARGO_BUILD_JOBS -match '^\d+$'){$buildCargoJobs=[int]$env:CARGO_BUILD_JOBS}
        & (Join-Path $Root 'build-hub-windows.ps1') -Clean:$(-not $SkipClean) -CargoJobs $buildCargoJobs -LogPath $BuildLog
        if($LASTEXITCODE -ne 0){throw "Build Hub falhou (exit $LASTEXITCODE)."}
        Run '13/13 source manifest final integrity' $python @('scripts/validate-source-manifest.py')
        if(-not $SkipSmokeTest){Run 'Runtime smoke test' 'powershell.exe' @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $Root 'run-hub-diagnostic.ps1'),'-KillExisting','-CloseAfterTest')}
        $ok=$true
    }finally{Pop-Location}
    Bundle $true
    Write-Host ("`n=== JINGU HUB - {0} v{1}: TUDO APROVADO ===" -f $ReleaseChannel.ToUpperInvariant(),$ReleaseVersion) -ForegroundColor Green
    exit 0
}catch{
    Add-Content $Log -Encoding UTF8 -Value ("`nFATAL: "+$_.Exception.Message)
    Write-Host "`n[FAIL] $($_.Exception.Message)" -ForegroundColor Red
    Bundle $false
    exit 1
}finally{
    if([string]::IsNullOrEmpty($oldJobs)){Remove-Item Env:CARGO_BUILD_JOBS -ErrorAction SilentlyContinue}else{$env:CARGO_BUILD_JOBS=$oldJobs}
    if([string]::IsNullOrEmpty($oldIncremental)){Remove-Item Env:CARGO_INCREMENTAL -ErrorAction SilentlyContinue}else{$env:CARGO_INCREMENTAL=$oldIncremental}
    if([string]::IsNullOrEmpty($oldDevDebug)){Remove-Item Env:CARGO_PROFILE_DEV_DEBUG -ErrorAction SilentlyContinue}else{$env:CARGO_PROFILE_DEV_DEBUG=$oldDevDebug}
    if([string]::IsNullOrEmpty($oldTestDebug)){Remove-Item Env:CARGO_PROFILE_TEST_DEBUG -ErrorAction SilentlyContinue}else{$env:CARGO_PROFILE_TEST_DEBUG=$oldTestDebug}
    if([string]::IsNullOrEmpty($oldDevUnits)){Remove-Item Env:CARGO_PROFILE_DEV_CODEGEN_UNITS -ErrorAction SilentlyContinue}else{$env:CARGO_PROFILE_DEV_CODEGEN_UNITS=$oldDevUnits}
    if([string]::IsNullOrEmpty($oldTestUnits)){Remove-Item Env:CARGO_PROFILE_TEST_CODEGEN_UNITS -ErrorAction SilentlyContinue}else{$env:CARGO_PROFILE_TEST_CODEGEN_UNITS=$oldTestUnits}
    foreach($generated in @($Work,$RuntimeDiagnostics)){if(Test-Path -LiteralPath $generated){Remove-Item -LiteralPath $generated -Recurse -Force -Confirm:$false -ErrorAction SilentlyContinue}}
}
